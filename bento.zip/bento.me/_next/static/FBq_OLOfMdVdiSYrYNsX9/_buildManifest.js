self.__BUILD_MANIFEST = function(s, a, e, c, t, n, i, o, h, r, l, d, b) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [{
                source: "/:nextInternalLocale(en)/home",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/home/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/main",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/main/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/launch",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/launch/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/jointheteam",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/jointheteam/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/inspo",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/inspo/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/discover",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/discover/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/inspiration",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/inspiration/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/explore",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/explore/:path*",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/_axiom/web-vitals",
                basePath: s
            }, {
                source: "/:nextInternalLocale(en)/_axiom/logs",
                basePath: s
            }],
            fallback: []
        },
        "/": [a, c, t, o, e, n, i, h, "static/chunks/pages/index-071b74bfde0da0c7.js"],
        "/_error": ["static/chunks/pages/_error-14f7aa5a56e26ccf.js"],
        "/admin": [a, r, "static/css/4679916e1da7c5bd.css", "static/chunks/pages/admin-f69983b84d1bee1a.js"],
        "/i/og/[handle]": [l, a, d, e, b, "static/css/1ff23cb7b59e795b.css", "static/chunks/pages/i/og/[handle]-792e5fcec1520009.js"],
        "/login": [a, c, t, o, e, n, i, h, "static/chunks/pages/login-492b44ce885d6ec5.js"],
        "/reset-password": [a, c, t, e, n, i, "static/chunks/pages/reset-password-88501b823aeb2626.js"],
        "/set-password": [a, c, t, e, n, i, "static/css/47675f8a2e3d839c.css", "static/chunks/pages/set-password-048c6804046628aa.js"],
        "/signup": [a, c, t, o, e, n, i, "static/css/8db1764170847697.css", "static/chunks/pages/signup-aa07e7049691db03.js"],
        "/[handle]": [l, a, c, t, d, "static/chunks/879-57353426c45ce39a.js", "static/chunks/767-2e87e299c046e2a2.js", e, b, r, "static/css/d07415fbc49591c3.css", "static/chunks/pages/[handle]-d7559d42bb16ceab.js"],
        "/[handle]/insights": [a, e, "static/css/c79f0e7900ed7f6c.css", "static/chunks/pages/[handle]/insights-7c41e7d68b696702.js"],
        sortedPages: ["/", "/_app", "/_error", "/admin", "/i/og/[handle]", "/login", "/reset-password", "/set-password", "/signup", "/[handle]", "/[handle]/insights"]
    }
}(!1, "static/chunks/736-fc525af6d7db5aa7.js", "static/chunks/891-3c855a302c7ac2d5.js", "static/chunks/25-c16969475fbc89ce.js", "static/chunks/759-75aa9d2cc73403ce.js", "static/css/79072a4c18eb25f4.css", "static/chunks/676-f5ca0008e899c86a.js", "static/chunks/97-ae84fa494e7f7c03.js", "static/chunks/936-4d462dd84f1098e1.js", "static/chunks/223-14896529b76aff22.js", "static/chunks/b155a556-2563bfd0c0314e19.js", "static/chunks/784-4b94dd6c44aa5879.js", "static/chunks/739-fc97641648d19345.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();