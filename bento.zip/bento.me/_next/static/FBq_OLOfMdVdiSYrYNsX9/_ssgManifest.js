self.__SSG_MANIFEST = new Set(["\u002F[handle]", "\u002Fi\u002Fog\u002F[handle]"]);
self.__SSG_MANIFEST_CB && self.__SSG_MANIFEST_CB()