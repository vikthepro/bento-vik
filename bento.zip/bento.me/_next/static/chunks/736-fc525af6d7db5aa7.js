"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [736], {
        6277: function(r, t, e) {
            t.Z = function() {
                for (var r, t, e = 0, n = ""; e < arguments.length;)(r = arguments[e++]) && (t = function r(t) {
                    var e, n, o = "";
                    if ("string" == typeof t || "number" == typeof t) o += t;
                    else if ("object" == typeof t) {
                        if (Array.isArray(t))
                            for (e = 0; e < t.length; e++) t[e] && (n = r(t[e])) && (o && (o += " "), o += n);
                        else
                            for (e in t) t[e] && (o && (o += " "), o += e)
                    }
                    return o
                }(r)) && (n && (n += " "), n += t);
                return n
            }
        },
        73463: function(r, t, e) {
            var n = e(48570),
                o = {
                    childContextTypes: !0,
                    contextType: !0,
                    contextTypes: !0,
                    defaultProps: !0,
                    displayName: !0,
                    getDefaultProps: !0,
                    getDerivedStateFromError: !0,
                    getDerivedStateFromProps: !0,
                    mixins: !0,
                    propTypes: !0,
                    type: !0
                },
                i = {
                    name: !0,
                    length: !0,
                    prototype: !0,
                    caller: !0,
                    callee: !0,
                    arguments: !0,
                    arity: !0
                },
                u = {
                    $$typeof: !0,
                    compare: !0,
                    defaultProps: !0,
                    displayName: !0,
                    propTypes: !0,
                    type: !0
                },
                a = {};

            function f(r) {
                return n.isMemo(r) ? u : a[r.$$typeof] || o
            }
            a[n.ForwardRef] = {
                $$typeof: !0,
                render: !0,
                defaultProps: !0,
                displayName: !0,
                propTypes: !0
            }, a[n.Memo] = u;
            var c = Object.defineProperty,
                s = Object.getOwnPropertyNames,
                l = Object.getOwnPropertySymbols,
                p = Object.getOwnPropertyDescriptor,
                y = Object.getPrototypeOf,
                v = Object.prototype;
            r.exports = function r(t, e, n) {
                if ("string" != typeof e) {
                    if (v) {
                        var o = y(e);
                        o && o !== v && r(t, o, n)
                    }
                    var u = s(e);
                    l && (u = u.concat(l(e)));
                    for (var a = f(t), d = f(e), h = 0; h < u.length; ++h) {
                        var m = u[h];
                        if (!i[m] && !(n && n[m]) && !(d && d[m]) && !(a && a[m])) {
                            var b = p(e, m);
                            try {
                                c(t, m, b)
                            } catch (r) {}
                        }
                    }
                }
                return t
            }
        },
        30235: function(r, t, e) {
            var n = this && this.__assign || function() {
                    return (n = Object.assign || function(r) {
                        for (var t, e = 1, n = arguments.length; e < n; e++)
                            for (var o in t = arguments[e]) Object.prototype.hasOwnProperty.call(t, o) && (r[o] = t[o]);
                        return r
                    }).apply(this, arguments)
                },
                o = this && this.__awaiter || function(r, t, e, n) {
                    return new(e || (e = Promise))(function(o, i) {
                        function u(r) {
                            try {
                                f(n.next(r))
                            } catch (r) {
                                i(r)
                            }
                        }

                        function a(r) {
                            try {
                                f(n.throw(r))
                            } catch (r) {
                                i(r)
                            }
                        }

                        function f(r) {
                            var t;
                            r.done ? o(r.value) : ((t = r.value) instanceof e ? t : new e(function(r) {
                                r(t)
                            })).then(u, a)
                        }
                        f((n = n.apply(r, t || [])).next())
                    })
                },
                i = this && this.__generator || function(r, t) {
                    var e, n, o, i, u = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return i = {
                        next: a(0),
                        throw: a(1),
                        return: a(2)
                    }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                        return this
                    }), i;

                    function a(i) {
                        return function(a) {
                            return function(i) {
                                if (e) throw TypeError("Generator is already executing.");
                                for (; u;) try {
                                    if (e = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, i[1])).done) return o;
                                    switch (n = 0, o && (i = [2 & i[0], o.value]), i[0]) {
                                        case 0:
                                        case 1:
                                            o = i;
                                            break;
                                        case 4:
                                            return u.label++, {
                                                value: i[1],
                                                done: !1
                                            };
                                        case 5:
                                            u.label++, n = i[1], i = [0];
                                            continue;
                                        case 7:
                                            i = u.ops.pop(), u.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = u.trys).length > 0 && o[o.length - 1]) && (6 === i[0] || 2 === i[0])) {
                                                u = 0;
                                                continue
                                            }
                                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                                u.label = i[1];
                                                break
                                            }
                                            if (6 === i[0] && u.label < o[1]) {
                                                u.label = o[1], o = i;
                                                break
                                            }
                                            if (o && u.label < o[2]) {
                                                u.label = o[2], u.ops.push(i);
                                                break
                                            }
                                            o[2] && u.ops.pop(), u.trys.pop();
                                            continue
                                    }
                                    i = t.call(r, u)
                                } catch (r) {
                                    i = [6, r], n = 0
                                } finally {
                                    e = o = 0
                                }
                                if (5 & i[0]) throw i[1];
                                return {
                                    value: i[0] ? i[1] : void 0,
                                    done: !0
                                }
                            }([i, a])
                        }
                    }
                },
                u = this && this.__rest || function(r, t) {
                    var e = {};
                    for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && 0 > t.indexOf(n) && (e[n] = r[n]);
                    if (null != r && "function" == typeof Object.getOwnPropertySymbols)
                        for (var o = 0, n = Object.getOwnPropertySymbols(r); o < n.length; o++) 0 > t.indexOf(n[o]) && Object.prototype.propertyIsEnumerable.call(r, n[o]) && (e[n[o]] = r[n[o]]);
                    return e
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.serialize = t.withSuperJSONPage = t.deserializeProps = t.withSuperJSONInitProps = t.withSuperJSONProps = void 0;
            var a = e(73463),
                f = e(2784),
                c = e(5725);

            function s(r) {
                var t = r._superjson,
                    e = u(r, ["_superjson"]);
                return c.default.deserialize({
                    json: e,
                    meta: t
                })
            }
            t.withSuperJSONProps = function(r, t) {
                return void 0 === t && (t = []),
                    function() {
                        for (var e = [], u = 0; u < arguments.length; u++) e[u] = arguments[u];
                        return o(this, void 0, void 0, function() {
                            var o, u, a, f, s, l;
                            return i(this, function(i) {
                                switch (i.label) {
                                    case 0:
                                        return [4, r.apply(void 0, e)];
                                    case 1:
                                        if (!("props" in (o = i.sent())) || !o.props) return [2, o];
                                        return u = t.map(function(r) {
                                            var t = o.props[r];
                                            return delete o.props[r], t
                                        }), f = (a = c.default.serialize(o.props)).json, s = a.meta, l = f, s && (l._superjson = s), t.forEach(function(r, t) {
                                            var e = u[t];
                                            void 0 !== e && (l[r] = e)
                                        }), [2, n(n({}, o), {
                                            props: l
                                        })]
                                }
                            })
                        })
                    }
            }, t.withSuperJSONInitProps = function(r, t) {
                return void 0 === t && (t = []),
                    function() {
                        for (var e = [], u = 0; u < arguments.length; u++) e[u] = arguments[u];
                        return o(this, void 0, void 0, function() {
                            var o, u, a, f, s, l;
                            return i(this, function(i) {
                                switch (i.label) {
                                    case 0:
                                        return [4, r.apply(void 0, e)];
                                    case 1:
                                        return o = i.sent(), u = t.map(function(r) {
                                            var t = o[r];
                                            return delete o[r], t
                                        }), f = (a = c.default.serialize(o)).json, s = a.meta, l = f, s && (l._superjson = s), t.forEach(function(r, t) {
                                            var e = u[t];
                                            void 0 !== e && (l[r] = e)
                                        }), [2, n(n({}, o), l)]
                                }
                            })
                        })
                    }
            }, t.deserializeProps = s, t.withSuperJSONPage = function(r) {
                function t(t) {
                    return f.createElement(r, n({}, s(t)))
                }
                return a(t, r), t
            }, t.serialize = function(r) {
                var t = c.default.serialize(r),
                    e = t.json,
                    o = t.meta;
                return n(n({}, e), {
                    _superjson: o
                })
            }
        },
        66866: function(r, t) {
            /** @license React v16.13.1
             * react-is.production.min.js
             *
             * Copyright (c) Facebook, Inc. and its affiliates.
             *
             * This source code is licensed under the MIT license found in the
             * LICENSE file in the root directory of this source tree.
             */
            var e = "function" == typeof Symbol && Symbol.for,
                n = e ? Symbol.for("react.element") : 60103,
                o = e ? Symbol.for("react.portal") : 60106,
                i = e ? Symbol.for("react.fragment") : 60107,
                u = e ? Symbol.for("react.strict_mode") : 60108,
                a = e ? Symbol.for("react.profiler") : 60114,
                f = e ? Symbol.for("react.provider") : 60109,
                c = e ? Symbol.for("react.context") : 60110,
                s = e ? Symbol.for("react.async_mode") : 60111,
                l = e ? Symbol.for("react.concurrent_mode") : 60111,
                p = e ? Symbol.for("react.forward_ref") : 60112,
                y = e ? Symbol.for("react.suspense") : 60113,
                v = e ? Symbol.for("react.suspense_list") : 60120,
                d = e ? Symbol.for("react.memo") : 60115,
                h = e ? Symbol.for("react.lazy") : 60116,
                m = e ? Symbol.for("react.block") : 60121,
                b = e ? Symbol.for("react.fundamental") : 60117,
                g = e ? Symbol.for("react.responder") : 60118,
                w = e ? Symbol.for("react.scope") : 60119;

            function O(r) {
                if ("object" == typeof r && null !== r) {
                    var t = r.$$typeof;
                    switch (t) {
                        case n:
                            switch (r = r.type) {
                                case s:
                                case l:
                                case i:
                                case a:
                                case u:
                                case y:
                                    return r;
                                default:
                                    switch (r = r && r.$$typeof) {
                                        case c:
                                        case p:
                                        case h:
                                        case d:
                                        case f:
                                            return r;
                                        default:
                                            return t
                                    }
                            }
                        case o:
                            return t
                    }
                }
            }

            function S(r) {
                return O(r) === l
            }
            t.AsyncMode = s, t.ConcurrentMode = l, t.ContextConsumer = c, t.ContextProvider = f, t.Element = n, t.ForwardRef = p, t.Fragment = i, t.Lazy = h, t.Memo = d, t.Portal = o, t.Profiler = a, t.StrictMode = u, t.Suspense = y, t.isAsyncMode = function(r) {
                return S(r) || O(r) === s
            }, t.isConcurrentMode = S, t.isContextConsumer = function(r) {
                return O(r) === c
            }, t.isContextProvider = function(r) {
                return O(r) === f
            }, t.isElement = function(r) {
                return "object" == typeof r && null !== r && r.$$typeof === n
            }, t.isForwardRef = function(r) {
                return O(r) === p
            }, t.isFragment = function(r) {
                return O(r) === i
            }, t.isLazy = function(r) {
                return O(r) === h
            }, t.isMemo = function(r) {
                return O(r) === d
            }, t.isPortal = function(r) {
                return O(r) === o
            }, t.isProfiler = function(r) {
                return O(r) === a
            }, t.isStrictMode = function(r) {
                return O(r) === u
            }, t.isSuspense = function(r) {
                return O(r) === y
            }, t.isValidElementType = function(r) {
                return "string" == typeof r || "function" == typeof r || r === i || r === l || r === a || r === u || r === y || r === v || "object" == typeof r && null !== r && (r.$$typeof === h || r.$$typeof === d || r.$$typeof === f || r.$$typeof === c || r.$$typeof === p || r.$$typeof === b || r.$$typeof === g || r.$$typeof === w || r.$$typeof === m)
            }, t.typeOf = O
        },
        48570: function(r, t, e) {
            r.exports = e(66866)
        },
        5725: function(r, t, e) {
            e.r(t), e.d(t, {
                default: function() {
                    return rc
                },
                deserialize: function() {
                    return rn
                },
                parse: function() {
                    return ri
                },
                registerClass: function() {
                    return ru
                },
                registerCustom: function() {
                    return rf
                },
                registerSymbol: function() {
                    return ra
                },
                serialize: function() {
                    return re
                },
                stringify: function() {
                    return ro
                }
            });
            var n, o = function() {
                    function r() {
                        this.keyToValue = new Map, this.valueToKey = new Map
                    }
                    return r.prototype.set = function(r, t) {
                        this.keyToValue.set(r, t), this.valueToKey.set(t, r)
                    }, r.prototype.getByKey = function(r) {
                        return this.keyToValue.get(r)
                    }, r.prototype.getByValue = function(r) {
                        return this.valueToKey.get(r)
                    }, r.prototype.clear = function() {
                        this.keyToValue.clear(), this.valueToKey.clear()
                    }, r
                }(),
                i = function() {
                    function r(r) {
                        this.generateIdentifier = r, this.kv = new o
                    }
                    return r.prototype.register = function(r, t) {
                        this.kv.getByValue(r) || (t || (t = this.generateIdentifier(r)), this.kv.set(t, r))
                    }, r.prototype.clear = function() {
                        this.kv.clear()
                    }, r.prototype.getIdentifier = function(r) {
                        return this.kv.getByValue(r)
                    }, r.prototype.getValue = function(r) {
                        return this.kv.getByKey(r)
                    }, r
                }(),
                u = (n = function(r, t) {
                    return (n = Object.setPrototypeOf || ({
                        __proto__: []
                    }) instanceof Array && function(r, t) {
                        r.__proto__ = t
                    } || function(r, t) {
                        for (var e in t) Object.prototype.hasOwnProperty.call(t, e) && (r[e] = t[e])
                    })(r, t)
                }, function(r, t) {
                    if ("function" != typeof t && null !== t) throw TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function e() {
                        this.constructor = r
                    }
                    n(r, t), r.prototype = null === t ? Object.create(t) : (e.prototype = t.prototype, new e)
                }),
                a = new(function(r) {
                    function t() {
                        var t = r.call(this, function(r) {
                            return r.name
                        }) || this;
                        return t.classToAllowedProps = new Map, t
                    }
                    return u(t, r), t.prototype.register = function(t, e) {
                        "object" == typeof e ? (e.allowProps && this.classToAllowedProps.set(t, e.allowProps), r.prototype.register.call(this, t, e.identifier)) : r.prototype.register.call(this, t, e)
                    }, t.prototype.getAllowedProps = function(r) {
                        return this.classToAllowedProps.get(r)
                    }, t
                }(i)),
                f = new i(function(r) {
                    var t;
                    return null !== (t = r.description) && void 0 !== t ? t : ""
                }),
                c = function(r, t) {
                    var e = "function" == typeof Symbol && r[Symbol.iterator];
                    if (!e) return r;
                    var n, o, i = e.call(r),
                        u = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) u.push(n.value)
                    } catch (r) {
                        o = {
                            error: r
                        }
                    } finally {
                        try {
                            n && !n.done && (e = i.return) && e.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return u
                };

            function s(r, t) {
                Object.entries(r).forEach(function(r) {
                    var e = c(r, 2),
                        n = e[0];
                    return t(e[1], n)
                })
            }

            function l(r, t) {
                return -1 !== r.indexOf(t)
            }

            function p(r, t) {
                for (var e = 0; e < r.length; e++) {
                    var n = r[e];
                    if (t(n)) return n
                }
            }
            var y = {},
                v = {
                    register: function(r) {
                        y[r.name] = r
                    },
                    findApplicable: function(r) {
                        return function(r, t) {
                            var e = function(r) {
                                if ("values" in Object) return Object.values(r);
                                var t = [];
                                for (var e in r) r.hasOwnProperty(e) && t.push(r[e]);
                                return t
                            }(r);
                            if ("find" in e) return e.find(t);
                            for (var n = 0; n < e.length; n++) {
                                var o = e[n];
                                if (t(o)) return o
                            }
                        }(y, function(t) {
                            return t.isApplicable(r)
                        })
                    },
                    findByName: function(r) {
                        return y[r]
                    }
                },
                d = function(r, t) {
                    var e = "function" == typeof Symbol && r[Symbol.iterator];
                    if (!e) return r;
                    var n, o, i = e.call(r),
                        u = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) u.push(n.value)
                    } catch (r) {
                        o = {
                            error: r
                        }
                    } finally {
                        try {
                            n && !n.done && (e = i.return) && e.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return u
                },
                h = function(r, t) {
                    for (var e = 0, n = t.length, o = r.length; e < n; e++, o++) r[o] = t[e];
                    return r
                },
                m = [],
                b = function(r) {
                    return Object.prototype.toString.call(r).slice(8, -1)
                },
                g = function(r) {
                    return void 0 === r
                },
                w = function(r) {
                    return "Object" === b(r) && (null === Object.getPrototypeOf(r) || r !== Object.prototype && r.constructor === Object && Object.getPrototypeOf(r) === Object.prototype)
                },
                O = function(r) {
                    return w(r) && 0 === Object.keys(r).length
                },
                S = function(r) {
                    return Array.isArray(r)
                },
                j = function(r) {
                    return r instanceof Map
                },
                P = function(r) {
                    return r instanceof Set
                },
                E = function(r) {
                    return "Symbol" === b(r)
                },
                _ = function(r) {
                    return "number" == typeof r && isNaN(r)
                },
                k = function(r) {
                    return "boolean" == typeof r || null === r || g(r) || "number" == typeof r && !isNaN(r) || "string" == typeof r || E(r)
                },
                A = function(r) {
                    return r.replace(/\./g, "\\.")
                },
                x = function(r) {
                    return r.map(String).map(A).join(".")
                },
                $ = function(r) {
                    for (var t = [], e = "", n = 0; n < r.length; n++) {
                        var o = r.charAt(n);
                        if ("\\" === o && "." === r.charAt(n + 1)) {
                            e += ".", n++;
                            continue
                        }
                        if ("." === o) {
                            t.push(e), e = "";
                            continue
                        }
                        e += o
                    }
                    var i = e;
                    return t.push(i), t
                },
                N = function() {
                    return (N = Object.assign || function(r) {
                        for (var t, e = 1, n = arguments.length; e < n; e++)
                            for (var o in t = arguments[e]) Object.prototype.hasOwnProperty.call(t, o) && (r[o] = t[o]);
                        return r
                    }).apply(this, arguments)
                },
                T = function(r, t) {
                    var e = "function" == typeof Symbol && r[Symbol.iterator];
                    if (!e) return r;
                    var n, o, i = e.call(r),
                        u = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) u.push(n.value)
                    } catch (r) {
                        o = {
                            error: r
                        }
                    } finally {
                        try {
                            n && !n.done && (e = i.return) && e.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return u
                },
                z = function(r, t) {
                    for (var e = 0, n = t.length, o = r.length; e < n; e++, o++) r[o] = t[e];
                    return r
                };

            function I(r, t, e, n) {
                return {
                    isApplicable: r,
                    annotation: t,
                    transform: e,
                    untransform: n
                }
            }
            var V = [I(g, "undefined", function() {
                return null
            }, function() {}), I(function(r) {
                return "bigint" == typeof r
            }, "bigint", function(r) {
                return r.toString()
            }, function(r) {
                return "undefined" != typeof BigInt ? BigInt(r) : (console.error("Please add a BigInt polyfill."), r)
            }), I(function(r) {
                return r instanceof Date && !isNaN(r.valueOf())
            }, "Date", function(r) {
                return r.toISOString()
            }, function(r) {
                return new Date(r)
            }), I(function(r) {
                return r instanceof Error
            }, "Error", function(r) {
                var t = {
                    name: r.name,
                    message: r.message
                };
                return m.forEach(function(e) {
                    t[e] = r[e]
                }), t
            }, function(r) {
                var t = Error(r.message);
                return t.name = r.name, t.stack = r.stack, m.forEach(function(e) {
                    t[e] = r[e]
                }), t
            }), I(function(r) {
                return r instanceof RegExp
            }, "regexp", function(r) {
                return "" + r
            }, function(r) {
                return RegExp(r.slice(1, r.lastIndexOf("/")), r.slice(r.lastIndexOf("/") + 1))
            }), I(P, "set", function(r) {
                return z([], T(r.values()))
            }, function(r) {
                return new Set(r)
            }), I(j, "map", function(r) {
                return z([], T(r.entries()))
            }, function(r) {
                return new Map(r)
            }), I(function(r) {
                var t;
                return _(r) || (t = r) === 1 / 0 || t === -1 / 0
            }, "number", function(r) {
                return _(r) ? "NaN" : r > 0 ? "Infinity" : "-Infinity"
            }, Number), I(function(r) {
                return 0 === r && 1 / r == -1 / 0
            }, "number", function() {
                return "-0"
            }, Number)];

            function C(r, t, e, n) {
                return {
                    isApplicable: r,
                    annotation: t,
                    transform: e,
                    untransform: n
                }
            }
            var M = C(function(r) {
                    return !!E(r) && !!f.getIdentifier(r)
                }, function(r) {
                    return ["symbol", f.getIdentifier(r)]
                }, function(r) {
                    return r.description
                }, function(r, t) {
                    var e = f.getValue(t[1]);
                    if (!e) throw Error("Trying to deserialize unknown symbol");
                    return e
                }),
                B = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array, Uint8ClampedArray].reduce(function(r, t) {
                    return r[t.name] = t, r
                }, {}),
                F = C(function(r) {
                    return ArrayBuffer.isView(r) && !(r instanceof DataView)
                }, function(r) {
                    return ["typed-array", r.constructor.name]
                }, function(r) {
                    return z([], T(r))
                }, function(r, t) {
                    var e = B[t[1]];
                    if (!e) throw Error("Trying to deserialize unknown typed array");
                    return new e(r)
                });

            function D(r) {
                return null != r && !!r.constructor && !!a.getIdentifier(r.constructor)
            }
            var J = C(D, function(r) {
                    return ["class", a.getIdentifier(r.constructor)]
                }, function(r) {
                    var t = a.getAllowedProps(r.constructor);
                    if (!t) return N({}, r);
                    var e = {};
                    return t.forEach(function(t) {
                        e[t] = r[t]
                    }), e
                }, function(r, t) {
                    var e = a.getValue(t[1]);
                    if (!e) throw Error("Trying to deserialize unknown class - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564");
                    return Object.assign(Object.create(e.prototype), r)
                }),
                K = C(function(r) {
                    return !!v.findApplicable(r)
                }, function(r) {
                    return ["custom", v.findApplicable(r).name]
                }, function(r) {
                    return v.findApplicable(r).serialize(r)
                }, function(r, t) {
                    var e = v.findByName(t[1]);
                    if (!e) throw Error("Trying to deserialize unknown custom value");
                    return e.deserialize(r)
                }),
                U = [J, M, K, F],
                R = function(r) {
                    var t = p(U, function(t) {
                        return t.isApplicable(r)
                    });
                    if (t) return {
                        value: t.transform(r),
                        type: t.annotation(r)
                    };
                    var e = p(V, function(t) {
                        return t.isApplicable(r)
                    });
                    if (e) return {
                        value: e.transform(r),
                        type: e.annotation
                    }
                },
                q = {};
            V.forEach(function(r) {
                q[r.annotation] = r
            });
            var L = function(r, t) {
                    if (S(t)) switch (t[0]) {
                        case "symbol":
                            return M.untransform(r, t);
                        case "class":
                            return J.untransform(r, t);
                        case "custom":
                            return K.untransform(r, t);
                        case "typed-array":
                            return F.untransform(r, t);
                        default:
                            throw Error("Unknown transformation: " + t)
                    } else {
                        var e = q[t];
                        if (!e) throw Error("Unknown transformation: " + t);
                        return e.untransform(r)
                    }
                },
                G = function(r, t) {
                    for (var e = r.keys(); t > 0;) e.next(), t--;
                    return e.next().value
                };

            function Z(r) {
                if (l(r, "__proto__")) throw Error("__proto__ is not allowed as a property");
                if (l(r, "prototype")) throw Error("prototype is not allowed as a property");
                if (l(r, "constructor")) throw Error("constructor is not allowed as a property")
            }
            var H = function(r, t, e) {
                    if (Z(t), 0 === t.length) return e(r);
                    for (var n = r, o = 0; o < t.length - 1; o++) {
                        var i = t[o];
                        if (S(n)) n = n[+i];
                        else if (w(n)) n = n[i];
                        else if (P(n)) {
                            var u = +i;
                            n = G(n, u)
                        } else if (j(n)) {
                            if (o === t.length - 2) break;
                            var u = +i,
                                a = 0 == +t[++o] ? "key" : "value",
                                f = G(n, u);
                            switch (a) {
                                case "key":
                                    n = f;
                                    break;
                                case "value":
                                    n = n.get(f)
                            }
                        }
                    }
                    var c = t[t.length - 1];
                    if ((S(n) || w(n)) && (n[c] = e(n[c])), P(n)) {
                        var s = G(n, +c),
                            l = e(s);
                        s !== l && (n.delete(s), n.add(l))
                    }
                    if (j(n)) {
                        var u = +t[t.length - 2],
                            p = G(n, u),
                            a = 0 == +c ? "key" : "value";
                        switch (a) {
                            case "key":
                                var y = e(p);
                                n.set(y, n.get(p)), y !== p && n.delete(p);
                                break;
                            case "value":
                                n.set(p, e(n.get(p)))
                        }
                    }
                    return r
                },
                Q = function(r, t) {
                    var e = "function" == typeof Symbol && r[Symbol.iterator];
                    if (!e) return r;
                    var n, o, i = e.call(r),
                        u = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) u.push(n.value)
                    } catch (r) {
                        o = {
                            error: r
                        }
                    } finally {
                        try {
                            n && !n.done && (e = i.return) && e.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return u
                },
                W = function(r, t) {
                    for (var e = 0, n = t.length, o = r.length; e < n; e++, o++) r[o] = t[e];
                    return r
                },
                X = function(r, t, e, n) {
                    if (void 0 === e && (e = []), void 0 === n && (n = []), k(r) || (o = r, i = e, (a = (u = t).get(o)) ? a.push(i) : u.set(o, [i])), !(w(r) || S(r) || j(r) || P(r) || D(r))) {
                        var o, i, u, a, f, c = R(r);
                        return c ? {
                            transformedValue: c.value,
                            annotations: [c.type]
                        } : {
                            transformedValue: r
                        }
                    }
                    if (l(n, r)) return {
                        transformedValue: null
                    };
                    var p = R(r),
                        y = null !== (f = null == p ? void 0 : p.value) && void 0 !== f ? f : r;
                    k(r) || (n = W(W([], Q(n)), [r]));
                    var v = S(y) ? [] : {},
                        d = {};
                    return (s(y, function(r, o) {
                        var i = X(r, t, W(W([], Q(e)), [o]), n);
                        v[o] = i.transformedValue, S(i.annotations) ? d[o] = i.annotations : w(i.annotations) && s(i.annotations, function(r, t) {
                            d[A(o) + "." + t] = r
                        })
                    }), O(d)) ? {
                        transformedValue: v,
                        annotations: p ? [p.type] : void 0
                    } : {
                        transformedValue: v,
                        annotations: p ? [p.type, d] : d
                    }
                };

            function Y(r) {
                return Object.prototype.toString.call(r).slice(8, -1)
            }

            function rr(r) {
                return "Array" === Y(r)
            }
            var rt = function() {
                    return (rt = Object.assign || function(r) {
                        for (var t, e = 1, n = arguments.length; e < n; e++)
                            for (var o in t = arguments[e]) Object.prototype.hasOwnProperty.call(t, o) && (r[o] = t[o]);
                        return r
                    }).apply(this, arguments)
                },
                re = function(r) {
                    var t, e, n = new Map,
                        o = X(r, n),
                        i = {
                            json: o.transformedValue
                        };
                    o.annotations && (i.meta = rt(rt({}, i.meta), {
                        values: o.annotations
                    }));
                    var u = (t = {}, e = void 0, (n.forEach(function(r) {
                        if (!(r.length <= 1)) {
                            var n = Q(r.map(function(r) {
                                    return r.map(String)
                                }).sort(function(r, t) {
                                    return r.length - t.length
                                })),
                                o = n[0],
                                i = n.slice(1);
                            0 === o.length ? e = i.map(x) : t[x(o)] = i.map(x)
                        }
                    }), e) ? O(t) ? [e] : [e, t] : O(t) ? void 0 : t);
                    return u && (i.meta = rt(rt({}, i.meta), {
                        referentialEqualities: u
                    })), i
                },
                rn = function(r) {
                    var t, e = r.json,
                        n = r.meta,
                        o = function r(t, e = {}) {
                            if (rr(t)) return t.map(t => r(t, e));
                            if (! function(r) {
                                    if ("Object" !== Y(r)) return !1;
                                    let t = Object.getPrototypeOf(r);
                                    return t.constructor === Object && t === Object.prototype
                                }(t)) return t;
                            let n = Object.getOwnPropertyNames(t),
                                o = Object.getOwnPropertySymbols(t);
                            return [...n, ...o].reduce((n, o) => {
                                if (rr(e.props) && !e.props.includes(o)) return n;
                                let i = t[o],
                                    u = r(i, e);
                                return ! function(r, t, e, n, o) {
                                    let i = ({}).propertyIsEnumerable.call(n, t) ? "enumerable" : "nonenumerable";
                                    "enumerable" === i && (r[t] = e), o && "nonenumerable" === i && Object.defineProperty(r, t, {
                                        value: e,
                                        enumerable: !1,
                                        writable: !0,
                                        configurable: !0
                                    })
                                }(n, o, u, t, e.nonenumerable), n
                            }, {})
                        }(e);
                    return (null == n ? void 0 : n.values) && (t = o, function r(t, e, n) {
                        if (void 0 === n && (n = []), t) {
                            if (!S(t)) {
                                s(t, function(t, o) {
                                    return r(t, e, W(W([], Q(n)), Q($(o))))
                                });
                                return
                            }
                            var o = Q(t, 2),
                                i = o[0],
                                u = o[1];
                            u && s(u, function(t, o) {
                                r(t, e, W(W([], Q(n)), Q($(o))))
                            }), e(i, n)
                        }
                    }(n.values, function(r, e) {
                        t = H(t, e, function(t) {
                            return L(t, r)
                        })
                    }), o = t), (null == n ? void 0 : n.referentialEqualities) && (o = function(r, t) {
                        function e(t, e) {
                            var n, o, i = (n = r, Z(o = $(e)), o.forEach(function(r) {
                                n = n[r]
                            }), n);
                            t.map($).forEach(function(t) {
                                r = H(r, t, function() {
                                    return i
                                })
                            })
                        }
                        if (S(t)) {
                            var n = Q(t, 2),
                                o = n[0],
                                i = n[1];
                            o.forEach(function(t) {
                                r = H(r, $(t), function() {
                                    return r
                                })
                            }), i && s(i, e)
                        } else s(t, e);
                        return r
                    }(o, n.referentialEqualities)), o
                },
                ro = function(r) {
                    return JSON.stringify(re(r))
                },
                ri = function(r) {
                    return rn(JSON.parse(r))
                },
                ru = function(r, t) {
                    return a.register(r, t)
                },
                ra = function(r, t) {
                    return f.register(r, t)
                },
                rf = function(r, t) {
                    return v.register(rt({
                        name: t
                    }, r))
                },
                rc = {
                    stringify: ro,
                    parse: ri,
                    serialize: re,
                    deserialize: rn,
                    registerClass: ru,
                    registerSymbol: ra,
                    registerCustom: rf,
                    allowErrorProps: function() {
                        for (var r = [], t = 0; t < arguments.length; t++) r[t] = arguments[t];
                        m.push.apply(m, h([], d(r)))
                    }
                }
        }
    }
]);