(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [784], {
        13536: function(t, e, n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            let {
                Decimal: r,
                objectEnumValues: i,
                makeStrictEnum: o,
                Public: s
            } = n(70714), a = {};
            e.Prisma = a, a.prismaVersion = {
                client: "4.16.2",
                engine: "4bc8b6e1b66cb932731fb1bdbbc550d1e010de81"
            }, a.PrismaClientKnownRequestError = () => {
                throw Error(`PrismaClientKnownRequestError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.PrismaClientUnknownRequestError = () => {
                throw Error(`PrismaClientUnknownRequestError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.PrismaClientRustPanicError = () => {
                throw Error(`PrismaClientRustPanicError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.PrismaClientInitializationError = () => {
                throw Error(`PrismaClientInitializationError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.PrismaClientValidationError = () => {
                throw Error(`PrismaClientValidationError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.NotFoundError = () => {
                throw Error(`NotFoundError is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.Decimal = r, a.sql = () => {
                throw Error(`sqltag is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.empty = () => {
                throw Error(`empty is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.join = () => {
                throw Error(`join is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.raw = () => {
                throw Error(`raw is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.validator = s.validator, a.getExtensionContext = () => {
                throw Error(`Extensions.getExtensionContext is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.defineExtension = () => {
                throw Error(`Extensions.defineExtension is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
            }, a.DbNull = i.instances.DbNull, a.JsonNull = i.instances.JsonNull, a.AnyNull = i.instances.AnyNull, a.NullTypes = {
                DbNull: i.classes.DbNull,
                JsonNull: i.classes.JsonNull,
                AnyNull: i.classes.AnyNull
            }, e.Prisma.TransactionIsolationLevel = o({
                ReadUncommitted: "ReadUncommitted",
                ReadCommitted: "ReadCommitted",
                RepeatableRead: "RepeatableRead",
                Serializable: "Serializable"
            }), e.Prisma.AccountScalarFieldEnum = {
                id: "id",
                userId: "userId",
                type: "type",
                provider: "provider",
                providerAccountId: "providerAccountId",
                refresh_token: "refresh_token",
                access_token: "access_token",
                expires_at: "expires_at",
                token_type: "token_type",
                scope: "scope",
                id_token: "id_token",
                session_state: "session_state",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.SessionScalarFieldEnum = {
                id: "id",
                sessionToken: "sessionToken",
                userId: "userId",
                expires: "expires",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.UserScalarFieldEnum = {
                id: "id",
                handle: "handle",
                name: "name",
                bio: "bio",
                bento: "bento",
                password: "password",
                email: "email",
                emailVerified: "emailVerified",
                image: "image",
                onboarded: "onboarded",
                inviteCodeId: "inviteCodeId",
                admin: "admin",
                ogImage: "ogImage",
                passwordResetToken: "passwordResetToken",
                passwordResetTokenExpiry: "passwordResetTokenExpiry",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.HandleChangelogScalarFieldEnum = {
                id: "id",
                handle: "handle",
                userId: "userId",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.VerificationTokenScalarFieldEnum = {
                identifier: "identifier",
                token: "token",
                expires: "expires"
            }, e.Prisma.MediaScalarFieldEnum = {
                id: "id",
                fileName: "fileName",
                originalFileName: "originalFileName",
                url: "url",
                path: "path",
                bytes: "bytes",
                mimetype: "mimetype",
                boundToId: "boundToId",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.UrlMetaDataScalarFieldEnum = {
                url: "url",
                title: "title",
                description: "description",
                siteName: "siteName",
                siteVideoUrl: "siteVideoUrl",
                imageUrl: "imageUrl",
                audioUrl: "audioUrl",
                videoUrl: "videoUrl",
                faviconUrl: "faviconUrl",
                touchIconUrl: "touchIconUrl",
                screenshotUrl: "screenshotUrl",
                status: "status",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.UrlRichDataScalarFieldEnum = {
                url: "url",
                data: "data",
                status: "status",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.InviteCodeScalarFieldEnum = {
                code: "code",
                maxRedemptions: "maxRedemptions",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.EmailStatusesScalarFieldEnum = {
                email: "email",
                status: "status",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.AnalyticsCacheScalarFieldEnum = {
                bentoId: "bentoId",
                data: "data",
                variant: "variant",
                createdAt: "createdAt",
                updatedAt: "updatedAt"
            }, e.Prisma.SortOrder = {
                asc: "asc",
                desc: "desc"
            }, e.Prisma.NullableJsonNullValueInput = {
                DbNull: a.DbNull,
                JsonNull: a.JsonNull
            }, e.Prisma.JsonNullValueInput = {
                JsonNull: a.JsonNull
            }, e.Prisma.QueryMode = {
                default: "default",
                insensitive: "insensitive"
            }, e.Prisma.NullsOrder = {
                first: "first",
                last: "last"
            }, e.Prisma.JsonNullValueFilter = {
                DbNull: a.DbNull,
                JsonNull: a.JsonNull,
                AnyNull: a.AnyNull
            }, e.EFetchStatus = {
                FETCHING: "FETCHING",
                FAILED: "FAILED",
                REFRESHING: "REFRESHING",
                COMPLETED: "COMPLETED"
            }, e.EAnalyticsVariant = {
                YESTERDAY: "YESTERDAY"
            }, e.Prisma.ModelName = {
                Account: "Account",
                Session: "Session",
                User: "User",
                HandleChangelog: "HandleChangelog",
                VerificationToken: "VerificationToken",
                Media: "Media",
                UrlMetaData: "UrlMetaData",
                UrlRichData: "UrlRichData",
                InviteCode: "InviteCode",
                EmailStatuses: "EmailStatuses",
                AnalyticsCache: "AnalyticsCache"
            }, e.PrismaClient = class {
                constructor() {
                    throw Error(`PrismaClient is unable to be run in the browser.
In case this error is unexpected for you, please report it in https://github.com/prisma/prisma/issues`)
                }
            }, Object.assign(e, a)
        },
        60696: function(t, e, n) {
            let r = n(13536);
            t.exports = r
        },
        70714: function(t) {
            "use strict";
            var e, n, r = Object.defineProperty,
                i = Object.getOwnPropertyDescriptor,
                o = Object.getOwnPropertyNames,
                s = Object.prototype.hasOwnProperty,
                a = (t, e) => {
                    for (var n in e) r(t, n, {
                        get: e[n],
                        enumerable: !0
                    })
                },
                l = {};
            a(l, {
                Decimal: () => tQ,
                Public: () => c,
                makeStrictEnum: () => x,
                objectEnumValues: () => v
            }), t.exports = ((t, e, n, a) => {
                if (e && "object" == typeof e || "function" == typeof e)
                    for (let n of o(e)) s.call(t, n) || void 0 === n || r(t, n, {
                        get: () => e[n],
                        enumerable: !(a = i(e, n)) || a.enumerable
                    });
                return t
            })(r({}, "__esModule", {
                value: !0
            }), l);
            var c = {};

            function u(...t) {
                return t => t
            }
            a(c, {
                validator: () => u
            });
            var h = Symbol(),
                p = new WeakMap,
                d = class {
                    constructor(t) {
                        t === h ? p.set(this, `Prisma.${this._getName()}`) : p.set(this, `new Prisma.${this._getNamespace()}.${this._getName()}()`)
                    }
                    _getName() {
                        return this.constructor.name
                    }
                    toString() {
                        return p.get(this)
                    }
                },
                f = class extends d {
                    _getNamespace() {
                        return "NullTypes"
                    }
                },
                m = class extends f {};
            w(m, "DbNull");
            var g = class extends f {};
            w(g, "JsonNull");
            var y = class extends f {};
            w(y, "AnyNull");
            var v = {
                classes: {
                    DbNull: m,
                    JsonNull: g,
                    AnyNull: y
                },
                instances: {
                    DbNull: new m(h),
                    JsonNull: new g(h),
                    AnyNull: new y(h)
                }
            };

            function w(t, e) {
                Object.defineProperty(t, "name", {
                    value: e,
                    configurable: !0
                })
            }
            var b = new Set(["toJSON", "$$typeof", "asymmetricMatch", Symbol.iterator, Symbol.toStringTag, Symbol.isConcatSpreadable, Symbol.toPrimitive]);

            function x(t) {
                return new Proxy(t, {
                    get(t, e) {
                        if (e in t) return t[e];
                        if (!b.has(e)) throw TypeError(`Invalid enum value: ${String(e)}`)
                    }
                })
            }
            var k = "0123456789abcdef",
                S = "2.3025850929940456840179914546843642076011014886287729760333279009675726096773524802359972050895982983419677840422862486334095254650828067566662873690987816894829072083255546808437998948262331985283935053089653777326288461633662222876982198867465436674744042432743651550489343149393914796194044002221051017141748003688084012647080685567743216228355220114804663715659121373450747856947683463616792101806445070648000277502684916746550586856935673420670581136429224554405758925724208241314695689016758940256776311356919292033376587141660230105703089634572075440370847469940168269282808481184289314848524948644871927809676271275775397027668605952496716674183485704422507197965004714951050492214776567636938662976979522110718264549734772662425709429322582798502585509785265383207606726317164309505995087807523710333101197857547331541421808427543863591778117054309827482385045648019095610299291824318237525357709750539565187697510374970888692180205189339507238539205144634197265287286965110862571492198849978748873771345686209167058",
                M = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491298336733624406566430860213949463952247371907021798609437027705392171762931767523846748184676694051320005681271452635608277857713427577896091736371787214684409012249534301465495853710507922796892589235420199561121290219608640344181598136297747713099605187072113499999983729780499510597317328160963185950244594553469083026425223082533446850352619311881710100031378387528865875332083814206171776691473035982534904287554687311595628638823537875937519577818577805321712268066130019278766111959092164201989380952572010654858632789",
                C = {
                    precision: 20,
                    rounding: 4,
                    modulo: 1,
                    toExpNeg: -7,
                    toExpPos: 21,
                    minE: -9e15,
                    maxE: 9e15,
                    crypto: !1
                },
                E = !0,
                N = "[DecimalError] ",
                O = N + "Invalid argument: ",
                A = N + "Precision limit exceeded",
                T = N + "crypto unavailable",
                I = "[object Decimal]",
                R = Math.floor,
                _ = Math.pow,
                $ = /^0b([01]+(\.[01]*)?|\.[01]+)(p[+-]?\d+)?$/i,
                D = /^0x([0-9a-f]+(\.[0-9a-f]*)?|\.[0-9a-f]+)(p[+-]?\d+)?$/i,
                P = /^0o([0-7]+(\.[0-7]*)?|\.[0-7]+)(p[+-]?\d+)?$/i,
                F = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i,
                z = S.length - 1,
                B = M.length - 1,
                j = {
                    toStringTag: I
                };

            function H(t) {
                var e, n, r, i = t.length - 1,
                    o = "",
                    s = t[0];
                if (i > 0) {
                    for (o += s, e = 1; e < i; e++)(n = 7 - (r = t[e] + "").length) && (o += Q(n)), o += r;
                    (n = 7 - (r = (s = t[e]) + "").length) && (o += Q(n))
                } else if (0 === s) return "0";
                for (; s % 10 == 0;) s /= 10;
                return o + s
            }

            function J(t, e, n) {
                if (t !== ~~t || t < e || t > n) throw Error(O + t)
            }

            function L(t, e, n, r) {
                var i, o, s, a;
                for (o = t[0]; o >= 10; o /= 10) --e;
                return --e < 0 ? (e += 7, i = 0) : (i = Math.ceil((e + 1) / 7), e %= 7), o = _(10, 7 - e), a = t[i] % o | 0, null == r ? e < 3 ? (0 == e ? a = a / 100 | 0 : 1 == e && (a = a / 10 | 0), s = n < 4 && 99999 == a || n > 3 && 49999 == a || 5e4 == a || 0 == a) : s = (n < 4 && a + 1 == o || n > 3 && a + 1 == o / 2) && (t[i + 1] / o / 100 | 0) == _(10, e - 2) - 1 || (a == o / 2 || 0 == a) && (t[i + 1] / o / 100 | 0) == 0 : e < 4 ? (0 == e ? a = a / 1e3 | 0 : 1 == e ? a = a / 100 | 0 : 2 == e && (a = a / 10 | 0), s = (r || n < 4) && 9999 == a || !r && n > 3 && 4999 == a) : s = ((r || n < 4) && a + 1 == o || !r && n > 3 && a + 1 == o / 2) && (t[i + 1] / o / 1e3 | 0) == _(10, e - 3) - 1, s
            }

            function q(t, e, n) {
                for (var r, i, o = [0], s = 0, a = t.length; s < a;) {
                    for (i = o.length; i--;) o[i] *= e;
                    for (o[0] += k.indexOf(t.charAt(s++)), r = 0; r < o.length; r++) o[r] > n - 1 && (void 0 === o[r + 1] && (o[r + 1] = 0), o[r + 1] += o[r] / n | 0, o[r] %= n)
                }
                return o.reverse()
            }
            j.absoluteValue = j.abs = function() {
                var t = new this.constructor(this);
                return t.s < 0 && (t.s = 1), Y(t)
            }, j.ceil = function() {
                return Y(new this.constructor(this), this.e + 1, 2)
            }, j.clampedTo = j.clamp = function(t, e) {
                var n = this.constructor;
                if (t = new n(t), e = new n(e), !t.s || !e.s) return new n(NaN);
                if (t.gt(e)) throw Error(O + e);
                return 0 > this.cmp(t) ? t : this.cmp(e) > 0 ? e : new n(this)
            }, j.comparedTo = j.cmp = function(t) {
                var e, n, r, i, o = this.d,
                    s = (t = new this.constructor(t)).d,
                    a = this.s,
                    l = t.s;
                if (!o || !s) return a && l ? a !== l ? a : o === s ? 0 : !o ^ a < 0 ? 1 : -1 : NaN;
                if (!o[0] || !s[0]) return o[0] ? a : s[0] ? -l : 0;
                if (a !== l) return a;
                if (this.e !== t.e) return this.e > t.e ^ a < 0 ? 1 : -1;
                for (e = 0, n = (r = o.length) < (i = s.length) ? r : i; e < n; ++e)
                    if (o[e] !== s[e]) return o[e] > s[e] ^ a < 0 ? 1 : -1;
                return r === i ? 0 : r > i ^ a < 0 ? 1 : -1
            }, j.cosine = j.cos = function() {
                var t, e, r = this,
                    i = r.constructor;
                return r.d ? r.d[0] ? (t = i.precision, e = i.rounding, i.precision = t + Math.max(r.e, r.sd()) + 7, i.rounding = 1, r = function(t, e) {
                    var n, r, i;
                    if (e.isZero()) return e;
                    (r = e.d.length) < 32 ? i = (1 / ta(4, n = Math.ceil(r / 3))).toString() : (n = 16, i = "2.3283064365386962890625e-10"), t.precision += n, e = ts(t, 1, e.times(i), new t(1));
                    for (var o = n; o--;) {
                        var s = e.times(e);
                        e = s.times(s).minus(s).times(8).plus(1)
                    }
                    return t.precision -= n, e
                }(i, tl(i, r)), i.precision = t, i.rounding = e, Y(2 == n || 3 == n ? r.neg() : r, t, e, !0)) : new i(1) : new i(NaN)
            }, j.cubeRoot = j.cbrt = function() {
                var t, e, n, r, i, o, s, a, l, c, u = this.constructor;
                if (!this.isFinite() || this.isZero()) return new u(this);
                for (E = !1, (o = this.s * _(this.s * this, 1 / 3)) && Math.abs(o) != 1 / 0 ? r = new u(o.toString()) : (n = H(this.d), (o = ((t = this.e) - n.length + 1) % 3) && (n += 1 == o || -2 == o ? "0" : "00"), o = _(n, 1 / 3), t = R((t + 1) / 3) - (t % 3 == (t < 0 ? -1 : 2)), n = o == 1 / 0 ? "5e" + t : (n = o.toExponential()).slice(0, n.indexOf("e") + 1) + t, (r = new u(n)).s = this.s), s = (t = u.precision) + 3;;)
                    if (c = (l = (a = r).times(a).times(a)).plus(this), r = V(c.plus(this).times(a), c.plus(l), s + 2, 1), H(a.d).slice(0, s) === (n = H(r.d)).slice(0, s)) {
                        if ("9999" != (n = n.slice(s - 3, s + 1)) && (i || "4999" != n)) {
                            +n && (+n.slice(1) || "5" != n.charAt(0)) || (Y(r, t + 1, 1), e = !r.times(r).times(r).eq(this));
                            break
                        }
                        if (!i && (Y(a, t + 1, 0), a.times(a).times(a).eq(this))) {
                            r = a;
                            break
                        }
                        s += 4, i = 1
                    }
                return E = !0, Y(r, t, u.rounding, e)
            }, j.decimalPlaces = j.dp = function() {
                var t, e = this.d,
                    n = NaN;
                if (e) {
                    if (n = ((t = e.length - 1) - R(this.e / 7)) * 7, t = e[t])
                        for (; t % 10 == 0; t /= 10) n--;
                    n < 0 && (n = 0)
                }
                return n
            }, j.dividedBy = j.div = function(t) {
                return V(this, new this.constructor(t))
            }, j.dividedToIntegerBy = j.divToInt = function(t) {
                var e = this.constructor;
                return Y(V(this, new e(t), 0, 1, 1), e.precision, e.rounding)
            }, j.equals = j.eq = function(t) {
                return 0 === this.cmp(t)
            }, j.floor = function() {
                return Y(new this.constructor(this), this.e + 1, 3)
            }, j.greaterThan = j.gt = function(t) {
                return this.cmp(t) > 0
            }, j.greaterThanOrEqualTo = j.gte = function(t) {
                var e = this.cmp(t);
                return 1 == e || 0 === e
            }, j.hyperbolicCosine = j.cosh = function() {
                var t, e, n, r, i, o = this,
                    s = o.constructor,
                    a = new s(1);
                if (!o.isFinite()) return new s(o.s ? 1 / 0 : NaN);
                if (o.isZero()) return a;
                n = s.precision, r = s.rounding, s.precision = n + Math.max(o.e, o.sd()) + 4, s.rounding = 1, (i = o.d.length) < 32 ? e = (1 / ta(4, t = Math.ceil(i / 3))).toString() : (t = 16, e = "2.3283064365386962890625e-10"), o = ts(s, 1, o.times(e), new s(1), !0);
                for (var l, c = t, u = new s(8); c--;) l = o.times(o), o = a.minus(l.times(u.minus(l.times(u))));
                return Y(o, s.precision = n, s.rounding = r, !0)
            }, j.hyperbolicSine = j.sinh = function() {
                var t, e, n, r, i = this,
                    o = i.constructor;
                if (!i.isFinite() || i.isZero()) return new o(i);
                if (e = o.precision, n = o.rounding, o.precision = e + Math.max(i.e, i.sd()) + 4, o.rounding = 1, (r = i.d.length) < 3) i = ts(o, 2, i, i, !0);
                else {
                    t = (t = 1.4 * Math.sqrt(r)) > 16 ? 16 : 0 | t, i = i.times(1 / ta(5, t)), i = ts(o, 2, i, i, !0);
                    for (var s, a = new o(5), l = new o(16), c = new o(20); t--;) s = i.times(i), i = i.times(a.plus(s.times(l.times(s).plus(c))))
                }
                return o.precision = e, o.rounding = n, Y(i, e, n, !0)
            }, j.hyperbolicTangent = j.tanh = function() {
                var t, e, n = this.constructor;
                return this.isFinite() ? this.isZero() ? new n(this) : (t = n.precision, e = n.rounding, n.precision = t + 7, n.rounding = 1, V(this.sinh(), this.cosh(), n.precision = t, n.rounding = e)) : new n(this.s)
            }, j.inverseCosine = j.acos = function() {
                var t, e = this,
                    n = e.constructor,
                    r = e.abs().cmp(1),
                    i = n.precision,
                    o = n.rounding;
                return -1 !== r ? 0 === r ? e.isNeg() ? K(n, i, o) : new n(0) : new n(NaN) : e.isZero() ? K(n, i + 4, o).times(.5) : (n.precision = i + 6, n.rounding = 1, e = e.asin(), t = K(n, i + 4, o).times(.5), n.precision = i, n.rounding = o, t.minus(e))
            }, j.inverseHyperbolicCosine = j.acosh = function() {
                var t, e, n = this,
                    r = n.constructor;
                return n.lte(1) ? new r(n.eq(1) ? 0 : NaN) : n.isFinite() ? (t = r.precision, e = r.rounding, r.precision = t + Math.max(Math.abs(n.e), n.sd()) + 4, r.rounding = 1, E = !1, n = n.times(n).minus(1).sqrt().plus(n), E = !0, r.precision = t, r.rounding = e, n.ln()) : new r(n)
            }, j.inverseHyperbolicSine = j.asinh = function() {
                var t, e, n = this,
                    r = n.constructor;
                return !n.isFinite() || n.isZero() ? new r(n) : (t = r.precision, e = r.rounding, r.precision = t + 2 * Math.max(Math.abs(n.e), n.sd()) + 6, r.rounding = 1, E = !1, n = n.times(n).plus(1).sqrt().plus(n), E = !0, r.precision = t, r.rounding = e, n.ln())
            }, j.inverseHyperbolicTangent = j.atanh = function() {
                var t, e, n, r, i = this,
                    o = i.constructor;
                return i.isFinite() ? i.e >= 0 ? new o(i.abs().eq(1) ? i.s / 0 : i.isZero() ? i : NaN) : (t = o.precision, e = o.rounding, Math.max(r = i.sd(), t) < -(2 * i.e) - 1) ? Y(new o(i), t, e, !0) : (o.precision = n = r - i.e, i = V(i.plus(1), new o(1).minus(i), n + t, 1), o.precision = t + 4, o.rounding = 1, i = i.ln(), o.precision = t, o.rounding = e, i.times(.5)) : new o(NaN)
            }, j.inverseSine = j.asin = function() {
                var t, e, n, r, i = this,
                    o = i.constructor;
                return i.isZero() ? new o(i) : (e = i.abs().cmp(1), n = o.precision, r = o.rounding, -1 !== e) ? 0 === e ? ((t = K(o, n + 4, r).times(.5)).s = i.s, t) : new o(NaN) : (o.precision = n + 6, o.rounding = 1, i = i.div(new o(1).minus(i.times(i)).sqrt().plus(1)).atan(), o.precision = n, o.rounding = r, i.times(2))
            }, j.inverseTangent = j.atan = function() {
                var t, e, n, r, i, o, s, a, l, c = this,
                    u = c.constructor,
                    h = u.precision,
                    p = u.rounding;
                if (c.isFinite()) {
                    if (c.isZero()) return new u(c);
                    if (c.abs().eq(1) && h + 4 <= B) return (s = K(u, h + 4, p).times(.25)).s = c.s, s
                } else {
                    if (!c.s) return new u(NaN);
                    if (h + 4 <= B) return (s = K(u, h + 4, p).times(.5)).s = c.s, s
                }
                for (u.precision = a = h + 10, u.rounding = 1, t = n = Math.min(28, a / 7 + 2 | 0); t; --t) c = c.div(c.times(c).plus(1).sqrt().plus(1));
                for (E = !1, e = Math.ceil(a / 7), r = 1, l = c.times(c), s = new u(c), i = c; - 1 !== t;)
                    if (i = i.times(l), o = s.minus(i.div(r += 2)), i = i.times(l), void 0 !== (s = o.plus(i.div(r += 2))).d[e])
                        for (t = e; s.d[t] === o.d[t] && t--;);
                return n && (s = s.times(2 << n - 1)), E = !0, Y(s, u.precision = h, u.rounding = p, !0)
            }, j.isFinite = function() {
                return !!this.d
            }, j.isInteger = j.isInt = function() {
                return !!this.d && R(this.e / 7) > this.d.length - 2
            }, j.isNaN = function() {
                return !this.s
            }, j.isNegative = j.isNeg = function() {
                return this.s < 0
            }, j.isPositive = j.isPos = function() {
                return this.s > 0
            }, j.isZero = function() {
                return !!this.d && 0 === this.d[0]
            }, j.lessThan = j.lt = function(t) {
                return 0 > this.cmp(t)
            }, j.lessThanOrEqualTo = j.lte = function(t) {
                return 1 > this.cmp(t)
            }, j.logarithm = j.log = function(t) {
                var e, n, r, i, o, s, a, l = this.constructor,
                    c = l.precision,
                    u = l.rounding;
                if (null == t) t = new l(10), e = !0;
                else {
                    if (n = (t = new l(t)).d, t.s < 0 || !n || !n[0] || t.eq(1)) return new l(NaN);
                    e = t.eq(10)
                }
                if (n = this.d, this.s < 0 || !n || !n[0] || this.eq(1)) return new l(n && !n[0] ? -1 / 0 : 1 != this.s ? NaN : n ? 0 : 1 / 0);
                if (e) {
                    if (n.length > 1) i = !0;
                    else {
                        for (r = n[0]; r % 10 == 0;) r /= 10;
                        i = 1 !== r
                    }
                }
                if (E = !1, L((a = V(tr(this, s = c + 5), e ? Z(l, s + 10) : tr(t, s), s, 1)).d, r = c, u))
                    do
                        if (s += 10, a = V(tr(this, s), e ? Z(l, s + 10) : tr(t, s), s, 1), !i) {
                            +H(a.d).slice(r + 1, r + 15) + 1 == 1e14 && (a = Y(a, c + 1, 0));
                            break
                        }
                while (L(a.d, r += 10, u));
                return E = !0, Y(a, c, u)
            }, j.minus = j.sub = function(t) {
                var e, n, r, i, o, s, a, l, c, u, h, p, d = this.constructor;
                if (t = new d(t), !this.d || !t.d) return this.s && t.s ? this.d ? t.s = -t.s : t = new d(t.d || this.s !== t.s ? this : NaN) : t = new d(NaN), t;
                if (this.s != t.s) return t.s = -t.s, this.plus(t);
                if (c = this.d, p = t.d, a = d.precision, l = d.rounding, !c[0] || !p[0]) {
                    if (p[0]) t.s = -t.s;
                    else {
                        if (!c[0]) return new d(-0);
                        t = new d(this)
                    }
                    return E ? Y(t, a, l) : t
                }
                if (n = R(t.e / 7), u = R(this.e / 7), c = c.slice(), o = u - n) {
                    for ((h = o < 0) ? (e = c, o = -o, s = p.length) : (e = p, n = u, s = c.length), r = Math.max(Math.ceil(a / 7), s) + 2, o > r && (o = r, e.length = 1), e.reverse(), r = o; r--;) e.push(0);
                    e.reverse()
                } else {
                    for ((h = (r = c.length) < (s = p.length)) && (s = r), r = 0; r < s; r++)
                        if (c[r] != p[r]) {
                            h = c[r] < p[r];
                            break
                        }
                    o = 0
                }
                for (h && (e = c, c = p, p = e, t.s = -t.s), s = c.length, r = p.length - s; r > 0; --r) c[s++] = 0;
                for (r = p.length; r > o;) {
                    if (c[--r] < p[r]) {
                        for (i = r; i && 0 === c[--i];) c[i] = 1e7 - 1;
                        --c[i], c[r] += 1e7
                    }
                    c[r] -= p[r]
                }
                for (; 0 === c[--s];) c.pop();
                for (; 0 === c[0]; c.shift()) --n;
                return c[0] ? (t.d = c, t.e = W(c, n), E ? Y(t, a, l) : t) : new d(-0)
            }, j.modulo = j.mod = function(t) {
                var e, n = this.constructor;
                return (t = new n(t), this.d && t.s && (!t.d || t.d[0])) ? t.d && (!this.d || this.d[0]) ? (E = !1, 9 == n.modulo ? (e = V(this, t.abs(), 0, 3, 1), e.s *= t.s) : e = V(this, t, 0, n.modulo, 1), e = e.times(t), E = !0, this.minus(e)) : Y(new n(this), n.precision, n.rounding) : new n(NaN)
            }, j.naturalExponential = j.exp = function() {
                return tn(this)
            }, j.naturalLogarithm = j.ln = function() {
                return tr(this)
            }, j.negated = j.neg = function() {
                var t = new this.constructor(this);
                return t.s = -t.s, Y(t)
            }, j.plus = j.add = function(t) {
                var e, n, r, i, o, s, a, l, c, u, h = this.constructor;
                if (t = new h(t), !this.d || !t.d) return this.s && t.s ? this.d || (t = new h(t.d || this.s === t.s ? this : NaN)) : t = new h(NaN), t;
                if (this.s != t.s) return t.s = -t.s, this.minus(t);
                if (c = this.d, u = t.d, a = h.precision, l = h.rounding, !c[0] || !u[0]) return u[0] || (t = new h(this)), E ? Y(t, a, l) : t;
                if (o = R(this.e / 7), r = R(t.e / 7), c = c.slice(), i = o - r) {
                    for (i < 0 ? (n = c, i = -i, s = u.length) : (n = u, r = o, s = c.length), i > (s = (o = Math.ceil(a / 7)) > s ? o + 1 : s + 1) && (i = s, n.length = 1), n.reverse(); i--;) n.push(0);
                    n.reverse()
                }
                for ((s = c.length) - (i = u.length) < 0 && (i = s, n = u, u = c, c = n), e = 0; i;) e = (c[--i] = c[i] + u[i] + e) / 1e7 | 0, c[i] %= 1e7;
                for (e && (c.unshift(e), ++r), s = c.length; 0 == c[--s];) c.pop();
                return t.d = c, t.e = W(c, r), E ? Y(t, a, l) : t
            }, j.precision = j.sd = function(t) {
                var e;
                if (void 0 !== t && !!t !== t && 1 !== t && 0 !== t) throw Error(O + t);
                return this.d ? (e = G(this.d), t && this.e + 1 > e && (e = this.e + 1)) : e = NaN, e
            }, j.round = function() {
                var t = this.constructor;
                return Y(new t(this), this.e + 1, t.rounding)
            }, j.sine = j.sin = function() {
                var t, e, r = this,
                    i = r.constructor;
                return r.isFinite() ? r.isZero() ? new i(r) : (t = i.precision, e = i.rounding, i.precision = t + Math.max(r.e, r.sd()) + 7, i.rounding = 1, r = function(t, e) {
                    var n, r = e.d.length;
                    if (r < 3) return e.isZero() ? e : ts(t, 2, e, e);
                    n = (n = 1.4 * Math.sqrt(r)) > 16 ? 16 : 0 | n, e = e.times(1 / ta(5, n)), e = ts(t, 2, e, e);
                    for (var i, o = new t(5), s = new t(16), a = new t(20); n--;) i = e.times(e), e = e.times(o.plus(i.times(s.times(i).minus(a))));
                    return e
                }(i, tl(i, r)), i.precision = t, i.rounding = e, Y(n > 2 ? r.neg() : r, t, e, !0)) : new i(NaN)
            }, j.squareRoot = j.sqrt = function() {
                var t, e, n, r, i, o, s = this.d,
                    a = this.e,
                    l = this.s,
                    c = this.constructor;
                if (1 !== l || !s || !s[0]) return new c(!l || l < 0 && (!s || s[0]) ? NaN : s ? this : 1 / 0);
                for (E = !1, 0 == (l = Math.sqrt(+this)) || l == 1 / 0 ? (((e = H(s)).length + a) % 2 == 0 && (e += "0"), l = Math.sqrt(e), a = R((a + 1) / 2) - (a < 0 || a % 2), e = l == 1 / 0 ? "5e" + a : (e = l.toExponential()).slice(0, e.indexOf("e") + 1) + a, r = new c(e)) : r = new c(l.toString()), n = (a = c.precision) + 3;;)
                    if (r = (o = r).plus(V(this, o, n + 2, 1)).times(.5), H(o.d).slice(0, n) === (e = H(r.d)).slice(0, n)) {
                        if ("9999" != (e = e.slice(n - 3, n + 1)) && (i || "4999" != e)) {
                            +e && (+e.slice(1) || "5" != e.charAt(0)) || (Y(r, a + 1, 1), t = !r.times(r).eq(this));
                            break
                        }
                        if (!i && (Y(o, a + 1, 0), o.times(o).eq(this))) {
                            r = o;
                            break
                        }
                        n += 4, i = 1
                    }
                return E = !0, Y(r, a, c.rounding, t)
            }, j.tangent = j.tan = function() {
                var t, e, r = this,
                    i = r.constructor;
                return r.isFinite() ? r.isZero() ? new i(r) : (t = i.precision, e = i.rounding, i.precision = t + 10, i.rounding = 1, (r = r.sin()).s = 1, r = V(r, new i(1).minus(r.times(r)).sqrt(), t + 10, 0), i.precision = t, i.rounding = e, Y(2 == n || 4 == n ? r.neg() : r, t, e, !0)) : new i(NaN)
            }, j.times = j.mul = function(t) {
                var e, n, r, i, o, s, a, l, c, u = this.constructor,
                    h = this.d,
                    p = (t = new u(t)).d;
                if (t.s *= this.s, !h || !h[0] || !p || !p[0]) return new u(t.s && (!h || h[0] || p) && (!p || p[0] || h) ? h && p ? 0 * t.s : t.s / 0 : NaN);
                for (n = R(this.e / 7) + R(t.e / 7), (l = h.length) < (c = p.length) && (o = h, h = p, p = o, s = l, l = c, c = s), o = [], r = s = l + c; r--;) o.push(0);
                for (r = c; --r >= 0;) {
                    for (e = 0, i = l + r; i > r;) a = o[i] + p[r] * h[i - r - 1] + e, o[i--] = a % 1e7 | 0, e = a / 1e7 | 0;
                    o[i] = (o[i] + e) % 1e7 | 0
                }
                for (; !o[--s];) o.pop();
                return e ? ++n : o.shift(), t.d = o, t.e = W(o, n), E ? Y(t, u.precision, u.rounding) : t
            }, j.toBinary = function(t, e) {
                return tc(this, 2, t, e)
            }, j.toDecimalPlaces = j.toDP = function(t, e) {
                var n = this,
                    r = n.constructor;
                return (n = new r(n), void 0 === t) ? n : (J(t, 0, 1e9), void 0 === e ? e = r.rounding : J(e, 0, 8), Y(n, t + n.e + 1, e))
            }, j.toExponential = function(t, e) {
                var n, r = this,
                    i = r.constructor;
                return void 0 === t ? n = U(r, !0) : (J(t, 0, 1e9), void 0 === e ? e = i.rounding : J(e, 0, 8), n = U(r = Y(new i(r), t + 1, e), !0, t + 1)), r.isNeg() && !r.isZero() ? "-" + n : n
            }, j.toFixed = function(t, e) {
                var n, r, i = this.constructor;
                return void 0 === t ? n = U(this) : (J(t, 0, 1e9), void 0 === e ? e = i.rounding : J(e, 0, 8), n = U(r = Y(new i(this), t + this.e + 1, e), !1, t + r.e + 1)), this.isNeg() && !this.isZero() ? "-" + n : n
            }, j.toFraction = function(t) {
                var e, n, r, i, o, s, a, l, c, u, h, p, d = this.d,
                    f = this.constructor;
                if (!d) return new f(this);
                if (c = n = new f(1), r = l = new f(0), s = (o = (e = new f(r)).e = G(d) - this.e - 1) % 7, e.d[0] = _(10, s < 0 ? 7 + s : s), null == t) t = o > 0 ? e : c;
                else {
                    if (!(a = new f(t)).isInt() || a.lt(c)) throw Error(O + a);
                    t = a.gt(e) ? o > 0 ? e : c : a
                }
                for (E = !1, a = new f(H(d)), u = f.precision, f.precision = o = 14 * d.length; h = V(a, e, 0, 1, 1), 1 != (i = n.plus(h.times(r))).cmp(t);) n = r, r = i, i = c, c = l.plus(h.times(i)), l = i, i = e, e = a.minus(h.times(i)), a = i;
                return i = V(t.minus(n), r, 0, 1, 1), l = l.plus(i.times(c)), n = n.plus(i.times(r)), l.s = c.s = this.s, p = 1 > V(c, r, o, 1).minus(this).abs().cmp(V(l, n, o, 1).minus(this).abs()) ? [c, r] : [l, n], f.precision = u, E = !0, p
            }, j.toHexadecimal = j.toHex = function(t, e) {
                return tc(this, 16, t, e)
            }, j.toNearest = function(t, e) {
                var n = this,
                    r = n.constructor;
                if (n = new r(n), null == t) {
                    if (!n.d) return n;
                    t = new r(1), e = r.rounding
                } else {
                    if (t = new r(t), void 0 === e ? e = r.rounding : J(e, 0, 8), !n.d) return t.s ? n : t;
                    if (!t.d) return t.s && (t.s = n.s), t
                }
                return t.d[0] ? (E = !1, n = V(n, t, 0, e, 1).times(t), E = !0, Y(n)) : (t.s = n.s, n = t), n
            }, j.toNumber = function() {
                return +this
            }, j.toOctal = function(t, e) {
                return tc(this, 8, t, e)
            }, j.toPower = j.pow = function(t) {
                var e, n, r, i, o, s, a = this,
                    l = a.constructor,
                    c = +(t = new l(t));
                if (!a.d || !t.d || !a.d[0] || !t.d[0]) return new l(_(+a, c));
                if ((a = new l(a)).eq(1)) return a;
                if (r = l.precision, o = l.rounding, t.eq(1)) return Y(a, r, o);
                if ((e = R(t.e / 7)) >= t.d.length - 1 && (n = c < 0 ? -c : c) <= 9007199254740991) return i = X(l, a, n, r), t.s < 0 ? new l(1).div(i) : Y(i, r, o);
                if ((s = a.s) < 0) {
                    if (e < t.d.length - 1) return new l(NaN);
                    if ((1 & t.d[e]) == 0 && (s = 1), 0 == a.e && 1 == a.d[0] && 1 == a.d.length) return a.s = s, a
                }
                return (e = 0 != (n = _(+a, c)) && isFinite(n) ? new l(n + "").e : R(c * (Math.log("0." + H(a.d)) / Math.LN10 + a.e + 1))) > l.maxE + 1 || e < l.minE - 1 ? new l(e > 0 ? s / 0 : 0) : (E = !1, l.rounding = a.s = 1, n = Math.min(12, (e + "").length), (i = tn(t.times(tr(a, r + n)), r)).d && L((i = Y(i, r + 5, 1)).d, r, o) && (e = r + 10, +H((i = Y(tn(t.times(tr(a, e + n)), e), e + 5, 1)).d).slice(r + 1, r + 15) + 1 == 1e14 && (i = Y(i, r + 1, 0))), i.s = s, E = !0, l.rounding = o, Y(i, r, o))
            }, j.toPrecision = function(t, e) {
                var n, r = this,
                    i = r.constructor;
                return void 0 === t ? n = U(r, r.e <= i.toExpNeg || r.e >= i.toExpPos) : (J(t, 1, 1e9), void 0 === e ? e = i.rounding : J(e, 0, 8), n = U(r = Y(new i(r), t, e), t <= r.e || r.e <= i.toExpNeg, t)), r.isNeg() && !r.isZero() ? "-" + n : n
            }, j.toSignificantDigits = j.toSD = function(t, e) {
                var n = this.constructor;
                return void 0 === t ? (t = n.precision, e = n.rounding) : (J(t, 1, 1e9), void 0 === e ? e = n.rounding : J(e, 0, 8)), Y(new n(this), t, e)
            }, j.toString = function() {
                var t = this.constructor,
                    e = U(this, this.e <= t.toExpNeg || this.e >= t.toExpPos);
                return this.isNeg() && !this.isZero() ? "-" + e : e
            }, j.truncated = j.trunc = function() {
                return Y(new this.constructor(this), this.e + 1, 1)
            }, j.valueOf = j.toJSON = function() {
                var t = this.constructor,
                    e = U(this, this.e <= t.toExpNeg || this.e >= t.toExpPos);
                return this.isNeg() ? "-" + e : e
            };
            var V = function() {
                function t(t, e, n) {
                    var r, i = 0,
                        o = t.length;
                    for (t = t.slice(); o--;) r = t[o] * e + i, t[o] = r % n | 0, i = r / n | 0;
                    return i && t.unshift(i), t
                }

                function n(t, e, n, r) {
                    var i, o;
                    if (n != r) o = n > r ? 1 : -1;
                    else
                        for (i = o = 0; i < n; i++)
                            if (t[i] != e[i]) {
                                o = t[i] > e[i] ? 1 : -1;
                                break
                            } return o
                }

                function r(t, e, n, r) {
                    for (var i = 0; n--;) t[n] -= i, i = t[n] < e[n] ? 1 : 0, t[n] = i * r + t[n] - e[n];
                    for (; !t[0] && t.length > 1;) t.shift()
                }
                return function(i, o, s, a, l, c) {
                    var u, h, p, d, f, m, g, y, v, w, b, x, k, S, M, C, E, N, O, A, T = i.constructor,
                        I = i.s == o.s ? 1 : -1,
                        _ = i.d,
                        $ = o.d;
                    if (!_ || !_[0] || !$ || !$[0]) return new T(i.s && o.s && (_ ? !$ || _[0] != $[0] : $) ? _ && 0 == _[0] || !$ ? 0 * I : I / 0 : NaN);
                    for (c ? (f = 1, h = i.e - o.e) : (c = 1e7, f = 7, h = R(i.e / f) - R(o.e / f)), O = $.length, E = _.length, w = (v = new T(I)).d = [], p = 0; $[p] == (_[p] || 0); p++);
                    if ($[p] > (_[p] || 0) && h--, null == s ? (S = s = T.precision, a = T.rounding) : S = l ? s + (i.e - o.e) + 1 : s, S < 0) w.push(1), m = !0;
                    else {
                        if (S = S / f + 2 | 0, p = 0, 1 == O) {
                            for (d = 0, $ = $[0], S++;
                                (p < E || d) && S--; p++) M = d * c + (_[p] || 0), w[p] = M / $ | 0, d = M % $ | 0;
                            m = d || p < E
                        } else {
                            for ((d = c / ($[0] + 1) | 0) > 1 && ($ = t($, d, c), _ = t(_, d, c), O = $.length, E = _.length), C = O, x = (b = _.slice(0, O)).length; x < O;) b[x++] = 0;
                            (A = $.slice()).unshift(0), N = $[0], $[1] >= c / 2 && ++N;
                            do d = 0, (u = n($, b, O, x)) < 0 ? (k = b[0], O != x && (k = k * c + (b[1] || 0)), (d = k / N | 0) > 1 ? (d >= c && (d = c - 1), y = (g = t($, d, c)).length, x = b.length, 1 == (u = n(g, b, y, x)) && (d--, r(g, O < y ? A : $, y, c))) : (0 == d && (u = d = 1), g = $.slice()), (y = g.length) < x && g.unshift(0), r(b, g, x, c), -1 == u && (x = b.length, (u = n($, b, O, x)) < 1 && (d++, r(b, O < x ? A : $, x, c))), x = b.length) : 0 === u && (d++, b = [0]), w[p++] = d, u && b[0] ? b[x++] = _[C] || 0 : (b = [_[C]], x = 1); while ((C++ < E || void 0 !== b[0]) && S--);
                            m = void 0 !== b[0]
                        }
                        w[0] || w.shift()
                    }
                    if (1 == f) v.e = h, e = m;
                    else {
                        for (p = 1, d = w[0]; d >= 10; d /= 10) p++;
                        v.e = p + h * f - 1, Y(v, l ? s + v.e + 1 : s, a, m)
                    }
                    return v
                }
            }();

            function Y(t, e, n, r) {
                var i, o, s, a, l, c, u, h, p, d = t.constructor;
                t: if (null != e) {
                    if (!(h = t.d)) return t;
                    for (i = 1, a = h[0]; a >= 10; a /= 10) i++;
                    if ((o = e - i) < 0) o += 7, s = e, l = (u = h[p = 0]) / _(10, i - s - 1) % 10 | 0;
                    else if (p = Math.ceil((o + 1) / 7), a = h.length, p >= a) {
                        if (r) {
                            for (; a++ <= p;) h.push(0);
                            u = l = 0, i = 1, o %= 7, s = o - 7 + 1
                        } else break t
                    } else {
                        for (i = 1, u = a = h[p]; a >= 10; a /= 10) i++;
                        o %= 7, l = (s = o - 7 + i) < 0 ? 0 : u / _(10, i - s - 1) % 10 | 0
                    }
                    if (r = r || e < 0 || void 0 !== h[p + 1] || (s < 0 ? u : u % _(10, i - s - 1)), c = n < 4 ? (l || r) && (0 == n || n == (t.s < 0 ? 3 : 2)) : l > 5 || 5 == l && (4 == n || r || 6 == n && (o > 0 ? s > 0 ? u / _(10, i - s) : 0 : h[p - 1]) % 10 & 1 || n == (t.s < 0 ? 8 : 7)), e < 1 || !h[0]) return h.length = 0, c ? (e -= t.e + 1, h[0] = _(10, (7 - e % 7) % 7), t.e = -e || 0) : h[0] = t.e = 0, t;
                    if (0 == o ? (h.length = p, a = 1, p--) : (h.length = p + 1, a = _(10, 7 - o), h[p] = s > 0 ? (u / _(10, i - s) % _(10, s) | 0) * a : 0), c)
                        for (;;) {
                            if (0 == p) {
                                for (o = 1, s = h[0]; s >= 10; s /= 10) o++;
                                for (s = h[0] += a, a = 1; s >= 10; s /= 10) a++;
                                o != a && (t.e++, 1e7 == h[0] && (h[0] = 1));
                                break
                            }
                            if (h[p] += a, 1e7 != h[p]) break;
                            h[p--] = 0, a = 1
                        }
                    for (o = h.length; 0 === h[--o];) h.pop()
                }
                return E && (t.e > d.maxE ? (t.d = null, t.e = NaN) : t.e < d.minE && (t.e = 0, t.d = [0])), t
            }

            function U(t, e, n) {
                if (!t.isFinite()) return ti(t);
                var r, i = t.e,
                    o = H(t.d),
                    s = o.length;
                return e ? (n && (r = n - s) > 0 ? o = o.charAt(0) + "." + o.slice(1) + Q(r) : s > 1 && (o = o.charAt(0) + "." + o.slice(1)), o = o + (t.e < 0 ? "e" : "e+") + t.e) : i < 0 ? (o = "0." + Q(-i - 1) + o, n && (r = n - s) > 0 && (o += Q(r))) : i >= s ? (o += Q(i + 1 - s), n && (r = n - i - 1) > 0 && (o = o + "." + Q(r))) : ((r = i + 1) < s && (o = o.slice(0, r) + "." + o.slice(r)), n && (r = n - s) > 0 && (i + 1 === s && (o += "."), o += Q(r))), o
            }

            function W(t, e) {
                var n = t[0];
                for (e *= 7; n >= 10; n /= 10) e++;
                return e
            }

            function Z(t, e, n) {
                if (e > z) throw E = !0, n && (t.precision = n), Error(A);
                return Y(new t(S), e, 1, !0)
            }

            function K(t, e, n) {
                if (e > B) throw Error(A);
                return Y(new t(M), e, n, !0)
            }

            function G(t) {
                var e = t.length - 1,
                    n = 7 * e + 1;
                if (e = t[e]) {
                    for (; e % 10 == 0; e /= 10) n--;
                    for (e = t[0]; e >= 10; e /= 10) n++
                }
                return n
            }

            function Q(t) {
                for (var e = ""; t--;) e += "0";
                return e
            }

            function X(t, e, n, r) {
                var i, o = new t(1),
                    s = Math.ceil(r / 7 + 4);
                for (E = !1;;) {
                    if (n % 2 && tu((o = o.times(e)).d, s) && (i = !0), 0 === (n = R(n / 2))) {
                        n = o.d.length - 1, i && 0 === o.d[n] && ++o.d[n];
                        break
                    }
                    tu((e = e.times(e)).d, s)
                }
                return E = !0, o
            }

            function tt(t) {
                return 1 & t.d[t.d.length - 1]
            }

            function te(t, e, n) {
                for (var r, i = new t(e[0]), o = 0; ++o < e.length;)
                    if ((r = new t(e[o])).s) i[n](r) && (i = r);
                    else {
                        i = r;
                        break
                    }
                return i
            }

            function tn(t, e) {
                var n, r, i, o, s, a, l, c = 0,
                    u = 0,
                    h = 0,
                    p = t.constructor,
                    d = p.rounding,
                    f = p.precision;
                if (!t.d || !t.d[0] || t.e > 17) return new p(t.d ? t.d[0] ? t.s < 0 ? 0 : 1 / 0 : 1 : t.s ? t.s < 0 ? 0 : t : 0 / 0);
                for (null == e ? (E = !1, l = f) : l = e, a = new p(.03125); t.e > -2;) t = t.times(a), h += 5;
                for (l += r = Math.log(_(2, h)) / Math.LN10 * 2 + 5 | 0, n = o = s = new p(1), p.precision = l;;) {
                    if (o = Y(o.times(t), l, 1), n = n.times(++u), H((a = s.plus(V(o, n, l, 1))).d).slice(0, l) === H(s.d).slice(0, l)) {
                        for (i = h; i--;) s = Y(s.times(s), l, 1);
                        if (null != e) return p.precision = f, s;
                        if (!(c < 3 && L(s.d, l - r, d, c))) return Y(s, p.precision = f, d, E = !0);
                        p.precision = l += 10, n = o = a = new p(1), u = 0, c++
                    }
                    s = a
                }
            }

            function tr(t, e) {
                var n, r, i, o, s, a, l, c, u, h, p, d = 1,
                    f = t,
                    m = f.d,
                    g = f.constructor,
                    y = g.rounding,
                    v = g.precision;
                if (f.s < 0 || !m || !m[0] || !f.e && 1 == m[0] && 1 == m.length) return new g(m && !m[0] ? -1 / 0 : 1 != f.s ? NaN : m ? 0 : f);
                if (null == e ? (E = !1, u = v) : u = e, g.precision = u += 10, r = (n = H(m)).charAt(0), !(15e14 > Math.abs(o = f.e))) return c = Z(g, u + 2, v).times(o + ""), f = tr(new g(r + "." + n.slice(1)), u - 10).plus(c), g.precision = v, null == e ? Y(f, v, y, E = !0) : f;
                for (; r < 7 && 1 != r || 1 == r && n.charAt(1) > 3;) r = (n = H((f = f.times(t)).d)).charAt(0), d++;
                for (o = f.e, r > 1 ? (f = new g("0." + n), o++) : f = new g(r + "." + n.slice(1)), h = f, l = s = f = V(f.minus(1), f.plus(1), u, 1), p = Y(f.times(f), u, 1), i = 3;;) {
                    if (s = Y(s.times(p), u, 1), H((c = l.plus(V(s, new g(i), u, 1))).d).slice(0, u) === H(l.d).slice(0, u)) {
                        if (l = l.times(2), 0 !== o && (l = l.plus(Z(g, u + 2, v).times(o + ""))), l = V(l, new g(d), u, 1), null != e) return g.precision = v, l;
                        if (!L(l.d, u - 10, y, a)) return Y(l, g.precision = v, y, E = !0);
                        g.precision = u += 10, c = s = f = V(h.minus(1), h.plus(1), u, 1), p = Y(f.times(f), u, 1), i = a = 1
                    }
                    l = c, i += 2
                }
            }

            function ti(t) {
                return String(t.s * t.s / 0)
            }

            function to(t, e) {
                var n, r, i;
                for ((n = e.indexOf(".")) > -1 && (e = e.replace(".", "")), (r = e.search(/e/i)) > 0 ? (n < 0 && (n = r), n += +e.slice(r + 1), e = e.substring(0, r)) : n < 0 && (n = e.length), r = 0; 48 === e.charCodeAt(r); r++);
                for (i = e.length; 48 === e.charCodeAt(i - 1); --i);
                if (e = e.slice(r, i)) {
                    if (i -= r, t.e = n = n - r - 1, t.d = [], r = (n + 1) % 7, n < 0 && (r += 7), r < i) {
                        for (r && t.d.push(+e.slice(0, r)), i -= 7; r < i;) t.d.push(+e.slice(r, r += 7));
                        r = 7 - (e = e.slice(r)).length
                    } else r -= i;
                    for (; r--;) e += "0";
                    t.d.push(+e), E && (t.e > t.constructor.maxE ? (t.d = null, t.e = NaN) : t.e < t.constructor.minE && (t.e = 0, t.d = [0]))
                } else t.e = 0, t.d = [0];
                return t
            }

            function ts(t, e, n, r, i) {
                var o, s, a, l, c = t.precision,
                    u = Math.ceil(c / 7);
                for (E = !1, l = n.times(n), a = new t(r);;) {
                    if (s = V(a.times(l), new t(e++ * e++), c, 1), a = i ? r.plus(s) : r.minus(s), r = V(s.times(l), new t(e++ * e++), c, 1), void 0 !== (s = a.plus(r)).d[u]) {
                        for (o = u; s.d[o] === a.d[o] && o--;);
                        if (-1 == o) break
                    }
                    o = a, a = r, r = s, s = o
                }
                return E = !0, s.d.length = u + 1, s
            }

            function ta(t, e) {
                for (var n = t; --e;) n *= t;
                return n
            }

            function tl(t, e) {
                var r, i = e.s < 0,
                    o = K(t, t.precision, 1),
                    s = o.times(.5);
                if ((e = e.abs()).lte(s)) return n = i ? 4 : 1, e;
                if ((r = e.divToInt(o)).isZero()) n = i ? 3 : 2;
                else {
                    if ((e = e.minus(r.times(o))).lte(s)) return n = tt(r) ? i ? 2 : 3 : i ? 4 : 1, e;
                    n = tt(r) ? i ? 1 : 4 : i ? 3 : 2
                }
                return e.minus(o).abs()
            }

            function tc(t, n, r, i) {
                var o, s, a, l, c, u, h, p, d, f = t.constructor,
                    m = void 0 !== r;
                if (m ? (J(r, 1, 1e9), void 0 === i ? i = f.rounding : J(i, 0, 8)) : (r = f.precision, i = f.rounding), t.isFinite()) {
                    for (a = (h = U(t)).indexOf("."), m ? (o = 2, 16 == n ? r = 4 * r - 3 : 8 == n && (r = 3 * r - 2)) : o = n, a >= 0 && (h = h.replace(".", ""), (d = new f(1)).e = h.length - a, d.d = q(U(d), 10, o), d.e = d.d.length), s = c = (p = q(h, 10, o)).length; 0 == p[--c];) p.pop();
                    if (p[0]) {
                        if (a < 0 ? s-- : ((t = new f(t)).d = p, t.e = s, p = (t = V(t, d, r, i, 0, o)).d, s = t.e, u = e), a = p[r], l = o / 2, u = u || void 0 !== p[r + 1], u = i < 4 ? (void 0 !== a || u) && (0 === i || i === (t.s < 0 ? 3 : 2)) : a > l || a === l && (4 === i || u || 6 === i && 1 & p[r - 1] || i === (t.s < 0 ? 8 : 7)), p.length = r, u)
                            for (; ++p[--r] > o - 1;) p[r] = 0, r || (++s, p.unshift(1));
                        for (c = p.length; !p[c - 1]; --c);
                        for (a = 0, h = ""; a < c; a++) h += k.charAt(p[a]);
                        if (m) {
                            if (c > 1) {
                                if (16 == n || 8 == n) {
                                    for (a = 16 == n ? 4 : 3, --c; c % a; c++) h += "0";
                                    for (c = (p = q(h, o, n)).length; !p[c - 1]; --c);
                                    for (a = 1, h = "1."; a < c; a++) h += k.charAt(p[a])
                                } else h = h.charAt(0) + "." + h.slice(1)
                            }
                            h = h + (s < 0 ? "p" : "p+") + s
                        } else if (s < 0) {
                            for (; ++s;) h = "0" + h;
                            h = "0." + h
                        } else if (++s > c)
                            for (s -= c; s--;) h += "0";
                        else s < c && (h = h.slice(0, s) + "." + h.slice(s))
                    } else h = m ? "0p+0" : "0";
                    h = (16 == n ? "0x" : 2 == n ? "0b" : 8 == n ? "0o" : "") + h
                } else h = ti(t);
                return t.s < 0 ? "-" + h : h
            }

            function tu(t, e) {
                if (t.length > e) return t.length = e, !0
            }

            function th(t) {
                return new this(t).abs()
            }

            function tp(t) {
                return new this(t).acos()
            }

            function td(t) {
                return new this(t).acosh()
            }

            function tf(t, e) {
                return new this(t).plus(e)
            }

            function tm(t) {
                return new this(t).asin()
            }

            function tg(t) {
                return new this(t).asinh()
            }

            function ty(t) {
                return new this(t).atan()
            }

            function tv(t) {
                return new this(t).atanh()
            }

            function tw(t, e) {
                t = new this(t), e = new this(e);
                var n, r = this.precision,
                    i = this.rounding,
                    o = r + 4;
                return t.s && e.s ? t.d || e.d ? !e.d || t.isZero() ? (n = e.s < 0 ? K(this, r, i) : new this(0)).s = t.s : !t.d || e.isZero() ? (n = K(this, o, 1).times(.5)).s = t.s : e.s < 0 ? (this.precision = o, this.rounding = 1, n = this.atan(V(t, e, o, 1)), e = K(this, o, 1), this.precision = r, this.rounding = i, n = t.s < 0 ? n.minus(e) : n.plus(e)) : n = this.atan(V(t, e, o, 1)) : (n = K(this, o, 1).times(e.s > 0 ? .25 : .75)).s = t.s : n = new this(NaN), n
            }

            function tb(t) {
                return new this(t).cbrt()
            }

            function tx(t) {
                return Y(t = new this(t), t.e + 1, 2)
            }

            function tk(t, e, n) {
                return new this(t).clamp(e, n)
            }

            function tS(t) {
                if (!t || "object" != typeof t) throw Error(N + "Object expected");
                var e, n, r, i = !0 === t.defaults,
                    o = ["precision", 1, 1e9, "rounding", 0, 8, "toExpNeg", -9e15, 0, "toExpPos", 0, 9e15, "maxE", 0, 9e15, "minE", -9e15, 0, "modulo", 0, 9];
                for (e = 0; e < o.length; e += 3)
                    if (n = o[e], i && (this[n] = C[n]), void 0 !== (r = t[n])) {
                        if (R(r) === r && r >= o[e + 1] && r <= o[e + 2]) this[n] = r;
                        else throw Error(O + n + ": " + r)
                    }
                if (n = "crypto", i && (this[n] = C[n]), void 0 !== (r = t[n])) {
                    if (!0 === r || !1 === r || 0 === r || 1 === r) {
                        if (r) {
                            if ("undefined" != typeof crypto && crypto && (crypto.getRandomValues || crypto.randomBytes)) this[n] = !0;
                            else throw Error(T)
                        } else this[n] = !1
                    } else throw Error(O + n + ": " + r)
                }
                return this
            }

            function tM(t) {
                return new this(t).cos()
            }

            function tC(t) {
                return new this(t).cosh()
            }

            function tE(t, e) {
                return new this(t).div(e)
            }

            function tN(t) {
                return new this(t).exp()
            }

            function tO(t) {
                return Y(t = new this(t), t.e + 1, 3)
            }

            function tA() {
                var t, e, n = new this(0);
                for (t = 0, E = !1; t < arguments.length;)
                    if (e = new this(arguments[t++]), e.d) n.d && (n = n.plus(e.times(e)));
                    else {
                        if (e.s) return E = !0, new this(1 / 0);
                        n = e
                    }
                return E = !0, n.sqrt()
            }

            function tT(t) {
                return t instanceof tG || t && t.toStringTag === I || !1
            }

            function tI(t) {
                return new this(t).ln()
            }

            function tR(t, e) {
                return new this(t).log(e)
            }

            function t_(t) {
                return new this(t).log(2)
            }

            function t$(t) {
                return new this(t).log(10)
            }

            function tD() {
                return te(this, arguments, "lt")
            }

            function tP() {
                return te(this, arguments, "gt")
            }

            function tF(t, e) {
                return new this(t).mod(e)
            }

            function tz(t, e) {
                return new this(t).mul(e)
            }

            function tB(t, e) {
                return new this(t).pow(e)
            }

            function tj(t) {
                var e, n, r, i, o = 0,
                    s = new this(1),
                    a = [];
                if (void 0 === t ? t = this.precision : J(t, 1, 1e9), r = Math.ceil(t / 7), this.crypto) {
                    if (crypto.getRandomValues)
                        for (e = crypto.getRandomValues(new Uint32Array(r)); o < r;)(i = e[o]) >= 429e7 ? e[o] = crypto.getRandomValues(new Uint32Array(1))[0] : a[o++] = i % 1e7;
                    else if (crypto.randomBytes) {
                        for (e = crypto.randomBytes(r *= 4); o < r;)(i = e[o] + (e[o + 1] << 8) + (e[o + 2] << 16) + ((127 & e[o + 3]) << 24)) >= 214e7 ? crypto.randomBytes(4).copy(e, o) : (a.push(i % 1e7), o += 4);
                        o = r / 4
                    } else throw Error(T)
                } else
                    for (; o < r;) a[o++] = 1e7 * Math.random() | 0;
                for (r = a[--o], t %= 7, r && t && (i = _(10, 7 - t), a[o] = (r / i | 0) * i); 0 === a[o]; o--) a.pop();
                if (o < 0) n = 0, a = [0];
                else {
                    for (n = -1; 0 === a[0]; n -= 7) a.shift();
                    for (r = 1, i = a[0]; i >= 10; i /= 10) r++;
                    r < 7 && (n -= 7 - r)
                }
                return s.e = n, s.d = a, s
            }

            function tH(t) {
                return Y(t = new this(t), t.e + 1, this.rounding)
            }

            function tJ(t) {
                return (t = new this(t)).d ? t.d[0] ? t.s : 0 * t.s : t.s || NaN
            }

            function tL(t) {
                return new this(t).sin()
            }

            function tq(t) {
                return new this(t).sinh()
            }

            function tV(t) {
                return new this(t).sqrt()
            }

            function tY(t, e) {
                return new this(t).sub(e)
            }

            function tU() {
                var t = 0,
                    e = arguments,
                    n = new this(e[t]);
                for (E = !1; n.s && ++t < e.length;) n = n.plus(e[t]);
                return E = !0, Y(n, this.precision, this.rounding)
            }

            function tW(t) {
                return new this(t).tan()
            }

            function tZ(t) {
                return new this(t).tanh()
            }

            function tK(t) {
                return Y(t = new this(t), t.e + 1, 1)
            }
            j[Symbol.for("nodejs.util.inspect.custom")] = j.toString, j[Symbol.toStringTag] = "Decimal";
            var tG = j.constructor = function t(e) {
                var n, r, i;

                function o(t) {
                    var e, n, r, i = this;
                    if (!(i instanceof o)) return new o(t);
                    if (i.constructor = o, tT(t)) {
                        i.s = t.s, E ? !t.d || t.e > o.maxE ? (i.e = NaN, i.d = null) : t.e < o.minE ? (i.e = 0, i.d = [0]) : (i.e = t.e, i.d = t.d.slice()) : (i.e = t.e, i.d = t.d ? t.d.slice() : t.d);
                        return
                    }
                    if ("number" == (r = typeof t)) {
                        if (0 === t) {
                            i.s = 1 / t < 0 ? -1 : 1, i.e = 0, i.d = [0];
                            return
                        }
                        if (t < 0 ? (t = -t, i.s = -1) : i.s = 1, t === ~~t && t < 1e7) {
                            for (e = 0, n = t; n >= 10; n /= 10) e++;
                            E ? e > o.maxE ? (i.e = NaN, i.d = null) : e < o.minE ? (i.e = 0, i.d = [0]) : (i.e = e, i.d = [t]) : (i.e = e, i.d = [t]);
                            return
                        }
                        if (0 * t != 0) {
                            t || (i.s = NaN), i.e = NaN, i.d = null;
                            return
                        }
                        return to(i, t.toString())
                    }
                    if ("string" !== r) throw Error(O + t);
                    return 45 === (n = t.charCodeAt(0)) ? (t = t.slice(1), i.s = -1) : (43 === n && (t = t.slice(1)), i.s = 1), F.test(t) ? to(i, t) : function(t, e) {
                        var n, r, i, o, s, a, l, c, u;
                        if (e.indexOf("_") > -1) {
                            if (e = e.replace(/(\d)_(?=\d)/g, "$1"), F.test(e)) return to(t, e)
                        } else if ("Infinity" === e || "NaN" === e) return +e || (t.s = NaN), t.e = NaN, t.d = null, t;
                        if (D.test(e)) n = 16, e = e.toLowerCase();
                        else if ($.test(e)) n = 2;
                        else if (P.test(e)) n = 8;
                        else throw Error(O + e);
                        for ((o = e.search(/p/i)) > 0 ? (l = +e.slice(o + 1), e = e.substring(2, o)) : e = e.slice(2), s = (o = e.indexOf(".")) >= 0, r = t.constructor, s && (o = (a = (e = e.replace(".", "")).length) - o, i = X(r, new r(n), o, 2 * o)), o = u = (c = q(e, n, 1e7)).length - 1; 0 === c[o]; --o) c.pop();
                        return o < 0 ? new r(0 * t.s) : (t.e = W(c, u), t.d = c, E = !1, s && (t = V(t, i, 4 * a)), l && (t = t.times(54 > Math.abs(l) ? _(2, l) : tG.pow(2, l))), E = !0, t)
                    }(i, t)
                }
                if (o.prototype = j, o.ROUND_UP = 0, o.ROUND_DOWN = 1, o.ROUND_CEIL = 2, o.ROUND_FLOOR = 3, o.ROUND_HALF_UP = 4, o.ROUND_HALF_DOWN = 5, o.ROUND_HALF_EVEN = 6, o.ROUND_HALF_CEIL = 7, o.ROUND_HALF_FLOOR = 8, o.EUCLID = 9, o.config = o.set = tS, o.clone = t, o.isDecimal = tT, o.abs = th, o.acos = tp, o.acosh = td, o.add = tf, o.asin = tm, o.asinh = tg, o.atan = ty, o.atanh = tv, o.atan2 = tw, o.cbrt = tb, o.ceil = tx, o.clamp = tk, o.cos = tM, o.cosh = tC, o.div = tE, o.exp = tN, o.floor = tO, o.hypot = tA, o.ln = tI, o.log = tR, o.log10 = t$, o.log2 = t_, o.max = tD, o.min = tP, o.mod = tF, o.mul = tz, o.pow = tB, o.random = tj, o.round = tH, o.sign = tJ, o.sin = tL, o.sinh = tq, o.sqrt = tV, o.sub = tY, o.sum = tU, o.tan = tW, o.tanh = tZ, o.trunc = tK, void 0 === e && (e = {}), e && !0 !== e.defaults)
                    for (n = 0, i = ["precision", "rounding", "toExpNeg", "toExpPos", "maxE", "minE", "modulo", "crypto"]; n < i.length;) e.hasOwnProperty(r = i[n++]) || (e[r] = this[r]);
                return o.config(e), o
            }(C);
            S = new tG(S), M = new tG(M);
            var tQ = tG;
            /*!
             *  decimal.js v10.4.3
             *  An arbitrary-precision Decimal type for JavaScript.
             *  https://github.com/MikeMcl/decimal.js
             *  Copyright (c) 2022 Michael Mclaughlin <M8ch88l@gmail.com>
             *  MIT Licence
             */
        },
        51630: function(t, e, n) {
            "use strict";
            n.d(e, {
                jE: function() {
                    return p
                },
                kg: function() {
                    return c
                }
            });
            var r = n(2784),
                i = n(33539),
                o = n(28316);
            class s extends i.ML {
                constructor() {
                    super(...arguments), this.contentComponent = null
                }
            }
            let a = ({
                renderers: t
            }) => r.createElement(r.Fragment, null, Object.entries(t).map(([t, e]) => o.createPortal(e.reactElement, e.element, t)));
            class l extends r.Component {
                constructor(t) {
                    super(t), this.editorContentRef = r.createRef(), this.initialized = !1, this.state = {
                        renderers: {}
                    }
                }
                componentDidMount() {
                    this.init()
                }
                componentDidUpdate() {
                    this.init()
                }
                init() {
                    let {
                        editor: t
                    } = this.props;
                    if (t && t.options.element) {
                        if (t.contentComponent) return;
                        let e = this.editorContentRef.current;
                        e.append(...t.options.element.childNodes), t.setOptions({
                            element: e
                        }), t.contentComponent = this, t.createNodeViews(), this.initialized = !0
                    }
                }
                maybeFlushSync(t) {
                    this.initialized ? (0, o.flushSync)(t) : t()
                }
                setRenderer(t, e) {
                    this.maybeFlushSync(() => {
                        this.setState(({
                            renderers: n
                        }) => ({
                            renderers: { ...n,
                                [t]: e
                            }
                        }))
                    })
                }
                removeRenderer(t) {
                    this.maybeFlushSync(() => {
                        this.setState(({
                            renderers: e
                        }) => {
                            let n = { ...e
                            };
                            return delete n[t], {
                                renderers: n
                            }
                        })
                    })
                }
                componentWillUnmount() {
                    let {
                        editor: t
                    } = this.props;
                    if (!t || (t.isDestroyed || t.view.setProps({
                            nodeViews: {}
                        }), t.contentComponent = null, !t.options.element.firstChild)) return;
                    let e = document.createElement("div");
                    e.append(...t.options.element.childNodes), t.setOptions({
                        element: e
                    })
                }
                render() {
                    let {
                        editor: t,
                        ...e
                    } = this.props;
                    return r.createElement(r.Fragment, null, r.createElement("div", {
                        ref: this.editorContentRef,
                        ...e
                    }), r.createElement(a, {
                        renderers: this.state.renderers
                    }))
                }
            }
            let c = r.memo(l),
                u = (0, r.createContext)({
                    onDragStart: void 0
                }),
                h = () => (0, r.useContext)(u);
            r.forwardRef((t, e) => {
                let {
                    onDragStart: n
                } = h(), i = t.as || "div";
                return r.createElement(i, { ...t,
                    ref: e,
                    "data-node-view-wrapper": "",
                    onDragStart: n,
                    style: {
                        whiteSpace: "normal",
                        ...t.style
                    }
                })
            });
            let p = (t = {}, e = []) => {
                let [n, i] = (0, r.useState)(null), o = function() {
                    let [, t] = (0, r.useState)(0);
                    return () => t(t => t + 1)
                }();
                return (0, r.useEffect)(() => {
                    let e = !0,
                        n = new s(t);
                    return i(n), n.on("transaction", () => {
                        requestAnimationFrame(() => {
                            requestAnimationFrame(() => {
                                e && o()
                            })
                        })
                    }), () => {
                        n.destroy(), e = !1
                    }
                }, e), n
            }
        },
        6185: function(t) {
            var e = "function" == typeof Float32Array;

            function n(t, e, n) {
                return (((1 - 3 * n + 3 * e) * t + (3 * n - 6 * e)) * t + 3 * e) * t
            }

            function r(t, e, n) {
                return 3 * (1 - 3 * n + 3 * e) * t * t + 2 * (3 * n - 6 * e) * t + 3 * e
            }

            function i(t) {
                return t
            }
            t.exports = function(t, o, s, a) {
                if (!(0 <= t && t <= 1 && 0 <= s && s <= 1)) throw Error("bezier x values must be in [0, 1] range");
                if (t === o && s === a) return i;
                for (var l = e ? new Float32Array(11) : Array(11), c = 0; c < 11; ++c) l[c] = n(.1 * c, t, s);
                return function(e) {
                    return 0 === e ? 0 : 1 === e ? 1 : n(function(e) {
                        for (var i = 0, o = 1; 10 !== o && l[o] <= e; ++o) i += .1;
                        var a = i + (e - l[--o]) / (l[o + 1] - l[o]) * .1,
                            c = r(a, t, s);
                        return c >= .001 ? function(t, e, i, o) {
                            for (var s = 0; s < 4; ++s) {
                                var a = r(e, i, o);
                                if (0 === a) break;
                                var l = n(e, i, o) - t;
                                e -= l / a
                            }
                            return e
                        }(e, a, t, s) : 0 === c ? a : function(t, e, r, i, o) {
                            var s, a, l = 0;
                            do(s = n(a = e + (r - e) / 2, i, o) - t) > 0 ? r = a : e = a; while (Math.abs(s) > 1e-7 && ++l < 10);
                            return a
                        }(e, i, i + .1, t, s)
                    }(e), o, a)
                }
            }
        },
        28879: function(t) {
            var e, n, r, i, o, s, a, l, c, u, h, p, d, f, m, g, y, v, w, b, x;
            t.exports = (e = "millisecond", n = "second", r = "minute", i = "hour", o = "week", s = "month", a = "quarter", l = "year", c = "date", u = "Invalid Date", h = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, p = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, d = function(t, e, n) {
                var r = String(t);
                return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t
            }, (m = {})[f = "en"] = {
                name: "en",
                weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
                months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
                ordinal: function(t) {
                    var e = ["th", "st", "nd", "rd"],
                        n = t % 100;
                    return "[" + t + (e[(n - 20) % 10] || e[n] || "th") + "]"
                }
            }, g = function(t) {
                return t instanceof b
            }, y = function t(e, n, r) {
                var i;
                if (!e) return f;
                if ("string" == typeof e) {
                    var o = e.toLowerCase();
                    m[o] && (i = o), n && (m[o] = n, i = o);
                    var s = e.split("-");
                    if (!i && s.length > 1) return t(s[0])
                } else {
                    var a = e.name;
                    m[a] = e, i = a
                }
                return !r && i && (f = i), i || !r && f
            }, v = function(t, e) {
                if (g(t)) return t.clone();
                var n = "object" == typeof e ? e : {};
                return n.date = t, n.args = arguments, new b(n)
            }, (w = {
                s: d,
                z: function(t) {
                    var e = -t.utcOffset(),
                        n = Math.abs(e);
                    return (e <= 0 ? "+" : "-") + d(Math.floor(n / 60), 2, "0") + ":" + d(n % 60, 2, "0")
                },
                m: function t(e, n) {
                    if (e.date() < n.date()) return -t(n, e);
                    var r = 12 * (n.year() - e.year()) + (n.month() - e.month()),
                        i = e.clone().add(r, s),
                        o = n - i < 0,
                        a = e.clone().add(r + (o ? -1 : 1), s);
                    return +(-(r + (n - i) / (o ? i - a : a - i)) || 0)
                },
                a: function(t) {
                    return t < 0 ? Math.ceil(t) || 0 : Math.floor(t)
                },
                p: function(t) {
                    return ({
                        M: s,
                        y: l,
                        w: o,
                        d: "day",
                        D: c,
                        h: i,
                        m: r,
                        s: n,
                        ms: e,
                        Q: a
                    })[t] || String(t || "").toLowerCase().replace(/s$/, "")
                },
                u: function(t) {
                    return void 0 === t
                }
            }).l = y, w.i = g, w.w = function(t, e) {
                return v(t, {
                    locale: e.$L,
                    utc: e.$u,
                    x: e.$x,
                    $offset: e.$offset
                })
            }, x = (b = function() {
                function t(t) {
                    this.$L = y(t.locale, null, !0), this.parse(t)
                }
                var d = t.prototype;
                return d.parse = function(t) {
                    this.$d = function(t) {
                        var e = t.date,
                            n = t.utc;
                        if (null === e) return new Date(NaN);
                        if (w.u(e)) return new Date;
                        if (e instanceof Date) return new Date(e);
                        if ("string" == typeof e && !/Z$/i.test(e)) {
                            var r = e.match(h);
                            if (r) {
                                var i = r[2] - 1 || 0,
                                    o = (r[7] || "0").substring(0, 3);
                                return n ? new Date(Date.UTC(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, o)) : new Date(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, o)
                            }
                        }
                        return new Date(e)
                    }(t), this.$x = t.x || {}, this.init()
                }, d.init = function() {
                    var t = this.$d;
                    this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds()
                }, d.$utils = function() {
                    return w
                }, d.isValid = function() {
                    return this.$d.toString() !== u
                }, d.isSame = function(t, e) {
                    var n = v(t);
                    return this.startOf(e) <= n && n <= this.endOf(e)
                }, d.isAfter = function(t, e) {
                    return v(t) < this.startOf(e)
                }, d.isBefore = function(t, e) {
                    return this.endOf(e) < v(t)
                }, d.$g = function(t, e, n) {
                    return w.u(t) ? this[e] : this.set(n, t)
                }, d.unix = function() {
                    return Math.floor(this.valueOf() / 1e3)
                }, d.valueOf = function() {
                    return this.$d.getTime()
                }, d.startOf = function(t, e) {
                    var a = this,
                        u = !!w.u(e) || e,
                        h = w.p(t),
                        p = function(t, e) {
                            var n = w.w(a.$u ? Date.UTC(a.$y, e, t) : new Date(a.$y, e, t), a);
                            return u ? n : n.endOf("day")
                        },
                        d = function(t, e) {
                            return w.w(a.toDate()[t].apply(a.toDate("s"), (u ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e)), a)
                        },
                        f = this.$W,
                        m = this.$M,
                        g = this.$D,
                        y = "set" + (this.$u ? "UTC" : "");
                    switch (h) {
                        case l:
                            return u ? p(1, 0) : p(31, 11);
                        case s:
                            return u ? p(1, m) : p(0, m + 1);
                        case o:
                            var v = this.$locale().weekStart || 0,
                                b = (f < v ? f + 7 : f) - v;
                            return p(u ? g - b : g + (6 - b), m);
                        case "day":
                        case c:
                            return d(y + "Hours", 0);
                        case i:
                            return d(y + "Minutes", 1);
                        case r:
                            return d(y + "Seconds", 2);
                        case n:
                            return d(y + "Milliseconds", 3);
                        default:
                            return this.clone()
                    }
                }, d.endOf = function(t) {
                    return this.startOf(t, !1)
                }, d.$set = function(t, o) {
                    var a, u = w.p(t),
                        h = "set" + (this.$u ? "UTC" : ""),
                        p = ((a = {}).day = h + "Date", a[c] = h + "Date", a[s] = h + "Month", a[l] = h + "FullYear", a[i] = h + "Hours", a[r] = h + "Minutes", a[n] = h + "Seconds", a[e] = h + "Milliseconds", a)[u],
                        d = "day" === u ? this.$D + (o - this.$W) : o;
                    if (u === s || u === l) {
                        var f = this.clone().set(c, 1);
                        f.$d[p](d), f.init(), this.$d = f.set(c, Math.min(this.$D, f.daysInMonth())).$d
                    } else p && this.$d[p](d);
                    return this.init(), this
                }, d.set = function(t, e) {
                    return this.clone().$set(t, e)
                }, d.get = function(t) {
                    return this[w.p(t)]()
                }, d.add = function(t, e) {
                    var a, c = this;
                    t = Number(t);
                    var u = w.p(e),
                        h = function(e) {
                            var n = v(c);
                            return w.w(n.date(n.date() + Math.round(e * t)), c)
                        };
                    if (u === s) return this.set(s, this.$M + t);
                    if (u === l) return this.set(l, this.$y + t);
                    if ("day" === u) return h(1);
                    if (u === o) return h(7);
                    var p = ((a = {})[r] = 6e4, a[i] = 36e5, a[n] = 1e3, a)[u] || 1,
                        d = this.$d.getTime() + t * p;
                    return w.w(d, this)
                }, d.subtract = function(t, e) {
                    return this.add(-1 * t, e)
                }, d.format = function(t) {
                    var e = this,
                        n = this.$locale();
                    if (!this.isValid()) return n.invalidDate || u;
                    var r = t || "YYYY-MM-DDTHH:mm:ssZ",
                        i = w.z(this),
                        o = this.$H,
                        s = this.$m,
                        a = this.$M,
                        l = n.weekdays,
                        c = n.months,
                        h = function(t, n, i, o) {
                            return t && (t[n] || t(e, r)) || i[n].slice(0, o)
                        },
                        d = function(t) {
                            return w.s(o % 12 || 12, t, "0")
                        },
                        f = n.meridiem || function(t, e, n) {
                            var r = t < 12 ? "AM" : "PM";
                            return n ? r.toLowerCase() : r
                        },
                        m = {
                            YY: String(this.$y).slice(-2),
                            YYYY: this.$y,
                            M: a + 1,
                            MM: w.s(a + 1, 2, "0"),
                            MMM: h(n.monthsShort, a, c, 3),
                            MMMM: h(c, a),
                            D: this.$D,
                            DD: w.s(this.$D, 2, "0"),
                            d: String(this.$W),
                            dd: h(n.weekdaysMin, this.$W, l, 2),
                            ddd: h(n.weekdaysShort, this.$W, l, 3),
                            dddd: l[this.$W],
                            H: String(o),
                            HH: w.s(o, 2, "0"),
                            h: d(1),
                            hh: d(2),
                            a: f(o, s, !0),
                            A: f(o, s, !1),
                            m: String(s),
                            mm: w.s(s, 2, "0"),
                            s: String(this.$s),
                            ss: w.s(this.$s, 2, "0"),
                            SSS: w.s(this.$ms, 3, "0"),
                            Z: i
                        };
                    return r.replace(p, function(t, e) {
                        return e || m[t] || i.replace(":", "")
                    })
                }, d.utcOffset = function() {
                    return -(15 * Math.round(this.$d.getTimezoneOffset() / 15))
                }, d.diff = function(t, e, c) {
                    var u, h = w.p(e),
                        p = v(t),
                        d = (p.utcOffset() - this.utcOffset()) * 6e4,
                        f = this - p,
                        m = w.m(this, p);
                    return m = ((u = {})[l] = m / 12, u[s] = m, u[a] = m / 3, u[o] = (f - d) / 6048e5, u.day = (f - d) / 864e5, u[i] = f / 36e5, u[r] = f / 6e4, u[n] = f / 1e3, u)[h] || f, c ? m : w.a(m)
                }, d.daysInMonth = function() {
                    return this.endOf(s).$D
                }, d.$locale = function() {
                    return m[this.$L]
                }, d.locale = function(t, e) {
                    if (!t) return this.$L;
                    var n = this.clone(),
                        r = y(t, e, !0);
                    return r && (n.$L = r), n
                }, d.clone = function() {
                    return w.w(this.$d, this)
                }, d.toDate = function() {
                    return new Date(this.valueOf())
                }, d.toJSON = function() {
                    return this.isValid() ? this.toISOString() : null
                }, d.toISOString = function() {
                    return this.$d.toISOString()
                }, d.toString = function() {
                    return this.$d.toUTCString()
                }, t
            }()).prototype, v.prototype = x, [
                ["$ms", e],
                ["$s", n],
                ["$m", r],
                ["$H", i],
                ["$W", "day"],
                ["$M", s],
                ["$y", l],
                ["$D", c]
            ].forEach(function(t) {
                x[t[1]] = function(e) {
                    return this.$g(e, t[0], t[1])
                }
            }), v.extend = function(t, e) {
                return t.$i || (t(e, b, v), t.$i = !0), v
            }, v.locale = y, v.isDayjs = g, v.unix = function(t) {
                return v(1e3 * t)
            }, v.en = m[f], v.Ls = m, v.p = {}, v)
        },
        10366: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.suspense = function() {
                let t = Error(r.NEXT_DYNAMIC_NO_SSR_CODE);
                throw t.digest = r.NEXT_DYNAMIC_NO_SSR_CODE, t
            }, e.NoSSR = function(t) {
                let {
                    children: e
                } = t;
                return e
            }, (0, n(23903).Z)(n(2784));
            var r = n(17821)
        },
        55263: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = function(t, e) {
                let n = o.default,
                    i = {
                        loading: t => {
                            let {
                                error: e,
                                isLoading: n,
                                pastDelay: r
                            } = t;
                            return null
                        }
                    };
                t instanceof Promise ? i.loader = () => t : "function" == typeof t ? i.loader = t : "object" == typeof t && (i = r({}, i, t)), i = r({}, i, e);
                let a = i.loader,
                    l = () => null != a ? a().then(s) : Promise.resolve(s(() => null));
                return i.loadableGenerated && delete(i = r({}, i, i.loadableGenerated)).loadableGenerated, "boolean" != typeof i.ssr || i.ssr || (delete i.webpack, delete i.modules), n(r({}, i, {
                    loader: l
                }))
            };
            var r = n(59419).Z,
                i = n(23903).Z;
            i(n(2784));
            var o = i(n(55933));

            function s(t) {
                return {
                    default: (null == t ? void 0 : t.default) || t
                }
            }("function" == typeof e.default || "object" == typeof e.default && null !== e.default) && void 0 === e.default.__esModule && (Object.defineProperty(e.default, "__esModule", {
                value: !0
            }), Object.assign(e.default, e), t.exports = e.default)
        },
        34798: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.LoadableContext = void 0;
            var r = (0, n(23903).Z)(n(2784));
            let i = r.default.createContext(null);
            e.LoadableContext = i
        },
        55933: function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = n(18282).Z,
                i = n(59419).Z,
                o = (0, n(23903).Z)(n(2784)),
                s = n(10366),
                a = n(34798);
            let l = [],
                c = [],
                u = !1;

            function h(t) {
                let e = t(),
                    n = {
                        loading: !0,
                        loaded: null,
                        error: null
                    };
                return n.promise = e.then(t => (n.loading = !1, n.loaded = t, t)).catch(t => {
                    throw n.loading = !1, n.error = t, t
                }), n
            }
            class p {
                promise() {
                    return this._res.promise
                }
                retry() {
                    this._clearTimeouts(), this._res = this._loadFn(this._opts.loader), this._state = {
                        pastDelay: !1,
                        timedOut: !1
                    };
                    let {
                        _res: t,
                        _opts: e
                    } = this;
                    t.loading && ("number" == typeof e.delay && (0 === e.delay ? this._state.pastDelay = !0 : this._delay = setTimeout(() => {
                        this._update({
                            pastDelay: !0
                        })
                    }, e.delay)), "number" == typeof e.timeout && (this._timeout = setTimeout(() => {
                        this._update({
                            timedOut: !0
                        })
                    }, e.timeout))), this._res.promise.then(() => {
                        this._update({}), this._clearTimeouts()
                    }).catch(t => {
                        this._update({}), this._clearTimeouts()
                    }), this._update({})
                }
                _update(t) {
                    this._state = i({}, this._state, {
                        error: this._res.error,
                        loaded: this._res.loaded,
                        loading: this._res.loading
                    }, t), this._callbacks.forEach(t => t())
                }
                _clearTimeouts() {
                    clearTimeout(this._delay), clearTimeout(this._timeout)
                }
                getCurrentValue() {
                    return this._state
                }
                subscribe(t) {
                    return this._callbacks.add(t), () => {
                        this._callbacks.delete(t)
                    }
                }
                constructor(t, e) {
                    this._loadFn = t, this._opts = e, this._callbacks = new Set, this._delay = null, this._timeout = null, this.retry()
                }
            }

            function d(t) {
                return function(t, e) {
                    let n = Object.assign({
                            loader: null,
                            loading: null,
                            delay: 200,
                            timeout: null,
                            webpack: null,
                            modules: null,
                            ssr: !0
                        }, e),
                        i = null;

                    function l() {
                        if (!i) {
                            let e = new p(t, n);
                            i = {
                                getCurrentValue: e.getCurrentValue.bind(e),
                                subscribe: e.subscribe.bind(e),
                                retry: e.retry.bind(e),
                                promise: e.promise.bind(e)
                            }
                        }
                        return i.promise()
                    }
                    if (n.lazy = o.default.lazy(r(function*() {
                            if (n.ssr && i) {
                                let t = i.getCurrentValue(),
                                    e = yield t.loaded;
                                if (e) return e
                            }
                            return yield n.loader()
                        })), !u) {
                        let t = n.webpack ? n.webpack() : n.modules;
                        t && c.push(e => {
                            for (let n of t)
                                if (-1 !== e.indexOf(n)) return l()
                        })
                    }

                    function h(t) {
                        ! function() {
                            l();
                            let t = o.default.useContext(a.LoadableContext);
                            t && Array.isArray(n.modules) && n.modules.forEach(e => {
                                t(e)
                            })
                        }();
                        let e = n.loading,
                            r = o.default.createElement(e, {
                                isLoading: !0,
                                pastDelay: !0,
                                error: null
                            }),
                            i = n.ssr ? o.default.Fragment : s.NoSSR,
                            c = n.lazy;
                        return o.default.createElement(o.default.Suspense, {
                            fallback: r
                        }, o.default.createElement(i, null, o.default.createElement(c, Object.assign({}, t))))
                    }
                    return h.preload = () => l(), h.displayName = "LoadableComponent", h
                }(h, t)
            }

            function f(t, e) {
                let n = [];
                for (; t.length;) {
                    let r = t.pop();
                    n.push(r(e))
                }
                return Promise.all(n).then(() => {
                    if (t.length) return f(t, e)
                })
            }
            d.preloadAll = () => new Promise((t, e) => {
                f(l).then(t, e)
            }), d.preloadReady = function() {
                let t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                return new Promise(e => {
                    let n = () => (u = !0, e());
                    f(c, t).then(n, n)
                })
            }, window.__NEXT_PRELOADREADY = d.preloadReady, e.default = d
        },
        25237: function(t, e, n) {
            t.exports = n(55263)
        },
        28638: function(t, e, n) {
            "use strict";

            function r(t) {
                this.content = t
            }
            n.d(e, {
                aw: function() {
                    return W
                },
                PW: function() {
                    return tr
                },
                HY: function() {
                    return i
                },
                vc: function() {
                    return c
                },
                ZU: function() {
                    return V
                },
                NB: function() {
                    return N
                },
                Ts: function() {
                    return M
                },
                e4: function() {
                    return u
                },
                V_: function() {
                    return Y
                },
                p2: function() {
                    return h
                }
            }), r.prototype = {
                constructor: r,
                find: function(t) {
                    for (var e = 0; e < this.content.length; e += 2)
                        if (this.content[e] === t) return e;
                    return -1
                },
                get: function(t) {
                    var e = this.find(t);
                    return -1 == e ? void 0 : this.content[e + 1]
                },
                update: function(t, e, n) {
                    var i = n && n != t ? this.remove(n) : this,
                        o = i.find(t),
                        s = i.content.slice();
                    return -1 == o ? s.push(n || t, e) : (s[o + 1] = e, n && (s[o] = n)), new r(s)
                },
                remove: function(t) {
                    var e = this.find(t);
                    if (-1 == e) return this;
                    var n = this.content.slice();
                    return n.splice(e, 2), new r(n)
                },
                addToStart: function(t, e) {
                    return new r([t, e].concat(this.remove(t).content))
                },
                addToEnd: function(t, e) {
                    var n = this.remove(t).content.slice();
                    return n.push(t, e), new r(n)
                },
                addBefore: function(t, e, n) {
                    var i = this.remove(e),
                        o = i.content.slice(),
                        s = i.find(t);
                    return o.splice(-1 == s ? o.length : s, 0, e, n), new r(o)
                },
                forEach: function(t) {
                    for (var e = 0; e < this.content.length; e += 2) t(this.content[e], this.content[e + 1])
                },
                prepend: function(t) {
                    return (t = r.from(t)).size ? new r(t.content.concat(this.subtract(t).content)) : this
                },
                append: function(t) {
                    return (t = r.from(t)).size ? new r(this.subtract(t).content.concat(t.content)) : this
                },
                subtract: function(t) {
                    var e = this;
                    t = r.from(t);
                    for (var n = 0; n < t.content.length; n += 2) e = e.remove(t.content[n]);
                    return e
                },
                get size() {
                    return this.content.length >> 1
                }
            }, r.from = function(t) {
                if (t instanceof r) return t;
                var e = [];
                if (t)
                    for (var n in t) e.push(n, t[n]);
                return new r(e)
            };
            var i = function(t, e) {
                    if (this.content = t, this.size = e || 0, null == e)
                        for (var n = 0; n < t.length; n++) this.size += t[n].nodeSize
                },
                o = {
                    firstChild: {
                        configurable: !0
                    },
                    lastChild: {
                        configurable: !0
                    },
                    childCount: {
                        configurable: !0
                    }
                };
            i.prototype.nodesBetween = function(t, e, n, r, i) {
                void 0 === r && (r = 0);
                for (var o = 0, s = 0; s < e; o++) {
                    var a = this.content[o],
                        l = s + a.nodeSize;
                    if (l > t && !1 !== n(a, r + s, i, o) && a.content.size) {
                        var c = s + 1;
                        a.nodesBetween(Math.max(0, t - c), Math.min(a.content.size, e - c), n, r + c)
                    }
                    s = l
                }
            }, i.prototype.descendants = function(t) {
                this.nodesBetween(0, this.size, t)
            }, i.prototype.textBetween = function(t, e, n, r) {
                var i = "",
                    o = !0;
                return this.nodesBetween(t, e, function(s, a) {
                    s.isText ? (i += s.text.slice(Math.max(t, a) - a, e - a), o = !n) : s.isLeaf && r ? (i += "function" == typeof r ? r(s) : r, o = !n) : !o && s.isBlock && (i += n, o = !0)
                }, 0), i
            }, i.prototype.append = function(t) {
                if (!t.size) return this;
                if (!this.size) return t;
                var e = this.lastChild,
                    n = t.firstChild,
                    r = this.content.slice(),
                    o = 0;
                for (e.isText && e.sameMarkup(n) && (r[r.length - 1] = e.withText(e.text + n.text), o = 1); o < t.content.length; o++) r.push(t.content[o]);
                return new i(r, this.size + t.size)
            }, i.prototype.cut = function(t, e) {
                if (null == e && (e = this.size), 0 == t && e == this.size) return this;
                var n = [],
                    r = 0;
                if (e > t)
                    for (var o = 0, s = 0; s < e; o++) {
                        var a = this.content[o],
                            l = s + a.nodeSize;
                        l > t && ((s < t || l > e) && (a = a.isText ? a.cut(Math.max(0, t - s), Math.min(a.text.length, e - s)) : a.cut(Math.max(0, t - s - 1), Math.min(a.content.size, e - s - 1))), n.push(a), r += a.nodeSize), s = l
                    }
                return new i(n, r)
            }, i.prototype.cutByIndex = function(t, e) {
                return t == e ? i.empty : 0 == t && e == this.content.length ? this : new i(this.content.slice(t, e))
            }, i.prototype.replaceChild = function(t, e) {
                var n = this.content[t];
                if (n == e) return this;
                var r = this.content.slice(),
                    o = this.size + e.nodeSize - n.nodeSize;
                return r[t] = e, new i(r, o)
            }, i.prototype.addToStart = function(t) {
                return new i([t].concat(this.content), this.size + t.nodeSize)
            }, i.prototype.addToEnd = function(t) {
                return new i(this.content.concat(t), this.size + t.nodeSize)
            }, i.prototype.eq = function(t) {
                if (this.content.length != t.content.length) return !1;
                for (var e = 0; e < this.content.length; e++)
                    if (!this.content[e].eq(t.content[e])) return !1;
                return !0
            }, o.firstChild.get = function() {
                return this.content.length ? this.content[0] : null
            }, o.lastChild.get = function() {
                return this.content.length ? this.content[this.content.length - 1] : null
            }, o.childCount.get = function() {
                return this.content.length
            }, i.prototype.child = function(t) {
                var e = this.content[t];
                if (!e) throw RangeError("Index " + t + " out of range for " + this);
                return e
            }, i.prototype.maybeChild = function(t) {
                return this.content[t]
            }, i.prototype.forEach = function(t) {
                for (var e = 0, n = 0; e < this.content.length; e++) {
                    var r = this.content[e];
                    t(r, n, e), n += r.nodeSize
                }
            }, i.prototype.findDiffStart = function(t, e) {
                return void 0 === e && (e = 0),
                    function t(e, n, r) {
                        for (var i = 0;; i++) {
                            if (i == e.childCount || i == n.childCount) return e.childCount == n.childCount ? null : r;
                            var o = e.child(i),
                                s = n.child(i);
                            if (o == s) {
                                r += o.nodeSize;
                                continue
                            }
                            if (!o.sameMarkup(s)) return r;
                            if (o.isText && o.text != s.text) {
                                for (var a = 0; o.text[a] == s.text[a]; a++) r++;
                                return r
                            }
                            if (o.content.size || s.content.size) {
                                var l = t(o.content, s.content, r + 1);
                                if (null != l) return l
                            }
                            r += o.nodeSize
                        }
                    }(this, t, e)
            }, i.prototype.findDiffEnd = function(t, e, n) {
                return void 0 === e && (e = this.size), void 0 === n && (n = t.size),
                    function t(e, n, r, i) {
                        for (var o = e.childCount, s = n.childCount;;) {
                            if (0 == o || 0 == s) return o == s ? null : {
                                a: r,
                                b: i
                            };
                            var a = e.child(--o),
                                l = n.child(--s),
                                c = a.nodeSize;
                            if (a == l) {
                                r -= c, i -= c;
                                continue
                            }
                            if (!a.sameMarkup(l)) return {
                                a: r,
                                b: i
                            };
                            if (a.isText && a.text != l.text) {
                                for (var u = 0, h = Math.min(a.text.length, l.text.length); u < h && a.text[a.text.length - u - 1] == l.text[l.text.length - u - 1];) u++, r--, i--;
                                return {
                                    a: r,
                                    b: i
                                }
                            }
                            if (a.content.size || l.content.size) {
                                var p = t(a.content, l.content, r - 1, i - 1);
                                if (p) return p
                            }
                            r -= c, i -= c
                        }
                    }(this, t, e, n)
            }, i.prototype.findIndex = function(t, e) {
                if (void 0 === e && (e = -1), 0 == t) return a(0, t);
                if (t == this.size) return a(this.content.length, t);
                if (t > this.size || t < 0) throw RangeError("Position " + t + " outside of fragment (" + this + ")");
                for (var n = 0, r = 0;; n++) {
                    var i = r + this.child(n).nodeSize;
                    if (i >= t) {
                        if (i == t || e > 0) return a(n + 1, i);
                        return a(n, r)
                    }
                    r = i
                }
            }, i.prototype.toString = function() {
                return "<" + this.toStringInner() + ">"
            }, i.prototype.toStringInner = function() {
                return this.content.join(", ")
            }, i.prototype.toJSON = function() {
                return this.content.length ? this.content.map(function(t) {
                    return t.toJSON()
                }) : null
            }, i.fromJSON = function(t, e) {
                if (!e) return i.empty;
                if (!Array.isArray(e)) throw RangeError("Invalid input for Fragment.fromJSON");
                return new i(e.map(t.nodeFromJSON))
            }, i.fromArray = function(t) {
                if (!t.length) return i.empty;
                for (var e, n = 0, r = 0; r < t.length; r++) {
                    var o = t[r];
                    n += o.nodeSize, r && o.isText && t[r - 1].sameMarkup(o) ? (e || (e = t.slice(0, r)), e[e.length - 1] = o.withText(e[e.length - 1].text + o.text)) : e && e.push(o)
                }
                return new i(e || t, n)
            }, i.from = function(t) {
                if (!t) return i.empty;
                if (t instanceof i) return t;
                if (Array.isArray(t)) return this.fromArray(t);
                if (t.attrs) return new i([t], t.nodeSize);
                throw RangeError("Can not convert " + t + " to a Fragment" + (t.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""))
            }, Object.defineProperties(i.prototype, o);
            var s = {
                index: 0,
                offset: 0
            };

            function a(t, e) {
                return s.index = t, s.offset = e, s
            }

            function l(t, e) {
                if (t === e) return !0;
                if (!(t && "object" == typeof t) || !(e && "object" == typeof e)) return !1;
                var n = Array.isArray(t);
                if (Array.isArray(e) != n) return !1;
                if (n) {
                    if (t.length != e.length) return !1;
                    for (var r = 0; r < t.length; r++)
                        if (!l(t[r], e[r])) return !1
                } else {
                    for (var i in t)
                        if (!(i in e) || !l(t[i], e[i])) return !1;
                    for (var o in e)
                        if (!(o in t)) return !1
                }
                return !0
            }
            i.empty = new i([], 0);
            var c = function(t, e) {
                this.type = t, this.attrs = e
            };

            function u(t) {
                var e = Error.call(this, t);
                return e.__proto__ = u.prototype, e
            }
            c.prototype.addToSet = function(t) {
                for (var e, n = !1, r = 0; r < t.length; r++) {
                    var i = t[r];
                    if (this.eq(i)) return t;
                    if (this.type.excludes(i.type)) e || (e = t.slice(0, r));
                    else {
                        if (i.type.excludes(this.type)) return t;
                        !n && i.type.rank > this.type.rank && (e || (e = t.slice(0, r)), e.push(this), n = !0), e && e.push(i)
                    }
                }
                return e || (e = t.slice()), n || e.push(this), e
            }, c.prototype.removeFromSet = function(t) {
                for (var e = 0; e < t.length; e++)
                    if (this.eq(t[e])) return t.slice(0, e).concat(t.slice(e + 1));
                return t
            }, c.prototype.isInSet = function(t) {
                for (var e = 0; e < t.length; e++)
                    if (this.eq(t[e])) return !0;
                return !1
            }, c.prototype.eq = function(t) {
                return this == t || this.type == t.type && l(this.attrs, t.attrs)
            }, c.prototype.toJSON = function() {
                var t = {
                    type: this.type.name
                };
                for (var e in this.attrs) {
                    t.attrs = this.attrs;
                    break
                }
                return t
            }, c.fromJSON = function(t, e) {
                if (!e) throw RangeError("Invalid input for Mark.fromJSON");
                var n = t.marks[e.type];
                if (!n) throw RangeError("There is no mark type " + e.type + " in this schema");
                return n.create(e.attrs)
            }, c.sameSet = function(t, e) {
                if (t == e) return !0;
                if (t.length != e.length) return !1;
                for (var n = 0; n < t.length; n++)
                    if (!t[n].eq(e[n])) return !1;
                return !0
            }, c.setFrom = function(t) {
                if (!t || 0 == t.length) return c.none;
                if (t instanceof c) return [t];
                var e = t.slice();
                return e.sort(function(t, e) {
                    return t.type.rank - e.type.rank
                }), e
            }, c.none = [], u.prototype = Object.create(Error.prototype), u.prototype.constructor = u, u.prototype.name = "ReplaceError";
            var h = function(t, e, n) {
                    this.content = t, this.openStart = e, this.openEnd = n
                },
                p = {
                    size: {
                        configurable: !0
                    }
                };

            function d(t, e) {
                if (!e.type.compatibleContent(t.type)) throw new u("Cannot join " + e.type.name + " onto " + t.type.name)
            }

            function f(t, e, n) {
                var r = t.node(n);
                return d(r, e.node(n)), r
            }

            function m(t, e) {
                var n = e.length - 1;
                n >= 0 && t.isText && t.sameMarkup(e[n]) ? e[n] = t.withText(e[n].text + t.text) : e.push(t)
            }

            function g(t, e, n, r) {
                var i = (e || t).node(n),
                    o = 0,
                    s = e ? e.index(n) : i.childCount;
                t && (o = t.index(n), t.depth > n ? o++ : t.textOffset && (m(t.nodeAfter, r), o++));
                for (var a = o; a < s; a++) m(i.child(a), r);
                e && e.depth == n && e.textOffset && m(e.nodeBefore, r)
            }

            function y(t, e) {
                if (!t.type.validContent(e)) throw new u("Invalid content for node " + t.type.name);
                return t.copy(e)
            }

            function v(t, e, n) {
                var r = [];
                return g(null, t, n, r), t.depth > n && m(y(f(t, e, n + 1), v(t, e, n + 1)), r), g(e, null, n, r), new i(r)
            }
            p.size.get = function() {
                return this.content.size - this.openStart - this.openEnd
            }, h.prototype.insertAt = function(t, e) {
                var n = function t(e, n, r, i) {
                    var o = e.findIndex(n),
                        s = o.index,
                        a = o.offset,
                        l = e.maybeChild(s);
                    if (a == n || l.isText) return i && !i.canReplace(s, s, r) ? null : e.cut(0, n).append(r).append(e.cut(n));
                    var c = t(l.content, n - a - 1, r);
                    return c && e.replaceChild(s, l.copy(c))
                }(this.content, t + this.openStart, e, null);
                return n && new h(n, this.openStart, this.openEnd)
            }, h.prototype.removeBetween = function(t, e) {
                return new h(function t(e, n, r) {
                    var i = e.findIndex(n),
                        o = i.index,
                        s = i.offset,
                        a = e.maybeChild(o),
                        l = e.findIndex(r),
                        c = l.index,
                        u = l.offset;
                    if (s == n || a.isText) {
                        if (u != r && !e.child(c).isText) throw RangeError("Removing non-flat range");
                        return e.cut(0, n).append(e.cut(r))
                    }
                    if (o != c) throw RangeError("Removing non-flat range");
                    return e.replaceChild(o, a.copy(t(a.content, n - s - 1, r - s - 1)))
                }(this.content, t + this.openStart, e + this.openStart), this.openStart, this.openEnd)
            }, h.prototype.eq = function(t) {
                return this.content.eq(t.content) && this.openStart == t.openStart && this.openEnd == t.openEnd
            }, h.prototype.toString = function() {
                return this.content + "(" + this.openStart + "," + this.openEnd + ")"
            }, h.prototype.toJSON = function() {
                if (!this.content.size) return null;
                var t = {
                    content: this.content.toJSON()
                };
                return this.openStart > 0 && (t.openStart = this.openStart), this.openEnd > 0 && (t.openEnd = this.openEnd), t
            }, h.fromJSON = function(t, e) {
                if (!e) return h.empty;
                var n = e.openStart || 0,
                    r = e.openEnd || 0;
                if ("number" != typeof n || "number" != typeof r) throw RangeError("Invalid input for Slice.fromJSON");
                return new h(i.fromJSON(t, e.content), n, r)
            }, h.maxOpen = function(t, e) {
                void 0 === e && (e = !0);
                for (var n = 0, r = 0, i = t.firstChild; i && !i.isLeaf && (e || !i.type.spec.isolating); i = i.firstChild) n++;
                for (var o = t.lastChild; o && !o.isLeaf && (e || !o.type.spec.isolating); o = o.lastChild) r++;
                return new h(t, n, r)
            }, Object.defineProperties(h.prototype, p), h.empty = new h(i.empty, 0, 0);
            var w = function(t, e, n) {
                    this.pos = t, this.path = e, this.depth = e.length / 3 - 1, this.parentOffset = n
                },
                b = {
                    parent: {
                        configurable: !0
                    },
                    doc: {
                        configurable: !0
                    },
                    textOffset: {
                        configurable: !0
                    },
                    nodeAfter: {
                        configurable: !0
                    },
                    nodeBefore: {
                        configurable: !0
                    }
                };
            w.prototype.resolveDepth = function(t) {
                return null == t ? this.depth : t < 0 ? this.depth + t : t
            }, b.parent.get = function() {
                return this.node(this.depth)
            }, b.doc.get = function() {
                return this.node(0)
            }, w.prototype.node = function(t) {
                return this.path[3 * this.resolveDepth(t)]
            }, w.prototype.index = function(t) {
                return this.path[3 * this.resolveDepth(t) + 1]
            }, w.prototype.indexAfter = function(t) {
                return t = this.resolveDepth(t), this.index(t) + (t != this.depth || this.textOffset ? 1 : 0)
            }, w.prototype.start = function(t) {
                return 0 == (t = this.resolveDepth(t)) ? 0 : this.path[3 * t - 1] + 1
            }, w.prototype.end = function(t) {
                return t = this.resolveDepth(t), this.start(t) + this.node(t).content.size
            }, w.prototype.before = function(t) {
                if (!(t = this.resolveDepth(t))) throw RangeError("There is no position before the top-level node");
                return t == this.depth + 1 ? this.pos : this.path[3 * t - 1]
            }, w.prototype.after = function(t) {
                if (!(t = this.resolveDepth(t))) throw RangeError("There is no position after the top-level node");
                return t == this.depth + 1 ? this.pos : this.path[3 * t - 1] + this.path[3 * t].nodeSize
            }, b.textOffset.get = function() {
                return this.pos - this.path[this.path.length - 1]
            }, b.nodeAfter.get = function() {
                var t = this.parent,
                    e = this.index(this.depth);
                if (e == t.childCount) return null;
                var n = this.pos - this.path[this.path.length - 1],
                    r = t.child(e);
                return n ? t.child(e).cut(n) : r
            }, b.nodeBefore.get = function() {
                var t = this.index(this.depth),
                    e = this.pos - this.path[this.path.length - 1];
                return e ? this.parent.child(t).cut(0, e) : 0 == t ? null : this.parent.child(t - 1)
            }, w.prototype.posAtIndex = function(t, e) {
                e = this.resolveDepth(e);
                for (var n = this.path[3 * e], r = 0 == e ? 0 : this.path[3 * e - 1] + 1, i = 0; i < t; i++) r += n.child(i).nodeSize;
                return r
            }, w.prototype.marks = function() {
                var t = this.parent,
                    e = this.index();
                if (0 == t.content.size) return c.none;
                if (this.textOffset) return t.child(e).marks;
                var n = t.maybeChild(e - 1),
                    r = t.maybeChild(e);
                if (!n) {
                    var i = n;
                    n = r, r = i
                }
                for (var o = n.marks, s = 0; s < o.length; s++) !1 !== o[s].type.spec.inclusive || r && o[s].isInSet(r.marks) || (o = o[s--].removeFromSet(o));
                return o
            }, w.prototype.marksAcross = function(t) {
                var e = this.parent.maybeChild(this.index());
                if (!e || !e.isInline) return null;
                for (var n = e.marks, r = t.parent.maybeChild(t.index()), i = 0; i < n.length; i++) !1 !== n[i].type.spec.inclusive || r && n[i].isInSet(r.marks) || (n = n[i--].removeFromSet(n));
                return n
            }, w.prototype.sharedDepth = function(t) {
                for (var e = this.depth; e > 0; e--)
                    if (this.start(e) <= t && this.end(e) >= t) return e;
                return 0
            }, w.prototype.blockRange = function(t, e) {
                if (void 0 === t && (t = this), t.pos < this.pos) return t.blockRange(this);
                for (var n = this.depth - (this.parent.inlineContent || this.pos == t.pos ? 1 : 0); n >= 0; n--)
                    if (t.pos <= this.end(n) && (!e || e(this.node(n)))) return new M(this, t, n)
            }, w.prototype.sameParent = function(t) {
                return this.pos - this.parentOffset == t.pos - t.parentOffset
            }, w.prototype.max = function(t) {
                return t.pos > this.pos ? t : this
            }, w.prototype.min = function(t) {
                return t.pos < this.pos ? t : this
            }, w.prototype.toString = function() {
                for (var t = "", e = 1; e <= this.depth; e++) t += (t ? "/" : "") + this.node(e).type.name + "_" + this.index(e - 1);
                return t + ":" + this.parentOffset
            }, w.resolve = function(t, e) {
                if (!(e >= 0 && e <= t.content.size)) throw RangeError("Position " + e + " out of range");
                for (var n = [], r = 0, i = e, o = t;;) {
                    var s = o.content.findIndex(i),
                        a = s.index,
                        l = s.offset,
                        c = i - l;
                    if (n.push(o, a, r + l), !c || (o = o.child(a)).isText) break;
                    i = c - 1, r += l + 1
                }
                return new w(e, n, i)
            }, w.resolveCached = function(t, e) {
                for (var n = 0; n < x.length; n++) {
                    var r = x[n];
                    if (r.pos == e && r.doc == t) return r
                }
                var i = x[k] = w.resolve(t, e);
                return k = (k + 1) % S, i
            }, Object.defineProperties(w.prototype, b);
            var x = [],
                k = 0,
                S = 12,
                M = function(t, e, n) {
                    this.$from = t, this.$to = e, this.depth = n
                },
                C = {
                    start: {
                        configurable: !0
                    },
                    end: {
                        configurable: !0
                    },
                    parent: {
                        configurable: !0
                    },
                    startIndex: {
                        configurable: !0
                    },
                    endIndex: {
                        configurable: !0
                    }
                };
            C.start.get = function() {
                return this.$from.before(this.depth + 1)
            }, C.end.get = function() {
                return this.$to.after(this.depth + 1)
            }, C.parent.get = function() {
                return this.$from.node(this.depth)
            }, C.startIndex.get = function() {
                return this.$from.index(this.depth)
            }, C.endIndex.get = function() {
                return this.$to.indexAfter(this.depth)
            }, Object.defineProperties(M.prototype, C);
            var E = Object.create(null),
                N = function(t, e, n, r) {
                    this.type = t, this.attrs = e, this.content = n || i.empty, this.marks = r || c.none
                },
                O = {
                    nodeSize: {
                        configurable: !0
                    },
                    childCount: {
                        configurable: !0
                    },
                    textContent: {
                        configurable: !0
                    },
                    firstChild: {
                        configurable: !0
                    },
                    lastChild: {
                        configurable: !0
                    },
                    isBlock: {
                        configurable: !0
                    },
                    isTextblock: {
                        configurable: !0
                    },
                    inlineContent: {
                        configurable: !0
                    },
                    isInline: {
                        configurable: !0
                    },
                    isText: {
                        configurable: !0
                    },
                    isLeaf: {
                        configurable: !0
                    },
                    isAtom: {
                        configurable: !0
                    }
                };
            O.nodeSize.get = function() {
                return this.isLeaf ? 1 : 2 + this.content.size
            }, O.childCount.get = function() {
                return this.content.childCount
            }, N.prototype.child = function(t) {
                return this.content.child(t)
            }, N.prototype.maybeChild = function(t) {
                return this.content.maybeChild(t)
            }, N.prototype.forEach = function(t) {
                this.content.forEach(t)
            }, N.prototype.nodesBetween = function(t, e, n, r) {
                void 0 === r && (r = 0), this.content.nodesBetween(t, e, n, r, this)
            }, N.prototype.descendants = function(t) {
                this.nodesBetween(0, this.content.size, t)
            }, O.textContent.get = function() {
                return this.textBetween(0, this.content.size, "")
            }, N.prototype.textBetween = function(t, e, n, r) {
                return this.content.textBetween(t, e, n, r)
            }, O.firstChild.get = function() {
                return this.content.firstChild
            }, O.lastChild.get = function() {
                return this.content.lastChild
            }, N.prototype.eq = function(t) {
                return this == t || this.sameMarkup(t) && this.content.eq(t.content)
            }, N.prototype.sameMarkup = function(t) {
                return this.hasMarkup(t.type, t.attrs, t.marks)
            }, N.prototype.hasMarkup = function(t, e, n) {
                return this.type == t && l(this.attrs, e || t.defaultAttrs || E) && c.sameSet(this.marks, n || c.none)
            }, N.prototype.copy = function(t) {
                return (void 0 === t && (t = null), t == this.content) ? this : new this.constructor(this.type, this.attrs, t, this.marks)
            }, N.prototype.mark = function(t) {
                return t == this.marks ? this : new this.constructor(this.type, this.attrs, this.content, t)
            }, N.prototype.cut = function(t, e) {
                return 0 == t && e == this.content.size ? this : this.copy(this.content.cut(t, e))
            }, N.prototype.slice = function(t, e, n) {
                if (void 0 === e && (e = this.content.size), void 0 === n && (n = !1), t == e) return h.empty;
                var r = this.resolve(t),
                    i = this.resolve(e),
                    o = n ? 0 : r.sharedDepth(e),
                    s = r.start(o),
                    a = r.node(o).content.cut(r.pos - s, i.pos - s);
                return new h(a, r.depth - o, i.depth - o)
            }, N.prototype.replace = function(t, e, n) {
                return function(t, e, n) {
                    if (n.openStart > t.depth) throw new u("Inserted content deeper than insertion position");
                    if (t.depth - n.openStart != e.depth - n.openEnd) throw new u("Inconsistent open depths");
                    return function t(e, n, r, o) {
                        var s = e.index(o),
                            a = e.node(o);
                        if (s == n.index(o) && o < e.depth - r.openStart) {
                            var l = t(e, n, r, o + 1);
                            return a.copy(a.content.replaceChild(s, l))
                        }
                        if (!r.content.size) return y(a, v(e, n, o));
                        if (r.openStart || r.openEnd || e.depth != o || n.depth != o) {
                            var c = function(t, e) {
                                    for (var n = e.depth - t.openStart, r = e.node(n).copy(t.content), o = n - 1; o >= 0; o--) r = e.node(o).copy(i.from(r));
                                    return {
                                        start: r.resolveNoCache(t.openStart + n),
                                        end: r.resolveNoCache(r.content.size - t.openEnd - n)
                                    }
                                }(r, e),
                                u = c.start,
                                h = c.end;
                            return y(a, function t(e, n, r, o, s) {
                                var a = e.depth > s && f(e, n, s + 1),
                                    l = o.depth > s && f(r, o, s + 1),
                                    c = [];
                                return g(null, e, s, c), a && l && n.index(s) == r.index(s) ? (d(a, l), m(y(a, t(e, n, r, o, s + 1)), c)) : (a && m(y(a, v(e, n, s + 1)), c), g(n, r, s, c), l && m(y(l, v(r, o, s + 1)), c)), g(o, null, s, c), new i(c)
                            }(e, u, h, n, o))
                        }
                        var p = e.parent,
                            w = p.content;
                        return y(p, w.cut(0, e.parentOffset).append(r.content).append(w.cut(n.parentOffset)))
                    }(t, e, n, 0)
                }(this.resolve(t), this.resolve(e), n)
            }, N.prototype.nodeAt = function(t) {
                for (var e = this;;) {
                    var n = e.content.findIndex(t),
                        r = n.index,
                        i = n.offset;
                    if (!(e = e.maybeChild(r))) return null;
                    if (i == t || e.isText) return e;
                    t -= i + 1
                }
            }, N.prototype.childAfter = function(t) {
                var e = this.content.findIndex(t),
                    n = e.index,
                    r = e.offset;
                return {
                    node: this.content.maybeChild(n),
                    index: n,
                    offset: r
                }
            }, N.prototype.childBefore = function(t) {
                if (0 == t) return {
                    node: null,
                    index: 0,
                    offset: 0
                };
                var e = this.content.findIndex(t),
                    n = e.index,
                    r = e.offset;
                if (r < t) return {
                    node: this.content.child(n),
                    index: n,
                    offset: r
                };
                var i = this.content.child(n - 1);
                return {
                    node: i,
                    index: n - 1,
                    offset: r - i.nodeSize
                }
            }, N.prototype.resolve = function(t) {
                return w.resolveCached(this, t)
            }, N.prototype.resolveNoCache = function(t) {
                return w.resolve(this, t)
            }, N.prototype.rangeHasMark = function(t, e, n) {
                var r = !1;
                return e > t && this.nodesBetween(t, e, function(t) {
                    return n.isInSet(t.marks) && (r = !0), !r
                }), r
            }, O.isBlock.get = function() {
                return this.type.isBlock
            }, O.isTextblock.get = function() {
                return this.type.isTextblock
            }, O.inlineContent.get = function() {
                return this.type.inlineContent
            }, O.isInline.get = function() {
                return this.type.isInline
            }, O.isText.get = function() {
                return this.type.isText
            }, O.isLeaf.get = function() {
                return this.type.isLeaf
            }, O.isAtom.get = function() {
                return this.type.isAtom
            }, N.prototype.toString = function() {
                if (this.type.spec.toDebugString) return this.type.spec.toDebugString(this);
                var t = this.type.name;
                return this.content.size && (t += "(" + this.content.toStringInner() + ")"), T(this.marks, t)
            }, N.prototype.contentMatchAt = function(t) {
                var e = this.type.contentMatch.matchFragment(this.content, 0, t);
                if (!e) throw Error("Called contentMatchAt on a node with invalid content");
                return e
            }, N.prototype.canReplace = function(t, e, n, r, o) {
                void 0 === n && (n = i.empty), void 0 === r && (r = 0), void 0 === o && (o = n.childCount);
                var s = this.contentMatchAt(t).matchFragment(n, r, o),
                    a = s && s.matchFragment(this.content, e);
                if (!a || !a.validEnd) return !1;
                for (var l = r; l < o; l++)
                    if (!this.type.allowsMarks(n.child(l).marks)) return !1;
                return !0
            }, N.prototype.canReplaceWith = function(t, e, n, r) {
                if (r && !this.type.allowsMarks(r)) return !1;
                var i = this.contentMatchAt(t).matchType(n),
                    o = i && i.matchFragment(this.content, e);
                return !!o && o.validEnd
            }, N.prototype.canAppend = function(t) {
                return t.content.size ? this.canReplace(this.childCount, this.childCount, t.content) : this.type.compatibleContent(t.type)
            }, N.prototype.check = function() {
                if (!this.type.validContent(this.content)) throw RangeError("Invalid content for node " + this.type.name + ": " + this.content.toString().slice(0, 50));
                for (var t = c.none, e = 0; e < this.marks.length; e++) t = this.marks[e].addToSet(t);
                if (!c.sameSet(t, this.marks)) throw RangeError("Invalid collection of marks for node " + this.type.name + ": " + this.marks.map(function(t) {
                    return t.type.name
                }));
                this.content.forEach(function(t) {
                    return t.check()
                })
            }, N.prototype.toJSON = function() {
                var t = {
                    type: this.type.name
                };
                for (var e in this.attrs) {
                    t.attrs = this.attrs;
                    break
                }
                return this.content.size && (t.content = this.content.toJSON()), this.marks.length && (t.marks = this.marks.map(function(t) {
                    return t.toJSON()
                })), t
            }, N.fromJSON = function(t, e) {
                if (!e) throw RangeError("Invalid input for Node.fromJSON");
                var n = null;
                if (e.marks) {
                    if (!Array.isArray(e.marks)) throw RangeError("Invalid mark data for Node.fromJSON");
                    n = e.marks.map(t.markFromJSON)
                }
                if ("text" == e.type) {
                    if ("string" != typeof e.text) throw RangeError("Invalid text node in JSON");
                    return t.text(e.text, n)
                }
                var r = i.fromJSON(t, e.content);
                return t.nodeType(e.type).create(e.attrs, r, n)
            }, Object.defineProperties(N.prototype, O);
            var A = function(t) {
                function e(e, n, r, i) {
                    if (t.call(this, e, n, null, i), !r) throw RangeError("Empty text nodes are not allowed");
                    this.text = r
                }
                t && (e.__proto__ = t), e.prototype = Object.create(t && t.prototype), e.prototype.constructor = e;
                var n = {
                    textContent: {
                        configurable: !0
                    },
                    nodeSize: {
                        configurable: !0
                    }
                };
                return e.prototype.toString = function() {
                    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : T(this.marks, JSON.stringify(this.text))
                }, n.textContent.get = function() {
                    return this.text
                }, e.prototype.textBetween = function(t, e) {
                    return this.text.slice(t, e)
                }, n.nodeSize.get = function() {
                    return this.text.length
                }, e.prototype.mark = function(t) {
                    return t == this.marks ? this : new e(this.type, this.attrs, this.text, t)
                }, e.prototype.withText = function(t) {
                    return t == this.text ? this : new e(this.type, this.attrs, t, this.marks)
                }, e.prototype.cut = function(t, e) {
                    return (void 0 === t && (t = 0), void 0 === e && (e = this.text.length), 0 == t && e == this.text.length) ? this : this.withText(this.text.slice(t, e))
                }, e.prototype.eq = function(t) {
                    return this.sameMarkup(t) && this.text == t.text
                }, e.prototype.toJSON = function() {
                    var e = t.prototype.toJSON.call(this);
                    return e.text = this.text, e
                }, Object.defineProperties(e.prototype, n), e
            }(N);

            function T(t, e) {
                for (var n = t.length - 1; n >= 0; n--) e = t[n].type.name + "(" + e + ")";
                return e
            }
            var I = function(t) {
                    this.validEnd = t, this.next = [], this.wrapCache = []
                },
                R = {
                    inlineContent: {
                        configurable: !0
                    },
                    defaultType: {
                        configurable: !0
                    },
                    edgeCount: {
                        configurable: !0
                    }
                };
            I.parse = function(t, e) {
                var n, r, i = new _(t, e);
                if (null == i.next) return I.empty;
                var o = function t(e) {
                    var n = [];
                    do n.push(function(e) {
                        var n = [];
                        do n.push(function(e) {
                            for (var n = function(e) {
                                    if (e.eat("(")) {
                                        var n = t(e);
                                        return e.eat(")") || e.err("Missing closing paren"), n
                                    }
                                    if (/\W/.test(e.next)) e.err("Unexpected token '" + e.next + "'");
                                    else {
                                        var r = (function(t, e) {
                                            var n = t.nodeTypes,
                                                r = n[e];
                                            if (r) return [r];
                                            var i = [];
                                            for (var o in n) {
                                                var s = n[o];
                                                s.groups.indexOf(e) > -1 && i.push(s)
                                            }
                                            return 0 == i.length && t.err("No node type or group '" + e + "' found"), i
                                        })(e, e.next).map(function(t) {
                                            return null == e.inline ? e.inline = t.isInline : e.inline != t.isInline && e.err("Mixing inline and block content"), {
                                                type: "name",
                                                value: t
                                            }
                                        });
                                        return e.pos++, 1 == r.length ? r[0] : {
                                            type: "choice",
                                            exprs: r
                                        }
                                    }
                                }(e);;)
                                if (e.eat("+")) n = {
                                    type: "plus",
                                    expr: n
                                };
                                else if (e.eat("*")) n = {
                                type: "star",
                                expr: n
                            };
                            else if (e.eat("?")) n = {
                                type: "opt",
                                expr: n
                            };
                            else if (e.eat("{")) n = function(t, e) {
                                var n = D(t),
                                    r = n;
                                return t.eat(",") && (r = "}" != t.next ? D(t) : -1), t.eat("}") || t.err("Unclosed braced range"), {
                                    type: "range",
                                    min: n,
                                    max: r,
                                    expr: e
                                }
                            }(e, n);
                            else break;
                            return n
                        }(e)); while (e.next && ")" != e.next && "|" != e.next);
                        return 1 == n.length ? n[0] : {
                            type: "seq",
                            exprs: n
                        }
                    }(e)); while (e.eat("|"));
                    return 1 == n.length ? n[0] : {
                        type: "choice",
                        exprs: n
                    }
                }(i);
                i.next && i.err("Unexpected trailing text");
                var s = (n = function(t) {
                    var e = [
                        []
                    ];
                    return i(function t(e, o) {
                        if ("choice" == e.type) return e.exprs.reduce(function(e, n) {
                            return e.concat(t(n, o))
                        }, []);
                        if ("seq" == e.type)
                            for (var s = 0;; s++) {
                                var a = t(e.exprs[s], o);
                                if (s == e.exprs.length - 1) return a;
                                i(a, o = n())
                            } else if ("star" == e.type) {
                                var l = n();
                                return r(o, l), i(t(e.expr, l), l), [r(l)]
                            } else if ("plus" == e.type) {
                            var c = n();
                            return i(t(e.expr, o), c), i(t(e.expr, c), c), [r(c)]
                        } else if ("opt" == e.type) return [r(o)].concat(t(e.expr, o));
                        else if ("range" == e.type) {
                            for (var u = o, h = 0; h < e.min; h++) {
                                var p = n();
                                i(t(e.expr, u), p), u = p
                            }
                            if (-1 == e.max) i(t(e.expr, u), u);
                            else
                                for (var d = e.min; d < e.max; d++) {
                                    var f = n();
                                    r(u, f), i(t(e.expr, u), f), u = f
                                }
                            return [r(u)]
                        } else if ("name" == e.type) return [r(o, null, e.value)]
                    }(t, 0), n()), e;

                    function n() {
                        return e.push([]) - 1
                    }

                    function r(t, n, r) {
                        var i = {
                            term: r,
                            to: n
                        };
                        return e[t].push(i), i
                    }

                    function i(t, e) {
                        t.forEach(function(t) {
                            return t.to = e
                        })
                    }
                }(o), r = Object.create(null), function t(e) {
                    var i = [];
                    e.forEach(function(t) {
                        n[t].forEach(function(t) {
                            var e = t.term,
                                r = t.to;
                            if (e) {
                                var o = i.indexOf(e),
                                    s = o > -1 && i[o + 1];
                                F(n, r).forEach(function(t) {
                                    s || i.push(e, s = []), -1 == s.indexOf(t) && s.push(t)
                                })
                            }
                        })
                    });
                    for (var o = r[e.join(",")] = new I(e.indexOf(n.length - 1) > -1), s = 0; s < i.length; s += 2) {
                        var a = i[s + 1].sort(P);
                        o.next.push(i[s], r[a.join(",")] || t(a))
                    }
                    return o
                }(F(n, 0)));
                return function(t, e) {
                    for (var n = 0, r = [t]; n < r.length; n++) {
                        for (var i = r[n], o = !i.validEnd, s = [], a = 0; a < i.next.length; a += 2) {
                            var l = i.next[a],
                                c = i.next[a + 1];
                            s.push(l.name), o && !(l.isText || l.hasRequiredAttrs()) && (o = !1), -1 == r.indexOf(c) && r.push(c)
                        }
                        o && e.err("Only non-generatable nodes (" + s.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)")
                    }
                }(s, i), s
            }, I.prototype.matchType = function(t) {
                for (var e = 0; e < this.next.length; e += 2)
                    if (this.next[e] == t) return this.next[e + 1];
                return null
            }, I.prototype.matchFragment = function(t, e, n) {
                void 0 === e && (e = 0), void 0 === n && (n = t.childCount);
                for (var r = this, i = e; r && i < n; i++) r = r.matchType(t.child(i).type);
                return r
            }, R.inlineContent.get = function() {
                var t = this.next[0];
                return !!t && t.isInline
            }, R.defaultType.get = function() {
                for (var t = 0; t < this.next.length; t += 2) {
                    var e = this.next[t];
                    if (!(e.isText || e.hasRequiredAttrs())) return e
                }
            }, I.prototype.compatible = function(t) {
                for (var e = 0; e < this.next.length; e += 2)
                    for (var n = 0; n < t.next.length; n += 2)
                        if (this.next[e] == t.next[n]) return !0;
                return !1
            }, I.prototype.fillBefore = function(t, e, n) {
                void 0 === e && (e = !1), void 0 === n && (n = 0);
                var r = [this];
                return function o(s, a) {
                    var l = s.matchFragment(t, n);
                    if (l && (!e || l.validEnd)) return i.from(a.map(function(t) {
                        return t.createAndFill()
                    }));
                    for (var c = 0; c < s.next.length; c += 2) {
                        var u = s.next[c],
                            h = s.next[c + 1];
                        if (!(u.isText || u.hasRequiredAttrs()) && -1 == r.indexOf(h)) {
                            r.push(h);
                            var p = o(h, a.concat(u));
                            if (p) return p
                        }
                    }
                }(this, [])
            }, I.prototype.findWrapping = function(t) {
                for (var e = 0; e < this.wrapCache.length; e += 2)
                    if (this.wrapCache[e] == t) return this.wrapCache[e + 1];
                var n = this.computeWrapping(t);
                return this.wrapCache.push(t, n), n
            }, I.prototype.computeWrapping = function(t) {
                for (var e = Object.create(null), n = [{
                        match: this,
                        type: null,
                        via: null
                    }]; n.length;) {
                    var r = n.shift(),
                        i = r.match;
                    if (i.matchType(t)) {
                        for (var o = [], s = r; s.type; s = s.via) o.push(s.type);
                        return o.reverse()
                    }
                    for (var a = 0; a < i.next.length; a += 2) {
                        var l = i.next[a];
                        l.isLeaf || l.hasRequiredAttrs() || l.name in e || r.type && !i.next[a + 1].validEnd || (n.push({
                            match: l.contentMatch,
                            type: l,
                            via: r
                        }), e[l.name] = !0)
                    }
                }
            }, R.edgeCount.get = function() {
                return this.next.length >> 1
            }, I.prototype.edge = function(t) {
                var e = t << 1;
                if (e >= this.next.length) throw RangeError("There's no " + t + "th edge in this content match");
                return {
                    type: this.next[e],
                    next: this.next[e + 1]
                }
            }, I.prototype.toString = function() {
                var t = [];
                return function e(n) {
                    t.push(n);
                    for (var r = 1; r < n.next.length; r += 2) - 1 == t.indexOf(n.next[r]) && e(n.next[r])
                }(this), t.map(function(e, n) {
                    for (var r = n + (e.validEnd ? "*" : " ") + " ", i = 0; i < e.next.length; i += 2) r += (i ? ", " : "") + e.next[i].name + "->" + t.indexOf(e.next[i + 1]);
                    return r
                }).join("\n")
            }, Object.defineProperties(I.prototype, R), I.empty = new I(!0);
            var _ = function(t, e) {
                    this.string = t, this.nodeTypes = e, this.inline = null, this.pos = 0, this.tokens = t.split(/\s*(?=\b|\W|$)/), "" == this.tokens[this.tokens.length - 1] && this.tokens.pop(), "" == this.tokens[0] && this.tokens.shift()
                },
                $ = {
                    next: {
                        configurable: !0
                    }
                };

            function D(t) {
                /\D/.test(t.next) && t.err("Expected number, got '" + t.next + "'");
                var e = Number(t.next);
                return t.pos++, e
            }

            function P(t, e) {
                return e - t
            }

            function F(t, e) {
                var n = [];
                return function e(r) {
                    var i = t[r];
                    if (1 == i.length && !i[0].term) return e(i[0].to);
                    n.push(r);
                    for (var o = 0; o < i.length; o++) {
                        var s = i[o],
                            a = s.term,
                            l = s.to;
                        a || -1 != n.indexOf(l) || e(l)
                    }
                }(e), n.sort(P)
            }

            function z(t) {
                var e = Object.create(null);
                for (var n in t) {
                    var r = t[n];
                    if (!r.hasDefault) return null;
                    e[n] = r.default
                }
                return e
            }

            function B(t, e) {
                var n = Object.create(null);
                for (var r in t) {
                    var i = e && e[r];
                    if (void 0 === i) {
                        var o = t[r];
                        if (o.hasDefault) i = o.default;
                        else throw RangeError("No value supplied for attribute " + r)
                    }
                    n[r] = i
                }
                return n
            }

            function j(t) {
                var e = Object.create(null);
                if (t)
                    for (var n in t) e[n] = new L(t[n]);
                return e
            }
            $.next.get = function() {
                return this.tokens[this.pos]
            }, _.prototype.eat = function(t) {
                return this.next == t && (this.pos++ || !0)
            }, _.prototype.err = function(t) {
                throw SyntaxError(t + " (in content expression '" + this.string + "')")
            }, Object.defineProperties(_.prototype, $);
            var H = function(t, e, n) {
                    this.name = t, this.schema = e, this.spec = n, this.groups = n.group ? n.group.split(" ") : [], this.attrs = j(n.attrs), this.defaultAttrs = z(this.attrs), this.contentMatch = null, this.markSet = null, this.inlineContent = null, this.isBlock = !(n.inline || "text" == t), this.isText = "text" == t
                },
                J = {
                    isInline: {
                        configurable: !0
                    },
                    isTextblock: {
                        configurable: !0
                    },
                    isLeaf: {
                        configurable: !0
                    },
                    isAtom: {
                        configurable: !0
                    },
                    whitespace: {
                        configurable: !0
                    }
                };
            J.isInline.get = function() {
                return !this.isBlock
            }, J.isTextblock.get = function() {
                return this.isBlock && this.inlineContent
            }, J.isLeaf.get = function() {
                return this.contentMatch == I.empty
            }, J.isAtom.get = function() {
                return this.isLeaf || this.spec.atom
            }, J.whitespace.get = function() {
                return this.spec.whitespace || (this.spec.code ? "pre" : "normal")
            }, H.prototype.hasRequiredAttrs = function() {
                for (var t in this.attrs)
                    if (this.attrs[t].isRequired) return !0;
                return !1
            }, H.prototype.compatibleContent = function(t) {
                return this == t || this.contentMatch.compatible(t.contentMatch)
            }, H.prototype.computeAttrs = function(t) {
                return !t && this.defaultAttrs ? this.defaultAttrs : B(this.attrs, t)
            }, H.prototype.create = function(t, e, n) {
                if (this.isText) throw Error("NodeType.create can't construct text nodes");
                return new N(this, this.computeAttrs(t), i.from(e), c.setFrom(n))
            }, H.prototype.createChecked = function(t, e, n) {
                if (e = i.from(e), !this.validContent(e)) throw RangeError("Invalid content for node " + this.name);
                return new N(this, this.computeAttrs(t), e, c.setFrom(n))
            }, H.prototype.createAndFill = function(t, e, n) {
                if (t = this.computeAttrs(t), (e = i.from(e)).size) {
                    var r = this.contentMatch.fillBefore(e);
                    if (!r) return null;
                    e = r.append(e)
                }
                var o = this.contentMatch.matchFragment(e).fillBefore(i.empty, !0);
                return o ? new N(this, t, e.append(o), c.setFrom(n)) : null
            }, H.prototype.validContent = function(t) {
                var e = this.contentMatch.matchFragment(t);
                if (!e || !e.validEnd) return !1;
                for (var n = 0; n < t.childCount; n++)
                    if (!this.allowsMarks(t.child(n).marks)) return !1;
                return !0
            }, H.prototype.allowsMarkType = function(t) {
                return null == this.markSet || this.markSet.indexOf(t) > -1
            }, H.prototype.allowsMarks = function(t) {
                if (null == this.markSet) return !0;
                for (var e = 0; e < t.length; e++)
                    if (!this.allowsMarkType(t[e].type)) return !1;
                return !0
            }, H.prototype.allowedMarks = function(t) {
                if (null == this.markSet) return t;
                for (var e, n = 0; n < t.length; n++) this.allowsMarkType(t[n].type) ? e && e.push(t[n]) : e || (e = t.slice(0, n));
                return e ? e.length ? e : c.empty : t
            }, H.compile = function(t, e) {
                var n = Object.create(null);
                t.forEach(function(t, r) {
                    return n[t] = new H(t, e, r)
                });
                var r = e.spec.topNode || "doc";
                if (!n[r]) throw RangeError("Schema is missing its top node type ('" + r + "')");
                if (!n.text) throw RangeError("Every schema needs a 'text' type");
                for (var i in n.text.attrs) throw RangeError("The text node type should not have attributes");
                return n
            }, Object.defineProperties(H.prototype, J);
            var L = function(t) {
                    this.hasDefault = Object.prototype.hasOwnProperty.call(t, "default"), this.default = t.default
                },
                q = {
                    isRequired: {
                        configurable: !0
                    }
                };
            q.isRequired.get = function() {
                return !this.hasDefault
            }, Object.defineProperties(L.prototype, q);
            var V = function(t, e, n, r) {
                this.name = t, this.schema = n, this.spec = r, this.attrs = j(r.attrs), this.rank = e, this.excluded = null;
                var i = z(this.attrs);
                this.instance = i && new c(this, i)
            };
            V.prototype.create = function(t) {
                return !t && this.instance ? this.instance : new c(this, B(this.attrs, t))
            }, V.compile = function(t, e) {
                var n = Object.create(null),
                    r = 0;
                return t.forEach(function(t, i) {
                    return n[t] = new V(t, r++, e, i)
                }), n
            }, V.prototype.removeFromSet = function(t) {
                for (var e = 0; e < t.length; e++) t[e].type == this && (t = t.slice(0, e).concat(t.slice(e + 1)), e--);
                return t
            }, V.prototype.isInSet = function(t) {
                for (var e = 0; e < t.length; e++)
                    if (t[e].type == this) return t[e]
            }, V.prototype.excludes = function(t) {
                return this.excluded.indexOf(t) > -1
            };
            var Y = function(t) {
                for (var e in this.spec = {}, t) this.spec[e] = t[e];
                this.spec.nodes = r.from(t.nodes), this.spec.marks = r.from(t.marks), this.nodes = H.compile(this.spec.nodes, this), this.marks = V.compile(this.spec.marks, this);
                var n = Object.create(null);
                for (var i in this.nodes) {
                    if (i in this.marks) throw RangeError(i + " can not be both a node and a mark");
                    var o = this.nodes[i],
                        s = o.spec.content || "",
                        a = o.spec.marks;
                    o.contentMatch = n[s] || (n[s] = I.parse(s, this.nodes)), o.inlineContent = o.contentMatch.inlineContent, o.markSet = "_" == a ? null : a ? U(this, a.split(" ")) : "" != a && o.inlineContent ? null : []
                }
                for (var l in this.marks) {
                    var c = this.marks[l],
                        u = c.spec.excludes;
                    c.excluded = null == u ? [c] : "" == u ? [] : U(this, u.split(" "))
                }
                this.nodeFromJSON = this.nodeFromJSON.bind(this), this.markFromJSON = this.markFromJSON.bind(this), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached = Object.create(null), this.cached.wrappings = Object.create(null)
            };

            function U(t, e) {
                for (var n = [], r = 0; r < e.length; r++) {
                    var i = e[r],
                        o = t.marks[i],
                        s = o;
                    if (o) n.push(o);
                    else
                        for (var a in t.marks) {
                            var l = t.marks[a];
                            ("_" == i || l.spec.group && l.spec.group.split(" ").indexOf(i) > -1) && n.push(s = l)
                        }
                    if (!s) throw SyntaxError("Unknown mark type: '" + e[r] + "'")
                }
                return n
            }
            Y.prototype.node = function(t, e, n, r) {
                if ("string" == typeof t) t = this.nodeType(t);
                else if (t instanceof H) {
                    if (t.schema != this) throw RangeError("Node type from different schema used (" + t.name + ")")
                } else throw RangeError("Invalid node type: " + t);
                return t.createChecked(e, n, r)
            }, Y.prototype.text = function(t, e) {
                var n = this.nodes.text;
                return new A(n, n.defaultAttrs, t, c.setFrom(e))
            }, Y.prototype.mark = function(t, e) {
                return "string" == typeof t && (t = this.marks[t]), t.create(e)
            }, Y.prototype.nodeFromJSON = function(t) {
                return N.fromJSON(this, t)
            }, Y.prototype.markFromJSON = function(t) {
                return c.fromJSON(this, t)
            }, Y.prototype.nodeType = function(t) {
                var e = this.nodes[t];
                if (!e) throw RangeError("Unknown node type: " + t);
                return e
            };
            var W = function(t, e) {
                var n = this;
                this.schema = t, this.rules = e, this.tags = [], this.styles = [], e.forEach(function(t) {
                    t.tag ? n.tags.push(t) : t.style && n.styles.push(t)
                }), this.normalizeLists = !this.tags.some(function(e) {
                    if (!/^(ul|ol)\b/.test(e.tag) || !e.node) return !1;
                    var n = t.nodes[e.node];
                    return n.contentMatch.matchType(n)
                })
            };
            W.prototype.parse = function(t, e) {
                void 0 === e && (e = {});
                var n = new tt(this, e, !1);
                return n.addAll(t, null, e.from, e.to), n.finish()
            }, W.prototype.parseSlice = function(t, e) {
                void 0 === e && (e = {});
                var n = new tt(this, e, !0);
                return n.addAll(t, null, e.from, e.to), h.maxOpen(n.finish())
            }, W.prototype.matchTag = function(t, e, n) {
                for (var r = n ? this.tags.indexOf(n) + 1 : 0; r < this.tags.length; r++) {
                    var i, o = this.tags[r];
                    if (i = o.tag, (t.matches || t.msMatchesSelector || t.webkitMatchesSelector || t.mozMatchesSelector).call(t, i) && (void 0 === o.namespace || t.namespaceURI == o.namespace) && (!o.context || e.matchesContext(o.context))) {
                        if (o.getAttrs) {
                            var s = o.getAttrs(t);
                            if (!1 === s) continue;
                            o.attrs = s
                        }
                        return o
                    }
                }
            }, W.prototype.matchStyle = function(t, e, n, r) {
                for (var i = r ? this.styles.indexOf(r) + 1 : 0; i < this.styles.length; i++) {
                    var o = this.styles[i];
                    if (0 == o.style.indexOf(t) && (!o.context || n.matchesContext(o.context)) && (!(o.style.length > t.length) || 61 == o.style.charCodeAt(t.length) && o.style.slice(t.length + 1) == e)) {
                        if (o.getAttrs) {
                            var s = o.getAttrs(e);
                            if (!1 === s) continue;
                            o.attrs = s
                        }
                        return o
                    }
                }
            }, W.schemaRules = function(t) {
                var e = [];

                function n(t) {
                    for (var n = null == t.priority ? 50 : t.priority, r = 0; r < e.length; r++) {
                        var i = e[r];
                        if ((null == i.priority ? 50 : i.priority) < n) break
                    }
                    e.splice(r, 0, t)
                }
                var r = function(e) {
                    var r = t.marks[e].spec.parseDOM;
                    r && r.forEach(function(t) {
                        n(t = tn(t)), t.mark = e
                    })
                };
                for (var i in t.marks) r(i);
                for (var o in t.nodes) ! function(e) {
                    var r = t.nodes[o].spec.parseDOM;
                    r && r.forEach(function(t) {
                        n(t = tn(t)), t.node = o
                    })
                }();
                return e
            }, W.fromSchema = function(t) {
                return t.cached.domParser || (t.cached.domParser = new W(t, W.schemaRules(t)))
            };
            var Z = {
                    address: !0,
                    article: !0,
                    aside: !0,
                    blockquote: !0,
                    canvas: !0,
                    dd: !0,
                    div: !0,
                    dl: !0,
                    fieldset: !0,
                    figcaption: !0,
                    figure: !0,
                    footer: !0,
                    form: !0,
                    h1: !0,
                    h2: !0,
                    h3: !0,
                    h4: !0,
                    h5: !0,
                    h6: !0,
                    header: !0,
                    hgroup: !0,
                    hr: !0,
                    li: !0,
                    noscript: !0,
                    ol: !0,
                    output: !0,
                    p: !0,
                    pre: !0,
                    section: !0,
                    table: !0,
                    tfoot: !0,
                    ul: !0
                },
                K = {
                    head: !0,
                    noscript: !0,
                    object: !0,
                    script: !0,
                    style: !0,
                    title: !0
                },
                G = {
                    ol: !0,
                    ul: !0
                };

            function Q(t, e, n) {
                return null != e ? (e ? 1 : 0) | ("full" === e ? 2 : 0) : t && "pre" == t.whitespace ? 3 : -5 & n
            }
            var X = function(t, e, n, r, i, o, s) {
                this.type = t, this.attrs = e, this.solid = i, this.match = o || (4 & s ? null : t.contentMatch), this.options = s, this.content = [], this.marks = n, this.activeMarks = c.none, this.pendingMarks = r, this.stashMarks = []
            };
            X.prototype.findWrapping = function(t) {
                if (!this.match) {
                    if (!this.type) return [];
                    var e = this.type.contentMatch.fillBefore(i.from(t));
                    if (e) this.match = this.type.contentMatch.matchFragment(e);
                    else {
                        var n, r = this.type.contentMatch;
                        return (n = r.findWrapping(t.type)) ? (this.match = r, n) : null
                    }
                }
                return this.match.findWrapping(t.type)
            }, X.prototype.finish = function(t) {
                if (!(1 & this.options)) {
                    var e, n = this.content[this.content.length - 1];
                    n && n.isText && (e = /[ \t\r\n\u000c]+$/.exec(n.text)) && (n.text.length == e[0].length ? this.content.pop() : this.content[this.content.length - 1] = n.withText(n.text.slice(0, n.text.length - e[0].length)))
                }
                var r = i.from(this.content);
                return !t && this.match && (r = r.append(this.match.fillBefore(i.empty, !0))), this.type ? this.type.create(this.attrs, r, this.marks) : r
            }, X.prototype.popFromStashMark = function(t) {
                for (var e = this.stashMarks.length - 1; e >= 0; e--)
                    if (t.eq(this.stashMarks[e])) return this.stashMarks.splice(e, 1)[0]
            }, X.prototype.applyPending = function(t) {
                for (var e = 0, n = this.pendingMarks; e < n.length; e++) {
                    var r = n[e];
                    (this.type ? this.type.allowsMarkType(r.type) : function(t, e) {
                        var n = e.schema.nodes;
                        for (var r in n) {
                            var i = function(r) {
                                var i = n[r];
                                if (i.allowsMarkType(t)) {
                                    var o = [],
                                        s = function(t) {
                                            o.push(t);
                                            for (var n = 0; n < t.edgeCount; n++) {
                                                var r = t.edge(n),
                                                    i = r.type,
                                                    a = r.next;
                                                if (i == e || 0 > o.indexOf(a) && s(a)) return !0
                                            }
                                        };
                                    if (s(i.contentMatch)) return {
                                        v: !0
                                    }
                                }
                            }(r);
                            if (i) return i.v
                        }
                    }(r.type, t)) && !r.isInSet(this.activeMarks) && (this.activeMarks = r.addToSet(this.activeMarks), this.pendingMarks = r.removeFromSet(this.pendingMarks))
                }
            }, X.prototype.inlineContext = function(t) {
                return this.type ? this.type.inlineContent : this.content.length ? this.content[0].isInline : t.parentNode && !Z.hasOwnProperty(t.parentNode.nodeName.toLowerCase())
            };
            var tt = function(t, e, n) {
                    this.parser = t, this.options = e, this.isOpen = n;
                    var r, i = e.topNode,
                        o = Q(null, e.preserveWhitespace, 0) | (n ? 4 : 0);
                    r = i ? new X(i.type, i.attrs, c.none, c.none, !0, e.topMatch || i.type.contentMatch, o) : n ? new X(null, null, c.none, c.none, !0, null, o) : new X(t.schema.topNodeType, null, c.none, c.none, !0, null, o), this.nodes = [r], this.open = 0, this.find = e.findPositions, this.needsBlock = !1
                },
                te = {
                    top: {
                        configurable: !0
                    },
                    currentPos: {
                        configurable: !0
                    }
                };

            function tn(t) {
                var e = {};
                for (var n in t) e[n] = t[n];
                return e
            }
            te.top.get = function() {
                return this.nodes[this.open]
            }, tt.prototype.addDOM = function(t) {
                if (3 == t.nodeType) this.addTextNode(t);
                else if (1 == t.nodeType) {
                    var e = t.getAttribute("style"),
                        n = e ? this.readStyles(function(t) {
                            for (var e, n = /\s*([\w-]+)\s*:\s*([^;]+)/g, r = []; e = n.exec(t);) r.push(e[1], e[2].trim());
                            return r
                        }(e)) : null,
                        r = this.top;
                    if (null != n)
                        for (var i = 0; i < n.length; i++) this.addPendingMark(n[i]);
                    if (this.addElement(t), null != n)
                        for (var o = 0; o < n.length; o++) this.removePendingMark(n[o], r)
                }
            }, tt.prototype.addTextNode = function(t) {
                var e = t.nodeValue,
                    n = this.top;
                if (2 & n.options || n.inlineContext(t) || /[^ \t\r\n\u000c]/.test(e)) {
                    if (1 & n.options) e = 2 & n.options ? e.replace(/\r\n?/g, "\n") : e.replace(/\r?\n|\r/g, " ");
                    else if (e = e.replace(/[ \t\r\n\u000c]+/g, " "), /^[ \t\r\n\u000c]/.test(e) && this.open == this.nodes.length - 1) {
                        var r = n.content[n.content.length - 1],
                            i = t.previousSibling;
                        (!r || i && "BR" == i.nodeName || r.isText && /[ \t\r\n\u000c]$/.test(r.text)) && (e = e.slice(1))
                    }
                    e && this.insertNode(this.parser.schema.text(e)), this.findInText(t)
                } else this.findInside(t)
            }, tt.prototype.addElement = function(t, e) {
                var n, r = t.nodeName.toLowerCase();
                G.hasOwnProperty(r) && this.parser.normalizeLists && function(t) {
                    for (var e = t.firstChild, n = null; e; e = e.nextSibling) {
                        var r = 1 == e.nodeType ? e.nodeName.toLowerCase() : null;
                        r && G.hasOwnProperty(r) && n ? (n.appendChild(e), e = n) : "li" == r ? n = e : r && (n = null)
                    }
                }(t);
                var i = this.options.ruleFromNode && this.options.ruleFromNode(t) || (n = this.parser.matchTag(t, this, e));
                if (i ? i.ignore : K.hasOwnProperty(r)) this.findInside(t), this.ignoreFallback(t);
                else if (!i || i.skip || i.closeParent) {
                    i && i.closeParent ? this.open = Math.max(0, this.open - 1) : i && i.skip.nodeType && (t = i.skip);
                    var o, s = this.top,
                        a = this.needsBlock;
                    if (Z.hasOwnProperty(r)) o = !0, s.type || (this.needsBlock = !0);
                    else if (!t.firstChild) {
                        this.leafFallback(t);
                        return
                    }
                    this.addAll(t), o && this.sync(s), this.needsBlock = a
                } else this.addElementByRule(t, i, !1 === i.consuming ? n : null)
            }, tt.prototype.leafFallback = function(t) {
                "BR" == t.nodeName && this.top.type && this.top.type.inlineContent && this.addTextNode(t.ownerDocument.createTextNode("\n"))
            }, tt.prototype.ignoreFallback = function(t) {
                "BR" != t.nodeName || this.top.type && this.top.type.inlineContent || this.findPlace(this.parser.schema.text("-"))
            }, tt.prototype.readStyles = function(t) {
                var e = c.none;
                e: for (var n = 0; n < t.length; n += 2)
                    for (var r = null;;) {
                        var i = this.parser.matchStyle(t[n], t[n + 1], this, r);
                        if (!i) continue e;
                        if (i.ignore) return null;
                        if (e = this.parser.schema.marks[i.mark].create(i.attrs).addToSet(e), !1 === i.consuming) r = i;
                        else break
                    }
                return e
            }, tt.prototype.addElementByRule = function(t, e, n) {
                var r, i, o, s = this;
                e.node ? (i = this.parser.schema.nodes[e.node]).isLeaf ? this.insertNode(i.create(e.attrs)) || this.leafFallback(t) : r = this.enter(i, e.attrs, e.preserveWhitespace) : (o = this.parser.schema.marks[e.mark].create(e.attrs), this.addPendingMark(o));
                var a = this.top;
                if (i && i.isLeaf) this.findInside(t);
                else if (n) this.addElement(t, n);
                else if (e.getContent) this.findInside(t), e.getContent(t, this.parser.schema).forEach(function(t) {
                    return s.insertNode(t)
                });
                else {
                    var l = e.contentElement;
                    "string" == typeof l ? l = t.querySelector(l) : "function" == typeof l && (l = l(t)), l || (l = t), this.findAround(t, l, !0), this.addAll(l, r)
                }
                r && (this.sync(a), this.open--), o && this.removePendingMark(o, a)
            }, tt.prototype.addAll = function(t, e, n, r) {
                for (var i = n || 0, o = n ? t.childNodes[n] : t.firstChild, s = null == r ? null : t.childNodes[r]; o != s; o = o.nextSibling, ++i) this.findAtPoint(t, i), this.addDOM(o), e && Z.hasOwnProperty(o.nodeName.toLowerCase()) && this.sync(e);
                this.findAtPoint(t, i)
            }, tt.prototype.findPlace = function(t) {
                for (var e, n, r = this.open; r >= 0; r--) {
                    var i = this.nodes[r],
                        o = i.findWrapping(t);
                    if (o && (!e || e.length > o.length) && (e = o, n = i, !o.length) || i.solid) break
                }
                if (!e) return !1;
                this.sync(n);
                for (var s = 0; s < e.length; s++) this.enterInner(e[s], null, !1);
                return !0
            }, tt.prototype.insertNode = function(t) {
                if (t.isInline && this.needsBlock && !this.top.type) {
                    var e = this.textblockFromContext();
                    e && this.enterInner(e)
                }
                if (this.findPlace(t)) {
                    this.closeExtra();
                    var n = this.top;
                    n.applyPending(t.type), n.match && (n.match = n.match.matchType(t.type));
                    for (var r = n.activeMarks, i = 0; i < t.marks.length; i++)(!n.type || n.type.allowsMarkType(t.marks[i].type)) && (r = t.marks[i].addToSet(r));
                    return n.content.push(t.mark(r)), !0
                }
                return !1
            }, tt.prototype.enter = function(t, e, n) {
                var r = this.findPlace(t.create(e));
                return r && this.enterInner(t, e, !0, n), r
            }, tt.prototype.enterInner = function(t, e, n, r) {
                this.closeExtra();
                var i = this.top;
                i.applyPending(t), i.match = i.match && i.match.matchType(t, e);
                var o = Q(t, r, i.options);
                4 & i.options && 0 == i.content.length && (o |= 4), this.nodes.push(new X(t, e, i.activeMarks, i.pendingMarks, n, null, o)), this.open++
            }, tt.prototype.closeExtra = function(t) {
                var e = this.nodes.length - 1;
                if (e > this.open) {
                    for (; e > this.open; e--) this.nodes[e - 1].content.push(this.nodes[e].finish(t));
                    this.nodes.length = this.open + 1
                }
            }, tt.prototype.finish = function() {
                return this.open = 0, this.closeExtra(this.isOpen), this.nodes[0].finish(this.isOpen || this.options.topOpen)
            }, tt.prototype.sync = function(t) {
                for (var e = this.open; e >= 0; e--)
                    if (this.nodes[e] == t) {
                        this.open = e;
                        return
                    }
            }, te.currentPos.get = function() {
                this.closeExtra();
                for (var t = 0, e = this.open; e >= 0; e--) {
                    for (var n = this.nodes[e].content, r = n.length - 1; r >= 0; r--) t += n[r].nodeSize;
                    e && t++
                }
                return t
            }, tt.prototype.findAtPoint = function(t, e) {
                if (this.find)
                    for (var n = 0; n < this.find.length; n++) this.find[n].node == t && this.find[n].offset == e && (this.find[n].pos = this.currentPos)
            }, tt.prototype.findInside = function(t) {
                if (this.find)
                    for (var e = 0; e < this.find.length; e++) null == this.find[e].pos && 1 == t.nodeType && t.contains(this.find[e].node) && (this.find[e].pos = this.currentPos)
            }, tt.prototype.findAround = function(t, e, n) {
                if (t != e && this.find)
                    for (var r = 0; r < this.find.length; r++) null == this.find[r].pos && 1 == t.nodeType && t.contains(this.find[r].node) && e.compareDocumentPosition(this.find[r].node) & (n ? 2 : 4) && (this.find[r].pos = this.currentPos)
            }, tt.prototype.findInText = function(t) {
                if (this.find)
                    for (var e = 0; e < this.find.length; e++) this.find[e].node == t && (this.find[e].pos = this.currentPos - (t.nodeValue.length - this.find[e].offset))
            }, tt.prototype.matchesContext = function(t) {
                var e = this;
                if (t.indexOf("|") > -1) return t.split(/\s*\|\s*/).some(this.matchesContext, this);
                var n = t.split("/"),
                    r = this.options.context,
                    i = !this.isOpen && (!r || r.parent.type == this.nodes[0].type),
                    o = -(r ? r.depth + 1 : 0) + (i ? 0 : 1),
                    s = function(t, a) {
                        for (; t >= 0; t--) {
                            var l = n[t];
                            if ("" == l) {
                                if (t == n.length - 1 || 0 == t) continue;
                                for (; a >= o; a--)
                                    if (s(t - 1, a)) return !0;
                                return !1
                            }
                            var c = a > 0 || 0 == a && i ? e.nodes[a].type : r && a >= o ? r.node(a - o).type : null;
                            if (!c || c.name != l && -1 == c.groups.indexOf(l)) return !1;
                            a--
                        }
                        return !0
                    };
                return s(n.length - 1, this.open)
            }, tt.prototype.textblockFromContext = function() {
                var t = this.options.context;
                if (t)
                    for (var e = t.depth; e >= 0; e--) {
                        var n = t.node(e).contentMatchAt(t.indexAfter(e)).defaultType;
                        if (n && n.isTextblock && n.defaultAttrs) return n
                    }
                for (var r in this.parser.schema.nodes) {
                    var i = this.parser.schema.nodes[r];
                    if (i.isTextblock && i.defaultAttrs) return i
                }
            }, tt.prototype.addPendingMark = function(t) {
                var e = function(t, e) {
                    for (var n = 0; n < e.length; n++)
                        if (t.eq(e[n])) return e[n]
                }(t, this.top.pendingMarks);
                e && this.top.stashMarks.push(e), this.top.pendingMarks = t.addToSet(this.top.pendingMarks)
            }, tt.prototype.removePendingMark = function(t, e) {
                for (var n = this.open; n >= 0; n--) {
                    var r = this.nodes[n];
                    if (r.pendingMarks.lastIndexOf(t) > -1) r.pendingMarks = t.removeFromSet(r.pendingMarks);
                    else {
                        r.activeMarks = t.removeFromSet(r.activeMarks);
                        var i = r.popFromStashMark(t);
                        i && r.type && r.type.allowsMarkType(i.type) && (r.activeMarks = i.addToSet(r.activeMarks))
                    }
                    if (r == e) break
                }
            }, Object.defineProperties(tt.prototype, te);
            var tr = function(t, e) {
                this.nodes = t || {}, this.marks = e || {}
            };

            function ti(t) {
                var e = {};
                for (var n in t) {
                    var r = t[n].spec.toDOM;
                    r && (e[n] = r)
                }
                return e
            }

            function to(t) {
                return t.document || window.document
            }
            tr.prototype.serializeFragment = function(t, e, n) {
                var r = this;
                void 0 === e && (e = {}), n || (n = to(e).createDocumentFragment());
                var i = n,
                    o = null;
                return t.forEach(function(t) {
                    if (o || t.marks.length) {
                        o || (o = []);
                        for (var n = 0, s = 0; n < o.length && s < t.marks.length;) {
                            var a = t.marks[s];
                            if (!r.marks[a.type.name]) {
                                s++;
                                continue
                            }
                            if (!a.eq(o[n]) || !1 === a.type.spec.spanning) break;
                            n += 2, s++
                        }
                        for (; n < o.length;) i = o.pop(), o.pop();
                        for (; s < t.marks.length;) {
                            var l = t.marks[s++],
                                c = r.serializeMark(l, t.isInline, e);
                            c && (o.push(l, i), i.appendChild(c.dom), i = c.contentDOM || c.dom)
                        }
                    }
                    i.appendChild(r.serializeNodeInner(t, e))
                }), n
            }, tr.prototype.serializeNodeInner = function(t, e) {
                void 0 === e && (e = {});
                var n = tr.renderSpec(to(e), this.nodes[t.type.name](t)),
                    r = n.dom,
                    i = n.contentDOM;
                if (i) {
                    if (t.isLeaf) throw RangeError("Content hole not allowed in a leaf node spec");
                    e.onContent ? e.onContent(t, i, e) : this.serializeFragment(t.content, e, i)
                }
                return r
            }, tr.prototype.serializeNode = function(t, e) {
                void 0 === e && (e = {});
                for (var n = this.serializeNodeInner(t, e), r = t.marks.length - 1; r >= 0; r--) {
                    var i = this.serializeMark(t.marks[r], t.isInline, e);
                    i && ((i.contentDOM || i.dom).appendChild(n), n = i.dom)
                }
                return n
            }, tr.prototype.serializeMark = function(t, e, n) {
                void 0 === n && (n = {});
                var r = this.marks[t.type.name];
                return r && tr.renderSpec(to(n), r(t, e))
            }, tr.renderSpec = function(t, e, n) {
                if (void 0 === n && (n = null), "string" == typeof e) return {
                    dom: t.createTextNode(e)
                };
                if (null != e.nodeType) return {
                    dom: e
                };
                if (e.dom && null != e.dom.nodeType) return e;
                var r = e[0],
                    i = r.indexOf(" ");
                i > 0 && (n = r.slice(0, i), r = r.slice(i + 1));
                var o = null,
                    s = n ? t.createElementNS(n, r) : t.createElement(r),
                    a = e[1],
                    l = 1;
                if (a && "object" == typeof a && null == a.nodeType && !Array.isArray(a)) {
                    for (var c in l = 2, a)
                        if (null != a[c]) {
                            var u = c.indexOf(" ");
                            u > 0 ? s.setAttributeNS(c.slice(0, u), c.slice(u + 1), a[c]) : s.setAttribute(c, a[c])
                        }
                }
                for (var h = l; h < e.length; h++) {
                    var p = e[h];
                    if (0 === p) {
                        if (h < e.length - 1 || h > l) throw RangeError("Content hole must be the only child of its parent node");
                        return {
                            dom: s,
                            contentDOM: s
                        }
                    }
                    var d = tr.renderSpec(t, p, n),
                        f = d.dom,
                        m = d.contentDOM;
                    if (s.appendChild(f), m) {
                        if (o) throw RangeError("Multiple content holes");
                        o = m
                    }
                }
                return {
                    dom: s,
                    contentDOM: o
                }
            }, tr.fromSchema = function(t) {
                return t.cached.domSerializer || (t.cached.domSerializer = new tr(this.nodesFromSchema(t), this.marksFromSchema(t)))
            }, tr.nodesFromSchema = function(t) {
                var e = ti(t.nodes);
                return e.text || (e.text = function(t) {
                    return t.text
                }), e
            }, tr.marksFromSchema = function(t) {
                return ti(t.marks)
            }
        },
        84510: function(t, e, n) {
            "use strict";
            var r = n(2784);
            e.Z = function(t, e) {
                var n = (0, r.createContext)(void 0);
                return [function() {
                    var t = (0, r.useContext)(n);
                    if (null == t) throw Error("useReducerContext must be used inside a ReducerProvider.");
                    return t
                }, function(i) {
                    var o, s = i.children,
                        a = i.initialState;
                    return o = {
                        value: (0, r.useReducer)(t, void 0 !== a ? a : e)
                    }, (0, r.createElement)(n.Provider, o, s)
                }, n]
            }
        },
        33539: function(t, e, n) {
            "use strict";
            n.d(e, {
                ML: function() {
                    return eY
                },
                hj: function() {
                    return tw
                },
                vc: function() {
                    return eZ
                },
                NB: function() {
                    return eK
                },
                J1: function() {
                    return eh
                },
                Cf: function() {
                    return eU
                },
                K9: function() {
                    return eG
                },
                P1: function() {
                    return tt
                },
                DS: function() {
                    return eW
                }
            });
            var r, i = n(27191),
                o = n(52780),
                s = {
                    8: "Backspace",
                    9: "Tab",
                    10: "Enter",
                    12: "NumLock",
                    13: "Enter",
                    16: "Shift",
                    17: "Control",
                    18: "Alt",
                    20: "CapsLock",
                    27: "Escape",
                    32: " ",
                    33: "PageUp",
                    34: "PageDown",
                    35: "End",
                    36: "Home",
                    37: "ArrowLeft",
                    38: "ArrowUp",
                    39: "ArrowRight",
                    40: "ArrowDown",
                    44: "PrintScreen",
                    45: "Insert",
                    46: "Delete",
                    59: ";",
                    61: "=",
                    91: "Meta",
                    92: "Meta",
                    106: "*",
                    107: "+",
                    108: ",",
                    109: "-",
                    110: ".",
                    111: "/",
                    144: "NumLock",
                    145: "ScrollLock",
                    160: "Shift",
                    161: "Shift",
                    162: "Control",
                    163: "Control",
                    164: "Alt",
                    165: "Alt",
                    173: "-",
                    186: ";",
                    187: "=",
                    188: ",",
                    189: "-",
                    190: ".",
                    191: "/",
                    192: "`",
                    219: "[",
                    220: "\\",
                    221: "]",
                    222: "'"
                },
                a = {
                    48: ")",
                    49: "!",
                    50: "@",
                    51: "#",
                    52: "$",
                    53: "%",
                    54: "^",
                    55: "&",
                    56: "*",
                    57: "(",
                    59: ":",
                    61: "+",
                    173: "_",
                    186: ":",
                    187: "+",
                    188: "<",
                    189: "_",
                    190: ">",
                    191: "?",
                    192: "~",
                    219: "{",
                    220: "|",
                    221: "}",
                    222: '"'
                },
                l = "undefined" != typeof navigator && /Chrome\/(\d+)/.exec(navigator.userAgent);
            "undefined" != typeof navigator && /Gecko\/\d+/.test(navigator.userAgent);
            for (var c = "undefined" != typeof navigator && /Mac/.test(navigator.platform), u = "undefined" != typeof navigator && /MSIE \d|Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(navigator.userAgent), h = c || l && 57 > +l[1], p = 0; p < 10; p++) s[48 + p] = s[96 + p] = String(p);
            for (var p = 1; p <= 24; p++) s[p + 111] = "F" + p;
            for (var p = 65; p <= 90; p++) s[p] = String.fromCharCode(p + 32), a[p] = String.fromCharCode(p);
            for (var d in s) a.hasOwnProperty(d) || (a[d] = s[d]);
            let f = "undefined" != typeof navigator && /Mac|iP(hone|[oa]d)/.test(navigator.platform);

            function m(t, e, n) {
                return e.altKey && (t = "Alt-" + t), e.ctrlKey && (t = "Ctrl-" + t), e.metaKey && (t = "Meta-" + t), !1 !== n && e.shiftKey && (t = "Shift-" + t), t
            }
            var g = n(28638),
                y = n(26151);
            let v = (t, e) => !t.selection.empty && (e && e(t.tr.deleteSelection().scrollIntoView()), !0),
                w = (t, e, n) => {
                    let r = function(t, e) {
                        let {
                            $cursor: n
                        } = t.selection;
                        return n && (e ? e.endOfTextblock("backward", t) : !(n.parentOffset > 0)) ? n : null
                    }(t, n);
                    if (!r) return !1;
                    let o = k(r);
                    if (!o) {
                        let n = r.blockRange(),
                            i = n && (0, y.k9)(n);
                        return null != i && (e && e(t.tr.lift(n, i).scrollIntoView()), !0)
                    }
                    let s = o.nodeBefore;
                    if (!s.type.spec.isolating && F(t, o, e)) return !0;
                    if (0 == r.parent.content.size && (b(s, "end") || i.qv.isSelectable(s))) {
                        let n = (0, y.dR)(t.doc, r.before(), r.after(), g.p2.empty);
                        if (n && n.slice.size < n.to - n.from) {
                            if (e) {
                                let r = t.tr.step(n);
                                r.setSelection(b(s, "end") ? i.Y1.findFrom(r.doc.resolve(r.mapping.map(o.pos, -1)), -1) : i.qv.create(r.doc, o.pos - s.nodeSize)), e(r.scrollIntoView())
                            }
                            return !0
                        }
                    }
                    return !!s.isAtom && o.depth == r.depth - 1 && (e && e(t.tr.delete(o.pos - s.nodeSize, o.pos).scrollIntoView()), !0)
                };

            function b(t, e, n = !1) {
                for (let r = t; r; r = "start" == e ? r.firstChild : r.lastChild) {
                    if (r.isTextblock) return !0;
                    if (n && 1 != r.childCount) break
                }
                return !1
            }
            let x = (t, e, n) => {
                let {
                    $head: r,
                    empty: o
                } = t.selection, s = r;
                if (!o) return !1;
                if (r.parent.isTextblock) {
                    if (n ? !n.endOfTextblock("backward", t) : r.parentOffset > 0) return !1;
                    s = k(r)
                }
                let a = s && s.nodeBefore;
                return !!(a && i.qv.isSelectable(a)) && (e && e(t.tr.setSelection(i.qv.create(t.doc, s.pos - a.nodeSize)).scrollIntoView()), !0)
            };

            function k(t) {
                if (!t.parent.type.spec.isolating)
                    for (let e = t.depth - 1; e >= 0; e--) {
                        if (t.index(e) > 0) return t.doc.resolve(t.before(e + 1));
                        if (t.node(e).type.spec.isolating) break
                    }
                return null
            }
            let S = (t, e, n) => {
                    let r = function(t, e) {
                        let {
                            $cursor: n
                        } = t.selection;
                        return n && (e ? e.endOfTextblock("forward", t) : !(n.parentOffset < n.parent.content.size)) ? n : null
                    }(t, n);
                    if (!r) return !1;
                    let o = C(r);
                    if (!o) return !1;
                    let s = o.nodeAfter;
                    if (F(t, o, e)) return !0;
                    if (0 == r.parent.content.size && (b(s, "start") || i.qv.isSelectable(s))) {
                        let n = (0, y.dR)(t.doc, r.before(), r.after(), g.p2.empty);
                        if (n && n.slice.size < n.to - n.from) {
                            if (e) {
                                let r = t.tr.step(n);
                                r.setSelection(b(s, "start") ? i.Y1.findFrom(r.doc.resolve(r.mapping.map(o.pos)), 1) : i.qv.create(r.doc, r.mapping.map(o.pos))), e(r.scrollIntoView())
                            }
                            return !0
                        }
                    }
                    return !!s.isAtom && o.depth == r.depth - 1 && (e && e(t.tr.delete(o.pos, o.pos + s.nodeSize).scrollIntoView()), !0)
                },
                M = (t, e, n) => {
                    let {
                        $head: r,
                        empty: o
                    } = t.selection, s = r;
                    if (!o) return !1;
                    if (r.parent.isTextblock) {
                        if (n ? !n.endOfTextblock("forward", t) : r.parentOffset < r.parent.content.size) return !1;
                        s = C(r)
                    }
                    let a = s && s.nodeAfter;
                    return !!(a && i.qv.isSelectable(a)) && (e && e(t.tr.setSelection(i.qv.create(t.doc, s.pos)).scrollIntoView()), !0)
                };

            function C(t) {
                if (!t.parent.type.spec.isolating)
                    for (let e = t.depth - 1; e >= 0; e--) {
                        let n = t.node(e);
                        if (t.index(e) + 1 < n.childCount) return t.doc.resolve(t.after(e + 1));
                        if (n.type.spec.isolating) break
                    }
                return null
            }
            let E = (t, e) => {
                    let n = t.selection,
                        r = n instanceof i.qv,
                        o;
                    if (r) {
                        if (n.node.isTextblock || !(0, y.Mn)(t.doc, n.from)) return !1;
                        o = n.from
                    } else if (null == (o = (0, y.GJ)(t.doc, n.from, -1))) return !1;
                    if (e) {
                        let n = t.tr.join(o);
                        r && n.setSelection(i.qv.create(n.doc, o - t.doc.resolve(o).nodeBefore.nodeSize)), e(n.scrollIntoView())
                    }
                    return !0
                },
                N = (t, e) => {
                    let n = t.selection,
                        r;
                    if (n instanceof i.qv) {
                        if (n.node.isTextblock || !(0, y.Mn)(t.doc, n.to)) return !1;
                        r = n.to
                    } else if (null == (r = (0, y.GJ)(t.doc, n.to, 1))) return !1;
                    return e && e(t.tr.join(r).scrollIntoView()), !0
                },
                O = (t, e) => {
                    let {
                        $from: n,
                        $to: r
                    } = t.selection, i = n.blockRange(r), o = i && (0, y.k9)(i);
                    return null != o && (e && e(t.tr.lift(i, o).scrollIntoView()), !0)
                },
                A = (t, e) => {
                    let {
                        $head: n,
                        $anchor: r
                    } = t.selection;
                    return !!(n.parent.type.spec.code && n.sameParent(r)) && (e && e(t.tr.insertText("\n").scrollIntoView()), !0)
                };

            function T(t) {
                for (let e = 0; e < t.edgeCount; e++) {
                    let {
                        type: n
                    } = t.edge(e);
                    if (n.isTextblock && !n.hasRequiredAttrs()) return n
                }
                return null
            }
            let I = (t, e) => {
                    let {
                        $head: n,
                        $anchor: r
                    } = t.selection;
                    if (!n.parent.type.spec.code || !n.sameParent(r)) return !1;
                    let o = n.node(-1),
                        s = n.indexAfter(-1),
                        a = T(o.contentMatchAt(s));
                    if (!a || !o.canReplaceWith(s, s, a)) return !1;
                    if (e) {
                        let r = n.after(),
                            o = t.tr.replaceWith(r, r, a.createAndFill());
                        o.setSelection(i.Y1.near(o.doc.resolve(r), 1)), e(o.scrollIntoView())
                    }
                    return !0
                },
                R = (t, e) => {
                    let n = t.selection,
                        {
                            $from: r,
                            $to: o
                        } = n;
                    if (n instanceof i.C1 || r.parent.inlineContent || o.parent.inlineContent) return !1;
                    let s = T(o.parent.contentMatchAt(o.indexAfter()));
                    if (!s || !s.isTextblock) return !1;
                    if (e) {
                        let n = (!r.parentOffset && o.index() < o.parent.childCount ? r : o).pos,
                            a = t.tr.insert(n, s.createAndFill());
                        a.setSelection(i.Bs.create(a.doc, n + 1)), e(a.scrollIntoView())
                    }
                    return !0
                },
                _ = (t, e) => {
                    let {
                        $cursor: n
                    } = t.selection;
                    if (!n || n.parent.content.size) return !1;
                    if (n.depth > 1 && n.after() != n.end(-1)) {
                        let r = n.before();
                        if ((0, y.Ax)(t.doc, r)) return e && e(t.tr.split(r).scrollIntoView()), !0
                    }
                    let r = n.blockRange(),
                        i = r && (0, y.k9)(r);
                    return null != i && (e && e(t.tr.lift(r, i).scrollIntoView()), !0)
                },
                $ = (t, e) => {
                    let {
                        $from: n,
                        $to: o
                    } = t.selection;
                    if (t.selection instanceof i.qv && t.selection.node.isBlock) return !!(n.parentOffset && (0, y.Ax)(t.doc, n.pos)) && (e && e(t.tr.split(n.pos).scrollIntoView()), !0);
                    if (!n.parent.isBlock) return !1;
                    if (e) {
                        let s = o.parentOffset == o.parent.content.size,
                            a = t.tr;
                        (t.selection instanceof i.Bs || t.selection instanceof i.C1) && a.deleteSelection();
                        let l = 0 == n.depth ? null : T(n.node(-1).contentMatchAt(n.indexAfter(-1))),
                            c = r && r(o.parent, s),
                            u = c ? [c] : s && l ? [{
                                type: l
                            }] : void 0,
                            h = (0, y.Ax)(a.doc, a.mapping.map(n.pos), 1, u);
                        if (!u && !h && (0, y.Ax)(a.doc, a.mapping.map(n.pos), 1, l ? [{
                                type: l
                            }] : void 0) && (l && (u = [{
                                type: l
                            }]), h = !0), h && (a.split(a.mapping.map(n.pos), 1, u), !s && !n.parentOffset && n.parent.type != l)) {
                            let t = a.mapping.map(n.before()),
                                e = a.doc.resolve(t);
                            l && n.node(-1).canReplaceWith(e.index(), e.index() + 1, l) && a.setNodeMarkup(a.mapping.map(n.before()), l)
                        }
                        e(a.scrollIntoView())
                    }
                    return !0
                },
                D = (t, e) => {
                    let {
                        $from: n,
                        to: r
                    } = t.selection, o, s = n.sharedDepth(r);
                    return 0 != s && (o = n.before(s), e && e(t.tr.setSelection(i.qv.create(t.doc, o))), !0)
                },
                P = (t, e) => (e && e(t.tr.setSelection(new i.C1(t.doc))), !0);

            function F(t, e, n) {
                let r, o, s, a = e.nodeBefore,
                    l = e.nodeAfter,
                    c, u;
                if (a.type.spec.isolating || l.type.spec.isolating) return !1;
                if (r = e.nodeBefore, o = e.nodeAfter, s = e.index(), r && o && r.type.compatibleContent(o.type) && (!r.content.size && e.parent.canReplace(s - 1, s) ? (n && n(t.tr.delete(e.pos - r.nodeSize, e.pos).scrollIntoView()), !0) : !!(e.parent.canReplace(s, s + 1) && (o.isTextblock || (0, y.Mn)(t.doc, e.pos))) && (n && n(t.tr.clearIncompatible(e.pos, r.type, r.contentMatchAt(r.childCount)).join(e.pos).scrollIntoView()), !0))) return !0;
                let h = e.parent.canReplace(e.index(), e.index() + 1);
                if (h && (c = (u = a.contentMatchAt(a.childCount)).findWrapping(l.type)) && u.matchType(c[0] || l.type).validEnd) {
                    if (n) {
                        let r = e.pos + l.nodeSize,
                            i = g.HY.empty;
                        for (let t = c.length - 1; t >= 0; t--) i = g.HY.from(c[t].create(null, i));
                        i = g.HY.from(a.copy(i));
                        let o = t.tr.step(new y.FC(e.pos - 1, r, e.pos, r, new g.p2(i, 1, 0), c.length, !0)),
                            s = r + 2 * c.length;
                        (0, y.Mn)(o.doc, s) && o.join(s), n(o.scrollIntoView())
                    }
                    return !0
                }
                let p = i.Y1.findFrom(e, 1),
                    d = p && p.$from.blockRange(p.$to),
                    f = d && (0, y.k9)(d);
                if (null != f && f >= e.depth) return n && n(t.tr.lift(d, f).scrollIntoView()), !0;
                if (h && b(l, "start", !0) && b(a, "end")) {
                    let r = a,
                        i = [];
                    for (; i.push(r), !r.isTextblock;) r = r.lastChild;
                    let o = l,
                        s = 1;
                    for (; !o.isTextblock; o = o.firstChild) s++;
                    if (r.canReplace(r.childCount, r.childCount, o.content)) {
                        if (n) {
                            let r = g.HY.empty;
                            for (let t = i.length - 1; t >= 0; t--) r = g.HY.from(i[t].copy(r));
                            n(t.tr.step(new y.FC(e.pos - i.length, e.pos + l.nodeSize, e.pos + s, e.pos + l.nodeSize - s, new g.p2(r, i.length, 0), 0, !0)).scrollIntoView())
                        }
                        return !0
                    }
                }
                return !1
            }

            function z(t) {
                return function(e, n) {
                    let r = e.selection,
                        o = t < 0 ? r.$from : r.$to,
                        s = o.depth;
                    for (; o.node(s).isInline;) {
                        if (!s) return !1;
                        s--
                    }
                    return !!o.node(s).isTextblock && (n && n(e.tr.setSelection(i.Bs.create(e.doc, t < 0 ? o.start(s) : o.end(s)))), !0)
                }
            }
            let B = z(-1),
                j = z(1);

            function H(t, e = null) {
                return function(n, r) {
                    let i = !1;
                    for (let r = 0; r < n.selection.ranges.length && !i; r++) {
                        let {
                            $from: {
                                pos: o
                            },
                            $to: {
                                pos: s
                            }
                        } = n.selection.ranges[r];
                        n.doc.nodesBetween(o, s, (r, o) => {
                            if (i) return !1;
                            if (!(!r.isTextblock || r.hasMarkup(t, e))) {
                                if (r.type == t) i = !0;
                                else {
                                    let e = n.doc.resolve(o),
                                        r = e.index();
                                    i = e.parent.canReplaceWith(r, r + 1, t)
                                }
                            }
                        })
                    }
                    if (!i) return !1;
                    if (r) {
                        let i = n.tr;
                        for (let r = 0; r < n.selection.ranges.length; r++) {
                            let {
                                $from: {
                                    pos: o
                                },
                                $to: {
                                    pos: s
                                }
                            } = n.selection.ranges[r];
                            i.setBlockType(o, s, t, e)
                        }
                        r(i.scrollIntoView())
                    }
                    return !0
                }
            }

            function J(...t) {
                return function(e, n, r) {
                    for (let i = 0; i < t.length; i++)
                        if (t[i](e, n, r)) return !0;
                    return !1
                }
            }
            let L = J(v, w, x),
                q = J(v, S, M),
                V = {
                    Enter: J(A, R, _, $),
                    "Mod-Enter": I,
                    Backspace: L,
                    "Mod-Backspace": L,
                    "Shift-Backspace": L,
                    Delete: q,
                    "Mod-Delete": q,
                    "Mod-a": P
                },
                Y = {
                    "Ctrl-h": V.Backspace,
                    "Alt-Backspace": V["Mod-Backspace"],
                    "Ctrl-d": V.Delete,
                    "Ctrl-Alt-Backspace": V["Mod-Delete"],
                    "Alt-Delete": V["Mod-Delete"],
                    "Alt-d": V["Mod-Delete"],
                    "Ctrl-a": B,
                    "Ctrl-e": j
                };
            for (let t in V) Y[t] = V[t];

            function U(t) {
                let {
                    state: e,
                    transaction: n
                } = t, {
                    selection: r
                } = n, {
                    doc: i
                } = n, {
                    storedMarks: o
                } = n;
                return { ...e,
                    apply: e.apply.bind(e),
                    applyTransaction: e.applyTransaction.bind(e),
                    filterTransaction: e.filterTransaction,
                    plugins: e.plugins,
                    schema: e.schema,
                    reconfigure: e.reconfigure.bind(e),
                    toJSON: e.toJSON.bind(e),
                    get storedMarks() {
                        return o
                    },
                    get selection() {
                        return r
                    },
                    get doc() {
                        return i
                    },
                    get tr() {
                        return r = n.selection, i = n.doc, o = n.storedMarks, n
                    }
                }
            }
            "undefined" != typeof navigator ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : "undefined" != typeof os && os.platform && os.platform();
            class W {
                constructor(t) {
                    this.editor = t.editor, this.rawCommands = this.editor.extensionManager.commands, this.customState = t.state
                }
                get hasCustomState() {
                    return !!this.customState
                }
                get state() {
                    return this.customState || this.editor.state
                }
                get commands() {
                    let {
                        rawCommands: t,
                        editor: e,
                        state: n
                    } = this, {
                        view: r
                    } = e, {
                        tr: i
                    } = n, o = this.buildProps(i);
                    return Object.fromEntries(Object.entries(t).map(([t, e]) => {
                        let n = (...t) => {
                            let n = e(...t)(o);
                            return i.getMeta("preventDispatch") || this.hasCustomState || r.dispatch(i), n
                        };
                        return [t, n]
                    }))
                }
                get chain() {
                    return () => this.createChain()
                }
                get can() {
                    return () => this.createCan()
                }
                createChain(t, e = !0) {
                    let {
                        rawCommands: n,
                        editor: r,
                        state: i
                    } = this, {
                        view: o
                    } = r, s = [], a = !!t, l = t || i.tr, c = () => (a || !e || l.getMeta("preventDispatch") || this.hasCustomState || o.dispatch(l), s.every(t => !0 === t)), u = { ...Object.fromEntries(Object.entries(n).map(([t, n]) => {
                            let r = (...t) => {
                                let r = this.buildProps(l, e),
                                    i = n(...t)(r);
                                return s.push(i), u
                            };
                            return [t, r]
                        })),
                        run: c
                    };
                    return u
                }
                createCan(t) {
                    let {
                        rawCommands: e,
                        state: n
                    } = this, r = t || n.tr, i = this.buildProps(r, !1), o = Object.fromEntries(Object.entries(e).map(([t, e]) => [t, (...t) => e(...t)({ ...i,
                        dispatch: void 0
                    })]));
                    return { ...o,
                        chain: () => this.createChain(r, !1)
                    }
                }
                buildProps(t, e = !0) {
                    let {
                        rawCommands: n,
                        editor: r,
                        state: i
                    } = this, {
                        view: o
                    } = r;
                    i.storedMarks && t.setStoredMarks(i.storedMarks);
                    let s = {
                        tr: t,
                        editor: r,
                        view: o,
                        state: U({
                            state: i,
                            transaction: t
                        }),
                        dispatch: e ? () => void 0 : void 0,
                        chain: () => this.createChain(t),
                        can: () => this.createCan(t),
                        get commands() {
                            return Object.fromEntries(Object.entries(n).map(([t, e]) => [t, (...t) => e(...t)(s)]))
                        }
                    };
                    return s
                }
            }
            class Z {
                constructor() {
                    this.callbacks = {}
                }
                on(t, e) {
                    return this.callbacks[t] || (this.callbacks[t] = []), this.callbacks[t].push(e), this
                }
                emit(t, ...e) {
                    let n = this.callbacks[t];
                    return n && n.forEach(t => t.apply(this, e)), this
                }
                off(t, e) {
                    let n = this.callbacks[t];
                    return n && (e ? this.callbacks[t] = n.filter(t => t !== e) : delete this.callbacks[t]), this
                }
                removeAllListeners() {
                    this.callbacks = {}
                }
            }

            function K(t, e, n) {
                if (void 0 === t.config[e] && t.parent) return K(t.parent, e, n);
                if ("function" == typeof t.config[e]) {
                    let r = t.config[e].bind({ ...n,
                        parent: t.parent ? K(t.parent, e, n) : null
                    });
                    return r
                }
                return t.config[e]
            }

            function G(t) {
                let e = t.filter(t => "extension" === t.type),
                    n = t.filter(t => "node" === t.type),
                    r = t.filter(t => "mark" === t.type);
                return {
                    baseExtensions: e,
                    nodeExtensions: n,
                    markExtensions: r
                }
            }

            function Q(t) {
                let e = [],
                    {
                        nodeExtensions: n,
                        markExtensions: r
                    } = G(t),
                    i = [...n, ...r],
                    o = {
                        default: null,
                        rendered: !0,
                        renderHTML: null,
                        parseHTML: null,
                        keepOnSplit: !0,
                        isRequired: !1
                    };
                return t.forEach(t => {
                    let n = {
                            name: t.name,
                            options: t.options,
                            storage: t.storage
                        },
                        r = K(t, "addGlobalAttributes", n);
                    if (!r) return;
                    let i = r();
                    i.forEach(t => {
                        t.types.forEach(n => {
                            Object.entries(t.attributes).forEach(([t, r]) => {
                                e.push({
                                    type: n,
                                    name: t,
                                    attribute: { ...o,
                                        ...r
                                    }
                                })
                            })
                        })
                    })
                }), i.forEach(t => {
                    let n = {
                            name: t.name,
                            options: t.options,
                            storage: t.storage
                        },
                        r = K(t, "addAttributes", n);
                    if (!r) return;
                    let i = r();
                    Object.entries(i).forEach(([n, r]) => {
                        let i = { ...o,
                            ...r
                        };
                        (null == r ? void 0 : r.isRequired) && (null == r ? void 0 : r.default) === void 0 && delete i.default, e.push({
                            type: t.name,
                            name: n,
                            attribute: i
                        })
                    })
                }), e
            }

            function X(t, e) {
                if ("string" == typeof t) {
                    if (!e.nodes[t]) throw Error(`There is no node type named '${t}'. Maybe you forgot to add the extension?`);
                    return e.nodes[t]
                }
                return t
            }

            function tt(...t) {
                return t.filter(t => !!t).reduce((t, e) => {
                    let n = { ...t
                    };
                    return Object.entries(e).forEach(([t, e]) => {
                        let r = n[t];
                        if (!r) {
                            n[t] = e;
                            return
                        }
                        "class" === t ? n[t] = [n[t], e].join(" ") : "style" === t ? n[t] = [n[t], e].join("; ") : n[t] = e
                    }), n
                }, {})
            }

            function te(t, e) {
                return e.filter(t => t.attribute.rendered).map(e => e.attribute.renderHTML ? e.attribute.renderHTML(t.attrs) || {} : {
                    [e.name]: t.attrs[e.name]
                }).reduce((t, e) => tt(t, e), {})
            }

            function tn(t) {
                return "function" == typeof t
            }

            function tr(t, e, ...n) {
                return tn(t) ? e ? t.bind(e)(...n) : t(...n) : t
            }

            function ti(t, e) {
                return t.style ? t : { ...t,
                    getAttrs: n => {
                        let r = t.getAttrs ? t.getAttrs(n) : t.attrs;
                        if (!1 === r) return !1;
                        let i = e.reduce((t, e) => {
                            var r;
                            let i = e.attribute.parseHTML ? e.attribute.parseHTML(n) : "string" != typeof(r = n.getAttribute(e.name)) ? r : r.match(/^[+-]?(?:\d*\.)?\d+$/) ? Number(r) : "true" === r || "false" !== r && r;
                            return null == i ? t : { ...t,
                                [e.name]: i
                            }
                        }, {});
                        return { ...r,
                            ...i
                        }
                    }
                }
            }

            function to(t) {
                return Object.fromEntries(Object.entries(t).filter(([t, e]) => !("attrs" === t && function(t = {}) {
                    return 0 === Object.keys(t).length && t.constructor === Object
                }(e)) && null != e))
            }

            function ts(t) {
                var e;
                let n = Q(t),
                    {
                        nodeExtensions: r,
                        markExtensions: i
                    } = G(t),
                    o = null === (e = r.find(t => K(t, "topNode"))) || void 0 === e ? void 0 : e.name,
                    s = Object.fromEntries(r.map(e => {
                        let r = n.filter(t => t.type === e.name),
                            i = {
                                name: e.name,
                                options: e.options,
                                storage: e.storage
                            },
                            o = t.reduce((t, n) => {
                                let r = K(n, "extendNodeSchema", i);
                                return { ...t,
                                    ...r ? r(e) : {}
                                }
                            }, {}),
                            s = to({ ...o,
                                content: tr(K(e, "content", i)),
                                marks: tr(K(e, "marks", i)),
                                group: tr(K(e, "group", i)),
                                inline: tr(K(e, "inline", i)),
                                atom: tr(K(e, "atom", i)),
                                selectable: tr(K(e, "selectable", i)),
                                draggable: tr(K(e, "draggable", i)),
                                code: tr(K(e, "code", i)),
                                defining: tr(K(e, "defining", i)),
                                isolating: tr(K(e, "isolating", i)),
                                attrs: Object.fromEntries(r.map(t => {
                                    var e;
                                    return [t.name, {
                                        default: null === (e = null == t ? void 0 : t.attribute) || void 0 === e ? void 0 : e.default
                                    }]
                                }))
                            }),
                            a = tr(K(e, "parseHTML", i));
                        a && (s.parseDOM = a.map(t => ti(t, r)));
                        let l = K(e, "renderHTML", i);
                        l && (s.toDOM = t => l({
                            node: t,
                            HTMLAttributes: te(t, r)
                        }));
                        let c = K(e, "renderText", i);
                        return c && (s.toText = c), [e.name, s]
                    })),
                    a = Object.fromEntries(i.map(e => {
                        let r = n.filter(t => t.type === e.name),
                            i = {
                                name: e.name,
                                options: e.options,
                                storage: e.storage
                            },
                            o = t.reduce((t, n) => {
                                let r = K(n, "extendMarkSchema", i);
                                return { ...t,
                                    ...r ? r(e) : {}
                                }
                            }, {}),
                            s = to({ ...o,
                                inclusive: tr(K(e, "inclusive", i)),
                                excludes: tr(K(e, "excludes", i)),
                                group: tr(K(e, "group", i)),
                                spanning: tr(K(e, "spanning", i)),
                                code: tr(K(e, "code", i)),
                                attrs: Object.fromEntries(r.map(t => {
                                    var e;
                                    return [t.name, {
                                        default: null === (e = null == t ? void 0 : t.attribute) || void 0 === e ? void 0 : e.default
                                    }]
                                }))
                            }),
                            a = tr(K(e, "parseHTML", i));
                        a && (s.parseDOM = a.map(t => ti(t, r)));
                        let l = K(e, "renderHTML", i);
                        return l && (s.toDOM = t => l({
                            mark: t,
                            HTMLAttributes: te(t, r)
                        })), [e.name, s]
                    }));
                return new g.V_({
                    topNode: o,
                    nodes: s,
                    marks: a
                })
            }

            function ta(t, e) {
                return e.nodes[t] || e.marks[t] || null
            }

            function tl(t, e) {
                return Array.isArray(e) ? e.some(e => {
                    let n = "string" == typeof e ? e : e.name;
                    return n === t.name
                }) : e
            }
            let tc = (t, e = 500) => {
                let n = "",
                    r = t.parentOffset;
                return t.parent.nodesBetween(Math.max(0, r - e), r, (t, e, i, o) => {
                    var s, a;
                    let l = (null === (a = (s = t.type.spec).toText) || void 0 === a ? void 0 : a.call(s, {
                        node: t,
                        pos: e,
                        parent: i,
                        index: o
                    })) || t.textContent || "%leaf%";
                    n += l.slice(0, Math.max(0, r - e))
                }), n
            };

            function tu(t) {
                return "[object RegExp]" === Object.prototype.toString.call(t)
            }
            class th {
                constructor(t) {
                    this.find = t.find, this.handler = t.handler
                }
            }
            let tp = (t, e) => {
                if (tu(e)) return e.exec(t);
                let n = e(t);
                if (!n) return null;
                let r = [];
                return r.push(n.text), r.index = n.index, r.input = t, r.data = n.data, n.replaceWith && (n.text.includes(n.replaceWith) || console.warn('[tiptap warn]: "inputRuleMatch.replaceWith" must be part of "inputRuleMatch.text".'), r.push(n.replaceWith)), r
            };

            function td(t) {
                var e;
                let {
                    editor: n,
                    from: r,
                    to: i,
                    text: o,
                    rules: s,
                    plugin: a
                } = t, {
                    view: l
                } = n;
                if (l.composing) return !1;
                let c = l.state.doc.resolve(r);
                if (c.parent.type.spec.code || (null === (e = c.nodeBefore || c.nodeAfter) || void 0 === e ? void 0 : e.marks.find(t => t.type.spec.code))) return !1;
                let u = !1,
                    h = tc(c) + o;
                return s.forEach(t => {
                    if (u) return;
                    let e = tp(h, t.find);
                    if (!e) return;
                    let s = l.state.tr,
                        c = U({
                            state: l.state,
                            transaction: s
                        }),
                        p = {
                            from: r - (e[0].length - o.length),
                            to: i
                        },
                        {
                            commands: d,
                            chain: f,
                            can: m
                        } = new W({
                            editor: n,
                            state: c
                        }),
                        g = t.handler({
                            state: c,
                            range: p,
                            match: e,
                            commands: d,
                            chain: f,
                            can: m
                        });
                    null !== g && s.steps.length && (s.setMeta(a, {
                        transform: s,
                        from: r,
                        to: i,
                        text: o
                    }), l.dispatch(s), u = !0)
                }), u
            }
            class tf {
                constructor(t) {
                    this.find = t.find, this.handler = t.handler
                }
            }
            let tm = (t, e) => {
                if (tu(e)) return [...t.matchAll(e)];
                let n = e(t);
                return n ? n.map(e => {
                    let n = [];
                    return n.push(e.text), n.index = e.index, n.input = t, n.data = e.data, e.replaceWith && (e.text.includes(e.replaceWith) || console.warn('[tiptap warn]: "pasteRuleMatch.replaceWith" must be part of "pasteRuleMatch.text".'), n.push(e.replaceWith)), n
                }) : []
            };
            class tg {
                constructor(t, e) {
                    this.splittableMarks = [], this.editor = e, this.extensions = tg.resolve(t), this.schema = ts(this.extensions), this.extensions.forEach(t => {
                        var e;
                        this.editor.extensionStorage[t.name] = t.storage;
                        let n = {
                            name: t.name,
                            options: t.options,
                            storage: t.storage,
                            editor: this.editor,
                            type: ta(t.name, this.schema)
                        };
                        if ("mark" === t.type) {
                            let r = null === (e = tr(K(t, "keepOnSplit", n))) || void 0 === e || e;
                            r && this.splittableMarks.push(t.name)
                        }
                        let r = K(t, "onBeforeCreate", n);
                        r && this.editor.on("beforeCreate", r);
                        let i = K(t, "onCreate", n);
                        i && this.editor.on("create", i);
                        let o = K(t, "onUpdate", n);
                        o && this.editor.on("update", o);
                        let s = K(t, "onSelectionUpdate", n);
                        s && this.editor.on("selectionUpdate", s);
                        let a = K(t, "onTransaction", n);
                        a && this.editor.on("transaction", a);
                        let l = K(t, "onFocus", n);
                        l && this.editor.on("focus", l);
                        let c = K(t, "onBlur", n);
                        c && this.editor.on("blur", c);
                        let u = K(t, "onDestroy", n);
                        u && this.editor.on("destroy", u)
                    })
                }
                static resolve(t) {
                    let e = tg.sort(tg.flatten(t)),
                        n = function(t) {
                            let e = t.filter((e, n) => t.indexOf(e) !== n);
                            return [...new Set(e)]
                        }(e.map(t => t.name));
                    return n.length && console.warn(`[tiptap warn]: Duplicate extension names found: [${n.map(t=>`'${t}'`).join(", ")}]. This can lead to issues.`), e
                }
                static flatten(t) {
                    return t.map(t => {
                        let e = {
                                name: t.name,
                                options: t.options,
                                storage: t.storage
                            },
                            n = K(t, "addExtensions", e);
                        return n ? [t, ...this.flatten(n())] : t
                    }).flat(10)
                }
                static sort(t) {
                    return t.sort((t, e) => {
                        let n = K(t, "priority") || 100,
                            r = K(e, "priority") || 100;
                        return n > r ? -1 : n < r ? 1 : 0
                    })
                }
                get commands() {
                    return this.extensions.reduce((t, e) => {
                        let n = {
                                name: e.name,
                                options: e.options,
                                storage: e.storage,
                                editor: this.editor,
                                type: ta(e.name, this.schema)
                            },
                            r = K(e, "addCommands", n);
                        return r ? { ...t,
                            ...r()
                        } : t
                    }, {})
                }
                get plugins() {
                    let {
                        editor: t
                    } = this, e = tg.sort([...this.extensions].reverse()), n = [], r = [], o = e.map(e => {
                        var o;
                        let l;
                        let c = {
                                name: e.name,
                                options: e.options,
                                storage: e.storage,
                                editor: t,
                                type: ta(e.name, this.schema)
                            },
                            p = [],
                            d = K(e, "addKeyboardShortcuts", c),
                            g = {};
                        if ("mark" === e.type && e.config.exitable && (g.ArrowRight = () => eZ.handleExit({
                                editor: t,
                                mark: e
                            })), d) {
                            let e = Object.fromEntries(Object.entries(d()).map(([e, n]) => [e, () => n({
                                editor: t
                            })]));
                            g = { ...g,
                                ...e
                            }
                        }
                        let y = (o = g, new i.Sy({
                            props: {
                                handleKeyDown: (l = function(t) {
                                    let e = Object.create(null);
                                    for (let n in t) e[function(t) {
                                        let e, n, r, i, o = t.split(/-(?!$)/),
                                            s = o[o.length - 1];
                                        "Space" == s && (s = " ");
                                        for (let t = 0; t < o.length - 1; t++) {
                                            let s = o[t];
                                            if (/^(cmd|meta|m)$/i.test(s)) i = !0;
                                            else if (/^a(lt)?$/i.test(s)) e = !0;
                                            else if (/^(c|ctrl|control)$/i.test(s)) n = !0;
                                            else if (/^s(hift)?$/i.test(s)) r = !0;
                                            else if (/^mod$/i.test(s)) f ? i = !0 : n = !0;
                                            else throw Error("Unrecognized modifier name: " + s)
                                        }
                                        return e && (s = "Alt-" + s), n && (s = "Ctrl-" + s), i && (s = "Meta-" + s), r && (s = "Shift-" + s), s
                                    }(n)] = t[n];
                                    return e
                                }(o), function(t, e) {
                                    var n;
                                    let r = ("Esc" == (n = !(h && (e.ctrlKey || e.altKey || e.metaKey) || u && e.shiftKey && e.key && 1 == e.key.length || "Unidentified" == e.key) && e.key || (e.shiftKey ? a : s)[e.keyCode] || e.key || "Unidentified") && (n = "Escape"), "Del" == n && (n = "Delete"), "Left" == n && (n = "ArrowLeft"), "Up" == n && (n = "ArrowUp"), "Right" == n && (n = "ArrowRight"), "Down" == n && (n = "ArrowDown"), n),
                                        i = 1 == r.length && " " != r,
                                        o, c = l[m(r, e, !i)];
                                    if (c && c(t.state, t.dispatch, t)) return !0;
                                    if (i && (e.shiftKey || e.altKey || e.metaKey || r.charCodeAt(0) > 127) && (o = s[e.keyCode]) && o != r) {
                                        let n = l[m(o, e, !0)];
                                        if (n && n(t.state, t.dispatch, t)) return !0
                                    } else if (i && e.shiftKey) {
                                        let n = l[m(r, e, !0)];
                                        if (n && n(t.state, t.dispatch, t)) return !0
                                    }
                                    return !1
                                })
                            }
                        }));
                        p.push(y);
                        let v = K(e, "addInputRules", c);
                        tl(e, t.options.enableInputRules) && v && n.push(...v());
                        let w = K(e, "addPasteRules", c);
                        tl(e, t.options.enablePasteRules) && w && r.push(...w());
                        let b = K(e, "addProseMirrorPlugins", c);
                        if (b) {
                            let t = b();
                            p.push(...t)
                        }
                        return p
                    }).flat();
                    return [function(t) {
                        let {
                            editor: e,
                            rules: n
                        } = t, r = new i.Sy({
                            state: {
                                init: () => null,
                                apply(t, e) {
                                    let n = t.getMeta(r);
                                    return n || (t.selectionSet || t.docChanged ? null : e)
                                }
                            },
                            props: {
                                handleTextInput: (t, i, o, s) => td({
                                    editor: e,
                                    from: i,
                                    to: o,
                                    text: s,
                                    rules: n,
                                    plugin: r
                                }),
                                handleDOMEvents: {
                                    compositionend: t => (setTimeout(() => {
                                        let {
                                            $cursor: i
                                        } = t.state.selection;
                                        i && td({
                                            editor: e,
                                            from: i.pos,
                                            to: i.pos,
                                            text: "",
                                            rules: n,
                                            plugin: r
                                        })
                                    }), !1)
                                },
                                handleKeyDown(t, i) {
                                    if ("Enter" !== i.key) return !1;
                                    let {
                                        $cursor: o
                                    } = t.state.selection;
                                    return !!o && td({
                                        editor: e,
                                        from: o.pos,
                                        to: o.pos,
                                        text: "\n",
                                        rules: n,
                                        plugin: r
                                    })
                                }
                            },
                            isInputRules: !0
                        });
                        return r
                    }({
                        editor: t,
                        rules: n
                    }), ... function(t) {
                        let {
                            editor: e,
                            rules: n
                        } = t, r = null, o = !1, s = !1, a = n.map(t => new i.Sy({
                            view(t) {
                                let e = e => {
                                    var n;
                                    r = (null === (n = t.dom.parentElement) || void 0 === n ? void 0 : n.contains(e.target)) ? t.dom.parentElement : null
                                };
                                return window.addEventListener("dragstart", e), {
                                    destroy() {
                                        window.removeEventListener("dragstart", e)
                                    }
                                }
                            },
                            props: {
                                handleDOMEvents: {
                                    drop: t => (s = r === t.dom.parentElement, !1),
                                    paste: (t, e) => {
                                        var n;
                                        let r = null === (n = e.clipboardData) || void 0 === n ? void 0 : n.getData("text/html");
                                        return o = !!(null == r ? void 0 : r.includes("data-pm-slice")), !1
                                    }
                                }
                            },
                            appendTransaction: (n, r, i) => {
                                let a = n[0],
                                    l = "paste" === a.getMeta("uiEvent") && !o,
                                    c = "drop" === a.getMeta("uiEvent") && !s;
                                if (!l && !c) return;
                                let u = r.doc.content.findDiffStart(i.doc.content),
                                    h = r.doc.content.findDiffEnd(i.doc.content);
                                if ("number" != typeof u || !h || u === h.b) return;
                                let p = i.tr,
                                    d = U({
                                        state: i,
                                        transaction: p
                                    }),
                                    f = function(t) {
                                        let {
                                            editor: e,
                                            state: n,
                                            from: r,
                                            to: i,
                                            rule: o
                                        } = t, {
                                            commands: s,
                                            chain: a,
                                            can: l
                                        } = new W({
                                            editor: e,
                                            state: n
                                        }), c = [];
                                        n.doc.nodesBetween(r, i, (t, e) => {
                                            if (!t.isTextblock || t.type.spec.code) return;
                                            let u = Math.max(r, e),
                                                h = Math.min(i, e + t.content.size),
                                                p = t.textBetween(u - e, h - e, void 0, "￼"),
                                                d = tm(p, o.find);
                                            d.forEach(t => {
                                                if (void 0 === t.index) return;
                                                let e = u + t.index + 1,
                                                    r = e + t[0].length,
                                                    i = {
                                                        from: n.tr.mapping.map(e),
                                                        to: n.tr.mapping.map(r)
                                                    },
                                                    h = o.handler({
                                                        state: n,
                                                        range: i,
                                                        match: t,
                                                        commands: s,
                                                        chain: a,
                                                        can: l
                                                    });
                                                c.push(h)
                                            })
                                        });
                                        let u = c.every(t => null !== t);
                                        return u
                                    }({
                                        editor: e,
                                        state: d,
                                        from: Math.max(u - 1, 0),
                                        to: h.b - 1,
                                        rule: t
                                    });
                                if (f && p.steps.length) return p
                            }
                        }));
                        return a
                    }({
                        editor: t,
                        rules: r
                    }), ...o]
                }
                get attributes() {
                    return Q(this.extensions)
                }
                get nodeViews() {
                    let {
                        editor: t
                    } = this, {
                        nodeExtensions: e
                    } = G(this.extensions);
                    return Object.fromEntries(e.filter(t => !!K(t, "addNodeView")).map(e => {
                        let n = this.attributes.filter(t => t.type === e.name),
                            r = {
                                name: e.name,
                                options: e.options,
                                storage: e.storage,
                                editor: t,
                                type: X(e.name, this.schema)
                            },
                            i = K(e, "addNodeView", r);
                        if (!i) return [];
                        let o = (r, o, s, a) => {
                            let l = te(r, n);
                            return i()({
                                editor: t,
                                node: r,
                                getPos: s,
                                decorations: a,
                                HTMLAttributes: l,
                                extension: e
                            })
                        };
                        return [e.name, o]
                    }))
                }
            }

            function ty(t) {
                return "Object" === Object.prototype.toString.call(t).slice(8, -1) && t.constructor === Object && Object.getPrototypeOf(t) === Object.prototype
            }

            function tv(t, e) {
                let n = { ...t
                };
                return ty(t) && ty(e) && Object.keys(e).forEach(r => {
                    ty(e[r]) && r in t ? n[r] = tv(t[r], e[r]) : Object.assign(n, {
                        [r]: e[r]
                    })
                }), n
            }
            class tw {
                constructor(t = {}) {
                    this.type = "extension", this.name = "extension", this.parent = null, this.child = null, this.config = {
                        name: this.name,
                        defaultOptions: {}
                    }, this.config = { ...this.config,
                        ...t
                    }, this.name = this.config.name, t.defaultOptions && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${this.name}".`), this.options = this.config.defaultOptions, this.config.addOptions && (this.options = tr(K(this, "addOptions", {
                        name: this.name
                    }))), this.storage = tr(K(this, "addStorage", {
                        name: this.name,
                        options: this.options
                    })) || {}
                }
                static create(t = {}) {
                    return new tw(t)
                }
                configure(t = {}) {
                    let e = this.extend();
                    return e.options = tv(this.options, t), e.storage = tr(K(e, "addStorage", {
                        name: e.name,
                        options: e.options
                    })), e
                }
                extend(t = {}) {
                    let e = new tw(t);
                    return e.parent = this, this.child = e, e.name = t.name ? t.name : e.parent.name, t.defaultOptions && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${e.name}".`), e.options = tr(K(e, "addOptions", {
                        name: e.name
                    })), e.storage = tr(K(e, "addStorage", {
                        name: e.name,
                        options: e.options
                    })), e
                }
            }

            function tb(t, e, n) {
                let {
                    from: r,
                    to: i
                } = e, {
                    blockSeparator: o = "\n\n",
                    textSerializers: s = {}
                } = n || {}, a = "", l = !0;
                return t.nodesBetween(r, i, (t, n, c, u) => {
                    var h;
                    let p = null == s ? void 0 : s[t.type.name];
                    p ? (t.isBlock && !l && (a += o, l = !0), c && (a += p({
                        node: t,
                        pos: n,
                        parent: c,
                        index: u,
                        range: e
                    }))) : t.isText ? (a += null === (h = null == t ? void 0 : t.text) || void 0 === h ? void 0 : h.slice(Math.max(r, n) - n, i - n), l = !1) : t.isBlock && !l && (a += o, l = !0)
                }), a
            }

            function tx(t) {
                return Object.fromEntries(Object.entries(t.nodes).filter(([, t]) => t.spec.toText).map(([t, e]) => [t, e.spec.toText]))
            }
            let tk = tw.create({
                    name: "clipboardTextSerializer",
                    addProseMirrorPlugins() {
                        return [new i.Sy({
                            key: new i.H$("clipboardTextSerializer"),
                            props: {
                                clipboardTextSerializer: () => {
                                    let {
                                        editor: t
                                    } = this, {
                                        state: e,
                                        schema: n
                                    } = t, {
                                        doc: r,
                                        selection: i
                                    } = e, {
                                        ranges: o
                                    } = i, s = Math.min(...o.map(t => t.$from.pos)), a = Math.max(...o.map(t => t.$to.pos)), l = tx(n);
                                    return tb(r, {
                                        from: s,
                                        to: a
                                    }, {
                                        textSerializers: l
                                    })
                                }
                            }
                        })]
                    }
                }),
                tS = () => ({
                    editor: t,
                    view: e
                }) => (requestAnimationFrame(() => {
                    var n;
                    t.isDestroyed || (e.dom.blur(), null === (n = null == window ? void 0 : window.getSelection()) || void 0 === n || n.removeAllRanges())
                }), !0),
                tM = (t = !1) => ({
                    commands: e
                }) => e.setContent("", t),
                tC = () => ({
                    state: t,
                    tr: e,
                    dispatch: n
                }) => {
                    let {
                        selection: r
                    } = e, {
                        ranges: i
                    } = r;
                    return !n || (i.forEach(({
                        $from: n,
                        $to: r
                    }) => {
                        t.doc.nodesBetween(n.pos, r.pos, (t, n) => {
                            if (t.type.isText) return;
                            let {
                                doc: r,
                                mapping: i
                            } = e, o = r.resolve(i.map(n)), s = r.resolve(i.map(n + t.nodeSize)), a = o.blockRange(s);
                            if (!a) return;
                            let l = (0, y.k9)(a);
                            if (t.type.isTextblock) {
                                let {
                                    defaultType: t
                                } = o.parent.contentMatchAt(o.index());
                                e.setNodeMarkup(a.start, t)
                            }(l || 0 === l) && e.lift(a, l)
                        })
                    }), !0)
                },
                tE = t => e => t(e),
                tN = () => ({
                    state: t,
                    dispatch: e
                }) => R(t, e),
                tO = () => ({
                    tr: t,
                    dispatch: e
                }) => {
                    let {
                        selection: n
                    } = t, r = n.$anchor.node();
                    if (r.content.size > 0) return !1;
                    let i = t.selection.$anchor;
                    for (let n = i.depth; n > 0; n -= 1) {
                        let o = i.node(n);
                        if (o.type === r.type) {
                            if (e) {
                                let e = i.before(n),
                                    r = i.after(n);
                                t.delete(e, r).scrollIntoView()
                            }
                            return !0
                        }
                    }
                    return !1
                },
                tA = t => ({
                    tr: e,
                    state: n,
                    dispatch: r
                }) => {
                    let i = X(t, n.schema),
                        o = e.selection.$anchor;
                    for (let t = o.depth; t > 0; t -= 1) {
                        let n = o.node(t);
                        if (n.type === i) {
                            if (r) {
                                let n = o.before(t),
                                    r = o.after(t);
                                e.delete(n, r).scrollIntoView()
                            }
                            return !0
                        }
                    }
                    return !1
                },
                tT = t => ({
                    tr: e,
                    dispatch: n
                }) => {
                    let {
                        from: r,
                        to: i
                    } = t;
                    return n && e.delete(r, i), !0
                },
                tI = () => ({
                    state: t,
                    dispatch: e
                }) => v(t, e),
                tR = () => ({
                    commands: t
                }) => t.keyboardShortcut("Enter"),
                t_ = () => ({
                    state: t,
                    dispatch: e
                }) => I(t, e);

            function t$(t, e, n = {
                strict: !0
            }) {
                let r = Object.keys(e);
                return !r.length || r.every(r => n.strict ? e[r] === t[r] : tu(e[r]) ? e[r].test(t[r]) : e[r] === t[r])
            }

            function tD(t, e, n = {}) {
                return t.find(t => t.type === e && t$(t.attrs, n))
            }

            function tP(t, e, n = {}) {
                if (!t || !e) return;
                let r = t.parent.childAfter(t.parentOffset);
                if (t.parentOffset === r.offset && 0 !== r.offset && (r = t.parent.childBefore(t.parentOffset)), !r.node) return;
                let i = tD([...r.node.marks], e, n);
                if (!i) return;
                let o = r.index,
                    s = t.start() + r.offset,
                    a = o + 1,
                    l = s + r.node.nodeSize;
                for (tD([...r.node.marks], e, n); o > 0 && i.isInSet(t.parent.child(o - 1).marks);) o -= 1, s -= t.parent.child(o).nodeSize;
                for (; a < t.parent.childCount && function(t, e, n = {}) {
                        return !!tD(t, e, n)
                    }([...t.parent.child(a).marks], e, n);) l += t.parent.child(a).nodeSize, a += 1;
                return {
                    from: s,
                    to: l
                }
            }

            function tF(t, e) {
                if ("string" == typeof t) {
                    if (!e.marks[t]) throw Error(`There is no mark type named '${t}'. Maybe you forgot to add the extension?`);
                    return e.marks[t]
                }
                return t
            }
            let tz = (t, e = {}) => ({
                    tr: n,
                    state: r,
                    dispatch: o
                }) => {
                    let s = tF(t, r.schema),
                        {
                            doc: a,
                            selection: l
                        } = n,
                        {
                            $from: c,
                            from: u,
                            to: h
                        } = l;
                    if (o) {
                        let t = tP(c, s, e);
                        if (t && t.from <= u && t.to >= h) {
                            let e = i.Bs.create(a, t.from, t.to);
                            n.setSelection(e)
                        }
                    }
                    return !0
                },
                tB = t => e => {
                    let n = "function" == typeof t ? t(e) : t;
                    for (let t = 0; t < n.length; t += 1)
                        if (n[t](e)) return !0;
                    return !1
                };

            function tj(t) {
                return t instanceof i.Bs
            }

            function tH(t = 0, e = 0, n = 0) {
                return Math.min(Math.max(t, e), n)
            }

            function tJ(t, e = null) {
                if (!e) return null;
                let n = i.Y1.atStart(t),
                    r = i.Y1.atEnd(t);
                if ("start" === e || !0 === e) return n;
                if ("end" === e) return r;
                let o = n.from,
                    s = r.to;
                return "all" === e ? i.Bs.create(t, tH(0, o, s), tH(t.content.size, o, s)) : i.Bs.create(t, tH(e, o, s), tH(e, o, s))
            }

            function tL() {
                return ["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"].includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in document
            }
            let tq = (t = null, e = {}) => ({
                    editor: n,
                    view: r,
                    tr: i,
                    dispatch: o
                }) => {
                    e = {
                        scrollIntoView: !0,
                        ...e
                    };
                    let s = () => {
                        tL() && r.dom.focus(), requestAnimationFrame(() => {
                            !n.isDestroyed && (r.focus(), (null == e ? void 0 : e.scrollIntoView) && n.commands.scrollIntoView())
                        })
                    };
                    if (r.hasFocus() && null === t || !1 === t) return !0;
                    if (o && null === t && !tj(n.state.selection)) return s(), !0;
                    let a = tJ(i.doc, t) || n.state.selection,
                        l = n.state.selection.eq(a);
                    return o && (l || i.setSelection(a), l && i.storedMarks && i.setStoredMarks(i.storedMarks), s()), !0
                },
                tV = (t, e) => n => t.every((t, r) => e(t, { ...n,
                    index: r
                })),
                tY = (t, e) => ({
                    tr: n,
                    commands: r
                }) => r.insertContentAt({
                    from: n.selection.from,
                    to: n.selection.to
                }, t, e);

            function tU(t) {
                let e = `<body>${t}</body>`;
                return new window.DOMParser().parseFromString(e, "text/html").body
            }

            function tW(t, e, n) {
                if (n = {
                        slice: !0,
                        parseOptions: {},
                        ...n
                    }, "object" == typeof t && null !== t) try {
                    if (Array.isArray(t)) return g.HY.fromArray(t.map(t => e.nodeFromJSON(t)));
                    return e.nodeFromJSON(t)
                } catch (r) {
                    return console.warn("[tiptap warn]: Invalid content.", "Passed value:", t, "Error:", r), tW("", e, n)
                }
                if ("string" == typeof t) {
                    let r = g.aw.fromSchema(e);
                    return n.slice ? r.parseSlice(tU(t), n.parseOptions).content : r.parse(tU(t), n.parseOptions)
                }
                return tW("", e, n)
            }
            let tZ = t => t.toString().startsWith("<"),
                tK = (t, e, n) => ({
                    tr: r,
                    dispatch: o,
                    editor: s
                }) => {
                    if (o) {
                        n = {
                            parseOptions: {},
                            updateSelection: !0,
                            ...n
                        };
                        let o = tW(e, s.schema, {
                            parseOptions: {
                                preserveWhitespace: "full",
                                ...n.parseOptions
                            }
                        });
                        if ("<>" === o.toString()) return !0;
                        let {
                            from: a,
                            to: l
                        } = "number" == typeof t ? {
                            from: t,
                            to: t
                        } : t, c = !0, u = !0, h = tZ(o) ? o : [o];
                        if (h.forEach(t => {
                                t.check(), c = !!c && t.isText && 0 === t.marks.length, u = !!u && t.isBlock
                            }), a === l && u) {
                            let {
                                parent: t
                            } = r.doc.resolve(a), e = t.isTextblock && !t.type.spec.code && !t.childCount;
                            e && (a -= 1, l += 1)
                        }
                        c ? r.insertText(e, a, l) : r.replaceWith(a, l, o), n.updateSelection && function(t, e, n) {
                            let r = t.steps.length - 1;
                            if (r < e) return;
                            let o = t.steps[r];
                            if (!(o instanceof y.Pu || o instanceof y.FC)) return;
                            let s = t.mapping.maps[r],
                                a = 0;
                            s.forEach((t, e, n, r) => {
                                0 === a && (a = r)
                            }), t.setSelection(i.Y1.near(t.doc.resolve(a), -1))
                        }(r, r.steps.length - 1, 0)
                    }
                    return !0
                },
                tG = () => ({
                    state: t,
                    dispatch: e
                }) => E(t, e),
                tQ = () => ({
                    state: t,
                    dispatch: e
                }) => N(t, e),
                tX = () => ({
                    state: t,
                    dispatch: e
                }) => w(t, e),
                t0 = () => ({
                    state: t,
                    dispatch: e
                }) => S(t, e);

            function t1() {
                return "undefined" != typeof navigator && /Mac/.test(navigator.platform)
            }
            let t2 = t => ({
                editor: e,
                view: n,
                tr: r,
                dispatch: i
            }) => {
                let o = (function(t) {
                        let e, n, r, i;
                        let o = t.split(/-(?!$)/),
                            s = o[o.length - 1];
                        "Space" === s && (s = " ");
                        for (let t = 0; t < o.length - 1; t += 1) {
                            let s = o[t];
                            if (/^(cmd|meta|m)$/i.test(s)) i = !0;
                            else if (/^a(lt)?$/i.test(s)) e = !0;
                            else if (/^(c|ctrl|control)$/i.test(s)) n = !0;
                            else if (/^s(hift)?$/i.test(s)) r = !0;
                            else if (/^mod$/i.test(s)) tL() || t1() ? i = !0 : n = !0;
                            else throw Error(`Unrecognized modifier name: ${s}`)
                        }
                        return e && (s = `Alt-${s}`), n && (s = `Ctrl-${s}`), i && (s = `Meta-${s}`), r && (s = `Shift-${s}`), s
                    })(t).split(/-(?!$)/),
                    s = o.find(t => !["Alt", "Ctrl", "Meta", "Shift"].includes(t)),
                    a = new KeyboardEvent("keydown", {
                        key: "Space" === s ? " " : s,
                        altKey: o.includes("Alt"),
                        ctrlKey: o.includes("Ctrl"),
                        metaKey: o.includes("Meta"),
                        shiftKey: o.includes("Shift"),
                        bubbles: !0,
                        cancelable: !0
                    }),
                    l = e.captureTransaction(() => {
                        n.someProp("handleKeyDown", t => t(n, a))
                    });
                return null == l || l.steps.forEach(t => {
                    let e = t.map(r.mapping);
                    e && i && r.maybeStep(e)
                }), !0
            };

            function t5(t, e, n = {}) {
                let {
                    from: r,
                    to: i,
                    empty: o
                } = t.selection, s = e ? X(e, t.schema) : null, a = [];
                t.doc.nodesBetween(r, i, (t, e) => {
                    if (t.isText) return;
                    let n = Math.min(i, e + t.nodeSize);
                    a.push({
                        node: t,
                        from: Math.max(r, e),
                        to: n
                    })
                });
                let l = a.filter(t => !s || s.name === t.node.type.name).filter(t => t$(t.node.attrs, n, {
                    strict: !1
                }));
                if (o) return !!l.length;
                let c = l.reduce((t, e) => t + e.to - e.from, 0);
                return c >= i - r
            }
            let t3 = (t, e = {}) => ({
                    state: n,
                    dispatch: r
                }) => {
                    let i = X(t, n.schema),
                        o = t5(n, i, e);
                    return !!o && O(n, r)
                },
                t9 = () => ({
                    state: t,
                    dispatch: e
                }) => _(t, e),
                t6 = t => ({
                    state: e,
                    dispatch: n
                }) => {
                    let r = X(t, e.schema);
                    return function(t, e) {
                        let {
                            $from: n,
                            $to: i
                        } = t.selection, o = n.blockRange(i, t => t.childCount > 0 && t.firstChild.type == r);
                        return !!o && (!e || (n.node(o.depth - 1).type == r ? function(t, e, n, r) {
                            let i = t.tr,
                                o = r.end,
                                s = r.$to.end(r.depth);
                            o < s && (i.step(new y.FC(o - 1, s, o, s, new g.p2(g.HY.from(n.create(null, r.parent.copy())), 1, 0), 1, !0)), r = new g.Ts(i.doc.resolve(r.$from.pos), i.doc.resolve(s), r.depth));
                            let a = (0, y.k9)(r);
                            if (null == a) return !1;
                            i.lift(r, a);
                            let l = i.mapping.map(o, -1) - 1;
                            return (0, y.Mn)(i.doc, l) && i.join(l), e(i.scrollIntoView()), !0
                        }(t, e, r, o) : function(t, e, n) {
                            let r = t.tr,
                                i = n.parent;
                            for (let t = n.end, e = n.endIndex - 1, o = n.startIndex; e > o; e--) t -= i.child(e).nodeSize, r.delete(t - 1, t + 1);
                            let o = r.doc.resolve(n.start),
                                s = o.nodeAfter;
                            if (r.mapping.map(n.end) != n.start + o.nodeAfter.nodeSize) return !1;
                            let a = 0 == n.startIndex,
                                l = n.endIndex == i.childCount,
                                c = o.node(-1),
                                u = o.index(-1);
                            if (!c.canReplace(u + (a ? 0 : 1), u + 1, s.content.append(l ? g.HY.empty : g.HY.from(i)))) return !1;
                            let h = o.pos,
                                p = h + s.nodeSize;
                            return r.step(new y.FC(h - (a ? 1 : 0), p + (l ? 1 : 0), h + 1, p - 1, new g.p2((a ? g.HY.empty : g.HY.from(i.copy(g.HY.empty))).append(l ? g.HY.empty : g.HY.from(i.copy(g.HY.empty))), a ? 0 : 1, l ? 0 : 1), a ? 0 : 1)), e(r.scrollIntoView()), !0
                        }(t, e, o)))
                    }(e, n)
                },
                t8 = () => ({
                    state: t,
                    dispatch: e
                }) => A(t, e);

            function t4(t, e) {
                return e.nodes[t] ? "node" : e.marks[t] ? "mark" : null
            }

            function t7(t, e) {
                let n = "string" == typeof e ? [e] : e;
                return Object.keys(t).reduce((e, r) => (n.includes(r) || (e[r] = t[r]), e), {})
            }
            let et = (t, e) => ({
                    tr: n,
                    state: r,
                    dispatch: i
                }) => {
                    let o = null,
                        s = null,
                        a = t4("string" == typeof t ? t : t.name, r.schema);
                    return !!a && ("node" === a && (o = X(t, r.schema)), "mark" === a && (s = tF(t, r.schema)), i && n.selection.ranges.forEach(t => {
                        r.doc.nodesBetween(t.$from.pos, t.$to.pos, (t, r) => {
                            o && o === t.type && n.setNodeMarkup(r, void 0, t7(t.attrs, e)), s && t.marks.length && t.marks.forEach(i => {
                                s === i.type && n.addMark(r, r + t.nodeSize, s.create(t7(i.attrs, e)))
                            })
                        })
                    }), !0)
                },
                ee = () => ({
                    tr: t,
                    dispatch: e
                }) => (e && t.scrollIntoView(), !0),
                en = () => ({
                    tr: t,
                    commands: e
                }) => e.setTextSelection({
                    from: 0,
                    to: t.doc.content.size
                }),
                er = () => ({
                    state: t,
                    dispatch: e
                }) => x(t, e),
                ei = () => ({
                    state: t,
                    dispatch: e
                }) => M(t, e),
                eo = () => ({
                    state: t,
                    dispatch: e
                }) => D(t, e),
                es = () => ({
                    state: t,
                    dispatch: e
                }) => j(t, e),
                ea = () => ({
                    state: t,
                    dispatch: e
                }) => B(t, e);

            function el(t, e, n = {}) {
                return tW(t, e, {
                    slice: !1,
                    parseOptions: n
                })
            }
            let ec = (t, e = !1, n = {}) => ({
                tr: r,
                editor: i,
                dispatch: o
            }) => {
                let {
                    doc: s
                } = r, a = el(t, i.schema, n);
                return o && r.replaceWith(0, s.content.size, a).setMeta("preventUpdate", !e), !0
            };

            function eu(t) {
                return e => (function(t, e) {
                    for (let n = t.depth; n > 0; n -= 1) {
                        let r = t.node(n);
                        if (e(r)) return {
                            pos: n > 0 ? t.before(n) : 0,
                            start: t.start(n),
                            depth: n,
                            node: r
                        }
                    }
                })(e.$from, t)
            }

            function eh(t) {
                let e = tg.resolve(t);
                return ts(e)
            }

            function ep(t, e) {
                let n = tF(e, t.schema),
                    {
                        from: r,
                        to: i,
                        empty: o
                    } = t.selection,
                    s = [];
                o ? (t.storedMarks && s.push(...t.storedMarks), s.push(...t.selection.$head.marks())) : t.doc.nodesBetween(r, i, t => {
                    s.push(...t.marks)
                });
                let a = s.find(t => t.type.name === n.name);
                return a ? { ...a.attrs
                } : {}
            }

            function ed(t, e, n) {
                let r = [];
                return t === e ? n.resolve(t).marks().forEach(e => {
                    let i = n.resolve(t - 1),
                        o = tP(i, e.type);
                    o && r.push({
                        mark: e,
                        ...o
                    })
                }) : n.nodesBetween(t, e, (t, e) => {
                    r.push(...t.marks.map(n => ({
                        from: e,
                        to: e + t.nodeSize,
                        mark: n
                    })))
                }), r
            }

            function ef(t, e, n = {}) {
                let {
                    empty: r,
                    ranges: i
                } = t.selection, o = e ? tF(e, t.schema) : null;
                if (r) return !!(t.storedMarks || t.selection.$from.marks()).filter(t => !o || o.name === t.type.name).find(t => t$(t.attrs, n, {
                    strict: !1
                }));
                let s = 0,
                    a = [];
                if (i.forEach(({
                        $from: e,
                        $to: n
                    }) => {
                        let r = e.pos,
                            i = n.pos;
                        t.doc.nodesBetween(r, i, (t, e) => {
                            if (!t.isText && !t.marks.length) return;
                            let n = Math.max(r, e),
                                o = Math.min(i, e + t.nodeSize);
                            s += o - n, a.push(...t.marks.map(t => ({
                                mark: t,
                                from: n,
                                to: o
                            })))
                        })
                    }), 0 === s) return !1;
                let l = a.filter(t => !o || o.name === t.mark.type.name).filter(t => t$(t.mark.attrs, n, {
                        strict: !1
                    })).reduce((t, e) => t + e.to - e.from, 0),
                    c = a.filter(t => !o || t.mark.type !== o && t.mark.type.excludes(o)).reduce((t, e) => t + e.to - e.from, 0);
                return (l > 0 ? l + c : l) >= s
            }

            function em(t, e) {
                let {
                    nodeExtensions: n
                } = G(e), r = n.find(e => e.name === t);
                if (!r) return !1;
                let i = {
                        name: r.name,
                        options: r.options,
                        storage: r.storage
                    },
                    o = tr(K(r, "group", i));
                return "string" == typeof o && o.split(" ").includes("list")
            }
            let eg = (t, e = {}) => ({
                    tr: n,
                    state: r,
                    dispatch: i
                }) => {
                    let {
                        selection: o
                    } = n, {
                        empty: s,
                        ranges: a
                    } = o, l = tF(t, r.schema);
                    if (i) {
                        if (s) {
                            let t = ep(r, l);
                            n.addStoredMark(l.create({ ...t,
                                ...e
                            }))
                        } else a.forEach(t => {
                            let i = t.$from.pos,
                                o = t.$to.pos;
                            r.doc.nodesBetween(i, o, (t, r) => {
                                let s = Math.max(r, i),
                                    a = Math.min(r + t.nodeSize, o),
                                    c = t.marks.find(t => t.type === l);
                                c ? t.marks.forEach(t => {
                                    l === t.type && n.addMark(s, a, l.create({ ...t.attrs,
                                        ...e
                                    }))
                                }) : n.addMark(s, a, l.create(e))
                            })
                        })
                    }
                    return function(t, e, n) {
                        var r;
                        let {
                            selection: i
                        } = e, o = null;
                        if (tj(i) && (o = i.$cursor), o) {
                            let e = null !== (r = t.storedMarks) && void 0 !== r ? r : o.marks();
                            return !!n.isInSet(e) || !e.some(t => t.type.excludes(n))
                        }
                        let {
                            ranges: s
                        } = i;
                        return s.some(({
                            $from: e,
                            $to: r
                        }) => {
                            let i = 0 === e.depth && t.doc.inlineContent && t.doc.type.allowsMarkType(n);
                            return t.doc.nodesBetween(e.pos, r.pos, (t, e, r) => {
                                if (i) return !1;
                                if (t.isInline) {
                                    let e = !r || r.type.allowsMarkType(n),
                                        o = !!n.isInSet(t.marks) || !t.marks.some(t => t.type.excludes(n));
                                    i = e && o
                                }
                                return !i
                            }), i
                        })
                    }(r, n, l)
                },
                ey = (t, e) => ({
                    tr: n
                }) => (n.setMeta(t, e), !0),
                ev = (t, e = {}) => ({
                    state: n,
                    dispatch: r,
                    chain: i
                }) => {
                    let o = X(t, n.schema);
                    return o.isTextblock ? i().command(({
                        commands: t
                    }) => {
                        let r = H(o, e)(n);
                        return !!r || t.clearNodes()
                    }).command(({
                        state: t
                    }) => H(o, e)(t, r)).run() : (console.warn('[tiptap warn]: Currently "setNode()" only supports text block nodes.'), !1)
                },
                ew = t => ({
                    tr: e,
                    dispatch: n
                }) => {
                    if (n) {
                        let {
                            doc: n
                        } = e, r = tH(t, 0, n.content.size), o = i.qv.create(n, r);
                        e.setSelection(o)
                    }
                    return !0
                },
                eb = t => ({
                    tr: e,
                    dispatch: n
                }) => {
                    if (n) {
                        let {
                            doc: n
                        } = e, {
                            from: r,
                            to: o
                        } = "number" == typeof t ? {
                            from: t,
                            to: t
                        } : t, s = i.Bs.atStart(n).from, a = i.Bs.atEnd(n).to, l = tH(r, s, a), c = tH(o, s, a), u = i.Bs.create(n, l, c);
                        e.setSelection(u)
                    }
                    return !0
                },
                ex = t => ({
                    state: e,
                    dispatch: n
                }) => {
                    let r = X(t, e.schema);
                    return function(t, e) {
                        let {
                            $from: n,
                            $to: i
                        } = t.selection, o = n.blockRange(i, t => t.childCount > 0 && t.firstChild.type == r);
                        if (!o) return !1;
                        let s = o.startIndex;
                        if (0 == s) return !1;
                        let a = o.parent,
                            l = a.child(s - 1);
                        if (l.type != r) return !1;
                        if (e) {
                            let n = l.lastChild && l.lastChild.type == a.type,
                                i = g.HY.from(n ? r.create() : null),
                                s = new g.p2(g.HY.from(r.create(null, g.HY.from(a.type.create(null, i)))), n ? 3 : 1, 0),
                                c = o.start,
                                u = o.end;
                            e(t.tr.step(new y.FC(c - (n ? 3 : 1), u, c, u, s, 1, !0)).scrollIntoView())
                        }
                        return !0
                    }(e, n)
                };

            function ek(t, e, n) {
                return Object.fromEntries(Object.entries(n).filter(([n]) => {
                    let r = t.find(t => t.type === e && t.name === n);
                    return !!r && r.attribute.keepOnSplit
                }))
            }

            function eS(t, e) {
                let n = t.storedMarks || t.selection.$to.parentOffset && t.selection.$from.marks();
                if (n) {
                    let r = n.filter(t => null == e ? void 0 : e.includes(t.type.name));
                    t.tr.ensureMarks(r)
                }
            }
            let eM = ({
                    keepMarks: t = !0
                } = {}) => ({
                    tr: e,
                    state: n,
                    dispatch: r,
                    editor: o
                }) => {
                    let {
                        selection: s,
                        doc: a
                    } = e, {
                        $from: l,
                        $to: c
                    } = s, u = o.extensionManager.attributes, h = ek(u, l.node().type.name, l.node().attrs);
                    if (s instanceof i.qv && s.node.isBlock) return !!(l.parentOffset && (0, y.Ax)(a, l.pos)) && (r && (t && eS(n, o.extensionManager.splittableMarks), e.split(l.pos).scrollIntoView()), !0);
                    if (!l.parent.isBlock) return !1;
                    if (r) {
                        let r = c.parentOffset === c.parent.content.size;
                        s instanceof i.Bs && e.deleteSelection();
                        let a = 0 === l.depth ? void 0 : function(t) {
                                for (let e = 0; e < t.edgeCount; e += 1) {
                                    let {
                                        type: n
                                    } = t.edge(e);
                                    if (n.isTextblock && !n.hasRequiredAttrs()) return n
                                }
                                return null
                            }(l.node(-1).contentMatchAt(l.indexAfter(-1))),
                            u = r && a ? [{
                                type: a,
                                attrs: h
                            }] : void 0,
                            p = (0, y.Ax)(e.doc, e.mapping.map(l.pos), 1, u);
                        if (!u && !p && (0, y.Ax)(e.doc, e.mapping.map(l.pos), 1, a ? [{
                                type: a
                            }] : void 0) && (p = !0, u = a ? [{
                                type: a,
                                attrs: h
                            }] : void 0), p && (e.split(e.mapping.map(l.pos), 1, u), a && !r && !l.parentOffset && l.parent.type !== a)) {
                            let t = e.mapping.map(l.before()),
                                n = e.doc.resolve(t);
                            l.node(-1).canReplaceWith(n.index(), n.index() + 1, a) && e.setNodeMarkup(e.mapping.map(l.before()), a)
                        }
                        t && eS(n, o.extensionManager.splittableMarks), e.scrollIntoView()
                    }
                    return !0
                },
                eC = t => ({
                    tr: e,
                    state: n,
                    dispatch: r,
                    editor: o
                }) => {
                    var s;
                    let a = X(t, n.schema),
                        {
                            $from: l,
                            $to: c
                        } = n.selection,
                        u = n.selection.node;
                    if (u && u.isBlock || l.depth < 2 || !l.sameParent(c)) return !1;
                    let h = l.node(-1);
                    if (h.type !== a) return !1;
                    let p = o.extensionManager.attributes;
                    if (0 === l.parent.content.size && l.node(-1).childCount === l.indexAfter(-1)) {
                        if (2 === l.depth || l.node(-3).type !== a || l.index(-2) !== l.node(-2).childCount - 1) return !1;
                        if (r) {
                            let t = g.HY.empty,
                                n = l.index(-1) ? 1 : l.index(-2) ? 2 : 3;
                            for (let e = l.depth - n; e >= l.depth - 3; e -= 1) t = g.HY.from(l.node(e).copy(t));
                            let r = l.indexAfter(-1) < l.node(-2).childCount ? 1 : l.indexAfter(-2) < l.node(-3).childCount ? 2 : 3,
                                o = ek(p, l.node().type.name, l.node().attrs),
                                c = (null === (s = a.contentMatch.defaultType) || void 0 === s ? void 0 : s.createAndFill(o)) || void 0;
                            t = t.append(g.HY.from(a.createAndFill(null, c) || void 0));
                            let u = l.before(l.depth - (n - 1));
                            e.replace(u, l.after(-r), new g.p2(t, 4 - n, 0));
                            let h = -1;
                            e.doc.nodesBetween(u, e.doc.content.size, (t, e) => {
                                if (h > -1) return !1;
                                t.isTextblock && 0 === t.content.size && (h = e + 1)
                            }), h > -1 && e.setSelection(i.Bs.near(e.doc.resolve(h))), e.scrollIntoView()
                        }
                        return !0
                    }
                    let d = c.pos === l.end() ? h.contentMatchAt(0).defaultType : null,
                        f = ek(p, h.type.name, h.attrs),
                        m = ek(p, l.node().type.name, l.node().attrs);
                    return e.delete(l.pos, c.pos), !!(0, y.Ax)(e.doc, l.pos, 2) && (r && e.split(l.pos, 2, d ? [{
                        type: a,
                        attrs: f
                    }, {
                        type: d,
                        attrs: m
                    }] : [{
                        type: a,
                        attrs: f
                    }]).scrollIntoView(), !0)
                },
                eE = (t, e) => {
                    let n = eu(t => t.type === e)(t.selection);
                    if (!n) return !0;
                    let r = t.doc.resolve(Math.max(0, n.pos - 1)).before(n.depth);
                    if (void 0 === r) return !0;
                    let i = t.doc.nodeAt(r),
                        o = n.node.type === (null == i ? void 0 : i.type) && (0, y.Mn)(t.doc, n.pos);
                    return !o || (t.join(n.pos), !0)
                },
                eN = (t, e) => {
                    let n = eu(t => t.type === e)(t.selection);
                    if (!n) return !0;
                    let r = t.doc.resolve(n.start).after(n.depth);
                    if (void 0 === r) return !0;
                    let i = t.doc.nodeAt(r),
                        o = n.node.type === (null == i ? void 0 : i.type) && (0, y.Mn)(t.doc, r);
                    return !o || (t.join(r), !0)
                },
                eO = (t, e) => ({
                    editor: n,
                    tr: r,
                    state: i,
                    dispatch: o,
                    chain: s,
                    commands: a,
                    can: l
                }) => {
                    let {
                        extensions: c
                    } = n.extensionManager, u = X(t, i.schema), h = X(e, i.schema), {
                        selection: p
                    } = i, {
                        $from: d,
                        $to: f
                    } = p, m = d.blockRange(f);
                    if (!m) return !1;
                    let g = eu(t => em(t.type.name, c))(p);
                    if (m.depth >= 1 && g && m.depth - g.depth <= 1) {
                        if (g.node.type === u) return a.liftListItem(h);
                        if (em(g.node.type.name, c) && u.validContent(g.node.content) && o) return s().command(() => (r.setNodeMarkup(g.pos, u), !0)).command(() => eE(r, u)).command(() => eN(r, u)).run()
                    }
                    return s().command(() => {
                        let t = l().wrapInList(u);
                        return !!t || a.clearNodes()
                    }).wrapInList(u).command(() => eE(r, u)).command(() => eN(r, u)).run()
                },
                eA = (t, e = {}, n = {}) => ({
                    state: r,
                    commands: i
                }) => {
                    let {
                        extendEmptyMarkRange: o = !1
                    } = n, s = tF(t, r.schema), a = ef(r, s, e);
                    return a ? i.unsetMark(s, {
                        extendEmptyMarkRange: o
                    }) : i.setMark(s, e)
                },
                eT = (t, e, n = {}) => ({
                    state: r,
                    commands: i
                }) => {
                    let o = X(t, r.schema),
                        s = X(e, r.schema),
                        a = t5(r, o, n);
                    return a ? i.setNode(s) : i.setNode(o, n)
                },
                eI = (t, e = {}) => ({
                    state: n,
                    commands: r
                }) => {
                    let i = X(t, n.schema),
                        o = t5(n, i, e);
                    return o ? r.lift(i) : r.wrapIn(i, e)
                },
                eR = () => ({
                    state: t,
                    dispatch: e
                }) => {
                    let n = t.plugins;
                    for (let r = 0; r < n.length; r += 1) {
                        let i;
                        let o = n[r];
                        if (o.spec.isInputRules && (i = o.getState(t))) {
                            if (e) {
                                let e = t.tr,
                                    n = i.transform;
                                for (let t = n.steps.length - 1; t >= 0; t -= 1) e.step(n.steps[t].invert(n.docs[t]));
                                if (i.text) {
                                    let n = e.doc.resolve(i.from).marks();
                                    e.replaceWith(i.from, i.to, t.schema.text(i.text, n))
                                } else e.delete(i.from, i.to)
                            }
                            return !0
                        }
                    }
                    return !1
                },
                e_ = () => ({
                    tr: t,
                    dispatch: e
                }) => {
                    let {
                        selection: n
                    } = t, {
                        empty: r,
                        ranges: i
                    } = n;
                    return !!r || (e && i.forEach(e => {
                        t.removeMark(e.$from.pos, e.$to.pos)
                    }), !0)
                },
                e$ = (t, e = {}) => ({
                    tr: n,
                    state: r,
                    dispatch: i
                }) => {
                    var o;
                    let {
                        extendEmptyMarkRange: s = !1
                    } = e, {
                        selection: a
                    } = n, l = tF(t, r.schema), {
                        $from: c,
                        empty: u,
                        ranges: h
                    } = a;
                    if (!i) return !0;
                    if (u && s) {
                        let {
                            from: t,
                            to: e
                        } = a, r = null === (o = c.marks().find(t => t.type === l)) || void 0 === o ? void 0 : o.attrs, i = tP(c, l, r);
                        i && (t = i.from, e = i.to), n.removeMark(t, e, l)
                    } else h.forEach(t => {
                        n.removeMark(t.$from.pos, t.$to.pos, l)
                    });
                    return n.removeStoredMark(l), !0
                },
                eD = (t, e = {}) => ({
                    tr: n,
                    state: r,
                    dispatch: i
                }) => {
                    let o = null,
                        s = null,
                        a = t4("string" == typeof t ? t : t.name, r.schema);
                    return !!a && ("node" === a && (o = X(t, r.schema)), "mark" === a && (s = tF(t, r.schema)), i && n.selection.ranges.forEach(t => {
                        let i = t.$from.pos,
                            a = t.$to.pos;
                        r.doc.nodesBetween(i, a, (t, r) => {
                            o && o === t.type && n.setNodeMarkup(r, void 0, { ...t.attrs,
                                ...e
                            }), s && t.marks.length && t.marks.forEach(o => {
                                if (s === o.type) {
                                    let l = Math.min(r + t.nodeSize, a);
                                    n.addMark(Math.max(r, i), l, s.create({ ...o.attrs,
                                        ...e
                                    }))
                                }
                            })
                        })
                    }), !0)
                },
                eP = (t, e = {}) => ({
                    state: n,
                    dispatch: r
                }) => {
                    let i = X(t, n.schema);
                    return (function(t, e = null) {
                        return function(n, r) {
                            let {
                                $from: i,
                                $to: o
                            } = n.selection, s = i.blockRange(o), a = s && (0, y.nd)(s, t, e);
                            return !!a && (r && r(n.tr.wrap(s, a).scrollIntoView()), !0)
                        }
                    })(i, e)(n, r)
                },
                eF = (t, e = {}) => ({
                    state: n,
                    dispatch: r
                }) => {
                    let i = X(t, n.schema);
                    return (function(t, e = null) {
                        return function(n, r) {
                            let {
                                $from: i,
                                $to: o
                            } = n.selection, s = i.blockRange(o), a = !1, l = s;
                            if (!s) return !1;
                            if (s.depth >= 2 && i.node(s.depth - 1).type.compatibleContent(t) && 0 == s.startIndex) {
                                if (0 == i.index(s.depth - 1)) return !1;
                                let t = n.doc.resolve(s.start - 2);
                                l = new g.Ts(t, t, s.depth), s.endIndex < s.parent.childCount && (s = new g.Ts(i, n.doc.resolve(o.end(s.depth)), s.depth)), a = !0
                            }
                            let c = (0, y.nd)(l, t, e, s);
                            return !!c && (r && r((function(t, e, n, r, i) {
                                let o = g.HY.empty;
                                for (let t = n.length - 1; t >= 0; t--) o = g.HY.from(n[t].type.create(n[t].attrs, o));
                                t.step(new y.FC(e.start - (r ? 2 : 0), e.end, e.start, e.end, new g.p2(o, 0, 0), n.length, !0));
                                let s = 0;
                                for (let t = 0; t < n.length; t++) n[t].type == i && (s = t + 1);
                                let a = n.length - s,
                                    l = e.start + n.length - (r ? 2 : 0),
                                    c = e.parent;
                                for (let n = e.startIndex, r = e.endIndex, i = !0; n < r; n++, i = !1) !i && (0, y.Ax)(t.doc, l, a) && (t.split(l, a), l += 2 * a), l += c.child(n).nodeSize;
                                return t
                            })(n.tr, s, c, a, t).scrollIntoView()), !0)
                        }
                    })(i, e)(n, r)
                };
            var ez = Object.freeze({
                __proto__: null,
                blur: tS,
                clearContent: tM,
                clearNodes: tC,
                command: tE,
                createParagraphNear: tN,
                deleteCurrentNode: tO,
                deleteNode: tA,
                deleteRange: tT,
                deleteSelection: tI,
                enter: tR,
                exitCode: t_,
                extendMarkRange: tz,
                first: tB,
                focus: tq,
                forEach: tV,
                insertContent: tY,
                insertContentAt: tK,
                joinUp: tG,
                joinDown: tQ,
                joinBackward: tX,
                joinForward: t0,
                keyboardShortcut: t2,
                lift: t3,
                liftEmptyBlock: t9,
                liftListItem: t6,
                newlineInCode: t8,
                resetAttributes: et,
                scrollIntoView: ee,
                selectAll: en,
                selectNodeBackward: er,
                selectNodeForward: ei,
                selectParentNode: eo,
                selectTextblockEnd: es,
                selectTextblockStart: ea,
                setContent: ec,
                setMark: eg,
                setMeta: ey,
                setNode: ev,
                setNodeSelection: ew,
                setTextSelection: eb,
                sinkListItem: ex,
                splitBlock: eM,
                splitListItem: eC,
                toggleList: eO,
                toggleMark: eA,
                toggleNode: eT,
                toggleWrap: eI,
                undoInputRule: eR,
                unsetAllMarks: e_,
                unsetMark: e$,
                updateAttributes: eD,
                wrapIn: eP,
                wrapInList: eF
            });
            let eB = tw.create({
                    name: "commands",
                    addCommands: () => ({ ...ez
                    })
                }),
                ej = tw.create({
                    name: "editable",
                    addProseMirrorPlugins() {
                        return [new i.Sy({
                            key: new i.H$("editable"),
                            props: {
                                editable: () => this.editor.options.editable
                            }
                        })]
                    }
                }),
                eH = tw.create({
                    name: "focusEvents",
                    addProseMirrorPlugins() {
                        let {
                            editor: t
                        } = this;
                        return [new i.Sy({
                            key: new i.H$("focusEvents"),
                            props: {
                                handleDOMEvents: {
                                    focus: (e, n) => {
                                        t.isFocused = !0;
                                        let r = t.state.tr.setMeta("focus", {
                                            event: n
                                        }).setMeta("addToHistory", !1);
                                        return e.dispatch(r), !1
                                    },
                                    blur: (e, n) => {
                                        t.isFocused = !1;
                                        let r = t.state.tr.setMeta("blur", {
                                            event: n
                                        }).setMeta("addToHistory", !1);
                                        return e.dispatch(r), !1
                                    }
                                }
                            }
                        })]
                    }
                }),
                eJ = tw.create({
                    name: "keymap",
                    addKeyboardShortcuts() {
                        let t = () => this.editor.commands.first(({
                                commands: t
                            }) => [() => t.undoInputRule(), () => t.command(({
                                tr: e
                            }) => {
                                let {
                                    selection: n,
                                    doc: r
                                } = e, {
                                    empty: o,
                                    $anchor: s
                                } = n, {
                                    pos: a,
                                    parent: l
                                } = s, c = i.Y1.atStart(r).from === a;
                                return !!o && !!c && !!l.type.isTextblock && !l.textContent.length && t.clearNodes()
                            }), () => t.deleteSelection(), () => t.joinBackward(), () => t.selectNodeBackward()]),
                            e = () => this.editor.commands.first(({
                                commands: t
                            }) => [() => t.deleteSelection(), () => t.deleteCurrentNode(), () => t.joinForward(), () => t.selectNodeForward()]),
                            n = () => this.editor.commands.first(({
                                commands: t
                            }) => [() => t.newlineInCode(), () => t.createParagraphNear(), () => t.liftEmptyBlock(), () => t.splitBlock()]),
                            r = {
                                Enter: n,
                                "Mod-Enter": () => this.editor.commands.exitCode(),
                                Backspace: t,
                                "Mod-Backspace": t,
                                "Shift-Backspace": t,
                                Delete: e,
                                "Mod-Delete": e,
                                "Mod-a": () => this.editor.commands.selectAll()
                            },
                            o = { ...r
                            },
                            s = { ...r,
                                "Ctrl-h": t,
                                "Alt-Backspace": t,
                                "Ctrl-d": e,
                                "Ctrl-Alt-Backspace": e,
                                "Alt-Delete": e,
                                "Alt-d": e,
                                "Ctrl-a": () => this.editor.commands.selectTextblockStart(),
                                "Ctrl-e": () => this.editor.commands.selectTextblockEnd()
                            };
                        return tL() || t1() ? s : o
                    },
                    addProseMirrorPlugins() {
                        return [new i.Sy({
                            key: new i.H$("clearDocument"),
                            appendTransaction: (t, e, n) => {
                                let r = t.some(t => t.docChanged) && !e.doc.eq(n.doc);
                                if (!r) return;
                                let {
                                    empty: o,
                                    from: s,
                                    to: a
                                } = e.selection, l = i.Y1.atStart(e.doc).from, c = i.Y1.atEnd(e.doc).to, u = 0 === n.doc.textBetween(0, n.doc.content.size, " ", " ").length;
                                if (o || !(s === l && a === c) || !u) return;
                                let h = n.tr,
                                    p = U({
                                        state: n,
                                        transaction: h
                                    }),
                                    {
                                        commands: d
                                    } = new W({
                                        editor: this.editor,
                                        state: p
                                    });
                                if (d.clearNodes(), h.steps.length) return h
                            }
                        })]
                    }
                }),
                eL = tw.create({
                    name: "tabindex",
                    addProseMirrorPlugins() {
                        return [new i.Sy({
                            key: new i.H$("tabindex"),
                            props: {
                                attributes: this.editor.isEditable ? {
                                    tabindex: "0"
                                } : {}
                            }
                        })]
                    }
                });
            var eq = Object.freeze({
                __proto__: null,
                ClipboardTextSerializer: tk,
                Commands: eB,
                Editable: ej,
                FocusEvents: eH,
                Keymap: eJ,
                Tabindex: eL
            });
            let eV = `.ProseMirror {
  position: relative;
}

.ProseMirror {
  word-wrap: break-word;
  white-space: pre-wrap;
  white-space: break-spaces;
  -webkit-font-variant-ligatures: none;
  font-variant-ligatures: none;
  font-feature-settings: "liga" 0; /* the above doesn't seem to work in Edge */
}

.ProseMirror [contenteditable="false"] {
  white-space: normal;
}

.ProseMirror [contenteditable="false"] [contenteditable="true"] {
  white-space: pre-wrap;
}

.ProseMirror pre {
  white-space: pre-wrap;
}

img.ProseMirror-separator {
  display: inline !important;
  border: none !important;
  margin: 0 !important;
  width: 1px !important;
  height: 1px !important;
}

.ProseMirror-gapcursor {
  display: none;
  pointer-events: none;
  position: absolute;
  margin: 0;
}

.ProseMirror-gapcursor:after {
  content: "";
  display: block;
  position: absolute;
  top: -2px;
  width: 20px;
  border-top: 1px solid black;
  animation: ProseMirror-cursor-blink 1.1s steps(2, start) infinite;
}

@keyframes ProseMirror-cursor-blink {
  to {
    visibility: hidden;
  }
}

.ProseMirror-hideselection *::selection {
  background: transparent;
}

.ProseMirror-hideselection *::-moz-selection {
  background: transparent;
}

.ProseMirror-hideselection * {
  caret-color: transparent;
}

.ProseMirror-focused .ProseMirror-gapcursor {
  display: block;
}

.tippy-box[data-animation=fade][data-state=hidden] {
  opacity: 0
}`;
            class eY extends Z {
                constructor(t = {}) {
                    super(), this.isFocused = !1, this.extensionStorage = {}, this.options = {
                        element: document.createElement("div"),
                        content: "",
                        injectCSS: !0,
                        injectNonce: void 0,
                        extensions: [],
                        autofocus: !1,
                        editable: !0,
                        editorProps: {},
                        parseOptions: {},
                        enableInputRules: !0,
                        enablePasteRules: !0,
                        enableCoreExtensions: !0,
                        onBeforeCreate: () => null,
                        onCreate: () => null,
                        onUpdate: () => null,
                        onSelectionUpdate: () => null,
                        onTransaction: () => null,
                        onFocus: () => null,
                        onBlur: () => null,
                        onDestroy: () => null
                    }, this.isCapturingTransaction = !1, this.capturedTransaction = null, this.setOptions(t), this.createExtensionManager(), this.createCommandManager(), this.createSchema(), this.on("beforeCreate", this.options.onBeforeCreate), this.emit("beforeCreate", {
                        editor: this
                    }), this.createView(), this.injectCSS(), this.on("create", this.options.onCreate), this.on("update", this.options.onUpdate), this.on("selectionUpdate", this.options.onSelectionUpdate), this.on("transaction", this.options.onTransaction), this.on("focus", this.options.onFocus), this.on("blur", this.options.onBlur), this.on("destroy", this.options.onDestroy), window.setTimeout(() => {
                        this.isDestroyed || (this.commands.focus(this.options.autofocus), this.emit("create", {
                            editor: this
                        }))
                    }, 0)
                }
                get storage() {
                    return this.extensionStorage
                }
                get commands() {
                    return this.commandManager.commands
                }
                chain() {
                    return this.commandManager.chain()
                }
                can() {
                    return this.commandManager.can()
                }
                injectCSS() {
                    this.options.injectCSS && document && (this.css = function(t, e) {
                        let n = document.querySelector("style[data-tiptap-style]");
                        if (null !== n) return n;
                        let r = document.createElement("style");
                        return e && r.setAttribute("nonce", e), r.setAttribute("data-tiptap-style", ""), r.innerHTML = t, document.getElementsByTagName("head")[0].appendChild(r), r
                    }(eV, this.options.injectNonce))
                }
                setOptions(t = {}) {
                    this.options = { ...this.options,
                        ...t
                    }, this.view && this.state && !this.isDestroyed && (this.options.editorProps && this.view.setProps(this.options.editorProps), this.view.updateState(this.state))
                }
                setEditable(t) {
                    this.setOptions({
                        editable: t
                    }), this.emit("update", {
                        editor: this,
                        transaction: this.state.tr
                    })
                }
                get isEditable() {
                    return this.options.editable && this.view && this.view.editable
                }
                get state() {
                    return this.view.state
                }
                registerPlugin(t, e) {
                    let n = tn(e) ? e(t, [...this.state.plugins]) : [...this.state.plugins, t],
                        r = this.state.reconfigure({
                            plugins: n
                        });
                    this.view.updateState(r)
                }
                unregisterPlugin(t) {
                    if (this.isDestroyed) return;
                    let e = "string" == typeof t ? `${t}$` : t.key,
                        n = this.state.reconfigure({
                            plugins: this.state.plugins.filter(t => !t.key.startsWith(e))
                        });
                    this.view.updateState(n)
                }
                createExtensionManager() {
                    let t = this.options.enableCoreExtensions ? Object.values(eq) : [],
                        e = [...t, ...this.options.extensions].filter(t => ["extension", "node", "mark"].includes(null == t ? void 0 : t.type));
                    this.extensionManager = new tg(e, this)
                }
                createCommandManager() {
                    this.commandManager = new W({
                        editor: this
                    })
                }
                createSchema() {
                    this.schema = this.extensionManager.schema
                }
                createView() {
                    let t = el(this.options.content, this.schema, this.options.parseOptions),
                        e = tJ(t, this.options.autofocus);
                    this.view = new o.tk(this.options.element, { ...this.options.editorProps,
                        dispatchTransaction: this.dispatchTransaction.bind(this),
                        state: i.yy.create({
                            doc: t,
                            selection: e || void 0
                        })
                    });
                    let n = this.state.reconfigure({
                        plugins: this.extensionManager.plugins
                    });
                    this.view.updateState(n), this.createNodeViews();
                    let r = this.view.dom;
                    r.editor = this
                }
                createNodeViews() {
                    this.view.setProps({
                        nodeViews: this.extensionManager.nodeViews
                    })
                }
                captureTransaction(t) {
                    this.isCapturingTransaction = !0, t(), this.isCapturingTransaction = !1;
                    let e = this.capturedTransaction;
                    return this.capturedTransaction = null, e
                }
                dispatchTransaction(t) {
                    if (this.isCapturingTransaction) {
                        if (!this.capturedTransaction) {
                            this.capturedTransaction = t;
                            return
                        }
                        t.steps.forEach(t => {
                            var e;
                            return null === (e = this.capturedTransaction) || void 0 === e ? void 0 : e.step(t)
                        });
                        return
                    }
                    let e = this.state.apply(t),
                        n = !this.state.selection.eq(e.selection);
                    this.view.updateState(e), this.emit("transaction", {
                        editor: this,
                        transaction: t
                    }), n && this.emit("selectionUpdate", {
                        editor: this,
                        transaction: t
                    });
                    let r = t.getMeta("focus"),
                        i = t.getMeta("blur");
                    r && this.emit("focus", {
                        editor: this,
                        event: r.event,
                        transaction: t
                    }), i && this.emit("blur", {
                        editor: this,
                        event: i.event,
                        transaction: t
                    }), !t.docChanged || t.getMeta("preventUpdate") || this.emit("update", {
                        editor: this,
                        transaction: t
                    })
                }
                getAttributes(t) {
                    return function(t, e) {
                        let n = t4("string" == typeof e ? e : e.name, t.schema);
                        return "node" === n ? function(t, e) {
                            let n = X(e, t.schema),
                                {
                                    from: r,
                                    to: i
                                } = t.selection,
                                o = [];
                            t.doc.nodesBetween(r, i, t => {
                                o.push(t)
                            });
                            let s = o.reverse().find(t => t.type.name === n.name);
                            return s ? { ...s.attrs
                            } : {}
                        }(t, e) : "mark" === n ? ep(t, e) : {}
                    }(this.state, t)
                }
                isActive(t, e) {
                    return function(t, e, n = {}) {
                        if (!e) return t5(t, null, n) || ef(t, null, n);
                        let r = t4(e, t.schema);
                        return "node" === r ? t5(t, e, n) : "mark" === r && ef(t, e, n)
                    }(this.state, "string" == typeof t ? t : null, "string" == typeof t ? e : t)
                }
                getJSON() {
                    return this.state.doc.toJSON()
                }
                getHTML() {
                    return function(t, e) {
                        let n = g.PW.fromSchema(e).serializeFragment(t),
                            r = document.implementation.createHTMLDocument(),
                            i = r.createElement("div");
                        return i.appendChild(n), i.innerHTML
                    }(this.state.doc.content, this.schema)
                }
                getText(t) {
                    let {
                        blockSeparator: e = "\n\n",
                        textSerializers: n = {}
                    } = t || {};
                    return function(t, e) {
                        let n = {
                            from: 0,
                            to: t.content.size
                        };
                        return tb(t, n, e)
                    }(this.state.doc, {
                        blockSeparator: e,
                        textSerializers: { ...n,
                            ...tx(this.schema)
                        }
                    })
                }
                get isEmpty() {
                    return function(t) {
                        var e;
                        let n = null === (e = t.type.createAndFill()) || void 0 === e ? void 0 : e.toJSON(),
                            r = t.toJSON();
                        return JSON.stringify(n) === JSON.stringify(r)
                    }(this.state.doc)
                }
                getCharacterCount() {
                    return console.warn('[tiptap warn]: "editor.getCharacterCount()" is deprecated. Please use "editor.storage.characterCount.characters()" instead.'), this.state.doc.content.size - 2
                }
                destroy() {
                    this.emit("destroy"), this.view && this.view.destroy(), this.removeAllListeners()
                }
                get isDestroyed() {
                    var t;
                    return !(null === (t = this.view) || void 0 === t ? void 0 : t.docView)
                }
            }

            function eU(t) {
                return new th({
                    find: t.find,
                    handler: ({
                        state: e,
                        range: n,
                        match: r
                    }) => {
                        let i = tr(t.getAttributes, void 0, r);
                        if (!1 === i || null === i) return null;
                        let {
                            tr: o
                        } = e, s = r[r.length - 1], a = r[0], l = n.to;
                        if (s) {
                            let r = a.search(/\S/),
                                c = n.from + a.indexOf(s),
                                u = c + s.length,
                                h = ed(n.from, n.to, e.doc).filter(e => {
                                    let n = e.mark.type.excluded;
                                    return n.find(n => n === t.type && n !== e.mark.type)
                                }).filter(t => t.to > c);
                            if (h.length) return null;
                            u < n.to && o.delete(u, n.to), c > n.from && o.delete(n.from + r, c), l = n.from + r + s.length, o.addMark(n.from + r, l, t.type.create(i || {})), o.removeStoredMark(t.type)
                        }
                    }
                })
            }

            function eW(t) {
                return new th({
                    find: t.find,
                    handler: ({
                        state: e,
                        range: n,
                        match: r
                    }) => {
                        let i = t.replace,
                            o = n.from,
                            s = n.to;
                        if (r[1]) {
                            let t = r[0].lastIndexOf(r[1]);
                            i += r[0].slice(t + r[1].length), o += t;
                            let e = o - s;
                            e > 0 && (i = r[0].slice(t - e, t) + i, o = s)
                        }
                        e.tr.insertText(i, o, s)
                    }
                })
            }
            class eZ {
                constructor(t = {}) {
                    this.type = "mark", this.name = "mark", this.parent = null, this.child = null, this.config = {
                        name: this.name,
                        defaultOptions: {}
                    }, this.config = { ...this.config,
                        ...t
                    }, this.name = this.config.name, t.defaultOptions && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${this.name}".`), this.options = this.config.defaultOptions, this.config.addOptions && (this.options = tr(K(this, "addOptions", {
                        name: this.name
                    }))), this.storage = tr(K(this, "addStorage", {
                        name: this.name,
                        options: this.options
                    })) || {}
                }
                static create(t = {}) {
                    return new eZ(t)
                }
                configure(t = {}) {
                    let e = this.extend();
                    return e.options = tv(this.options, t), e.storage = tr(K(e, "addStorage", {
                        name: e.name,
                        options: e.options
                    })), e
                }
                extend(t = {}) {
                    let e = new eZ(t);
                    return e.parent = this, this.child = e, e.name = t.name ? t.name : e.parent.name, t.defaultOptions && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${e.name}".`), e.options = tr(K(e, "addOptions", {
                        name: e.name
                    })), e.storage = tr(K(e, "addStorage", {
                        name: e.name,
                        options: e.options
                    })), e
                }
                static handleExit({
                    editor: t,
                    mark: e
                }) {
                    let {
                        tr: n
                    } = t.state, r = t.state.selection.$from, i = r.pos === r.end();
                    if (i) {
                        let i = r.marks(),
                            o = !!i.find(t => (null == t ? void 0 : t.type.name) === e.name);
                        if (!o) return !1;
                        let s = i.find(t => (null == t ? void 0 : t.type.name) === e.name);
                        return s && n.removeStoredMark(s), n.insertText(" ", r.pos), t.view.dispatch(n), !0
                    }
                    return !1
                }
            }
            class eK {
                constructor(t = {}) {
                    this.type = "node", this.name = "node", this.parent = null, this.child = null, this.config = {
                        name: this.name,
                        defaultOptions: {}
                    }, this.config = { ...this.config,
                        ...t
                    }, this.name = this.config.name, t.defaultOptions && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${this.name}".`), this.options = this.config.defaultOptions, this.config.addOptions && (this.options = tr(K(this, "addOptions", {
                        name: this.name
                    }))), this.storage = tr(K(this, "addStorage", {
                        name: this.name,
                        options: this.options
                    })) || {}
                }
                static create(t = {}) {
                    return new eK(t)
                }
                configure(t = {}) {
                    let e = this.extend();
                    return e.options = tv(this.options, t), e.storage = tr(K(e, "addStorage", {
                        name: e.name,
                        options: e.options
                    })), e
                }
                extend(t = {}) {
                    let e = new eK(t);
                    return e.parent = this, this.child = e, e.name = t.name ? t.name : e.parent.name, t.defaultOptions && console.warn(`[tiptap warn]: BREAKING CHANGE: "defaultOptions" is deprecated. Please use "addOptions" instead. Found in extension: "${e.name}".`), e.options = tr(K(e, "addOptions", {
                        name: e.name
                    })), e.storage = tr(K(e, "addStorage", {
                        name: e.name,
                        options: e.options
                    })), e
                }
            }

            function eG(t) {
                return new tf({
                    find: t.find,
                    handler: ({
                        state: e,
                        range: n,
                        match: r
                    }) => {
                        let i = tr(t.getAttributes, void 0, r);
                        if (!1 === i || null === i) return null;
                        let {
                            tr: o
                        } = e, s = r[r.length - 1], a = r[0], l = n.to;
                        if (s) {
                            let r = a.search(/\S/),
                                c = n.from + a.indexOf(s),
                                u = c + s.length,
                                h = ed(n.from, n.to, e.doc).filter(e => {
                                    let n = e.mark.type.excluded;
                                    return n.find(n => n === t.type && n !== e.mark.type)
                                }).filter(t => t.to > c);
                            if (h.length) return null;
                            u < n.to && o.delete(u, n.to), c > n.from && o.delete(n.from + r, c), l = n.from + r + s.length, o.addMark(n.from + r, l, t.type.create(i || {})), o.removeStoredMark(t.type)
                        }
                    }
                })
            }
        },
        96458: function(t, e, n) {
            "use strict";
            n.d(e, {
                B: function() {
                    return i
                },
                Z: function() {
                    return i
                }
            });
            var r = n(33539);
            let i = r.NB.create({
                name: "doc",
                topNode: !0,
                content: "block+"
            })
        },
        6776: function(t, e, n) {
            "use strict";
            n.d(e, {
                ZP: function() {
                    return s
                }
            });
            var r = n(33539);
            let i = /(?:^|\s)((?:==)((?:[^~=]+))(?:==))$/,
                o = /(?:^|\s)((?:==)((?:[^~=]+))(?:==))/g,
                s = r.vc.create({
                    name: "highlight",
                    addOptions: () => ({
                        multicolor: !1,
                        HTMLAttributes: {}
                    }),
                    addAttributes() {
                        return this.options.multicolor ? {
                            color: {
                                default: null,
                                parseHTML: t => t.getAttribute("data-color") || t.style.backgroundColor,
                                renderHTML: t => t.color ? {
                                    "data-color": t.color,
                                    style: `background-color: ${t.color}; color: inherit`
                                } : {}
                            }
                        } : {}
                    },
                    parseHTML: () => [{
                        tag: "mark"
                    }],
                    renderHTML({
                        HTMLAttributes: t
                    }) {
                        return ["mark", (0, r.P1)(this.options.HTMLAttributes, t), 0]
                    },
                    addCommands() {
                        return {
                            setHighlight: t => ({
                                commands: e
                            }) => e.setMark(this.name, t),
                            toggleHighlight: t => ({
                                commands: e
                            }) => e.toggleMark(this.name, t),
                            unsetHighlight: () => ({
                                commands: t
                            }) => t.unsetMark(this.name)
                        }
                    },
                    addKeyboardShortcuts() {
                        return {
                            "Mod-Shift-h": () => this.editor.commands.toggleHighlight()
                        }
                    },
                    addInputRules() {
                        return [(0, r.Cf)({
                            find: i,
                            type: this.type
                        })]
                    },
                    addPasteRules() {
                        return [(0, r.K9)({
                            find: o,
                            type: this.type
                        })]
                    }
                })
        },
        99631: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return S
                }
            });
            var r = n(33539),
                i = function() {};
            i.prototype.append = function(t) {
                return t.length ? (t = i.from(t), !this.length && t || t.length < 200 && this.leafAppend(t) || this.length < 200 && t.leafPrepend(this) || this.appendInner(t)) : this
            }, i.prototype.prepend = function(t) {
                return t.length ? i.from(t).append(this) : this
            }, i.prototype.appendInner = function(t) {
                return new s(this, t)
            }, i.prototype.slice = function(t, e) {
                return (void 0 === t && (t = 0), void 0 === e && (e = this.length), t >= e) ? i.empty : this.sliceInner(Math.max(0, t), Math.min(this.length, e))
            }, i.prototype.get = function(t) {
                if (!(t < 0) && !(t >= this.length)) return this.getInner(t)
            }, i.prototype.forEach = function(t, e, n) {
                void 0 === e && (e = 0), void 0 === n && (n = this.length), e <= n ? this.forEachInner(t, e, n, 0) : this.forEachInvertedInner(t, e, n, 0)
            }, i.prototype.map = function(t, e, n) {
                void 0 === e && (e = 0), void 0 === n && (n = this.length);
                var r = [];
                return this.forEach(function(e, n) {
                    return r.push(t(e, n))
                }, e, n), r
            }, i.from = function(t) {
                return t instanceof i ? t : t && t.length ? new o(t) : i.empty
            };
            var o = function(t) {
                function e(e) {
                    t.call(this), this.values = e
                }
                t && (e.__proto__ = t), e.prototype = Object.create(t && t.prototype), e.prototype.constructor = e;
                var n = {
                    length: {
                        configurable: !0
                    },
                    depth: {
                        configurable: !0
                    }
                };
                return e.prototype.flatten = function() {
                    return this.values
                }, e.prototype.sliceInner = function(t, n) {
                    return 0 == t && n == this.length ? this : new e(this.values.slice(t, n))
                }, e.prototype.getInner = function(t) {
                    return this.values[t]
                }, e.prototype.forEachInner = function(t, e, n, r) {
                    for (var i = e; i < n; i++)
                        if (!1 === t(this.values[i], r + i)) return !1
                }, e.prototype.forEachInvertedInner = function(t, e, n, r) {
                    for (var i = e - 1; i >= n; i--)
                        if (!1 === t(this.values[i], r + i)) return !1
                }, e.prototype.leafAppend = function(t) {
                    if (this.length + t.length <= 200) return new e(this.values.concat(t.flatten()))
                }, e.prototype.leafPrepend = function(t) {
                    if (this.length + t.length <= 200) return new e(t.flatten().concat(this.values))
                }, n.length.get = function() {
                    return this.values.length
                }, n.depth.get = function() {
                    return 0
                }, Object.defineProperties(e.prototype, n), e
            }(i);
            i.empty = new o([]);
            var s = function(t) {
                    function e(e, n) {
                        t.call(this), this.left = e, this.right = n, this.length = e.length + n.length, this.depth = Math.max(e.depth, n.depth) + 1
                    }
                    return t && (e.__proto__ = t), e.prototype = Object.create(t && t.prototype), e.prototype.constructor = e, e.prototype.flatten = function() {
                        return this.left.flatten().concat(this.right.flatten())
                    }, e.prototype.getInner = function(t) {
                        return t < this.left.length ? this.left.get(t) : this.right.get(t - this.left.length)
                    }, e.prototype.forEachInner = function(t, e, n, r) {
                        var i = this.left.length;
                        if (e < i && !1 === this.left.forEachInner(t, e, Math.min(n, i), r) || n > i && !1 === this.right.forEachInner(t, Math.max(e - i, 0), Math.min(this.length, n) - i, r + i)) return !1
                    }, e.prototype.forEachInvertedInner = function(t, e, n, r) {
                        var i = this.left.length;
                        if (e > i && !1 === this.right.forEachInvertedInner(t, e - i, Math.max(n, i) - i, r + i) || n < i && !1 === this.left.forEachInvertedInner(t, Math.min(e, i), n, r)) return !1
                    }, e.prototype.sliceInner = function(t, e) {
                        if (0 == t && e == this.length) return this;
                        var n = this.left.length;
                        return e <= n ? this.left.slice(t, e) : t >= n ? this.right.slice(t - n, e - n) : this.left.slice(t, n).append(this.right.slice(0, e - n))
                    }, e.prototype.leafAppend = function(t) {
                        var n = this.right.leafAppend(t);
                        if (n) return new e(this.left, n)
                    }, e.prototype.leafPrepend = function(t) {
                        var n = this.left.leafPrepend(t);
                        if (n) return new e(n, this.right)
                    }, e.prototype.appendInner = function(t) {
                        return this.left.depth >= Math.max(this.right.depth, t.depth) + 1 ? new e(this.left, new e(this.right, t)) : new e(this, t)
                    }, e
                }(i),
                a = n(26151),
                l = n(27191);
            class c {
                constructor(t, e) {
                    this.items = t, this.eventCount = e
                }
                popEvent(t, e) {
                    let n, r, i, o;
                    if (0 == this.eventCount) return null;
                    let s = this.items.length;
                    for (;; s--)
                        if (this.items.get(s - 1).selection) {
                            --s;
                            break
                        }
                    e && (r = (n = this.remapping(s, this.items.length)).maps.length);
                    let a = t.tr,
                        l = [],
                        h = [];
                    return this.items.forEach((t, e) => {
                        if (!t.step) {
                            n || (r = (n = this.remapping(s, e + 1)).maps.length), r--, h.push(t);
                            return
                        }
                        if (n) {
                            h.push(new u(t.map));
                            let e = t.step.map(n.slice(r)),
                                i;
                            e && a.maybeStep(e).doc && (i = a.mapping.maps[a.mapping.maps.length - 1], l.push(new u(i, void 0, void 0, l.length + h.length))), r--, i && n.appendMap(i, r)
                        } else a.maybeStep(t.step);
                        if (t.selection) return i = n ? t.selection.map(n.slice(r)) : t.selection, o = new c(this.items.slice(0, s).append(h.reverse().concat(l)), this.eventCount - 1), !1
                    }, this.items.length, 0), {
                        remaining: o,
                        transform: a,
                        selection: i
                    }
                }
                addTransform(t, e, n, r) {
                    var i, o;
                    let s, a = [],
                        l = this.eventCount,
                        h = this.items,
                        d = !r && h.length ? h.get(h.length - 1) : null;
                    for (let n = 0; n < t.steps.length; n++) {
                        let i = t.steps[n].invert(t.docs[n]),
                            o = new u(t.mapping.maps[n], i, e),
                            s;
                        (s = d && d.merge(o)) && (o = s, n ? a.pop() : h = h.slice(0, h.length - 1)), a.push(o), e && (l++, e = void 0), r || (d = o)
                    }
                    let f = l - n.depth;
                    return f > p && (i = h, o = f, i.forEach((t, e) => {
                        if (t.selection && 0 == o--) return s = e, !1
                    }), h = i.slice(s), l -= f), new c(h.append(a), l)
                }
                remapping(t, e) {
                    let n = new a.vs;
                    return this.items.forEach((e, r) => {
                        let i = null != e.mirrorOffset && r - e.mirrorOffset >= t ? n.maps.length - e.mirrorOffset : void 0;
                        n.appendMap(e.map, i)
                    }, t, e), n
                }
                addMaps(t) {
                    return 0 == this.eventCount ? this : new c(this.items.append(t.map(t => new u(t))), this.eventCount)
                }
                rebased(t, e) {
                    if (!this.eventCount) return this;
                    let n = [],
                        r = Math.max(0, this.items.length - e),
                        i = t.mapping,
                        o = t.steps.length,
                        s = this.eventCount;
                    this.items.forEach(t => {
                        t.selection && s--
                    }, r);
                    let a = e;
                    this.items.forEach(e => {
                        let r = i.getMirror(--a);
                        if (null == r) return;
                        o = Math.min(o, r);
                        let l = i.maps[r];
                        if (e.step) {
                            let o = t.steps[r].invert(t.docs[r]),
                                c = e.selection && e.selection.map(i.slice(a + 1, r));
                            c && s++, n.push(new u(l, o, c))
                        } else n.push(new u(l))
                    }, r);
                    let l = [];
                    for (let t = e; t < o; t++) l.push(new u(i.maps[t]));
                    let h = this.items.slice(0, r).append(l).append(n),
                        p = new c(h, s);
                    return p.emptyItemCount() > 500 && (p = p.compress(this.items.length - n.length)), p
                }
                emptyItemCount() {
                    let t = 0;
                    return this.items.forEach(e => {
                        !e.step && t++
                    }), t
                }
                compress(t = this.items.length) {
                    let e = this.remapping(0, t),
                        n = e.maps.length,
                        r = [],
                        o = 0;
                    return this.items.forEach((i, s) => {
                        if (s >= t) r.push(i), i.selection && o++;
                        else if (i.step) {
                            let t = i.step.map(e.slice(n)),
                                s = t && t.getMap();
                            if (n--, s && e.appendMap(s, n), t) {
                                let a = i.selection && i.selection.map(e.slice(n));
                                a && o++;
                                let l = new u(s.invert(), t, a),
                                    c, h = r.length - 1;
                                (c = r.length && r[h].merge(l)) ? r[h] = c: r.push(l)
                            }
                        } else i.map && n--
                    }, this.items.length, 0), new c(i.from(r.reverse()), o)
                }
            }
            c.empty = new c(i.empty, 0);
            class u {
                constructor(t, e, n, r) {
                    this.map = t, this.step = e, this.selection = n, this.mirrorOffset = r
                }
                merge(t) {
                    if (this.step && t.step && !t.selection) {
                        let e = t.step.merge(this.step);
                        if (e) return new u(e.getMap().invert(), e, this.selection)
                    }
                }
            }
            class h {
                constructor(t, e, n, r) {
                    this.done = t, this.undone = e, this.prevRanges = n, this.prevTime = r
                }
            }
            let p = 20;

            function d(t) {
                let e = [];
                return t.forEach((t, n, r, i) => e.push(r, i)), e
            }

            function f(t, e) {
                if (!t) return null;
                let n = [];
                for (let r = 0; r < t.length; r += 2) {
                    let i = e.map(t[r], 1),
                        o = e.map(t[r + 1], -1);
                    i <= o && n.push(i, o)
                }
                return n
            }

            function m(t, e, n, r) {
                let i = v(e),
                    o = w.get(e).spec.config,
                    s = (r ? t.undone : t.done).popEvent(e, i);
                if (!s) return;
                let a = s.selection.resolve(s.transform.doc),
                    l = (r ? t.done : t.undone).addTransform(s.transform, e.selection.getBookmark(), o, i),
                    c = new h(r ? l : s.remaining, r ? s.remaining : l, null, 0);
                n(s.transform.setSelection(a).setMeta(w, {
                    redo: r,
                    historyState: c
                }).scrollIntoView())
            }
            let g = !1,
                y = null;

            function v(t) {
                let e = t.plugins;
                if (y != e) {
                    g = !1, y = e;
                    for (let t = 0; t < e.length; t++)
                        if (e[t].spec.historyPreserveItems) {
                            g = !0;
                            break
                        }
                }
                return g
            }
            let w = new l.H$("history"),
                b = new l.H$("closeHistory"),
                x = (t, e) => {
                    let n = w.getState(t);
                    return !!n && 0 != n.done.eventCount && (e && m(n, t, e, !1), !0)
                },
                k = (t, e) => {
                    let n = w.getState(t);
                    return !!n && 0 != n.undone.eventCount && (e && m(n, t, e, !0), !0)
                },
                S = r.hj.create({
                    name: "history",
                    addOptions: () => ({
                        depth: 100,
                        newGroupDelay: 500
                    }),
                    addCommands: () => ({
                        undo: () => ({
                            state: t,
                            dispatch: e
                        }) => x(t, e),
                        redo: () => ({
                            state: t,
                            dispatch: e
                        }) => k(t, e)
                    }),
                    addProseMirrorPlugins() {
                        return [function(t = {}) {
                            return t = {
                                depth: t.depth || 100,
                                newGroupDelay: t.newGroupDelay || 500
                            }, new l.Sy({
                                key: w,
                                state: {
                                    init: () => new h(c.empty, c.empty, null, 0),
                                    apply: (e, n, r) => (function(t, e, n, r) {
                                        let i = n.getMeta(w),
                                            o;
                                        if (i) return i.historyState;
                                        n.getMeta(b) && (t = new h(t.done, t.undone, null, 0));
                                        let s = n.getMeta("appendedTransaction");
                                        if (0 == n.steps.length) return t;
                                        if (s && s.getMeta(w)) return s.getMeta(w).redo ? new h(t.done.addTransform(n, void 0, r, v(e)), t.undone, d(n.mapping.maps[n.steps.length - 1]), t.prevTime) : new h(t.done, t.undone.addTransform(n, void 0, r, v(e)), null, t.prevTime);
                                        if (!1 === n.getMeta("addToHistory") || s && !1 === s.getMeta("addToHistory")) return (o = n.getMeta("rebased")) ? new h(t.done.rebased(n, o), t.undone.rebased(n, o), f(t.prevRanges, n.mapping), t.prevTime) : new h(t.done.addMaps(n.mapping.maps), t.undone.addMaps(n.mapping.maps), f(t.prevRanges, n.mapping), t.prevTime); {
                                            let i = 0 == t.prevTime || !s && (t.prevTime < (n.time || 0) - r.newGroupDelay || ! function(t, e) {
                                                    if (!e) return !1;
                                                    if (!t.docChanged) return !0;
                                                    let n = !1;
                                                    return t.mapping.maps[0].forEach((t, r) => {
                                                        for (let i = 0; i < e.length; i += 2) t <= e[i + 1] && r >= e[i] && (n = !0)
                                                    }), n
                                                }(n, t.prevRanges)),
                                                o = s ? f(t.prevRanges, n.mapping) : d(n.mapping.maps[n.steps.length - 1]);
                                            return new h(t.done.addTransform(n, i ? e.selection.getBookmark() : void 0, r, v(e)), c.empty, o, n.time)
                                        }
                                    })(n, r, e, t)
                                },
                                config: t,
                                props: {
                                    handleDOMEvents: {
                                        beforeinput(t, e) {
                                            let n = e.inputType,
                                                r = "historyUndo" == n ? x : "historyRedo" == n ? k : null;
                                            return !!r && (e.preventDefault(), r(t.state, t.dispatch))
                                        }
                                    }
                                }
                            })
                        }(this.options)]
                    },
                    addKeyboardShortcuts() {
                        return {
                            "Mod-z": () => this.editor.commands.undo(),
                            "Mod-y": () => this.editor.commands.redo(),
                            "Shift-Mod-z": () => this.editor.commands.redo(),
                            "Mod-я": () => this.editor.commands.undo(),
                            "Shift-Mod-я": () => this.editor.commands.redo()
                        }
                    }
                })
        },
        74704: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return i
                },
                n: function() {
                    return i
                }
            });
            var r = n(33539);
            let i = r.NB.create({
                name: "paragraph",
                priority: 1e3,
                addOptions: () => ({
                    HTMLAttributes: {}
                }),
                group: "block",
                content: "inline*",
                parseHTML: () => [{
                    tag: "p"
                }],
                renderHTML({
                    HTMLAttributes: t
                }) {
                    return ["p", (0, r.P1)(this.options.HTMLAttributes, t), 0]
                },
                addCommands() {
                    return {
                        setParagraph: () => ({
                            commands: t
                        }) => t.setNode(this.name)
                    }
                },
                addKeyboardShortcuts() {
                    return {
                        "Mod-Alt-0": () => this.editor.commands.setParagraph()
                    }
                }
            })
        },
        32259: function(t, e, n) {
            "use strict";
            n.d(e, {
                V: function() {
                    return s
                },
                Z: function() {
                    return s
                }
            });
            var r = n(33539),
                i = n(27191),
                o = n(52780);
            let s = r.hj.create({
                name: "placeholder",
                addOptions: () => ({
                    emptyEditorClass: "is-editor-empty",
                    emptyNodeClass: "is-empty",
                    placeholder: "Write something …",
                    showOnlyWhenEditable: !0,
                    showOnlyCurrent: !0,
                    includeChildren: !1
                }),
                addProseMirrorPlugins() {
                    return [new i.Sy({
                        props: {
                            decorations: ({
                                doc: t,
                                selection: e
                            }) => {
                                let n = this.editor.isEditable || !this.options.showOnlyWhenEditable,
                                    {
                                        anchor: r
                                    } = e,
                                    i = [];
                                if (!n) return null;
                                let s = t.type.createAndFill(),
                                    a = (null == s ? void 0 : s.sameMarkup(t)) && null === s.content.findDiffStart(t.content);
                                return t.descendants((t, e) => {
                                    let n = r >= e && r <= e + t.nodeSize,
                                        s = !t.isLeaf && !t.childCount;
                                    if ((n || !this.options.showOnlyCurrent) && s) {
                                        let r = [this.options.emptyNodeClass];
                                        a && r.push(this.options.emptyEditorClass);
                                        let s = o.p.node(e, e + t.nodeSize, {
                                            class: r.join(" "),
                                            "data-placeholder": "function" == typeof this.options.placeholder ? this.options.placeholder({
                                                editor: this.editor,
                                                node: t,
                                                pos: e,
                                                hasAnchor: n
                                            }) : this.options.placeholder
                                        });
                                        i.push(s)
                                    }
                                    return this.options.includeChildren
                                }), o.EH.create(t, i)
                            }
                        }
                    })]
                }
            })
        },
        67780: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return i
                },
                x: function() {
                    return i
                }
            });
            var r = n(33539);
            let i = r.NB.create({
                name: "text",
                group: "inline"
            })
        },
        64652: function(t, e, n) {
            "use strict";
            n.d(e, {
                ZP: function() {
                    return E
                }
            });
            var r = n(33539);
            let i = (0, r.DS)({
                    find: /--$/,
                    replace: "—"
                }),
                o = (0, r.DS)({
                    find: /\.\.\.$/,
                    replace: "…"
                }),
                s = (0, r.DS)({
                    find: /(?:^|[\s{[(<'"\u2018\u201C])(")$/,
                    replace: "“"
                }),
                a = (0, r.DS)({
                    find: /"$/,
                    replace: "”"
                }),
                l = (0, r.DS)({
                    find: /(?:^|[\s{[(<'"\u2018\u201C])(')$/,
                    replace: "‘"
                }),
                c = (0, r.DS)({
                    find: /'$/,
                    replace: "’"
                }),
                u = (0, r.DS)({
                    find: /<-$/,
                    replace: "←"
                }),
                h = (0, r.DS)({
                    find: /->$/,
                    replace: "→"
                }),
                p = (0, r.DS)({
                    find: /\(c\)$/,
                    replace: "\xa9"
                }),
                d = (0, r.DS)({
                    find: /\(tm\)$/,
                    replace: "™"
                }),
                f = (0, r.DS)({
                    find: /\(sm\)$/,
                    replace: "℠"
                }),
                m = (0, r.DS)({
                    find: /\(r\)$/,
                    replace: "\xae"
                }),
                g = (0, r.DS)({
                    find: /(?:^|\s)(1\/2)$/,
                    replace: "\xbd"
                }),
                y = (0, r.DS)({
                    find: /\+\/-$/,
                    replace: "\xb1"
                }),
                v = (0, r.DS)({
                    find: /!=$/,
                    replace: "≠"
                }),
                w = (0, r.DS)({
                    find: /<<$/,
                    replace: "\xab"
                }),
                b = (0, r.DS)({
                    find: />>$/,
                    replace: "\xbb"
                }),
                x = (0, r.DS)({
                    find: /\d+\s?([*x])\s?\d+$/,
                    replace: "\xd7"
                }),
                k = (0, r.DS)({
                    find: /\^2$/,
                    replace: "\xb2"
                }),
                S = (0, r.DS)({
                    find: /\^3$/,
                    replace: "\xb3"
                }),
                M = (0, r.DS)({
                    find: /(?:^|\s)(1\/4)$/,
                    replace: "\xbc"
                }),
                C = (0, r.DS)({
                    find: /(?:^|\s)(3\/4)$/,
                    replace: "\xbe"
                }),
                E = r.hj.create({
                    name: "typography",
                    addInputRules() {
                        let t = [];
                        return !1 !== this.options.emDash && t.push(i), !1 !== this.options.ellipsis && t.push(o), !1 !== this.options.openDoubleQuote && t.push(s), !1 !== this.options.closeDoubleQuote && t.push(a), !1 !== this.options.openSingleQuote && t.push(l), !1 !== this.options.closeSingleQuote && t.push(c), !1 !== this.options.leftArrow && t.push(u), !1 !== this.options.rightArrow && t.push(h), !1 !== this.options.copyright && t.push(p), !1 !== this.options.trademark && t.push(d), !1 !== this.options.servicemark && t.push(f), !1 !== this.options.registeredTrademark && t.push(m), !1 !== this.options.oneHalf && t.push(g), !1 !== this.options.plusMinus && t.push(y), !1 !== this.options.notEqual && t.push(v), !1 !== this.options.laquo && t.push(w), !1 !== this.options.raquo && t.push(b), !1 !== this.options.multiplication && t.push(x), !1 !== this.options.superscriptTwo && t.push(k), !1 !== this.options.superscriptThree && t.push(S), !1 !== this.options.oneQuarter && t.push(M), !1 !== this.options.threeQuarters && t.push(C), t
                    }
                })
        },
        27191: function(t, e, n) {
            "use strict";
            n.d(e, {
                Bs: function() {
                    return u
                },
                C1: function() {
                    return f
                },
                H$: function() {
                    return N
                },
                Sy: function() {
                    return M
                },
                Y1: function() {
                    return s
                },
                qv: function() {
                    return p
                },
                yy: function() {
                    return S
                }
            });
            var r = n(28638),
                i = n(26151);
            let o = Object.create(null);
            class s {
                constructor(t, e, n) {
                    this.$anchor = t, this.$head = e, this.ranges = n || [new a(t.min(e), t.max(e))]
                }
                get anchor() {
                    return this.$anchor.pos
                }
                get head() {
                    return this.$head.pos
                }
                get from() {
                    return this.$from.pos
                }
                get to() {
                    return this.$to.pos
                }
                get $from() {
                    return this.ranges[0].$from
                }
                get $to() {
                    return this.ranges[0].$to
                }
                get empty() {
                    let t = this.ranges;
                    for (let e = 0; e < t.length; e++)
                        if (t[e].$from.pos != t[e].$to.pos) return !1;
                    return !0
                }
                content() {
                    return this.$from.doc.slice(this.from, this.to, !0)
                }
                replace(t, e = r.p2.empty) {
                    let n = e.content.lastChild,
                        i = null;
                    for (let t = 0; t < e.openEnd; t++) i = n, n = n.lastChild;
                    let o = t.steps.length,
                        s = this.ranges;
                    for (let a = 0; a < s.length; a++) {
                        let {
                            $from: l,
                            $to: c
                        } = s[a], u = t.mapping.slice(o);
                        t.replaceRange(u.map(l.pos), u.map(c.pos), a ? r.p2.empty : e), 0 == a && y(t, o, (n ? n.isInline : i && i.isTextblock) ? -1 : 1)
                    }
                }
                replaceWith(t, e) {
                    let n = t.steps.length,
                        r = this.ranges;
                    for (let i = 0; i < r.length; i++) {
                        let {
                            $from: o,
                            $to: s
                        } = r[i], a = t.mapping.slice(n), l = a.map(o.pos), c = a.map(s.pos);
                        i ? t.deleteRange(l, c) : (t.replaceRangeWith(l, c, e), y(t, n, e.isInline ? -1 : 1))
                    }
                }
                static findFrom(t, e, n = !1) {
                    let r = t.parent.inlineContent ? new u(t) : g(t.node(0), t.parent, t.pos, t.index(), e, n);
                    if (r) return r;
                    for (let r = t.depth - 1; r >= 0; r--) {
                        let i = e < 0 ? g(t.node(0), t.node(r), t.before(r + 1), t.index(r), e, n) : g(t.node(0), t.node(r), t.after(r + 1), t.index(r) + 1, e, n);
                        if (i) return i
                    }
                    return null
                }
                static near(t, e = 1) {
                    return this.findFrom(t, e) || this.findFrom(t, -e) || new f(t.node(0))
                }
                static atStart(t) {
                    return g(t, t, 0, 0, 1) || new f(t)
                }
                static atEnd(t) {
                    return g(t, t, t.content.size, t.childCount, -1) || new f(t)
                }
                static fromJSON(t, e) {
                    if (!e || !e.type) throw RangeError("Invalid input for Selection.fromJSON");
                    let n = o[e.type];
                    if (!n) throw RangeError(`No selection type ${e.type} defined`);
                    return n.fromJSON(t, e)
                }
                static jsonID(t, e) {
                    if (t in o) throw RangeError("Duplicate use of selection JSON ID " + t);
                    return o[t] = e, e.prototype.jsonID = t, e
                }
                getBookmark() {
                    return u.between(this.$anchor, this.$head).getBookmark()
                }
            }
            s.prototype.visible = !0;
            class a {
                constructor(t, e) {
                    this.$from = t, this.$to = e
                }
            }
            let l = !1;

            function c(t) {
                l || t.parent.inlineContent || (l = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + t.parent.type.name + ")"))
            }
            class u extends s {
                constructor(t, e = t) {
                    c(t), c(e), super(t, e)
                }
                get $cursor() {
                    return this.$anchor.pos == this.$head.pos ? this.$head : null
                }
                map(t, e) {
                    let n = t.resolve(e.map(this.head));
                    if (!n.parent.inlineContent) return s.near(n);
                    let r = t.resolve(e.map(this.anchor));
                    return new u(r.parent.inlineContent ? r : n, n)
                }
                replace(t, e = r.p2.empty) {
                    if (super.replace(t, e), e == r.p2.empty) {
                        let e = this.$from.marksAcross(this.$to);
                        e && t.ensureMarks(e)
                    }
                }
                eq(t) {
                    return t instanceof u && t.anchor == this.anchor && t.head == this.head
                }
                getBookmark() {
                    return new h(this.anchor, this.head)
                }
                toJSON() {
                    return {
                        type: "text",
                        anchor: this.anchor,
                        head: this.head
                    }
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.anchor || "number" != typeof e.head) throw RangeError("Invalid input for TextSelection.fromJSON");
                    return new u(t.resolve(e.anchor), t.resolve(e.head))
                }
                static create(t, e, n = e) {
                    let r = t.resolve(e);
                    return new this(r, n == e ? r : t.resolve(n))
                }
                static between(t, e, n) {
                    let r = t.pos - e.pos;
                    if ((!n || r) && (n = r >= 0 ? 1 : -1), !e.parent.inlineContent) {
                        let t = s.findFrom(e, n, !0) || s.findFrom(e, -n, !0);
                        if (!t) return s.near(e, n);
                        e = t.$head
                    }
                    return t.parent.inlineContent || (0 == r ? t = e : (t = (s.findFrom(t, -n, !0) || s.findFrom(t, n, !0)).$anchor).pos < e.pos == r < 0 || (t = e)), new u(t, e)
                }
            }
            s.jsonID("text", u);
            class h {
                constructor(t, e) {
                    this.anchor = t, this.head = e
                }
                map(t) {
                    return new h(t.map(this.anchor), t.map(this.head))
                }
                resolve(t) {
                    return u.between(t.resolve(this.anchor), t.resolve(this.head))
                }
            }
            class p extends s {
                constructor(t) {
                    let e = t.nodeAfter;
                    super(t, t.node(0).resolve(t.pos + e.nodeSize)), this.node = e
                }
                map(t, e) {
                    let {
                        deleted: n,
                        pos: r
                    } = e.mapResult(this.anchor), i = t.resolve(r);
                    return n ? s.near(i) : new p(i)
                }
                content() {
                    return new r.p2(r.HY.from(this.node), 0, 0)
                }
                eq(t) {
                    return t instanceof p && t.anchor == this.anchor
                }
                toJSON() {
                    return {
                        type: "node",
                        anchor: this.anchor
                    }
                }
                getBookmark() {
                    return new d(this.anchor)
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.anchor) throw RangeError("Invalid input for NodeSelection.fromJSON");
                    return new p(t.resolve(e.anchor))
                }
                static create(t, e) {
                    return new p(t.resolve(e))
                }
                static isSelectable(t) {
                    return !t.isText && !1 !== t.type.spec.selectable
                }
            }
            p.prototype.visible = !1, s.jsonID("node", p);
            class d {
                constructor(t) {
                    this.anchor = t
                }
                map(t) {
                    let {
                        deleted: e,
                        pos: n
                    } = t.mapResult(this.anchor);
                    return e ? new h(n, n) : new d(n)
                }
                resolve(t) {
                    let e = t.resolve(this.anchor),
                        n = e.nodeAfter;
                    return n && p.isSelectable(n) ? new p(e) : s.near(e)
                }
            }
            class f extends s {
                constructor(t) {
                    super(t.resolve(0), t.resolve(t.content.size))
                }
                replace(t, e = r.p2.empty) {
                    if (e == r.p2.empty) {
                        t.delete(0, t.doc.content.size);
                        let e = s.atStart(t.doc);
                        e.eq(t.selection) || t.setSelection(e)
                    } else super.replace(t, e)
                }
                toJSON() {
                    return {
                        type: "all"
                    }
                }
                static fromJSON(t) {
                    return new f(t)
                }
                map(t) {
                    return new f(t)
                }
                eq(t) {
                    return t instanceof f
                }
                getBookmark() {
                    return m
                }
            }
            s.jsonID("all", f);
            let m = {
                map() {
                    return this
                },
                resolve: t => new f(t)
            };

            function g(t, e, n, r, i, o = !1) {
                if (e.inlineContent) return u.create(t, n);
                for (let s = r - (i > 0 ? 0 : 1); i > 0 ? s < e.childCount : s >= 0; s += i) {
                    let r = e.child(s);
                    if (r.isAtom) {
                        if (!o && p.isSelectable(r)) return p.create(t, n - (i < 0 ? r.nodeSize : 0))
                    } else {
                        let e = g(t, r, n + i, i < 0 ? r.childCount : 0, i, o);
                        if (e) return e
                    }
                    n += r.nodeSize * i
                }
                return null
            }

            function y(t, e, n) {
                let r, o = t.steps.length - 1;
                if (o < e) return;
                let a = t.steps[o];
                (a instanceof i.Pu || a instanceof i.FC) && (t.mapping.maps[o].forEach((t, e, n, i) => {
                    null == r && (r = i)
                }), t.setSelection(s.near(t.doc.resolve(r), n)))
            }
            class v extends i.wx {
                constructor(t) {
                    super(t.doc), this.curSelectionFor = 0, this.updated = 0, this.meta = Object.create(null), this.time = Date.now(), this.curSelection = t.selection, this.storedMarks = t.storedMarks
                }
                get selection() {
                    return this.curSelectionFor < this.steps.length && (this.curSelection = this.curSelection.map(this.doc, this.mapping.slice(this.curSelectionFor)), this.curSelectionFor = this.steps.length), this.curSelection
                }
                setSelection(t) {
                    if (t.$from.doc != this.doc) throw RangeError("Selection passed to setSelection must point at the current document");
                    return this.curSelection = t, this.curSelectionFor = this.steps.length, this.updated = (1 | this.updated) & -3, this.storedMarks = null, this
                }
                get selectionSet() {
                    return (1 & this.updated) > 0
                }
                setStoredMarks(t) {
                    return this.storedMarks = t, this.updated |= 2, this
                }
                ensureMarks(t) {
                    return r.vc.sameSet(this.storedMarks || this.selection.$from.marks(), t) || this.setStoredMarks(t), this
                }
                addStoredMark(t) {
                    return this.ensureMarks(t.addToSet(this.storedMarks || this.selection.$head.marks()))
                }
                removeStoredMark(t) {
                    return this.ensureMarks(t.removeFromSet(this.storedMarks || this.selection.$head.marks()))
                }
                get storedMarksSet() {
                    return (2 & this.updated) > 0
                }
                addStep(t, e) {
                    super.addStep(t, e), this.updated = -3 & this.updated, this.storedMarks = null
                }
                setTime(t) {
                    return this.time = t, this
                }
                replaceSelection(t) {
                    return this.selection.replace(this, t), this
                }
                replaceSelectionWith(t, e = !0) {
                    let n = this.selection;
                    return e && (t = t.mark(this.storedMarks || (n.empty ? n.$from.marks() : n.$from.marksAcross(n.$to) || r.vc.none))), n.replaceWith(this, t), this
                }
                deleteSelection() {
                    return this.selection.replace(this), this
                }
                insertText(t, e, n) {
                    let r = this.doc.type.schema;
                    if (null == e) return t ? this.replaceSelectionWith(r.text(t), !0) : this.deleteSelection(); {
                        if (null == n && (n = e), n = null == n ? e : n, !t) return this.deleteRange(e, n);
                        let i = this.storedMarks;
                        if (!i) {
                            let t = this.doc.resolve(e);
                            i = n == e ? t.marks() : t.marksAcross(this.doc.resolve(n))
                        }
                        return this.replaceRangeWith(e, n, r.text(t, i)), this.selection.empty || this.setSelection(s.near(this.selection.$to)), this
                    }
                }
                setMeta(t, e) {
                    return this.meta["string" == typeof t ? t : t.key] = e, this
                }
                getMeta(t) {
                    return this.meta["string" == typeof t ? t : t.key]
                }
                get isGeneric() {
                    for (let t in this.meta) return !1;
                    return !0
                }
                scrollIntoView() {
                    return this.updated |= 4, this
                }
                get scrolledIntoView() {
                    return (4 & this.updated) > 0
                }
            }

            function w(t, e) {
                return e && t ? t.bind(e) : t
            }
            class b {
                constructor(t, e, n) {
                    this.name = t, this.init = w(e.init, n), this.apply = w(e.apply, n)
                }
            }
            let x = [new b("doc", {
                init: t => t.doc || t.schema.topNodeType.createAndFill(),
                apply: t => t.doc
            }), new b("selection", {
                init: (t, e) => t.selection || s.atStart(e.doc),
                apply: t => t.selection
            }), new b("storedMarks", {
                init: t => t.storedMarks || null,
                apply: (t, e, n, r) => r.selection.$cursor ? t.storedMarks : null
            }), new b("scrollToSelection", {
                init: () => 0,
                apply: (t, e) => t.scrolledIntoView ? e + 1 : e
            })];
            class k {
                constructor(t, e) {
                    this.schema = t, this.plugins = [], this.pluginsByKey = Object.create(null), this.fields = x.slice(), e && e.forEach(t => {
                        if (this.pluginsByKey[t.key]) throw RangeError("Adding different instances of a keyed plugin (" + t.key + ")");
                        this.plugins.push(t), this.pluginsByKey[t.key] = t, t.spec.state && this.fields.push(new b(t.key, t.spec.state, t))
                    })
                }
            }
            class S {
                constructor(t) {
                    this.config = t
                }
                get schema() {
                    return this.config.schema
                }
                get plugins() {
                    return this.config.plugins
                }
                apply(t) {
                    return this.applyTransaction(t).state
                }
                filterTransaction(t, e = -1) {
                    for (let n = 0; n < this.config.plugins.length; n++)
                        if (n != e) {
                            let e = this.config.plugins[n];
                            if (e.spec.filterTransaction && !e.spec.filterTransaction.call(e, t, this)) return !1
                        }
                    return !0
                }
                applyTransaction(t) {
                    if (!this.filterTransaction(t)) return {
                        state: this,
                        transactions: []
                    };
                    let e = [t],
                        n = this.applyInner(t),
                        r = null;
                    for (;;) {
                        let i = !1;
                        for (let o = 0; o < this.config.plugins.length; o++) {
                            let s = this.config.plugins[o];
                            if (s.spec.appendTransaction) {
                                let a = r ? r[o].n : 0,
                                    l = r ? r[o].state : this,
                                    c = a < e.length && s.spec.appendTransaction.call(s, a ? e.slice(a) : e, l, n);
                                if (c && n.filterTransaction(c, o)) {
                                    if (c.setMeta("appendedTransaction", t), !r) {
                                        r = [];
                                        for (let t = 0; t < this.config.plugins.length; t++) r.push(t < o ? {
                                            state: n,
                                            n: e.length
                                        } : {
                                            state: this,
                                            n: 0
                                        })
                                    }
                                    e.push(c), n = n.applyInner(c), i = !0
                                }
                                r && (r[o] = {
                                    state: n,
                                    n: e.length
                                })
                            }
                        }
                        if (!i) return {
                            state: n,
                            transactions: e
                        }
                    }
                }
                applyInner(t) {
                    if (!t.before.eq(this.doc)) throw RangeError("Applying a mismatched transaction");
                    let e = new S(this.config),
                        n = this.config.fields;
                    for (let r = 0; r < n.length; r++) {
                        let i = n[r];
                        e[i.name] = i.apply(t, this[i.name], this, e)
                    }
                    return e
                }
                get tr() {
                    return new v(this)
                }
                static create(t) {
                    let e = new k(t.doc ? t.doc.type.schema : t.schema, t.plugins),
                        n = new S(e);
                    for (let r = 0; r < e.fields.length; r++) n[e.fields[r].name] = e.fields[r].init(t, n);
                    return n
                }
                reconfigure(t) {
                    let e = new k(this.schema, t.plugins),
                        n = e.fields,
                        r = new S(e);
                    for (let e = 0; e < n.length; e++) {
                        let i = n[e].name;
                        r[i] = this.hasOwnProperty(i) ? this[i] : n[e].init(t, r)
                    }
                    return r
                }
                toJSON(t) {
                    let e = {
                        doc: this.doc.toJSON(),
                        selection: this.selection.toJSON()
                    };
                    if (this.storedMarks && (e.storedMarks = this.storedMarks.map(t => t.toJSON())), t && "object" == typeof t)
                        for (let n in t) {
                            if ("doc" == n || "selection" == n) throw RangeError("The JSON fields `doc` and `selection` are reserved");
                            let r = t[n],
                                i = r.spec.state;
                            i && i.toJSON && (e[n] = i.toJSON.call(r, this[r.key]))
                        }
                    return e
                }
                static fromJSON(t, e, n) {
                    if (!e) throw RangeError("Invalid input for EditorState.fromJSON");
                    if (!t.schema) throw RangeError("Required config field 'schema' missing");
                    let i = new k(t.schema, t.plugins),
                        o = new S(i);
                    return i.fields.forEach(i => {
                        if ("doc" == i.name) o.doc = r.NB.fromJSON(t.schema, e.doc);
                        else if ("selection" == i.name) o.selection = s.fromJSON(o.doc, e.selection);
                        else if ("storedMarks" == i.name) e.storedMarks && (o.storedMarks = e.storedMarks.map(t.schema.markFromJSON));
                        else {
                            if (n)
                                for (let r in n) {
                                    let s = n[r],
                                        a = s.spec.state;
                                    if (s.key == i.name && a && a.fromJSON && Object.prototype.hasOwnProperty.call(e, r)) {
                                        o[i.name] = a.fromJSON.call(s, t, e[r], o);
                                        return
                                    }
                                }
                            o[i.name] = i.init(t, o)
                        }
                    }), o
                }
            }
            class M {
                constructor(t) {
                    this.spec = t, this.props = {}, t.props && function t(e, n, r) {
                        for (let i in e) {
                            let o = e[i];
                            o instanceof Function ? o = o.bind(n) : "handleDOMEvents" == i && (o = t(o, n, {})), r[i] = o
                        }
                        return r
                    }(t.props, this, this.props), this.key = t.key ? t.key.key : E("plugin")
                }
                getState(t) {
                    return t[this.key]
                }
            }
            let C = Object.create(null);

            function E(t) {
                return t in C ? t + "$" + ++C[t] : (C[t] = 0, t + "$")
            }
            class N {
                constructor(t = "key") {
                    this.key = E(t)
                }
                get(t) {
                    return t.config.pluginsByKey[this.key]
                }
                getState(t) {
                    return t[this.key]
                }
            }
        },
        26151: function(t, e, n) {
            "use strict";
            n.d(e, {
                Ax: function() {
                    return x
                },
                FC: function() {
                    return g
                },
                GJ: function() {
                    return M
                },
                Mn: function() {
                    return k
                },
                Pu: function() {
                    return m
                },
                dR: function() {
                    return E
                },
                k9: function() {
                    return v
                },
                nd: function() {
                    return w
                },
                nj: function() {
                    return C
                },
                vs: function() {
                    return s
                },
                wx: function() {
                    return P
                }
            });
            var r = n(28638);
            class i {
                constructor(t, e, n) {
                    this.pos = t, this.delInfo = e, this.recover = n
                }
                get deleted() {
                    return (8 & this.delInfo) > 0
                }
                get deletedBefore() {
                    return (5 & this.delInfo) > 0
                }
                get deletedAfter() {
                    return (6 & this.delInfo) > 0
                }
                get deletedAcross() {
                    return (4 & this.delInfo) > 0
                }
            }
            class o {
                constructor(t, e = !1) {
                    if (this.ranges = t, this.inverted = e, !t.length && o.empty) return o.empty
                }
                recover(t) {
                    let e = 0,
                        n = 65535 & t;
                    if (!this.inverted)
                        for (let t = 0; t < n; t++) e += this.ranges[3 * t + 2] - this.ranges[3 * t + 1];
                    return this.ranges[3 * n] + e + (t - (65535 & t)) / 65536
                }
                mapResult(t, e = 1) {
                    return this._map(t, e, !1)
                }
                map(t, e = 1) {
                    return this._map(t, e, !0)
                }
                _map(t, e, n) {
                    let r = 0,
                        o = this.inverted ? 2 : 1,
                        s = this.inverted ? 1 : 2;
                    for (let a = 0; a < this.ranges.length; a += 3) {
                        let l = this.ranges[a] - (this.inverted ? r : 0);
                        if (l > t) break;
                        let c = this.ranges[a + o],
                            u = this.ranges[a + s],
                            h = l + c;
                        if (t <= h) {
                            let o = c ? t == l ? -1 : t == h ? 1 : e : e,
                                s = l + r + (o < 0 ? 0 : u);
                            if (n) return s;
                            let p = t == (e < 0 ? l : h) ? null : a / 3 + (t - l) * 65536,
                                d = t == l ? 2 : t == h ? 1 : 4;
                            return (e < 0 ? t != l : t != h) && (d |= 8), new i(s, d, p)
                        }
                        r += u - c
                    }
                    return n ? t + r : new i(t + r, 0, null)
                }
                touches(t, e) {
                    let n = 0,
                        r = 65535 & e,
                        i = this.inverted ? 2 : 1,
                        o = this.inverted ? 1 : 2;
                    for (let e = 0; e < this.ranges.length; e += 3) {
                        let s = this.ranges[e] - (this.inverted ? n : 0);
                        if (s > t) break;
                        let a = this.ranges[e + i];
                        if (t <= s + a && e == 3 * r) return !0;
                        n += this.ranges[e + o] - a
                    }
                    return !1
                }
                forEach(t) {
                    let e = this.inverted ? 2 : 1,
                        n = this.inverted ? 1 : 2;
                    for (let r = 0, i = 0; r < this.ranges.length; r += 3) {
                        let o = this.ranges[r],
                            s = o - (this.inverted ? i : 0),
                            a = o + (this.inverted ? 0 : i),
                            l = this.ranges[r + e],
                            c = this.ranges[r + n];
                        t(s, s + l, a, a + c), i += c - l
                    }
                }
                invert() {
                    return new o(this.ranges, !this.inverted)
                }
                toString() {
                    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges)
                }
                static offset(t) {
                    return 0 == t ? o.empty : new o(t < 0 ? [0, -t, 0] : [0, 0, t])
                }
            }
            o.empty = new o([]);
            class s {
                constructor(t = [], e, n = 0, r = t.length) {
                    this.maps = t, this.mirror = e, this.from = n, this.to = r
                }
                slice(t = 0, e = this.maps.length) {
                    return new s(this.maps, this.mirror, t, e)
                }
                copy() {
                    return new s(this.maps.slice(), this.mirror && this.mirror.slice(), this.from, this.to)
                }
                appendMap(t, e) {
                    this.to = this.maps.push(t), null != e && this.setMirror(this.maps.length - 1, e)
                }
                appendMapping(t) {
                    for (let e = 0, n = this.maps.length; e < t.maps.length; e++) {
                        let r = t.getMirror(e);
                        this.appendMap(t.maps[e], null != r && r < e ? n + r : void 0)
                    }
                }
                getMirror(t) {
                    if (this.mirror) {
                        for (let e = 0; e < this.mirror.length; e++)
                            if (this.mirror[e] == t) return this.mirror[e + (e % 2 ? -1 : 1)]
                    }
                }
                setMirror(t, e) {
                    this.mirror || (this.mirror = []), this.mirror.push(t, e)
                }
                appendMappingInverted(t) {
                    for (let e = t.maps.length - 1, n = this.maps.length + t.maps.length; e >= 0; e--) {
                        let r = t.getMirror(e);
                        this.appendMap(t.maps[e].invert(), null != r && r > e ? n - r - 1 : void 0)
                    }
                }
                invert() {
                    let t = new s;
                    return t.appendMappingInverted(this), t
                }
                map(t, e = 1) {
                    if (this.mirror) return this._map(t, e, !0);
                    for (let n = this.from; n < this.to; n++) t = this.maps[n].map(t, e);
                    return t
                }
                mapResult(t, e = 1) {
                    return this._map(t, e, !1)
                }
                _map(t, e, n) {
                    let r = 0;
                    for (let n = this.from; n < this.to; n++) {
                        let i = this.maps[n].mapResult(t, e);
                        if (null != i.recover) {
                            let e = this.getMirror(n);
                            if (null != e && e > n && e < this.to) {
                                n = e, t = this.maps[e].recover(i.recover);
                                continue
                            }
                        }
                        r |= i.delInfo, t = i.pos
                    }
                    return n ? t : new i(t, r, null)
                }
            }
            let a = Object.create(null);
            class l {
                getMap() {
                    return o.empty
                }
                merge(t) {
                    return null
                }
                static fromJSON(t, e) {
                    if (!e || !e.stepType) throw RangeError("Invalid input for Step.fromJSON");
                    let n = a[e.stepType];
                    if (!n) throw RangeError(`No step type ${e.stepType} defined`);
                    return n.fromJSON(t, e)
                }
                static jsonID(t, e) {
                    if (t in a) throw RangeError("Duplicate use of step JSON ID " + t);
                    return a[t] = e, e.prototype.jsonID = t, e
                }
            }
            class c {
                constructor(t, e) {
                    this.doc = t, this.failed = e
                }
                static ok(t) {
                    return new c(t, null)
                }
                static fail(t) {
                    return new c(null, t)
                }
                static fromReplace(t, e, n, i) {
                    try {
                        return c.ok(t.replace(e, n, i))
                    } catch (t) {
                        if (t instanceof r.e4) return c.fail(t.message);
                        throw t
                    }
                }
            }

            function u(t, e, n) {
                let i = [];
                for (let r = 0; r < t.childCount; r++) {
                    let o = t.child(r);
                    o.content.size && (o = o.copy(u(o.content, e, o))), o.isInline && (o = e(o, n, r)), i.push(o)
                }
                return r.HY.fromArray(i)
            }
            class h extends l {
                constructor(t, e, n) {
                    super(), this.from = t, this.to = e, this.mark = n
                }
                apply(t) {
                    let e = t.slice(this.from, this.to),
                        n = t.resolve(this.from),
                        i = n.node(n.sharedDepth(this.to)),
                        o = new r.p2(u(e.content, (t, e) => t.isAtom && e.type.allowsMarkType(this.mark.type) ? t.mark(this.mark.addToSet(t.marks)) : t, i), e.openStart, e.openEnd);
                    return c.fromReplace(t, this.from, this.to, o)
                }
                invert() {
                    return new p(this.from, this.to, this.mark)
                }
                map(t) {
                    let e = t.mapResult(this.from, 1),
                        n = t.mapResult(this.to, -1);
                    return e.deleted && n.deleted || e.pos >= n.pos ? null : new h(e.pos, n.pos, this.mark)
                }
                merge(t) {
                    return t instanceof h && t.mark.eq(this.mark) && this.from <= t.to && this.to >= t.from ? new h(Math.min(this.from, t.from), Math.max(this.to, t.to), this.mark) : null
                }
                toJSON() {
                    return {
                        stepType: "addMark",
                        mark: this.mark.toJSON(),
                        from: this.from,
                        to: this.to
                    }
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.from || "number" != typeof e.to) throw RangeError("Invalid input for AddMarkStep.fromJSON");
                    return new h(e.from, e.to, t.markFromJSON(e.mark))
                }
            }
            l.jsonID("addMark", h);
            class p extends l {
                constructor(t, e, n) {
                    super(), this.from = t, this.to = e, this.mark = n
                }
                apply(t) {
                    let e = t.slice(this.from, this.to),
                        n = new r.p2(u(e.content, t => t.mark(this.mark.removeFromSet(t.marks)), t), e.openStart, e.openEnd);
                    return c.fromReplace(t, this.from, this.to, n)
                }
                invert() {
                    return new h(this.from, this.to, this.mark)
                }
                map(t) {
                    let e = t.mapResult(this.from, 1),
                        n = t.mapResult(this.to, -1);
                    return e.deleted && n.deleted || e.pos >= n.pos ? null : new p(e.pos, n.pos, this.mark)
                }
                merge(t) {
                    return t instanceof p && t.mark.eq(this.mark) && this.from <= t.to && this.to >= t.from ? new p(Math.min(this.from, t.from), Math.max(this.to, t.to), this.mark) : null
                }
                toJSON() {
                    return {
                        stepType: "removeMark",
                        mark: this.mark.toJSON(),
                        from: this.from,
                        to: this.to
                    }
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.from || "number" != typeof e.to) throw RangeError("Invalid input for RemoveMarkStep.fromJSON");
                    return new p(e.from, e.to, t.markFromJSON(e.mark))
                }
            }
            l.jsonID("removeMark", p);
            class d extends l {
                constructor(t, e) {
                    super(), this.pos = t, this.mark = e
                }
                apply(t) {
                    let e = t.nodeAt(this.pos);
                    if (!e) return c.fail("No node at mark step's position");
                    let n = e.type.create(e.attrs, null, this.mark.addToSet(e.marks));
                    return c.fromReplace(t, this.pos, this.pos + 1, new r.p2(r.HY.from(n), 0, e.isLeaf ? 0 : 1))
                }
                invert(t) {
                    let e = t.nodeAt(this.pos);
                    if (e) {
                        let t = this.mark.addToSet(e.marks);
                        if (t.length == e.marks.length) {
                            for (let n = 0; n < e.marks.length; n++)
                                if (!e.marks[n].isInSet(t)) return new d(this.pos, e.marks[n]);
                            return new d(this.pos, this.mark)
                        }
                    }
                    return new f(this.pos, this.mark)
                }
                map(t) {
                    let e = t.mapResult(this.pos, 1);
                    return e.deletedAfter ? null : new d(e.pos, this.mark)
                }
                toJSON() {
                    return {
                        stepType: "addNodeMark",
                        pos: this.pos,
                        mark: this.mark.toJSON()
                    }
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.pos) throw RangeError("Invalid input for AddNodeMarkStep.fromJSON");
                    return new d(e.pos, t.markFromJSON(e.mark))
                }
            }
            l.jsonID("addNodeMark", d);
            class f extends l {
                constructor(t, e) {
                    super(), this.pos = t, this.mark = e
                }
                apply(t) {
                    let e = t.nodeAt(this.pos);
                    if (!e) return c.fail("No node at mark step's position");
                    let n = e.type.create(e.attrs, null, this.mark.removeFromSet(e.marks));
                    return c.fromReplace(t, this.pos, this.pos + 1, new r.p2(r.HY.from(n), 0, e.isLeaf ? 0 : 1))
                }
                invert(t) {
                    let e = t.nodeAt(this.pos);
                    return e && this.mark.isInSet(e.marks) ? new d(this.pos, this.mark) : this
                }
                map(t) {
                    let e = t.mapResult(this.pos, 1);
                    return e.deletedAfter ? null : new f(e.pos, this.mark)
                }
                toJSON() {
                    return {
                        stepType: "removeNodeMark",
                        pos: this.pos,
                        mark: this.mark.toJSON()
                    }
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.pos) throw RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
                    return new f(e.pos, t.markFromJSON(e.mark))
                }
            }
            l.jsonID("removeNodeMark", f);
            class m extends l {
                constructor(t, e, n, r = !1) {
                    super(), this.from = t, this.to = e, this.slice = n, this.structure = r
                }
                apply(t) {
                    return this.structure && y(t, this.from, this.to) ? c.fail("Structure replace would overwrite content") : c.fromReplace(t, this.from, this.to, this.slice)
                }
                getMap() {
                    return new o([this.from, this.to - this.from, this.slice.size])
                }
                invert(t) {
                    return new m(this.from, this.from + this.slice.size, t.slice(this.from, this.to))
                }
                map(t) {
                    let e = t.mapResult(this.from, 1),
                        n = t.mapResult(this.to, -1);
                    return e.deletedAcross && n.deletedAcross ? null : new m(e.pos, Math.max(e.pos, n.pos), this.slice)
                }
                merge(t) {
                    if (!(t instanceof m) || t.structure || this.structure) return null;
                    if (this.from + this.slice.size != t.from || this.slice.openEnd || t.slice.openStart) {
                        if (t.to != this.from || this.slice.openStart || t.slice.openEnd) return null; {
                            let e = this.slice.size + t.slice.size == 0 ? r.p2.empty : new r.p2(t.slice.content.append(this.slice.content), t.slice.openStart, this.slice.openEnd);
                            return new m(t.from, this.to, e, this.structure)
                        }
                    } {
                        let e = this.slice.size + t.slice.size == 0 ? r.p2.empty : new r.p2(this.slice.content.append(t.slice.content), this.slice.openStart, t.slice.openEnd);
                        return new m(this.from, this.to + (t.to - t.from), e, this.structure)
                    }
                }
                toJSON() {
                    let t = {
                        stepType: "replace",
                        from: this.from,
                        to: this.to
                    };
                    return this.slice.size && (t.slice = this.slice.toJSON()), this.structure && (t.structure = !0), t
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.from || "number" != typeof e.to) throw RangeError("Invalid input for ReplaceStep.fromJSON");
                    return new m(e.from, e.to, r.p2.fromJSON(t, e.slice), !!e.structure)
                }
            }
            l.jsonID("replace", m);
            class g extends l {
                constructor(t, e, n, r, i, o, s = !1) {
                    super(), this.from = t, this.to = e, this.gapFrom = n, this.gapTo = r, this.slice = i, this.insert = o, this.structure = s
                }
                apply(t) {
                    if (this.structure && (y(t, this.from, this.gapFrom) || y(t, this.gapTo, this.to))) return c.fail("Structure gap-replace would overwrite content");
                    let e = t.slice(this.gapFrom, this.gapTo);
                    if (e.openStart || e.openEnd) return c.fail("Gap is not a flat range");
                    let n = this.slice.insertAt(this.insert, e.content);
                    return n ? c.fromReplace(t, this.from, this.to, n) : c.fail("Content does not fit in gap")
                }
                getMap() {
                    return new o([this.from, this.gapFrom - this.from, this.insert, this.gapTo, this.to - this.gapTo, this.slice.size - this.insert])
                }
                invert(t) {
                    let e = this.gapTo - this.gapFrom;
                    return new g(this.from, this.from + this.slice.size + e, this.from + this.insert, this.from + this.insert + e, t.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure)
                }
                map(t) {
                    let e = t.mapResult(this.from, 1),
                        n = t.mapResult(this.to, -1),
                        r = t.map(this.gapFrom, -1),
                        i = t.map(this.gapTo, 1);
                    return e.deletedAcross && n.deletedAcross || r < e.pos || i > n.pos ? null : new g(e.pos, n.pos, r, i, this.slice, this.insert, this.structure)
                }
                toJSON() {
                    let t = {
                        stepType: "replaceAround",
                        from: this.from,
                        to: this.to,
                        gapFrom: this.gapFrom,
                        gapTo: this.gapTo,
                        insert: this.insert
                    };
                    return this.slice.size && (t.slice = this.slice.toJSON()), this.structure && (t.structure = !0), t
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.from || "number" != typeof e.to || "number" != typeof e.gapFrom || "number" != typeof e.gapTo || "number" != typeof e.insert) throw RangeError("Invalid input for ReplaceAroundStep.fromJSON");
                    return new g(e.from, e.to, e.gapFrom, e.gapTo, r.p2.fromJSON(t, e.slice), e.insert, !!e.structure)
                }
            }

            function y(t, e, n) {
                let r = t.resolve(e),
                    i = n - e,
                    o = r.depth;
                for (; i > 0 && o > 0 && r.indexAfter(o) == r.node(o).childCount;) o--, i--;
                if (i > 0) {
                    let t = r.node(o).maybeChild(r.indexAfter(o));
                    for (; i > 0;) {
                        if (!t || t.isLeaf) return !0;
                        t = t.firstChild, i--
                    }
                }
                return !1
            }

            function v(t) {
                let e = t.parent.content.cutByIndex(t.startIndex, t.endIndex);
                for (let n = t.depth;; --n) {
                    let r = t.$from.node(n),
                        i = t.$from.index(n),
                        o = t.$to.indexAfter(n);
                    if (n < t.depth && r.canReplace(i, o, e)) return n;
                    if (0 == n || r.type.spec.isolating || !((0 == i || r.canReplace(i, r.childCount)) && (o == r.childCount || r.canReplace(0, o)))) break
                }
                return null
            }

            function w(t, e, n = null, r = t) {
                let i = function(t, e) {
                        let {
                            parent: n,
                            startIndex: r,
                            endIndex: i
                        } = t, o = n.contentMatchAt(r).findWrapping(e);
                        if (!o) return null;
                        let s = o.length ? o[0] : e;
                        return n.canReplaceWith(r, i, s) ? o : null
                    }(t, e),
                    o = i && function(t, e) {
                        let {
                            parent: n,
                            startIndex: r,
                            endIndex: i
                        } = t, o = n.child(r), s = e.contentMatch.findWrapping(o.type);
                        if (!s) return null;
                        let a = (s.length ? s[s.length - 1] : e).contentMatch;
                        for (let t = r; a && t < i; t++) a = a.matchType(n.child(t).type);
                        return a && a.validEnd ? s : null
                    }(r, e);
                return o ? i.map(b).concat({
                    type: e,
                    attrs: n
                }).concat(o.map(b)) : null
            }

            function b(t) {
                return {
                    type: t,
                    attrs: null
                }
            }

            function x(t, e, n = 1, r) {
                let i = t.resolve(e),
                    o = i.depth - n,
                    s = r && r[r.length - 1] || i.parent;
                if (o < 0 || i.parent.type.spec.isolating || !i.parent.canReplace(i.index(), i.parent.childCount) || !s.type.validContent(i.parent.content.cutByIndex(i.index(), i.parent.childCount))) return !1;
                for (let t = i.depth - 1, e = n - 2; t > o; t--, e--) {
                    let n = i.node(t),
                        o = i.index(t);
                    if (n.type.spec.isolating) return !1;
                    let s = n.content.cutByIndex(o, n.childCount),
                        a = r && r[e] || n;
                    if (a != n && (s = s.replaceChild(0, a.type.create(a.attrs))), !n.canReplace(o + 1, n.childCount) || !a.type.validContent(s)) return !1
                }
                let a = i.indexAfter(o),
                    l = r && r[0];
                return i.node(o).canReplaceWith(a, a, l ? l.type : i.node(o + 1).type)
            }

            function k(t, e) {
                let n = t.resolve(e),
                    r = n.index();
                return S(n.nodeBefore, n.nodeAfter) && n.parent.canReplace(r, r + 1)
            }

            function S(t, e) {
                return !!(t && e && !t.isLeaf && t.canAppend(e))
            }

            function M(t, e, n = -1) {
                let r = t.resolve(e);
                for (let t = r.depth;; t--) {
                    let i, o, s = r.index(t);
                    if (t == r.depth ? (i = r.nodeBefore, o = r.nodeAfter) : n > 0 ? (i = r.node(t + 1), s++, o = r.node(t).maybeChild(s)) : (i = r.node(t).maybeChild(s - 1), o = r.node(t + 1)), i && !i.isTextblock && S(i, o) && r.node(t).canReplace(s, s + 1)) return e;
                    if (0 == t) break;
                    e = n < 0 ? r.before(t) : r.after(t)
                }
            }

            function C(t, e, n) {
                let r = t.resolve(e);
                if (!n.content.size) return e;
                let i = n.content;
                for (let t = 0; t < n.openStart; t++) i = i.firstChild.content;
                for (let t = 1; t <= (0 == n.openStart && n.size ? 2 : 1); t++)
                    for (let e = r.depth; e >= 0; e--) {
                        let n = e == r.depth ? 0 : r.pos <= (r.start(e + 1) + r.end(e + 1)) / 2 ? -1 : 1,
                            o = r.index(e) + (n > 0 ? 1 : 0),
                            s = r.node(e),
                            a = !1;
                        if (1 == t) a = s.canReplace(o, o, i);
                        else {
                            let t = s.contentMatchAt(o).findWrapping(i.firstChild.type);
                            a = t && s.canReplaceWith(o, o, t[0])
                        }
                        if (a) return 0 == n ? r.pos : n < 0 ? r.before(e + 1) : r.after(e + 1)
                    }
                return null
            }

            function E(t, e, n = e, i = r.p2.empty) {
                if (e == n && !i.size) return null;
                let o = t.resolve(e),
                    s = t.resolve(n);
                return N(o, s, i) ? new m(e, n, i) : new O(o, s, i).fit()
            }

            function N(t, e, n) {
                return !n.openStart && !n.openEnd && t.start() == e.start() && t.parent.canReplace(t.index(), e.index(), n.content)
            }
            l.jsonID("replaceAround", g);
            class O {
                constructor(t, e, n) {
                    this.$from = t, this.$to = e, this.unplaced = n, this.frontier = [], this.placed = r.HY.empty;
                    for (let e = 0; e <= t.depth; e++) {
                        let n = t.node(e);
                        this.frontier.push({
                            type: n.type,
                            match: n.contentMatchAt(t.indexAfter(e))
                        })
                    }
                    for (let e = t.depth; e > 0; e--) this.placed = r.HY.from(t.node(e).copy(this.placed))
                }
                get depth() {
                    return this.frontier.length - 1
                }
                fit() {
                    for (; this.unplaced.size;) {
                        let t = this.findFittable();
                        t ? this.placeNodes(t) : this.openMore() || this.dropNode()
                    }
                    let t = this.mustMoveInline(),
                        e = this.placed.size - this.depth - this.$from.depth,
                        n = this.$from,
                        i = this.close(t < 0 ? this.$to : n.doc.resolve(t));
                    if (!i) return null;
                    let o = this.placed,
                        s = n.depth,
                        a = i.depth;
                    for (; s && a && 1 == o.childCount;) o = o.firstChild.content, s--, a--;
                    let l = new r.p2(o, s, a);
                    return t > -1 ? new g(n.pos, t, this.$to.pos, this.$to.end(), l, e) : l.size || n.pos != this.$to.pos ? new m(n.pos, i.pos, l) : null
                }
                findFittable() {
                    for (let t = 1; t <= 2; t++)
                        for (let e = this.unplaced.openStart; e >= 0; e--) {
                            let n = null,
                                i = (e ? (n = I(this.unplaced.content, e - 1).firstChild).content : this.unplaced.content).firstChild;
                            for (let o = this.depth; o >= 0; o--) {
                                let {
                                    type: s,
                                    match: a
                                } = this.frontier[o], l, c = null;
                                if (1 == t && (i ? a.matchType(i.type) || (c = a.fillBefore(r.HY.from(i), !1)) : n && s.compatibleContent(n.type))) return {
                                    sliceDepth: e,
                                    frontierDepth: o,
                                    parent: n,
                                    inject: c
                                };
                                if (2 == t && i && (l = a.findWrapping(i.type))) return {
                                    sliceDepth: e,
                                    frontierDepth: o,
                                    parent: n,
                                    wrap: l
                                };
                                if (n && a.matchType(n.type)) break
                            }
                        }
                }
                openMore() {
                    let {
                        content: t,
                        openStart: e,
                        openEnd: n
                    } = this.unplaced, i = I(t, e);
                    return !!i.childCount && !i.firstChild.isLeaf && (this.unplaced = new r.p2(t, e + 1, Math.max(n, i.size + e >= t.size - n ? e + 1 : 0)), !0)
                }
                dropNode() {
                    let {
                        content: t,
                        openStart: e,
                        openEnd: n
                    } = this.unplaced, i = I(t, e);
                    if (i.childCount <= 1 && e > 0) {
                        let o = t.size - e <= e + i.size;
                        this.unplaced = new r.p2(A(t, e - 1, 1), e - 1, o ? e - 1 : n)
                    } else this.unplaced = new r.p2(A(t, e, 1), e, n)
                }
                placeNodes({
                    sliceDepth: t,
                    frontierDepth: e,
                    parent: n,
                    inject: i,
                    wrap: o
                }) {
                    for (; this.depth > e;) this.closeFrontierNode();
                    if (o)
                        for (let t = 0; t < o.length; t++) this.openFrontierNode(o[t]);
                    let s = this.unplaced,
                        a = n ? n.content : s.content,
                        l = s.openStart - t,
                        c = 0,
                        u = [],
                        {
                            match: h,
                            type: p
                        } = this.frontier[e];
                    if (i) {
                        for (let t = 0; t < i.childCount; t++) u.push(i.child(t));
                        h = h.matchFragment(i)
                    }
                    let d = a.size + t - (s.content.size - s.openEnd);
                    for (; c < a.childCount;) {
                        let t = a.child(c),
                            e = h.matchType(t.type);
                        if (!e) break;
                        (++c > 1 || 0 == l || t.content.size) && (h = e, u.push(function t(e, n, i) {
                            if (n <= 0) return e;
                            let o = e.content;
                            return n > 1 && (o = o.replaceChild(0, t(o.firstChild, n - 1, 1 == o.childCount ? i - 1 : 0))), n > 0 && (o = e.type.contentMatch.fillBefore(o).append(o), i <= 0 && (o = o.append(e.type.contentMatch.matchFragment(o).fillBefore(r.HY.empty, !0)))), e.copy(o)
                        }(t.mark(p.allowedMarks(t.marks)), 1 == c ? l : 0, c == a.childCount ? d : -1)))
                    }
                    let f = c == a.childCount;
                    f || (d = -1), this.placed = T(this.placed, e, r.HY.from(u)), this.frontier[e].match = h, f && d < 0 && n && n.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
                    for (let t = 0, e = a; t < d; t++) {
                        let t = e.lastChild;
                        this.frontier.push({
                            type: t.type,
                            match: t.contentMatchAt(t.childCount)
                        }), e = t.content
                    }
                    this.unplaced = f ? 0 == t ? r.p2.empty : new r.p2(A(s.content, t - 1, 1), t - 1, d < 0 ? s.openEnd : t - 1) : new r.p2(A(s.content, t, c), s.openStart, s.openEnd)
                }
                mustMoveInline() {
                    if (!this.$to.parent.isTextblock) return -1;
                    let t = this.frontier[this.depth],
                        e;
                    if (!t.type.isTextblock || !R(this.$to, this.$to.depth, t.type, t.match, !1) || this.$to.depth == this.depth && (e = this.findCloseLevel(this.$to)) && e.depth == this.depth) return -1;
                    let {
                        depth: n
                    } = this.$to, r = this.$to.after(n);
                    for (; n > 1 && r == this.$to.end(--n);) ++r;
                    return r
                }
                findCloseLevel(t) {
                    n: for (let e = Math.min(this.depth, t.depth); e >= 0; e--) {
                        let {
                            match: n,
                            type: r
                        } = this.frontier[e], i = e < t.depth && t.end(e + 1) == t.pos + (t.depth - (e + 1)), o = R(t, e, r, n, i);
                        if (o) {
                            for (let n = e - 1; n >= 0; n--) {
                                let {
                                    match: e,
                                    type: r
                                } = this.frontier[n], i = R(t, n, r, e, !0);
                                if (!i || i.childCount) continue n
                            }
                            return {
                                depth: e,
                                fit: o,
                                move: i ? t.doc.resolve(t.after(e + 1)) : t
                            }
                        }
                    }
                }
                close(t) {
                    let e = this.findCloseLevel(t);
                    if (!e) return null;
                    for (; this.depth > e.depth;) this.closeFrontierNode();
                    e.fit.childCount && (this.placed = T(this.placed, e.depth, e.fit)), t = e.move;
                    for (let n = e.depth + 1; n <= t.depth; n++) {
                        let e = t.node(n),
                            r = e.type.contentMatch.fillBefore(e.content, !0, t.index(n));
                        this.openFrontierNode(e.type, e.attrs, r)
                    }
                    return t
                }
                openFrontierNode(t, e = null, n) {
                    let i = this.frontier[this.depth];
                    i.match = i.match.matchType(t), this.placed = T(this.placed, this.depth, r.HY.from(t.create(e, n))), this.frontier.push({
                        type: t,
                        match: t.contentMatch
                    })
                }
                closeFrontierNode() {
                    let t = this.frontier.pop().match.fillBefore(r.HY.empty, !0);
                    t.childCount && (this.placed = T(this.placed, this.frontier.length, t))
                }
            }

            function A(t, e, n) {
                return 0 == e ? t.cutByIndex(n, t.childCount) : t.replaceChild(0, t.firstChild.copy(A(t.firstChild.content, e - 1, n)))
            }

            function T(t, e, n) {
                return 0 == e ? t.append(n) : t.replaceChild(t.childCount - 1, t.lastChild.copy(T(t.lastChild.content, e - 1, n)))
            }

            function I(t, e) {
                for (let n = 0; n < e; n++) t = t.firstChild.content;
                return t
            }

            function R(t, e, n, r, i) {
                let o = t.node(e),
                    s = i ? t.indexAfter(e) : t.index(e);
                if (s == o.childCount && !n.compatibleContent(o.type)) return null;
                let a = r.fillBefore(o.content, !0, s);
                return a && ! function(t, e, n) {
                    for (let r = n; r < e.childCount; r++)
                        if (!t.allowsMarks(e.child(r).marks)) return !0;
                    return !1
                }(n, o.content, s) ? a : null
            }

            function _(t, e) {
                let n = [],
                    r = Math.min(t.depth, e.depth);
                for (let i = r; i >= 0; i--) {
                    let r = t.start(i);
                    if (r < t.pos - (t.depth - i) || e.end(i) > e.pos + (e.depth - i) || t.node(i).type.spec.isolating || e.node(i).type.spec.isolating) break;
                    (r == e.start(i) || i == t.depth && i == e.depth && t.parent.inlineContent && e.parent.inlineContent && i && e.start(i - 1) == r - 1) && n.push(i)
                }
                return n
            }
            class $ extends l {
                constructor(t, e, n) {
                    super(), this.pos = t, this.attr = e, this.value = n
                }
                apply(t) {
                    let e = t.nodeAt(this.pos);
                    if (!e) return c.fail("No node at attribute step's position");
                    let n = Object.create(null);
                    for (let t in e.attrs) n[t] = e.attrs[t];
                    n[this.attr] = this.value;
                    let i = e.type.create(n, null, e.marks);
                    return c.fromReplace(t, this.pos, this.pos + 1, new r.p2(r.HY.from(i), 0, e.isLeaf ? 0 : 1))
                }
                getMap() {
                    return o.empty
                }
                invert(t) {
                    return new $(this.pos, this.attr, t.nodeAt(this.pos).attrs[this.attr])
                }
                map(t) {
                    let e = t.mapResult(this.pos, 1);
                    return e.deletedAfter ? null : new $(e.pos, this.attr, this.value)
                }
                toJSON() {
                    return {
                        stepType: "attr",
                        pos: this.pos,
                        attr: this.attr,
                        value: this.value
                    }
                }
                static fromJSON(t, e) {
                    if ("number" != typeof e.pos || "string" != typeof e.attr) throw RangeError("Invalid input for AttrStep.fromJSON");
                    return new $(e.pos, e.attr, e.value)
                }
            }
            l.jsonID("attr", $);
            let D = class extends Error {};
            (D = function t(e) {
                let n = Error.call(this, e);
                return n.__proto__ = t.prototype, n
            }).prototype = Object.create(Error.prototype), D.prototype.constructor = D, D.prototype.name = "TransformError";
            class P {
                constructor(t) {
                    this.doc = t, this.steps = [], this.docs = [], this.mapping = new s
                }
                get before() {
                    return this.docs.length ? this.docs[0] : this.doc
                }
                step(t) {
                    let e = this.maybeStep(t);
                    if (e.failed) throw new D(e.failed);
                    return this
                }
                maybeStep(t) {
                    let e = t.apply(this.doc);
                    return e.failed || this.addStep(t, e.doc), e
                }
                get docChanged() {
                    return this.steps.length > 0
                }
                addStep(t, e) {
                    this.docs.push(this.doc), this.steps.push(t), this.mapping.appendMap(t.getMap()), this.doc = e
                }
                replace(t, e = t, n = r.p2.empty) {
                    let i = E(this.doc, t, e, n);
                    return i && this.step(i), this
                }
                replaceWith(t, e, n) {
                    return this.replace(t, e, new r.p2(r.HY.from(n), 0, 0))
                }
                delete(t, e) {
                    return this.replace(t, e, r.p2.empty)
                }
                insert(t, e) {
                    return this.replaceWith(t, t, e)
                }
                replaceRange(t, e, n) {
                    return ! function(t, e, n, i) {
                        if (!i.size) return t.deleteRange(e, n);
                        let o = t.doc.resolve(e),
                            s = t.doc.resolve(n);
                        if (N(o, s, i)) return t.step(new m(e, n, i));
                        let a = _(o, t.doc.resolve(n));
                        0 == a[a.length - 1] && a.pop();
                        let l = -(o.depth + 1);
                        a.unshift(l);
                        for (let t = o.depth, e = o.pos - 1; t > 0; t--, e--) {
                            let n = o.node(t).type.spec;
                            if (n.defining || n.definingAsContext || n.isolating) break;
                            a.indexOf(t) > -1 ? l = t : o.before(t) == e && a.splice(1, 0, -t)
                        }
                        let c = a.indexOf(l),
                            u = [],
                            h = i.openStart;
                        for (let t = i.content, e = 0;; e++) {
                            let n = t.firstChild;
                            if (u.push(n), e == i.openStart) break;
                            t = n.content
                        }
                        for (let t = h - 1; t >= 0; t--) {
                            let e = u[t].type,
                                n = e.spec.defining || e.spec.definingForContent;
                            if (n && o.node(c).type != e) h = t;
                            else if (n || !e.isTextblock) break
                        }
                        for (let e = i.openStart; e >= 0; e--) {
                            let l = (e + h + 1) % (i.openStart + 1),
                                p = u[l];
                            if (p)
                                for (let e = 0; e < a.length; e++) {
                                    let u = a[(e + c) % a.length],
                                        h = !0;
                                    u < 0 && (h = !1, u = -u);
                                    let d = o.node(u - 1),
                                        f = o.index(u - 1);
                                    if (d.canReplaceWith(f, f, p.type, p.marks)) return t.replace(o.before(u), h ? s.after(u) : n, new r.p2(function t(e, n, i, o, s) {
                                        if (n < i) {
                                            let r = e.firstChild;
                                            e = e.replaceChild(0, r.copy(t(r.content, n + 1, i, o, r)))
                                        }
                                        if (n > o) {
                                            let t = s.contentMatchAt(0),
                                                n = t.fillBefore(e).append(e);
                                            e = n.append(t.matchFragment(n).fillBefore(r.HY.empty, !0))
                                        }
                                        return e
                                    }(i.content, 0, i.openStart, l), l, i.openEnd))
                                }
                        }
                        let p = t.steps.length;
                        for (let r = a.length - 1; r >= 0 && (t.replace(e, n, i), !(t.steps.length > p)); r--) {
                            let t = a[r];
                            t < 0 || (e = o.before(t), n = s.after(t))
                        }
                    }(this, t, e, n), this
                }
                replaceRangeWith(t, e, n) {
                    return ! function(t, e, n, i) {
                        if (!i.isInline && e == n && t.doc.resolve(e).parent.content.size) {
                            let r = function(t, e, n) {
                                let r = t.resolve(e);
                                if (r.parent.canReplaceWith(r.index(), r.index(), n)) return e;
                                if (0 == r.parentOffset)
                                    for (let t = r.depth - 1; t >= 0; t--) {
                                        let e = r.index(t);
                                        if (r.node(t).canReplaceWith(e, e, n)) return r.before(t + 1);
                                        if (e > 0) return null
                                    }
                                if (r.parentOffset == r.parent.content.size)
                                    for (let t = r.depth - 1; t >= 0; t--) {
                                        let e = r.indexAfter(t);
                                        if (r.node(t).canReplaceWith(e, e, n)) return r.after(t + 1);
                                        if (e < r.node(t).childCount) break
                                    }
                                return null
                            }(t.doc, e, i.type);
                            null != r && (e = n = r)
                        }
                        t.replaceRange(e, n, new r.p2(r.HY.from(i), 0, 0))
                    }(this, t, e, n), this
                }
                deleteRange(t, e) {
                    return ! function(t, e, n) {
                        let r = t.doc.resolve(e),
                            i = t.doc.resolve(n),
                            o = _(r, i);
                        for (let e = 0; e < o.length; e++) {
                            let n = o[e],
                                s = e == o.length - 1;
                            if (s && 0 == n || r.node(n).type.contentMatch.validEnd) return t.delete(r.start(n), i.end(n));
                            if (n > 0 && (s || r.node(n - 1).canReplace(r.index(n - 1), i.indexAfter(n - 1)))) return t.delete(r.before(n), i.after(n))
                        }
                        for (let o = 1; o <= r.depth && o <= i.depth; o++)
                            if (e - r.start(o) == r.depth - o && n > r.end(o) && i.end(o) - n != i.depth - o) return t.delete(r.before(o), n);
                        t.delete(e, n)
                    }(this, t, e), this
                }
                lift(t, e) {
                    return ! function(t, e, n) {
                        let {
                            $from: i,
                            $to: o,
                            depth: s
                        } = e, a = i.before(s + 1), l = o.after(s + 1), c = a, u = l, h = r.HY.empty, p = 0;
                        for (let t = s, e = !1; t > n; t--) e || i.index(t) > 0 ? (e = !0, h = r.HY.from(i.node(t).copy(h)), p++) : c--;
                        let d = r.HY.empty,
                            f = 0;
                        for (let t = s, e = !1; t > n; t--) e || o.after(t + 1) < o.end(t) ? (e = !0, d = r.HY.from(o.node(t).copy(d)), f++) : u++;
                        t.step(new g(c, u, a, l, new r.p2(h.append(d), p, f), h.size - p, !0))
                    }(this, t, e), this
                }
                join(t, e = 1) {
                    return ! function(t, e, n) {
                        let i = new m(e - n, e + n, r.p2.empty, !0);
                        t.step(i)
                    }(this, t, e), this
                }
                wrap(t, e) {
                    return ! function(t, e, n) {
                        let i = r.HY.empty;
                        for (let t = n.length - 1; t >= 0; t--) {
                            if (i.size) {
                                let e = n[t].type.contentMatch.matchFragment(i);
                                if (!e || !e.validEnd) throw RangeError("Wrapper type given to Transform.wrap does not form valid content of its parent wrapper")
                            }
                            i = r.HY.from(n[t].type.create(n[t].attrs, i))
                        }
                        let o = e.start,
                            s = e.end;
                        t.step(new g(o, s, o, s, new r.p2(i, 0, 0), n.length, !0))
                    }(this, t, e), this
                }
                setBlockType(t, e = t, n, i = null) {
                    return ! function(t, e, n, i, o) {
                        if (!i.isTextblock) throw RangeError("Type given to setBlockType should be a textblock");
                        let s = t.steps.length;
                        t.doc.nodesBetween(e, n, (e, n) => {
                            var a, l;
                            let c, u;
                            if (e.isTextblock && !e.hasMarkup(i, o) && (a = t.doc, l = t.mapping.slice(s).map(n), u = (c = a.resolve(l)).index(), c.parent.canReplaceWith(u, u + 1, i))) {
                                t.clearIncompatible(t.mapping.slice(s).map(n, 1), i);
                                let a = t.mapping.slice(s),
                                    l = a.map(n, 1),
                                    c = a.map(n + e.nodeSize, 1);
                                return t.step(new g(l, c, l + 1, c - 1, new r.p2(r.HY.from(i.create(o, null, e.marks)), 0, 0), 1, !0)), !1
                            }
                        })
                    }(this, t, e, n, i), this
                }
                setNodeMarkup(t, e, n = null, i = []) {
                    return ! function(t, e, n, i, o) {
                        let s = t.doc.nodeAt(e);
                        if (!s) throw RangeError("No node at given position");
                        n || (n = s.type);
                        let a = n.create(i, null, o || s.marks);
                        if (s.isLeaf) return t.replaceWith(e, e + s.nodeSize, a);
                        if (!n.validContent(s.content)) throw RangeError("Invalid content for node type " + n.name);
                        t.step(new g(e, e + s.nodeSize, e + 1, e + s.nodeSize - 1, new r.p2(r.HY.from(a), 0, 0), 1, !0))
                    }(this, t, e, n, i), this
                }
                setNodeAttribute(t, e, n) {
                    return this.step(new $(t, e, n)), this
                }
                addNodeMark(t, e) {
                    return this.step(new d(t, e)), this
                }
                removeNodeMark(t, e) {
                    if (!(e instanceof r.vc)) {
                        let n = this.doc.nodeAt(t);
                        if (!n) throw RangeError("No node at position " + t);
                        if (!(e = e.isInSet(n.marks))) return this
                    }
                    return this.step(new f(t, e)), this
                }
                split(t, e = 1, n) {
                    return ! function(t, e, n = 1, i) {
                        let o = t.doc.resolve(e),
                            s = r.HY.empty,
                            a = r.HY.empty;
                        for (let t = o.depth, e = o.depth - n, l = n - 1; t > e; t--, l--) {
                            s = r.HY.from(o.node(t).copy(s));
                            let e = i && i[l];
                            a = r.HY.from(e ? e.type.create(e.attrs, a) : o.node(t).copy(a))
                        }
                        t.step(new m(e, e, new r.p2(s.append(a), n, n), !0))
                    }(this, t, e, n), this
                }
                addMark(t, e, n) {
                    var r;
                    let i, o, s, a;
                    return r = this, s = [], a = [], r.doc.nodesBetween(t, e, (r, l, c) => {
                        if (!r.isInline) return;
                        let u = r.marks;
                        if (!n.isInSet(u) && c.type.allowsMarkType(n.type)) {
                            let c = Math.max(l, t),
                                d = Math.min(l + r.nodeSize, e),
                                f = n.addToSet(u);
                            for (let t = 0; t < u.length; t++) u[t].isInSet(f) || (i && i.to == c && i.mark.eq(u[t]) ? i.to = d : s.push(i = new p(c, d, u[t])));
                            o && o.to == c ? o.to = d : a.push(o = new h(c, d, n))
                        }
                    }), s.forEach(t => r.step(t)), a.forEach(t => r.step(t)), this
                }
                removeMark(t, e, n) {
                    var i;
                    let o, s;
                    return i = this, o = [], s = 0, i.doc.nodesBetween(t, e, (i, a) => {
                        if (!i.isInline) return;
                        s++;
                        let l = null;
                        if (n instanceof r.ZU) {
                            let t = i.marks,
                                e;
                            for (; e = n.isInSet(t);)(l || (l = [])).push(e), t = e.removeFromSet(t)
                        } else n ? n.isInSet(i.marks) && (l = [n]) : l = i.marks;
                        if (l && l.length) {
                            let n = Math.min(a + i.nodeSize, e);
                            for (let e = 0; e < l.length; e++) {
                                let r = l[e],
                                    i;
                                for (let t = 0; t < o.length; t++) {
                                    let e = o[t];
                                    e.step == s - 1 && r.eq(o[t].style) && (i = e)
                                }
                                i ? (i.to = n, i.step = s) : o.push({
                                    style: r,
                                    from: Math.max(a, t),
                                    to: n,
                                    step: s
                                })
                            }
                        }
                    }), o.forEach(t => i.step(new p(t.from, t.to, t.style))), this
                }
                clearIncompatible(t, e, n) {
                    return ! function(t, e, n, i = n.contentMatch) {
                        let o = t.doc.nodeAt(e),
                            s = [],
                            a = e + 1;
                        for (let e = 0; e < o.childCount; e++) {
                            let l = o.child(e),
                                c = a + l.nodeSize,
                                u = i.matchType(l.type);
                            if (u) {
                                i = u;
                                for (let e = 0; e < l.marks.length; e++) n.allowsMarkType(l.marks[e].type) || t.step(new p(a, c, l.marks[e]))
                            } else s.push(new m(a, c, r.p2.empty));
                            a = c
                        }
                        if (!i.validEnd) {
                            let e = i.fillBefore(r.HY.empty, !0);
                            t.replace(a, a, new r.p2(e, 0, 0))
                        }
                        for (let e = s.length - 1; e >= 0; e--) t.step(s[e])
                    }(this, t, e, n), this
                }
            }
        },
        1547: function(t, e, n) {
            "use strict";
            n.d(e, {
                Z: function() {
                    return o
                }
            });
            let r = /^\s+/,
                i = /\s+$/;

            function o(t, e) {
                if (e = e || {}, (t = t || "") instanceof o) return t;
                if (!(this instanceof o)) return new o(t, e);
                var n, s, a, l, c, u, h, p, d, f, m, g, y, v, w, b, x, k, S, M, E = (s = {
                    r: 0,
                    g: 0,
                    b: 0
                }, a = 1, l = null, c = null, u = null, h = !1, p = !1, "string" == typeof(n = t) && (n = function(t) {
                    t = t.replace(r, "").replace(i, "").toLowerCase();
                    var e, n = !1;
                    if (C[t]) t = C[t], n = !0;
                    else if ("transparent" == t) return {
                        r: 0,
                        g: 0,
                        b: 0,
                        a: 0,
                        format: "name"
                    };
                    return (e = $.rgb.exec(t)) ? {
                        r: e[1],
                        g: e[2],
                        b: e[3]
                    } : (e = $.rgba.exec(t)) ? {
                        r: e[1],
                        g: e[2],
                        b: e[3],
                        a: e[4]
                    } : (e = $.hsl.exec(t)) ? {
                        h: e[1],
                        s: e[2],
                        l: e[3]
                    } : (e = $.hsla.exec(t)) ? {
                        h: e[1],
                        s: e[2],
                        l: e[3],
                        a: e[4]
                    } : (e = $.hsv.exec(t)) ? {
                        h: e[1],
                        s: e[2],
                        v: e[3]
                    } : (e = $.hsva.exec(t)) ? {
                        h: e[1],
                        s: e[2],
                        v: e[3],
                        a: e[4]
                    } : (e = $.hex8.exec(t)) ? {
                        r: T(e[1]),
                        g: T(e[2]),
                        b: T(e[3]),
                        a: T(e[4]) / 255,
                        format: n ? "name" : "hex8"
                    } : (e = $.hex6.exec(t)) ? {
                        r: T(e[1]),
                        g: T(e[2]),
                        b: T(e[3]),
                        format: n ? "name" : "hex"
                    } : (e = $.hex4.exec(t)) ? {
                        r: T(e[1] + "" + e[1]),
                        g: T(e[2] + "" + e[2]),
                        b: T(e[3] + "" + e[3]),
                        a: T(e[4] + "" + e[4]) / 255,
                        format: n ? "name" : "hex8"
                    } : !!(e = $.hex3.exec(t)) && {
                        r: T(e[1] + "" + e[1]),
                        g: T(e[2] + "" + e[2]),
                        b: T(e[3] + "" + e[3]),
                        format: n ? "name" : "hex"
                    }
                }(n)), "object" == typeof n && (D(n.r) && D(n.g) && D(n.b) ? (d = n.r, f = n.g, m = n.b, s = {
                    r: 255 * O(d, 255),
                    g: 255 * O(f, 255),
                    b: 255 * O(m, 255)
                }, h = !0, p = "%" === String(n.r).substr(-1) ? "prgb" : "rgb") : D(n.h) && D(n.s) && D(n.v) ? (l = R(n.s), c = R(n.v), g = n.h, y = l, v = c, g = 6 * O(g, 360), y = O(y, 100), v = O(v, 100), w = Math.floor(g), b = g - w, x = v * (1 - y), k = v * (1 - b * y), S = v * (1 - (1 - b) * y), s = {
                    r: 255 * [v, k, x, x, S, v][M = w % 6],
                    g: 255 * [S, v, v, k, x, x][M],
                    b: 255 * [x, x, S, v, v, k][M]
                }, h = !0, p = "hsv") : D(n.h) && D(n.s) && D(n.l) && (l = R(n.s), u = R(n.l), s = function(t, e, n) {
                    var r, i, o;

                    function s(t, e, n) {
                        return (n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6) ? t + (e - t) * 6 * n : n < .5 ? e : n < 2 / 3 ? t + (e - t) * (2 / 3 - n) * 6 : t
                    }
                    if (t = O(t, 360), e = O(e, 100), n = O(n, 100), 0 === e) r = i = o = n;
                    else {
                        var a = n < .5 ? n * (1 + e) : n + e - n * e,
                            l = 2 * n - a;
                        r = s(l, a, t + 1 / 3), i = s(l, a, t), o = s(l, a, t - 1 / 3)
                    }
                    return {
                        r: 255 * r,
                        g: 255 * i,
                        b: 255 * o
                    }
                }(n.h, l, u), h = !0, p = "hsl"), n.hasOwnProperty("a") && (a = n.a)), a = N(a), {
                    ok: h,
                    format: n.format || p,
                    r: Math.min(255, Math.max(s.r, 0)),
                    g: Math.min(255, Math.max(s.g, 0)),
                    b: Math.min(255, Math.max(s.b, 0)),
                    a: a
                });
                this._originalInput = t, this._r = E.r, this._g = E.g, this._b = E.b, this._a = E.a, this._roundA = Math.round(100 * this._a) / 100, this._format = e.format || E.format, this._gradientType = e.gradientType, this._r < 1 && (this._r = Math.round(this._r)), this._g < 1 && (this._g = Math.round(this._g)), this._b < 1 && (this._b = Math.round(this._b)), this._ok = E.ok
            }

            function s(t, e, n) {
                var r, i, o = Math.max(t = O(t, 255), e = O(e, 255), n = O(n, 255)),
                    s = Math.min(t, e, n),
                    a = (o + s) / 2;
                if (o == s) r = i = 0;
                else {
                    var l = o - s;
                    switch (i = a > .5 ? l / (2 - o - s) : l / (o + s), o) {
                        case t:
                            r = (e - n) / l + (e < n ? 6 : 0);
                            break;
                        case e:
                            r = (n - t) / l + 2;
                            break;
                        case n:
                            r = (t - e) / l + 4
                    }
                    r /= 6
                }
                return {
                    h: r,
                    s: i,
                    l: a
                }
            }

            function a(t, e, n) {
                var r, i = Math.max(t = O(t, 255), e = O(e, 255), n = O(n, 255)),
                    o = Math.min(t, e, n),
                    s = i - o;
                if (i == o) r = 0;
                else {
                    switch (i) {
                        case t:
                            r = (e - n) / s + (e < n ? 6 : 0);
                            break;
                        case e:
                            r = (n - t) / s + 2;
                            break;
                        case n:
                            r = (t - e) / s + 4
                    }
                    r /= 6
                }
                return {
                    h: r,
                    s: 0 === i ? 0 : s / i,
                    v: i
                }
            }

            function l(t, e, n, r) {
                var i = [I(Math.round(t).toString(16)), I(Math.round(e).toString(16)), I(Math.round(n).toString(16))];
                return r && i[0].charAt(0) == i[0].charAt(1) && i[1].charAt(0) == i[1].charAt(1) && i[2].charAt(0) == i[2].charAt(1) ? i[0].charAt(0) + i[1].charAt(0) + i[2].charAt(0) : i.join("")
            }

            function c(t, e, n, r) {
                return [I(_(r)), I(Math.round(t).toString(16)), I(Math.round(e).toString(16)), I(Math.round(n).toString(16))].join("")
            }

            function u(t, e) {
                e = 0 === e ? 0 : e || 10;
                var n = o(t).toHsl();
                return n.s -= e / 100, n.s = A(n.s), o(n)
            }

            function h(t, e) {
                e = 0 === e ? 0 : e || 10;
                var n = o(t).toHsl();
                return n.s += e / 100, n.s = A(n.s), o(n)
            }

            function p(t) {
                return o(t).desaturate(100)
            }

            function d(t, e) {
                e = 0 === e ? 0 : e || 10;
                var n = o(t).toHsl();
                return n.l += e / 100, n.l = A(n.l), o(n)
            }

            function f(t, e) {
                e = 0 === e ? 0 : e || 10;
                var n = o(t).toRgb();
                return n.r = Math.max(0, Math.min(255, n.r - Math.round(-(255 * (e / 100))))), n.g = Math.max(0, Math.min(255, n.g - Math.round(-(255 * (e / 100))))), n.b = Math.max(0, Math.min(255, n.b - Math.round(-(255 * (e / 100))))), o(n)
            }

            function m(t, e) {
                e = 0 === e ? 0 : e || 10;
                var n = o(t).toHsl();
                return n.l -= e / 100, n.l = A(n.l), o(n)
            }

            function g(t, e) {
                var n = o(t).toHsl(),
                    r = (n.h + e) % 360;
                return n.h = r < 0 ? 360 + r : r, o(n)
            }

            function y(t) {
                var e = o(t).toHsl();
                return e.h = (e.h + 180) % 360, o(e)
            }

            function v(t, e) {
                if (isNaN(e) || e <= 0) throw Error("Argument to polyad must be a positive number");
                for (var n = o(t).toHsl(), r = [o(t)], i = 360 / e, s = 1; s < e; s++) r.push(o({
                    h: (n.h + s * i) % 360,
                    s: n.s,
                    l: n.l
                }));
                return r
            }

            function w(t) {
                var e = o(t).toHsl(),
                    n = e.h;
                return [o(t), o({
                    h: (n + 72) % 360,
                    s: e.s,
                    l: e.l
                }), o({
                    h: (n + 216) % 360,
                    s: e.s,
                    l: e.l
                })]
            }

            function b(t, e, n) {
                e = e || 6, n = n || 30;
                var r = o(t).toHsl(),
                    i = 360 / n,
                    s = [o(t)];
                for (r.h = (r.h - (i * e >> 1) + 720) % 360; --e;) r.h = (r.h + i) % 360, s.push(o(r));
                return s
            }

            function x(t, e) {
                e = e || 6;
                for (var n = o(t).toHsv(), r = n.h, i = n.s, s = n.v, a = [], l = 1 / e; e--;) a.push(o({
                    h: r,
                    s: i,
                    v: s
                })), s = (s + l) % 1;
                return a
            }
            o.prototype = {
                isDark: function() {
                    return 128 > this.getBrightness()
                },
                isLight: function() {
                    return !this.isDark()
                },
                isValid: function() {
                    return this._ok
                },
                getOriginalInput: function() {
                    return this._originalInput
                },
                getFormat: function() {
                    return this._format
                },
                getAlpha: function() {
                    return this._a
                },
                getBrightness: function() {
                    var t = this.toRgb();
                    return (299 * t.r + 587 * t.g + 114 * t.b) / 1e3
                },
                getLuminance: function() {
                    var t, e, n, r = this.toRgb();
                    return t = r.r / 255, .2126 * (t <= .03928 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4)) + .7152 * ((e = r.g / 255) <= .03928 ? e / 12.92 : Math.pow((e + .055) / 1.055, 2.4)) + .0722 * ((n = r.b / 255) <= .03928 ? n / 12.92 : Math.pow((n + .055) / 1.055, 2.4))
                },
                setAlpha: function(t) {
                    return this._a = N(t), this._roundA = Math.round(100 * this._a) / 100, this
                },
                toHsv: function() {
                    var t = a(this._r, this._g, this._b);
                    return {
                        h: 360 * t.h,
                        s: t.s,
                        v: t.v,
                        a: this._a
                    }
                },
                toHsvString: function() {
                    var t = a(this._r, this._g, this._b),
                        e = Math.round(360 * t.h),
                        n = Math.round(100 * t.s),
                        r = Math.round(100 * t.v);
                    return 1 == this._a ? "hsv(" + e + ", " + n + "%, " + r + "%)" : "hsva(" + e + ", " + n + "%, " + r + "%, " + this._roundA + ")"
                },
                toHsl: function() {
                    var t = s(this._r, this._g, this._b);
                    return {
                        h: 360 * t.h,
                        s: t.s,
                        l: t.l,
                        a: this._a
                    }
                },
                toHslString: function() {
                    var t = s(this._r, this._g, this._b),
                        e = Math.round(360 * t.h),
                        n = Math.round(100 * t.s),
                        r = Math.round(100 * t.l);
                    return 1 == this._a ? "hsl(" + e + ", " + n + "%, " + r + "%)" : "hsla(" + e + ", " + n + "%, " + r + "%, " + this._roundA + ")"
                },
                toHex: function(t) {
                    return l(this._r, this._g, this._b, t)
                },
                toHexString: function(t) {
                    return "#" + this.toHex(t)
                },
                toHex8: function(t) {
                    var e, n, r, i, o;
                    return e = this._r, n = this._g, r = this._b, i = this._a, o = [I(Math.round(e).toString(16)), I(Math.round(n).toString(16)), I(Math.round(r).toString(16)), I(_(i))], t && o[0].charAt(0) == o[0].charAt(1) && o[1].charAt(0) == o[1].charAt(1) && o[2].charAt(0) == o[2].charAt(1) && o[3].charAt(0) == o[3].charAt(1) ? o[0].charAt(0) + o[1].charAt(0) + o[2].charAt(0) + o[3].charAt(0) : o.join("")
                },
                toHex8String: function(t) {
                    return "#" + this.toHex8(t)
                },
                toRgb: function() {
                    return {
                        r: Math.round(this._r),
                        g: Math.round(this._g),
                        b: Math.round(this._b),
                        a: this._a
                    }
                },
                toRgbString: function() {
                    return 1 == this._a ? "rgb(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ")" : "rgba(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ", " + this._roundA + ")"
                },
                toPercentageRgb: function() {
                    return {
                        r: Math.round(100 * O(this._r, 255)) + "%",
                        g: Math.round(100 * O(this._g, 255)) + "%",
                        b: Math.round(100 * O(this._b, 255)) + "%",
                        a: this._a
                    }
                },
                toPercentageRgbString: function() {
                    return 1 == this._a ? "rgb(" + Math.round(100 * O(this._r, 255)) + "%, " + Math.round(100 * O(this._g, 255)) + "%, " + Math.round(100 * O(this._b, 255)) + "%)" : "rgba(" + Math.round(100 * O(this._r, 255)) + "%, " + Math.round(100 * O(this._g, 255)) + "%, " + Math.round(100 * O(this._b, 255)) + "%, " + this._roundA + ")"
                },
                toName: function() {
                    return 0 === this._a ? "transparent" : !(this._a < 1) && (E[l(this._r, this._g, this._b, !0)] || !1)
                },
                toFilter: function(t) {
                    var e = "#" + c(this._r, this._g, this._b, this._a),
                        n = e,
                        r = this._gradientType ? "GradientType = 1, " : "";
                    if (t) {
                        var i = o(t);
                        n = "#" + c(i._r, i._g, i._b, i._a)
                    }
                    return "progid:DXImageTransform.Microsoft.gradient(" + r + "startColorstr=" + e + ",endColorstr=" + n + ")"
                },
                toString: function(t) {
                    var e = !!t;
                    t = t || this._format;
                    var n = !1,
                        r = this._a < 1 && this._a >= 0;
                    return !e && r && ("hex" === t || "hex6" === t || "hex3" === t || "hex4" === t || "hex8" === t || "name" === t) ? "name" === t && 0 === this._a ? this.toName() : this.toRgbString() : ("rgb" === t && (n = this.toRgbString()), "prgb" === t && (n = this.toPercentageRgbString()), ("hex" === t || "hex6" === t) && (n = this.toHexString()), "hex3" === t && (n = this.toHexString(!0)), "hex4" === t && (n = this.toHex8String(!0)), "hex8" === t && (n = this.toHex8String()), "name" === t && (n = this.toName()), "hsl" === t && (n = this.toHslString()), "hsv" === t && (n = this.toHsvString()), n || this.toHexString())
                },
                clone: function() {
                    return o(this.toString())
                },
                _applyModification: function(t, e) {
                    var n = t.apply(null, [this].concat([].slice.call(e)));
                    return this._r = n._r, this._g = n._g, this._b = n._b, this.setAlpha(n._a), this
                },
                lighten: function() {
                    return this._applyModification(d, arguments)
                },
                brighten: function() {
                    return this._applyModification(f, arguments)
                },
                darken: function() {
                    return this._applyModification(m, arguments)
                },
                desaturate: function() {
                    return this._applyModification(u, arguments)
                },
                saturate: function() {
                    return this._applyModification(h, arguments)
                },
                greyscale: function() {
                    return this._applyModification(p, arguments)
                },
                spin: function() {
                    return this._applyModification(g, arguments)
                },
                _applyCombination: function(t, e) {
                    return t.apply(null, [this].concat([].slice.call(e)))
                },
                analogous: function() {
                    return this._applyCombination(b, arguments)
                },
                complement: function() {
                    return this._applyCombination(y, arguments)
                },
                monochromatic: function() {
                    return this._applyCombination(x, arguments)
                },
                splitcomplement: function() {
                    return this._applyCombination(w, arguments)
                },
                triad: function() {
                    return this._applyCombination(v, [3])
                },
                tetrad: function() {
                    return this._applyCombination(v, [4])
                }
            }, o.fromRatio = function(t, e) {
                if ("object" == typeof t) {
                    var n = {};
                    for (var r in t) t.hasOwnProperty(r) && ("a" === r ? n[r] = t[r] : n[r] = R(t[r]));
                    t = n
                }
                return o(t, e)
            }, o.equals = function(t, e) {
                return !!t && !!e && o(t).toRgbString() == o(e).toRgbString()
            }, o.random = function() {
                return o.fromRatio({
                    r: Math.random(),
                    g: Math.random(),
                    b: Math.random()
                })
            }, o.mix = function(t, e, n) {
                n = 0 === n ? 0 : n || 50;
                var r = o(t).toRgb(),
                    i = o(e).toRgb(),
                    s = n / 100;
                return o({
                    r: (i.r - r.r) * s + r.r,
                    g: (i.g - r.g) * s + r.g,
                    b: (i.b - r.b) * s + r.b,
                    a: (i.a - r.a) * s + r.a
                })
            }, o.readability = function(t, e) {
                var n = o(t),
                    r = o(e);
                return (Math.max(n.getLuminance(), r.getLuminance()) + .05) / (Math.min(n.getLuminance(), r.getLuminance()) + .05)
            }, o.isReadable = function(t, e, n) {
                var r, i, s, a, l, c = o.readability(t, e);
                switch (l = !1, (i = ((r = (r = n) || {
                    level: "AA",
                    size: "small"
                }).level || "AA").toUpperCase(), s = (r.size || "small").toLowerCase(), "AA" !== i && "AAA" !== i && (i = "AA"), "small" !== s && "large" !== s && (s = "small"), a = {
                    level: i,
                    size: s
                }).level + a.size) {
                    case "AAsmall":
                    case "AAAlarge":
                        l = c >= 4.5;
                        break;
                    case "AAlarge":
                        l = c >= 3;
                        break;
                    case "AAAsmall":
                        l = c >= 7
                }
                return l
            }, o.mostReadable = function(t, e, n) {
                var r, i, s, a, l = null,
                    c = 0;
                i = (n = n || {}).includeFallbackColors, s = n.level, a = n.size;
                for (var u = 0; u < e.length; u++)(r = o.readability(t, e[u])) > c && (c = r, l = o(e[u]));
                return o.isReadable(t, l, {
                    level: s,
                    size: a
                }) || !i ? l : (n.includeFallbackColors = !1, o.mostReadable(t, ["#fff", "#000"], n))
            };
            var k, S, M, C = o.names = {
                    aliceblue: "f0f8ff",
                    antiquewhite: "faebd7",
                    aqua: "0ff",
                    aquamarine: "7fffd4",
                    azure: "f0ffff",
                    beige: "f5f5dc",
                    bisque: "ffe4c4",
                    black: "000",
                    blanchedalmond: "ffebcd",
                    blue: "00f",
                    blueviolet: "8a2be2",
                    brown: "a52a2a",
                    burlywood: "deb887",
                    burntsienna: "ea7e5d",
                    cadetblue: "5f9ea0",
                    chartreuse: "7fff00",
                    chocolate: "d2691e",
                    coral: "ff7f50",
                    cornflowerblue: "6495ed",
                    cornsilk: "fff8dc",
                    crimson: "dc143c",
                    cyan: "0ff",
                    darkblue: "00008b",
                    darkcyan: "008b8b",
                    darkgoldenrod: "b8860b",
                    darkgray: "a9a9a9",
                    darkgreen: "006400",
                    darkgrey: "a9a9a9",
                    darkkhaki: "bdb76b",
                    darkmagenta: "8b008b",
                    darkolivegreen: "556b2f",
                    darkorange: "ff8c00",
                    darkorchid: "9932cc",
                    darkred: "8b0000",
                    darksalmon: "e9967a",
                    darkseagreen: "8fbc8f",
                    darkslateblue: "483d8b",
                    darkslategray: "2f4f4f",
                    darkslategrey: "2f4f4f",
                    darkturquoise: "00ced1",
                    darkviolet: "9400d3",
                    deeppink: "ff1493",
                    deepskyblue: "00bfff",
                    dimgray: "696969",
                    dimgrey: "696969",
                    dodgerblue: "1e90ff",
                    firebrick: "b22222",
                    floralwhite: "fffaf0",
                    forestgreen: "228b22",
                    fuchsia: "f0f",
                    gainsboro: "dcdcdc",
                    ghostwhite: "f8f8ff",
                    gold: "ffd700",
                    goldenrod: "daa520",
                    gray: "808080",
                    green: "008000",
                    greenyellow: "adff2f",
                    grey: "808080",
                    honeydew: "f0fff0",
                    hotpink: "ff69b4",
                    indianred: "cd5c5c",
                    indigo: "4b0082",
                    ivory: "fffff0",
                    khaki: "f0e68c",
                    lavender: "e6e6fa",
                    lavenderblush: "fff0f5",
                    lawngreen: "7cfc00",
                    lemonchiffon: "fffacd",
                    lightblue: "add8e6",
                    lightcoral: "f08080",
                    lightcyan: "e0ffff",
                    lightgoldenrodyellow: "fafad2",
                    lightgray: "d3d3d3",
                    lightgreen: "90ee90",
                    lightgrey: "d3d3d3",
                    lightpink: "ffb6c1",
                    lightsalmon: "ffa07a",
                    lightseagreen: "20b2aa",
                    lightskyblue: "87cefa",
                    lightslategray: "789",
                    lightslategrey: "789",
                    lightsteelblue: "b0c4de",
                    lightyellow: "ffffe0",
                    lime: "0f0",
                    limegreen: "32cd32",
                    linen: "faf0e6",
                    magenta: "f0f",
                    maroon: "800000",
                    mediumaquamarine: "66cdaa",
                    mediumblue: "0000cd",
                    mediumorchid: "ba55d3",
                    mediumpurple: "9370db",
                    mediumseagreen: "3cb371",
                    mediumslateblue: "7b68ee",
                    mediumspringgreen: "00fa9a",
                    mediumturquoise: "48d1cc",
                    mediumvioletred: "c71585",
                    midnightblue: "191970",
                    mintcream: "f5fffa",
                    mistyrose: "ffe4e1",
                    moccasin: "ffe4b5",
                    navajowhite: "ffdead",
                    navy: "000080",
                    oldlace: "fdf5e6",
                    olive: "808000",
                    olivedrab: "6b8e23",
                    orange: "ffa500",
                    orangered: "ff4500",
                    orchid: "da70d6",
                    palegoldenrod: "eee8aa",
                    palegreen: "98fb98",
                    paleturquoise: "afeeee",
                    palevioletred: "db7093",
                    papayawhip: "ffefd5",
                    peachpuff: "ffdab9",
                    peru: "cd853f",
                    pink: "ffc0cb",
                    plum: "dda0dd",
                    powderblue: "b0e0e6",
                    purple: "800080",
                    rebeccapurple: "663399",
                    red: "f00",
                    rosybrown: "bc8f8f",
                    royalblue: "4169e1",
                    saddlebrown: "8b4513",
                    salmon: "fa8072",
                    sandybrown: "f4a460",
                    seagreen: "2e8b57",
                    seashell: "fff5ee",
                    sienna: "a0522d",
                    silver: "c0c0c0",
                    skyblue: "87ceeb",
                    slateblue: "6a5acd",
                    slategray: "708090",
                    slategrey: "708090",
                    snow: "fffafa",
                    springgreen: "00ff7f",
                    steelblue: "4682b4",
                    tan: "d2b48c",
                    teal: "008080",
                    thistle: "d8bfd8",
                    tomato: "ff6347",
                    turquoise: "40e0d0",
                    violet: "ee82ee",
                    wheat: "f5deb3",
                    white: "fff",
                    whitesmoke: "f5f5f5",
                    yellow: "ff0",
                    yellowgreen: "9acd32"
                },
                E = o.hexNames = function(t) {
                    var e = {};
                    for (var n in t) t.hasOwnProperty(n) && (e[t[n]] = n);
                    return e
                }(C);

            function N(t) {
                return (isNaN(t = parseFloat(t)) || t < 0 || t > 1) && (t = 1), t
            }

            function O(t, e) {
                "string" == typeof(n = t) && -1 != n.indexOf(".") && 1 === parseFloat(n) && (t = "100%");
                var n, r, i = "string" == typeof(r = t) && -1 != r.indexOf("%");
                return (t = Math.min(e, Math.max(0, parseFloat(t))), i && (t = parseInt(t * e, 10) / 100), 1e-6 > Math.abs(t - e)) ? 1 : t % e / parseFloat(e)
            }

            function A(t) {
                return Math.min(1, Math.max(0, t))
            }

            function T(t) {
                return parseInt(t, 16)
            }

            function I(t) {
                return 1 == t.length ? "0" + t : "" + t
            }

            function R(t) {
                return t <= 1 && (t = 100 * t + "%"), t
            }

            function _(t) {
                return Math.round(255 * parseFloat(t)).toString(16)
            }
            var $ = (S = "[\\s|\\(]+(" + (k = "(?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?)") + ")[,|\\s]+(" + k + ")[,|\\s]+(" + k + ")\\s*\\)?", M = "[\\s|\\(]+(" + k + ")[,|\\s]+(" + k + ")[,|\\s]+(" + k + ")[,|\\s]+(" + k + ")\\s*\\)?", {
                CSS_UNIT: RegExp(k),
                rgb: RegExp("rgb" + S),
                rgba: RegExp("rgba" + M),
                hsl: RegExp("hsl" + S),
                hsla: RegExp("hsla" + M),
                hsv: RegExp("hsv" + S),
                hsva: RegExp("hsva" + M),
                hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
                hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
            });

            function D(t) {
                return !!$.CSS_UNIT.exec(t)
            }
        }
    }
]);