(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [901], {
        50901: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                MapGl: function() {
                    return E
                }
            });
            var i = n(52322),
                o = n(6277),
                r = n(2784),
                l = n(55),
                a = n.n(l),
                d = n(88285),
                s = n(57985),
                u = n(70433),
                m = n(28316),
                f = n(72279),
                c = n(31920),
                v = n(91334),
                w = n(97008),
                p = n(59371),
                g = n(18559),
                b = n(24920);
            let E = e => {
                let {
                    data: t,
                    lat: n,
                    long: l,
                    zoom: E,
                    style: L,
                    hasCaption: x
                } = e, h = t.id, [z, k] = (0, r.useState)(null), [{
                    editing: y
                }, Z] = (0, v.U)(), [, _] = (0, d.w)(), T = (0, r.useMemo)(() => (0, p.j)(), []), C = (0, r.useCallback)((e, n, i, o) => {
                    if (y) {
                        var r, l, a, d, s, u;
                        let m = ((0, g.J)(null === (r = t.overrides) || void 0 === r ? void 0 : r.mapCaption, T) || (0, g.V)(null === (l = t.overrides) || void 0 === l ? void 0 : l.mapCaption, T) === (null === (a = t.overrides) || void 0 === a ? void 0 : a.mapPlace) || !(null === (d = t.overrides) || void 0 === d ? void 0 : d.mapPlace)) && o,
                            f = (0, w.Of)(t.href);
                        Z({
                            type: "set-bento-item-partial",
                            bento: {
                                id: h,
                                href: "https://www.google.com/maps/@".concat(null != e ? e : f.lat, ",").concat(null != n ? n : f.long, ",").concat(i ? i + w.by : f.zoom + w.by, "z"),
                                overrides: { ...t.overrides,
                                    mapPlace: null != o ? o : null === (s = t.overrides) || void 0 === s ? void 0 : s.mapPlace,
                                    mapCaption: m ? o : null === (u = t.overrides) || void 0 === u ? void 0 : u.mapCaption
                                }
                            }
                        })
                    }
                }, [t, y, Z]);
                return (0, r.useEffect)(() => {
                    if (z) {
                        a().accessToken = "pk.eyJ1IjoibXVnZWViIiwiYSI6ImNsdG5idzFrbTA0c3UycnA4OWRtbTJ6dmMifQ.Qa0vYWIbFEHuNuPpbVkdEQ", z.__proto__ = HTMLElement.prototype;
                        let e = new(a()).Map({
                            container: z,
                            style: "mapbox://styles/eikedrescher/clg552oz2000401mn852bcp04",
                            center: [l, n],
                            zoom: E,
                            boxZoom: !1,
                            touchZoomRotate: !1,
                            scrollZoom: !1,
                            doubleClickZoom: !1,
                            dragPan: !1,
                            maxZoom: 18
                        });
                        return _(t => ({ ...t,
                            map: e
                        })), () => {
                            _(e => ({ ...e,
                                map: void 0
                            }))
                        }
                    }
                }, [z]), ! function(e, t, n, o) {
                    let [{
                        map: l,
                        marker: s
                    }, c] = (0, d.w)();
                    (0, r.useEffect)(() => {
                        if (l) {
                            let e = document.createElement("div");
                            e.className = "marker", e.style.width = "28px", e.style.height = "28px", (0, m.render)((0, i.jsx)(f.O, {}), e);
                            let o = new(a()).Marker(e).setLngLat([n, t]).addTo(l);
                            return c(e => ({ ...e,
                                marker: o
                            })), () => {
                                o.remove(), c(e => ({ ...e,
                                    marker: void 0
                                }))
                            }
                        }
                    }, [l, e]), (0, r.useEffect)(() => {
                        if (l && s) {
                            let e;
                            let t = t => {
                                let n = (0, u.$)();
                                if (!t.skipMarker && t.originalEvent && n && t.originalEvent instanceof n.MouseEvent) {
                                    let {
                                        lat: t,
                                        lng: n
                                    } = l.getCenter();
                                    s.setLngLat({
                                        lat: t,
                                        lng: n
                                    }), e && clearTimeout(e), e = setTimeout(() => {
                                        o(t, n, l.getZoom(), void 0)
                                    }, 250)
                                }
                            };
                            return l.on("movestart", t), l.on("move", t), l.on("moveend", t), () => {
                                l.off("movestart", t), l.off("move", t), l.off("moveend", t)
                            }
                        }
                    }, [l, s, o])
                }(h, n, l, C), ! function(e) {
                    let [{
                        map: t,
                        marker: n
                    }] = (0, d.w)(), i = (0, s.A)(e => e.highlighting);
                    (0, r.useEffect)(() => {
                        if (t && n) {
                            if (i === e) {
                                t.dragPan.enable(), t.dragRotate.enable(), t.scrollZoom.enable({
                                    around: n
                                });
                                let e = e => {
                                        e.preventDefault()
                                    },
                                    i = t.getContainer().parentElement;
                                return i.addEventListener("click", e), () => {
                                    i.removeEventListener("click", e)
                                }
                            }
                            t.dragPan.disable(), t.scrollZoom.disable()
                        }
                    }, [t, n, i, e])
                }(h), ! function(e, t) {
                    let [{
                        map: n
                    }] = (0, d.w)();
                    (0, r.useEffect)(() => {
                        if (n) {
                            let t = !1,
                                i = () => {
                                    setTimeout(() => {
                                        n.resize()
                                    }, 0), t || requestAnimationFrame(i)
                                },
                                o = n => {
                                    n.detail.id === e && (t = !1, i())
                                },
                                r = n => {
                                    n.detail.id === e && (t = !0, i())
                                };
                            return window.addEventListener("bento:grid:widget:resize:start", o), window.addEventListener("bento:grid:widget:resize:end", r), () => {
                                window.removeEventListener("bento:grid:widget:resize:start", o), window.removeEventListener("bento:grid:widget:resize:end", r)
                            }
                        }
                    }, [n, e]), (0, r.useEffect)(() => {
                        n && n.resize()
                    }, [t]), (0, r.useEffect)(() => {
                        if (n) {
                            let e = (0, u.$)(),
                                t = () => {
                                    n.resize()
                                };
                            return null == e || e.addEventListener("resize", t), window.addEventListener("resize", t), () => {
                                null == e || e.removeEventListener("resize", t), window.removeEventListener("resize", t)
                            }
                        }
                    }, [n]), (0, r.useEffect)(() => {
                        if (n) {
                            let e = !1,
                                t = () => {
                                    setTimeout(() => {
                                        n.resize()
                                    }, 0), e || requestAnimationFrame(t)
                                };
                            t();
                            let i = setTimeout(() => {
                                e = !0
                            }, 1e3);
                            return () => {
                                e = !0, clearTimeout(i)
                            }
                        }
                    }, [n])
                }(h, L), (0, c.P)(h, L, x), ! function(e, t) {
                    let [{
                        map: n,
                        marker: i
                    }] = (0, d.w)();
                    (0, r.useEffect)(() => {
                        if (n) {
                            let o = o => {
                                if (o.detail.id === e) {
                                    var r;
                                    let e = null !== (r = ({
                                        street: 15.5,
                                        city: 11,
                                        country: 4
                                    })[o.detail.type]) && void 0 !== r ? r : 13;
                                    "city" === o.detail.type && (o.detail.lat = o.detail.lat - .008), n.flyTo({
                                        center: [o.detail.lng, o.detail.lat],
                                        zoom: e,
                                        speed: 2,
                                        maxDuration: 3e3,
                                        curve: .8
                                    }), i && (i.setLngLat({
                                        lat: o.detail.lat,
                                        lng: o.detail.lng
                                    }), t(o.detail.lat, o.detail.lng, e, o.detail.description))
                                }
                            };
                            return window.addEventListener("bento:map:locate", o), () => {
                                window.removeEventListener("bento:map:locate", o)
                            }
                        }
                    }, [n, i, e, t])
                }(h, C), ! function(e, t) {
                    let [{
                        map: n,
                        marker: i
                    }] = (0, d.w)();
                    (0, r.useEffect)(() => {
                        if (n) {
                            let i = i => {
                                    if (i.detail.id === e) {
                                        let e = (0, b.uZ)(n.getZoom() + 1, 1, 18);
                                        n.zoomTo(e), t(void 0, void 0, e, void 0)
                                    }
                                },
                                o = i => {
                                    if (i.detail.id === e) {
                                        let e = (0, b.uZ)(n.getZoom() - 1, 1, 18);
                                        n.zoomTo(e), t(void 0, void 0, e, void 0)
                                    }
                                };
                            return window.addEventListener("bento:map:zoomIn", i), window.addEventListener("bento:map:zoomOut", o), () => {
                                window.removeEventListener("bento:map:zoomIn", i), window.removeEventListener("bento:map:zoomOut", o)
                            }
                        }
                    }, [n, i, e, t])
                }(h, C), ! function(e) {
                    let [{
                        map: t,
                        marker: n
                    }] = (0, d.w)();
                    (0, r.useEffect)(() => {
                        if (t) {
                            let i = i => {
                                i.detail.id === e && (t.setCenter([i.detail.lng, i.detail.lat]), t.setZoom(i.detail.zoom), n && n.setLngLat({
                                    lat: i.detail.lat,
                                    lng: i.detail.lng
                                }))
                            };
                            return window.addEventListener("bento:map:refresh", i), () => {
                                window.removeEventListener("bento:map:refresh", i)
                            }
                        }
                    }, [t, n, e])
                }(h), (0, i.jsx)("div", {
                    ref: k,
                    className: (0, o.Z)("h-full w-full rounded-[var(--widget-radius)] will-change-auto")
                })
            }
        },
        72279: function(e, t, n) {
            "use strict";
            n.d(t, {
                O: function() {
                    return a
                }
            });
            var i = n(52322),
                o = n(6277),
                r = n(34129),
                l = n.n(r);
            let a = e => {
                let {} = e;
                return (0, i.jsxs)("div", {
                    className: "relative h-full w-full",
                    children: [(0, i.jsx)("div", {
                        className: (0, o.Z)("absolute left-1/2 top-1/2 rounded-full bg-[#679BFF] opacity-20 s-3", l()["marker-pulse"])
                    }), (0, i.jsxs)("div", {
                        className: (0, o.Z)("relative flex h-full w-full items-center justify-center rounded-full bg-white", l().marker),
                        children: [(0, i.jsx)("div", {
                            className: "absolute inset-[3px] rounded-full bg-[#679BFF]"
                        }), (0, i.jsx)("div", {
                            className: (0, o.Z)("absolute inset-[3px] rounded-full", l()["marker-border"])
                        }), (0, i.jsx)("div", {
                            className: (0, o.Z)("absolute inset-[5px] rounded-full bg-[#679BFF]")
                        })]
                    })]
                })
            }
        },
        31920: function(e, t, n) {
            "use strict";
            n.d(t, {
                P: function() {
                    return s
                }
            });
            var i = n(2784),
                o = n(88285),
                r = n(70433),
                l = n(84090),
                a = n(88242);
            let d = {
                "1x4": {
                    left: 0,
                    bottom: 0
                },
                "2x2": {
                    left: 0,
                    bottom: 1
                },
                "2x4": {
                    left: 1,
                    bottom: 0
                },
                "4x2": {
                    left: 0,
                    bottom: 0
                },
                "4x4": {
                    left: 0,
                    bottom: 0
                }
            };

            function s(e, t, n) {
                let s = (0, a.A)(e => e.engine),
                    u = (0, l.$)(),
                    m = (0, i.useRef)(u),
                    [{
                        map: f,
                        marker: c
                    }] = (0, o.w)(),
                    v = (0, i.useRef)({ ...d[t]
                    }),
                    w = (0, i.useRef)(n ? 1 : 0),
                    p = function() {
                        let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        if (f && s) {
                            var n, i;
                            let o = e => s.view.getCellSize() * e + (e - 1) * s.settings.spacing,
                                r = {
                                    "1x4": {
                                        h: o(1),
                                        w: o(4)
                                    },
                                    "2x2": {
                                        h: o(2),
                                        w: o(2)
                                    },
                                    "2x4": {
                                        h: o(2),
                                        w: o(4)
                                    },
                                    "4x2": {
                                        h: o(4),
                                        w: o(2)
                                    },
                                    "4x4": {
                                        h: o(4),
                                        w: o(4)
                                    }
                                },
                                l = r[t].h,
                                a = r[t].w,
                                d = {
                                    left: v.current.left * (a / 7 * 4) * w.current,
                                    right: 0,
                                    top: 0,
                                    bottom: v.current.bottom * (l / 3) * w.current
                                };
                            e ? f.jumpTo({
                                center: null !== (n = null == c ? void 0 : c.getLngLat()) && void 0 !== n ? n : f.getCenter(),
                                padding: d
                            }) : f.flyTo({
                                center: null !== (i = null == c ? void 0 : c.getLngLat()) && void 0 !== i ? i : f.getCenter(),
                                padding: d,
                                maxDuration: 3e3
                            })
                        }
                    };
                (0, i.useEffect)(() => {
                    if (f) {
                        let e = () => {
                                p(!0)
                            },
                            t = (0, r.$)();
                        return null == t || t.addEventListener("resize", e), () => {
                            null == t || t.removeEventListener("resize", e)
                        }
                    }
                }, [f, t]), (0, i.useEffect)(() => {
                    f && p(!0)
                }, [f]), (0, i.useEffect)(() => {
                    w.current = n ? 1 : 0, v.current = { ...d[t]
                    }, p()
                }, [n]), (0, i.useEffect)(() => {
                    u !== m.current ? (m.current = u, v.current = { ...d[t]
                    }, p(!0)) : n && (d[t].left !== v.current.left || d[t].bottom !== v.current.bottom) && (v.current = { ...d[t]
                    }, p())
                }, [t, u])
            }
        },
        34129: function(e) {
            e.exports = {
                marker: "styles_marker__Mzm27",
                "marker-pulse": "styles_marker-pulse__BxsPp",
                "marker-border": "styles_marker-border__fxi6v"
            }
        }
    }
]);