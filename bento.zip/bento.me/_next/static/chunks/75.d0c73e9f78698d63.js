"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [75], {
        1075: function(e, t, n) {
            n.r(t), n.d(t, {
                Video: function() {
                    return o
                }
            });
            var r = n(52322),
                a = n(14574),
                u = n(30299),
                l = n(2784);
            let o = e => {
                var t;
                let {
                    src: n,
                    vRef: o,
                    ...s
                } = e, c = (0, l.useRef)(null), {
                    inView: i,
                    ref: d
                } = (0, u.YD)({});
                return (0, l.useEffect)(() => {
                    var e, t;
                    i ? null === (t = c.current) || void 0 === t || t.play() : null === (e = c.current) || void 0 === e || e.pause()
                }, [i]), (0, l.useEffect)(() => {
                    if (c.current) {
                        let e = c.current;
                        e.readyState > 3 ? e.style.opacity = "1" : (e.style.opacity = "0", e.style.transition = "opacity 1s ease-in-out", e.addEventListener("loadeddata", () => {
                            e.style.opacity = "1"
                        }))
                    }
                }, [c]), (0, r.jsx)(a.Z, { ...s,
                    ref: (t = [o, c, d], e => {
                        t.forEach(t => {
                            t && ("function" == typeof t ? t(e) : null != t && (t.current = e))
                        })
                    }),
                    streamType: "on-demand",
                    className: "rounded-[inherit] object-cover",
                    src: n,
                    playsInline: !0,
                    autoPlay: i,
                    muted: !0,
                    loop: !0,
                    controls: !1
                })
            }
        }
    }
]);