(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [574], {
        57615: function(e) {
            e.exports = function() {
                var e = {
                        80: function(e, t, r) {
                            e.exports = r(728).default
                        },
                        728: function(e, t, r) {
                            "use strict";
                            r.d(t, {
                                default: function() {
                                    return tP
                                }
                            });
                            var a = r(48),
                                n = r.n(a),
                                i = function() {
                                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                                        var t = 16 * Math.random() | 0;
                                        return ("x" === e ? t : 3 & t | 8).toString(16)
                                    })
                                },
                                o = function() {
                                    return ("000000" + (2176782336 * Math.random() << 0).toString(36)).slice(-6)
                                },
                                s = function(e) {
                                    return e && void 0 !== e.nodeName ? (e.muxId || (e.muxId = e.id || o()), e.muxId) : e
                                },
                                l = function(e) {
                                    e && void 0 !== e.nodeName ? e = s(t = e) : t = document.querySelector(e);
                                    var t, r = t && t.nodeName ? t.nodeName.toLowerCase() : "";
                                    return [t, e, r]
                                },
                                u = r(640),
                                d = r.n(u),
                                c = d().methodFactory;
                            d().methodFactory = function(e, t, r) {
                                var a = c(e, t, r);
                                return function() {
                                    for (var e = ["[mux]"], t = 0; t < arguments.length; t++) e.push(arguments[t]);
                                    a.apply(void 0, e)
                                }
                            }, d().setLevel(d().getLevel());
                            var f = d();

                            function p() {
                                return "1" === (n().doNotTrack || n().navigator && n().navigator.doNotTrack)
                            }
                            var _ = {
                                    now: function() {
                                        var e = n().performance,
                                            t = e && e.timing,
                                            r = t && t.navigationStart;
                                        return Math.round("number" == typeof r && "function" == typeof e.now ? r + e.now() : Date.now())
                                    }
                                },
                                v = function(e) {
                                    return h(e)[0]
                                },
                                h = function(e) {
                                    if ("string" != typeof e || "" === e) return ["localhost"];
                                    var t, r = (e.match(/^(([^:\/?#]+):)?(\/\/([^\/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/) || [])[4];
                                    return r && (t = (r.match(/[^\.]+\.[^\.]+$/) || [])[0]), [r, t]
                                },
                                m = {
                                    exists: function() {
                                        var e = n().performance;
                                        return void 0 !== (e && e.timing)
                                    },
                                    domContentLoadedEventEnd: function() {
                                        var e = n().performance,
                                            t = e && e.timing;
                                        return t && t.domContentLoadedEventEnd
                                    },
                                    navigationStart: function() {
                                        var e = n().performance,
                                            t = e && e.timing;
                                        return t && t.navigationStart
                                    }
                                };

                            function y(e, t, r) {
                                r = void 0 === r ? 1 : r, e[t] = e[t] || 0, e[t] += r
                            }
                            var b = ["x-cdn", "content-type", "x-request-id"];

                            function g(e) {
                                var t = {};
                                return (e = e || "").trim().split(/[\r\n]+/).forEach(function(e) {
                                    if (e) {
                                        var r = e.split(": "),
                                            a = r.shift();
                                        a && (b.indexOf(a.toLowerCase()) >= 0 || 0 === a.toLowerCase().indexOf("x-litix-")) && (t[a] = r.join(": "))
                                    }
                                }), t
                            }
                            var w = function(e) {
                                var t = {};
                                for (var r in e) {
                                    var a = e[r]; - 1 !== a["DATA-ID"].search("io.litix.data.") && (t[a["DATA-ID"].replace("io.litix.data.", "")] = a.VALUE)
                                }
                                return t
                            };

                            function E(e, t) {
                                var r = Object.keys(e);
                                if (Object.getOwnPropertySymbols) {
                                    var a = Object.getOwnPropertySymbols(e);
                                    t && (a = a.filter(function(t) {
                                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                                    })), r.push.apply(r, a)
                                }
                                return r
                            }

                            function T(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var r = null != arguments[t] ? arguments[t] : {};
                                    t % 2 ? E(Object(r), !0).forEach(function(t) {
                                        var a, n;
                                        a = e, n = r[t], t in a ? Object.defineProperty(a, t, {
                                            value: n,
                                            enumerable: !0,
                                            configurable: !0,
                                            writable: !0
                                        }) : a[t] = n
                                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : E(Object(r)).forEach(function(t) {
                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                                    })
                                }
                                return e
                            }
                            var k = function(e) {
                                    if (!e) return {};
                                    var t = m.navigationStart(),
                                        r = e.loading,
                                        a = r ? r.start : e.trequest,
                                        n = r ? r.first : e.tfirst,
                                        i = r ? r.end : e.tload;
                                    return {
                                        bytesLoaded: e.total,
                                        requestStart: Math.round(t + a),
                                        responseStart: Math.round(t + n),
                                        responseEnd: Math.round(t + i)
                                    }
                                },
                                O = function(e) {
                                    if (e && "function" == typeof e.getAllResponseHeaders) return g(e.getAllResponseHeaders())
                                };

                            function D(e, t) {
                                var r = Object.keys(e);
                                if (Object.getOwnPropertySymbols) {
                                    var a = Object.getOwnPropertySymbols(e);
                                    t && (a = a.filter(function(t) {
                                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                                    })), r.push.apply(r, a)
                                }
                                return r
                            }

                            function x(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var r = null != arguments[t] ? arguments[t] : {};
                                    t % 2 ? D(Object(r), !0).forEach(function(t) {
                                        var a, n;
                                        a = e, n = r[t], t in a ? Object.defineProperty(a, t, {
                                            value: n,
                                            enumerable: !0,
                                            configurable: !0,
                                            writable: !0
                                        }) : a[t] = n
                                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : D(Object(r)).forEach(function(t) {
                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                                    })
                                }
                                return e
                            }
                            var R = function(e, t) {
                                    if (!e || "function" != typeof e.getRequests) return {};
                                    var r = e.getRequests({
                                        state: "executed"
                                    });
                                    if (0 === r.length) return {};
                                    var a, n = r[r.length - 1],
                                        i = v(n.url),
                                        o = n.url,
                                        s = n.bytesLoaded,
                                        l = new Date(n.requestStartDate).getTime(),
                                        u = new Date(n.firstByteDate).getTime(),
                                        d = new Date(n.requestEndDate).getTime(),
                                        c = isNaN(n.duration) ? 0 : n.duration,
                                        f = "function" == typeof t.getMetricsFor ? t.getMetricsFor(n.mediaType).HttpList : t.getDashMetrics().getHttpRequests(n.mediaType);
                                    return f.length > 0 && (a = g(f[f.length - 1]._responseHeaders || "")), {
                                        requestStart: l,
                                        requestResponseStart: u,
                                        requestResponseEnd: d,
                                        requestBytesLoaded: s,
                                        requestResponseHeaders: a,
                                        requestMediaDuration: c,
                                        requestHostname: i,
                                        requestUrl: o
                                    }
                                },
                                A = function(e, t) {
                                    var r = t.getQualityFor(e),
                                        a = t.getCurrentTrackFor(e).bitrateList;
                                    return a ? {
                                        currentLevel: r,
                                        renditionWidth: a[r].width || null,
                                        renditionHeight: a[r].height || null,
                                        renditionBitrate: a[r].bandwidth
                                    } : {}
                                },
                                S = function(e) {
                                    var t;
                                    return null === (t = e.match(/.*codecs\*?="(.*)"/)) || void 0 === t ? void 0 : t[1]
                                };

                            function P(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var q = 0,
                                L = function() {
                                    var e, t;

                                    function r() {
                                        ! function(e, t) {
                                            if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                        }(this, r)
                                    }
                                    return e = [{
                                        key: "on",
                                        value: function(e, t, r) {
                                            return t._eventEmitterGuid = t._eventEmitterGuid || ++q, this._listeners = this._listeners || {}, this._listeners[e] = this._listeners[e] || [], r && (t = t.bind(r)), this._listeners[e].push(t), t
                                        }
                                    }, {
                                        key: "off",
                                        value: function(e, t) {
                                            var r = this._listeners && this._listeners[e];
                                            r && r.forEach(function(e, a) {
                                                e._eventEmitterGuid === t._eventEmitterGuid && r.splice(a, 1)
                                            })
                                        }
                                    }, {
                                        key: "one",
                                        value: function(e, t, r) {
                                            var a = this;
                                            t._eventEmitterGuid = t._eventEmitterGuid || ++q;
                                            var n = function n() {
                                                a.off(e, n), t.apply(r || this, arguments)
                                            };
                                            n._eventEmitterGuid = t._eventEmitterGuid, this.on(e, n)
                                        }
                                    }, {
                                        key: "emit",
                                        value: function(e, t) {
                                            var r = this;
                                            if (this._listeners) {
                                                t = t || {};
                                                var a = this._listeners["before*"] || [],
                                                    n = this._listeners[e] || [],
                                                    i = this._listeners["after" + e] || [],
                                                    o = function(t, a) {
                                                        (t = t.slice()).forEach(function(t) {
                                                            t.call(r, {
                                                                type: e
                                                            }, a)
                                                        })
                                                    };
                                                o(a, t), o(n, t), o(i, t)
                                            }
                                        }
                                    }], P(r.prototype, e), t && P(r, t), Object.defineProperty(r, "prototype", {
                                        writable: !1
                                    }), r
                                }();

                            function I(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var j = function() {
                                var e;

                                function t(e) {
                                    var r = this;
                                    (function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    })(this, t), this.pm = e, this._playbackHeartbeatInterval = null, this._playheadShouldBeProgressing = !1, e.on("playing", function() {
                                        r._playheadShouldBeProgressing = !0
                                    }), e.on("play", this._startPlaybackHeartbeatInterval.bind(this)), e.on("playing", this._startPlaybackHeartbeatInterval.bind(this)), e.on("adbreakstart", this._startPlaybackHeartbeatInterval.bind(this)), e.on("adplay", this._startPlaybackHeartbeatInterval.bind(this)), e.on("adplaying", this._startPlaybackHeartbeatInterval.bind(this)), e.on("seeking", this._startPlaybackHeartbeatInterval.bind(this)), e.on("devicewake", this._startPlaybackHeartbeatInterval.bind(this)), e.on("viewstart", this._startPlaybackHeartbeatInterval.bind(this)), e.on("rebufferstart", this._startPlaybackHeartbeatInterval.bind(this)), e.on("pause", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("ended", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("viewend", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("error", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("aderror", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("adpause", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("adended", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("adbreakend", this._stopPlaybackHeartbeatInterval.bind(this)), e.on("seeked", function() {
                                        e.data.player_is_paused ? r._stopPlaybackHeartbeatInterval() : r._startPlaybackHeartbeatInterval()
                                    }), e.on("timeupdate", function() {
                                        null !== r._playbackHeartbeatInterval && e.emit("playbackheartbeat")
                                    }), e.on("devicesleep", function(t, a) {
                                        null !== r._playbackHeartbeatInterval && (n().clearInterval(r._playbackHeartbeatInterval), e.emit("playbackheartbeatend", {
                                            viewer_time: a.viewer_time
                                        }), r._playbackHeartbeatInterval = null)
                                    })
                                }
                                return I(t.prototype, [{
                                    key: "_startPlaybackHeartbeatInterval",
                                    value: function() {
                                        var e = this;
                                        null === this._playbackHeartbeatInterval && (this.pm.emit("playbackheartbeat"), this._playbackHeartbeatInterval = n().setInterval(function() {
                                            e.pm.emit("playbackheartbeat")
                                        }, this.pm.playbackHeartbeatTime))
                                    }
                                }, {
                                    key: "_stopPlaybackHeartbeatInterval",
                                    value: function() {
                                        this._playheadShouldBeProgressing = !1, null !== this._playbackHeartbeatInterval && (n().clearInterval(this._playbackHeartbeatInterval), this.pm.emit("playbackheartbeatend"), this._playbackHeartbeatInterval = null)
                                    }
                                }]), e && I(t, e), Object.defineProperty(t, "prototype", {
                                    writable: !1
                                }), t
                            }();

                            function C(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var N = (e0 = function e(t) {
                                var r = this;
                                (function(e, t) {
                                    if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                })(this, e), t.on("viewinit", function() {
                                    r.viewErrored = !1
                                }), t.on("error", function(e, a) {
                                    try {
                                        var n = t.errorTranslator({
                                            player_error_code: a.player_error_code,
                                            player_error_message: a.player_error_message,
                                            player_error_context: a.player_error_context
                                        });
                                        n ? (t.data.player_error_code = n.player_error_code || a.player_error_code, t.data.player_error_message = n.player_error_message || a.player_error_message, t.data.player_error_context = n.player_error_context || a.player_error_context, r.viewErrored = !0) : (delete t.data.player_error_code, delete t.data.player_error_message, delete t.data.player_error_context)
                                    } catch (e) {
                                        t.mux.log.warn("Exception in error translator callback.", e), r.viewErrored = !0
                                    }
                                })
                            }, e1 && C(e0.prototype, e1), e2 && C(e0, e2), Object.defineProperty(e0, "prototype", {
                                writable: !1
                            }), e0);

                            function M(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var H = function() {
                                var e;

                                function t(e) {
                                    (function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    })(this, t), this.pm = e, this._watchTimeTrackerLastCheckedTime = null, e.on("playbackheartbeat", this._updateWatchTime.bind(this)), e.on("playbackheartbeatend", this._clearWatchTimeState.bind(this))
                                }
                                return M(t.prototype, [{
                                    key: "_updateWatchTime",
                                    value: function(e, t) {
                                        var r = t.viewer_time;
                                        null === this._watchTimeTrackerLastCheckedTime && (this._watchTimeTrackerLastCheckedTime = r), y(this.pm.data, "view_watch_time", r - this._watchTimeTrackerLastCheckedTime), this._watchTimeTrackerLastCheckedTime = r
                                    }
                                }, {
                                    key: "_clearWatchTimeState",
                                    value: function(e, t) {
                                        this._updateWatchTime(e, t), this._watchTimeTrackerLastCheckedTime = null
                                    }
                                }]), e && M(t, e), Object.defineProperty(t, "prototype", {
                                    writable: !1
                                }), t
                            }();

                            function U(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var B = function() {
                                var e;

                                function t(e) {
                                    (function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    })(this, t), this.pm = e, this._playbackTimeTrackerLastPlayheadPosition = -1, e.on("playbackheartbeat", this._updatePlaybackTime.bind(this)), e.on("playbackheartbeatend", this._clearPlaybackTimeState.bind(this)), e.on("seeking", this._clearPlaybackTimeState.bind(this))
                                }
                                return U(t.prototype, [{
                                    key: "_updatePlaybackTime",
                                    value: function() {
                                        var e = this.pm.data.player_playhead_time;
                                        if (this._playbackTimeTrackerLastPlayheadPosition >= 0 && e > this._playbackTimeTrackerLastPlayheadPosition) {
                                            var t = e - this._playbackTimeTrackerLastPlayheadPosition;
                                            t <= 1e3 && y(this.pm.data, "view_content_playback_time", t)
                                        }
                                        this._playbackTimeTrackerLastPlayheadPosition = e
                                    }
                                }, {
                                    key: "_clearPlaybackTimeState",
                                    value: function() {
                                        this._updatePlaybackTime(), this._playbackTimeTrackerLastPlayheadPosition = -1
                                    }
                                }]), e && U(t, e), Object.defineProperty(t, "prototype", {
                                    writable: !1
                                }), t
                            }();

                            function F(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var V = function() {
                                var e, t;

                                function r(e) {
                                    (function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    })(this, r), this.pm = e;
                                    var t = this._updatePlayheadTime.bind(this);
                                    e.on("playbackheartbeat", t), e.on("playbackheartbeatend", t), e.on("timeupdate", t), e.on("destroy", function() {
                                        e.off("timeupdate", t)
                                    })
                                }
                                return e = [{
                                    key: "_updateMaxPlayheadPosition",
                                    value: function() {
                                        this.pm.data.view_max_playhead_position = void 0 === this.pm.data.view_max_playhead_position ? this.pm.data.player_playhead_time : Math.max(this.pm.data.view_max_playhead_position, this.pm.data.player_playhead_time)
                                    }
                                }, {
                                    key: "_updatePlayheadTime",
                                    value: function(e, t) {
                                        var r = this,
                                            a = function() {
                                                r.pm.currentFragmentPDT && r.pm.currentFragmentStart && (r.pm.data.player_program_time = r.pm.currentFragmentPDT + r.pm.data.player_playhead_time - r.pm.currentFragmentStart)
                                            };
                                        if (t && t.player_playhead_time) this.pm.data.player_playhead_time = t.player_playhead_time, a(), this._updateMaxPlayheadPosition();
                                        else if (this.pm.getPlayheadTime) {
                                            var n = this.pm.getPlayheadTime();
                                            void 0 !== n && (this.pm.data.player_playhead_time = n, a(), this._updateMaxPlayheadPosition())
                                        }
                                    }
                                }], F(r.prototype, e), t && F(r, t), Object.defineProperty(r, "prototype", {
                                    writable: !1
                                }), r
                            }();

                            function W(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var G = (e3 = function e(t) {
                                if (function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    }(this, e), !t.disableRebufferTracking) {
                                    var r, a = function(e, t) {
                                            n(t), r = void 0
                                        },
                                        n = function(e) {
                                            if (r) {
                                                var a = e.viewer_time - r;
                                                y(t.data, "view_rebuffer_duration", a), r = e.viewer_time, t.data.view_rebuffer_duration > 3e5 && (t.emit("viewend"), t.send("viewend"))
                                            }
                                            t.data.view_watch_time >= 0 && t.data.view_rebuffer_count > 0 && (t.data.view_rebuffer_frequency = t.data.view_rebuffer_count / t.data.view_watch_time, t.data.view_rebuffer_percentage = t.data.view_rebuffer_duration / t.data.view_watch_time)
                                        };
                                    t.on("playbackheartbeat", function(e, t) {
                                        return n(t)
                                    }), t.on("rebufferstart", function(e, n) {
                                        r || (y(t.data, "view_rebuffer_count", 1), r = n.viewer_time, t.one("rebufferend", a))
                                    }), t.on("viewinit", function() {
                                        r = void 0, t.off("rebufferend", a)
                                    })
                                }
                            }, e5 && W(e3.prototype, e5), e8 && W(e3, e8), Object.defineProperty(e3, "prototype", {
                                writable: !1
                            }), e3);

                            function Q(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var J = function() {
                                var e;

                                function t(e) {
                                    var r = this;
                                    (function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    })(this, t), this.pm = e, e.disableRebufferTracking || e.disablePlayheadRebufferTracking || (this._lastCheckedTime = null, this._lastPlayheadTime = null, this._lastPlayheadTimeUpdatedTime = null, e.on("playbackheartbeat", this._checkIfRebuffering.bind(this)), e.on("playbackheartbeatend", this._cleanupRebufferTracker.bind(this)), e.on("seeking", function() {
                                        r._cleanupRebufferTracker(null, {
                                            viewer_time: _.now()
                                        })
                                    }))
                                }
                                return Q(t.prototype, [{
                                    key: "_checkIfRebuffering",
                                    value: function(e, t) {
                                        if (this.pm.seekingTracker.isSeeking || this.pm.adTracker.isAdBreak || !this.pm.playbackHeartbeat._playheadShouldBeProgressing) this._cleanupRebufferTracker(e, t);
                                        else if (null !== this._lastCheckedTime) {
                                            if (this._lastPlayheadTime === this.pm.data.player_playhead_time) {
                                                var r = t.viewer_time - this._lastPlayheadTimeUpdatedTime;
                                                "number" == typeof this.pm.sustainedRebufferThreshold && r >= this.pm.sustainedRebufferThreshold && (this._rebuffering || (this._rebuffering = !0, this.pm.emit("rebufferstart", {
                                                    viewer_time: this._lastPlayheadTimeUpdatedTime
                                                }))), this._lastCheckedTime = t.viewer_time
                                            } else this._cleanupRebufferTracker(e, t, !0)
                                        } else this._prepareRebufferTrackerState(t.viewer_time)
                                    }
                                }, {
                                    key: "_clearRebufferTrackerState",
                                    value: function() {
                                        this._lastCheckedTime = null, this._lastPlayheadTime = null, this._lastPlayheadTimeUpdatedTime = null
                                    }
                                }, {
                                    key: "_prepareRebufferTrackerState",
                                    value: function(e) {
                                        this._lastCheckedTime = e, this._lastPlayheadTime = this.pm.data.player_playhead_time, this._lastPlayheadTimeUpdatedTime = e
                                    }
                                }, {
                                    key: "_cleanupRebufferTracker",
                                    value: function(e, t) {
                                        var r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                                        if (this._rebuffering) this._rebuffering = !1, this.pm.emit("rebufferend", {
                                            viewer_time: t.viewer_time
                                        });
                                        else {
                                            if (null === this._lastCheckedTime) return;
                                            var a = this.pm.data.player_playhead_time - this._lastPlayheadTime,
                                                n = t.viewer_time - this._lastPlayheadTimeUpdatedTime;
                                            "number" == typeof this.pm.minimumRebufferDuration && a > 0 && n - a > this.pm.minimumRebufferDuration && (this.pm.emit("rebufferstart", {
                                                viewer_time: this._lastPlayheadTimeUpdatedTime
                                            }), this.pm.emit("rebufferend", {
                                                viewer_time: this._lastPlayheadTimeUpdatedTime + n - a
                                            }))
                                        }
                                        r ? this._prepareRebufferTrackerState(t.viewer_time) : this._clearRebufferTrackerState()
                                    }
                                }]), e && Q(t, e), Object.defineProperty(t, "prototype", {
                                    writable: !1
                                }), t
                            }();

                            function K(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var z = function() {
                                var e;

                                function t(e) {
                                    var r = this;
                                    (function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    })(this, t), this.pm = e, e.on("viewinit", function() {
                                        var t = e.data,
                                            a = t.view_id;
                                        if (!t.view_program_changed) {
                                            var n = function(t, n) {
                                                var i = n.viewer_time;
                                                "playing" === t.type && void 0 === e.data.view_time_to_first_frame ? r.calculateTimeToFirstFrame(i || _.now(), a) : "adplaying" === t.type && (void 0 === e.data.view_time_to_first_frame || r._inPrerollPosition()) && r.calculateTimeToFirstFrame(i || _.now(), a)
                                            };
                                            e.one("playing", n), e.one("adplaying", n), e.one("viewend", function() {
                                                e.off("playing", n), e.off("adplaying", n)
                                            })
                                        }
                                    })
                                }
                                return K(t.prototype, [{
                                    key: "_inPrerollPosition",
                                    value: function() {
                                        return void 0 === this.pm.data.view_content_playback_time || this.pm.data.view_content_playback_time <= 1e3
                                    }
                                }, {
                                    key: "calculateTimeToFirstFrame",
                                    value: function(e, t) {
                                        t === this.pm.data.view_id && (this.pm.watchTimeTracker._updateWatchTime(null, {
                                            viewer_time: e
                                        }), this.pm.data.view_time_to_first_frame = this.pm.data.view_watch_time, (this.pm.data.player_autoplay_on || this.pm.data.video_is_autoplay) && this.NAVIGATION_START && (this.pm.data.view_aggregate_startup_time = this.pm.data.view_start + this.pm.data.view_watch_time - this.NAVIGATION_START))
                                    }
                                }]), e && K(t, e), Object.defineProperty(t, "prototype", {
                                    writable: !1
                                }), t
                            }();

                            function Y(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var X = (e4 = function e(t) {
                                var r = this;
                                (function(e, t) {
                                    if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                })(this, e), t.on("viewinit", function() {
                                    r._lastPlayheadPosition = -1
                                }), ["pause", "rebufferstart", "seeking", "error", "adbreakstart", "hb"].forEach(function(e) {
                                    t.on(e, function() {
                                        if (r._lastPlayheadPosition >= 0 && t.data.player_playhead_time >= 0 && r._lastPlayerWidth >= 0 && r._lastSourceWidth > 0 && r._lastPlayerHeight >= 0 && r._lastSourceHeight > 0) {
                                            var e = t.data.player_playhead_time - r._lastPlayheadPosition;
                                            if (e < 0) return void(r._lastPlayheadPosition = -1);
                                            var a = Math.min(r._lastPlayerWidth / r._lastSourceWidth, r._lastPlayerHeight / r._lastSourceHeight),
                                                n = Math.max(0, a - 1),
                                                i = Math.max(0, 1 - a);
                                            t.data.view_max_upscale_percentage = Math.max(t.data.view_max_upscale_percentage || 0, n), t.data.view_max_downscale_percentage = Math.max(t.data.view_max_downscale_percentage || 0, i), y(t.data, "view_total_content_playback_time", e), y(t.data, "view_total_upscaling", n * e), y(t.data, "view_total_downscaling", i * e)
                                        }
                                        r._lastPlayheadPosition = -1
                                    })
                                }), ["playing", "hb"].forEach(function(e) {
                                    t.on(e, function() {
                                        r._lastPlayheadPosition = t.data.player_playhead_time, r._lastPlayerWidth = t.data.player_width, r._lastPlayerHeight = t.data.player_height, r._lastSourceWidth = t.data.video_source_width, r._lastSourceHeight = t.data.video_source_height
                                    })
                                })
                            }, e6 && Y(e4.prototype, e6), e7 && Y(e4, e7), Object.defineProperty(e4, "prototype", {
                                writable: !1
                            }), e4);

                            function $(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var Z = (e9 = function e(t) {
                                var r = this;
                                (function(e, t) {
                                    if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                })(this, e), this.isSeeking = !1, t.on("seeking", function(e, a) {
                                    Object.assign(t.data, a), r._lastSeekingTime = _.now(), !1 === r.isSeeking && (r.isSeeking = !0, t.send("seeking"))
                                }), t.on("seeked", function() {
                                    r.isSeeking = !1;
                                    var e = r._lastSeekingTime || _.now(),
                                        a = _.now() - e;
                                    y(t.data, "view_seek_count", 1), y(t.data, "view_seek_duration", a);
                                    var n = t.data.view_max_seek_time || 0;
                                    t.data.view_max_seek_time = Math.max(n, a)
                                }), t.on("viewend", function() {
                                    r.isSeeking = !1
                                })
                            }, te && $(e9.prototype, te), tt && $(e9, tt), Object.defineProperty(e9, "prototype", {
                                writable: !1
                            }), e9);

                            function ee(e, t) {
                                return function(e) {
                                    if (Array.isArray(e)) return e
                                }(e) || function(e, t) {
                                    var r = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                    if (null != r) {
                                        var a, n, i = [],
                                            o = !0,
                                            s = !1;
                                        try {
                                            for (r = r.call(e); !(o = (a = r.next()).done) && (i.push(a.value), !t || i.length !== t); o = !0);
                                        } catch (e) {
                                            s = !0, n = e
                                        } finally {
                                            try {
                                                o || null == r.return || r.return()
                                            } finally {
                                                if (s) throw n
                                            }
                                        }
                                        return i
                                    }
                                }(e, t) || function(e, t) {
                                    if (e) {
                                        if ("string" == typeof e) return et(e, t);
                                        var r = Object.prototype.toString.call(e).slice(8, -1);
                                        return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? et(e, t) : void 0
                                    }
                                }(e, t) || function() {
                                    throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                }()
                            }

                            function et(e, t) {
                                (null == t || t > e.length) && (t = e.length);
                                for (var r = 0, a = Array(t); r < t; r++) a[r] = e[r];
                                return a
                            }

                            function er(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var ea = function(e, t) {
                                    e.push(t), e.sort(function(e, t) {
                                        return e.viewer_time - t.viewer_time
                                    })
                                },
                                en = ["adbreakstart", "adrequest", "adresponse", "adplay", "adplaying", "adpause", "adended", "adbreakend", "aderror"],
                                ei = function() {
                                    var e, t;

                                    function r(e) {
                                        var t = this;
                                        (function(e, t) {
                                            if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                        })(this, r), this.pm = e, e.on("viewinit", function() {
                                            t.isAdBreak = !1, t._currentAdRequestNumber = 0, t._currentAdResponseNumber = 0, t._adRequests = [], t._adResponses = [], t._adHasPlayed = !1, t._wouldBeNewAdPlay = !0, t._prerollPlayTime = void 0
                                        }), en.forEach(function(r) {
                                            return e.on(r, t._updateAdData.bind(t))
                                        });
                                        var a = function() {
                                            t.isAdBreak = !1
                                        };
                                        e.on("adbreakstart", function() {
                                            t.isAdBreak = !0
                                        }), e.on("play", a), e.on("playing", a), e.on("viewend", a), e.on("adrequest", function(r, a) {
                                            a = Object.assign({
                                                ad_request_id: "generatedAdRequestId" + t._currentAdRequestNumber++
                                            }, a), ea(t._adRequests, a), y(e.data, "view_ad_request_count"), t.inPrerollPosition() && (e.data.view_preroll_requested = !0, t._adHasPlayed || y(e.data, "view_preroll_request_count"))
                                        }), e.on("adresponse", function(r, a) {
                                            a = Object.assign({
                                                ad_request_id: "generatedAdRequestId" + t._currentAdResponseNumber++
                                            }, a), ea(t._adResponses, a);
                                            var n = t.findAdRequest(a.ad_request_id);
                                            n && y(e.data, "view_ad_request_time", Math.max(0, a.viewer_time - n.viewer_time))
                                        }), e.on("adplay", function(r, a) {
                                            t._adHasPlayed = !0, t._wouldBeNewAdPlay && (t._wouldBeNewAdPlay = !1, y(e.data, "view_ad_played_count")), t.inPrerollPosition() && !e.data.view_preroll_played && (e.data.view_preroll_played = !0, t._adRequests.length > 0 && (e.data.view_preroll_request_time = Math.max(0, a.viewer_time - t._adRequests[0].viewer_time)), e.data.view_start && (e.data.view_startup_preroll_request_time = Math.max(0, a.viewer_time - e.data.view_start)), t._prerollPlayTime = a.viewer_time)
                                        }), e.on("adplaying", function(r, a) {
                                            t.inPrerollPosition() && void 0 === e.data.view_preroll_load_time && void 0 !== t._prerollPlayTime && (e.data.view_preroll_load_time = a.viewer_time - t._prerollPlayTime, e.data.view_startup_preroll_load_time = a.viewer_time - t._prerollPlayTime)
                                        }), e.on("adended", function() {
                                            t._wouldBeNewAdPlay = !0
                                        }), e.on("aderror", function() {
                                            t._wouldBeNewAdPlay = !0
                                        })
                                    }
                                    return e = [{
                                        key: "inPrerollPosition",
                                        value: function() {
                                            return void 0 === this.pm.data.view_content_playback_time || this.pm.data.view_content_playback_time <= 1e3
                                        }
                                    }, {
                                        key: "findAdRequest",
                                        value: function(e) {
                                            for (var t = 0; t < this._adRequests.length; t++)
                                                if (this._adRequests[t].ad_request_id === e) return this._adRequests[t]
                                        }
                                    }, {
                                        key: "_updateAdData",
                                        value: function(e, t) {
                                            if (this.inPrerollPosition()) {
                                                if (!this.pm.data.view_preroll_ad_tag_hostname && t.ad_tag_url) {
                                                    var r = ee(h(t.ad_tag_url), 2),
                                                        a = r[0],
                                                        n = r[1];
                                                    this.pm.data.view_preroll_ad_tag_domain = n, this.pm.data.view_preroll_ad_tag_hostname = a
                                                }
                                                if (!this.pm.data.view_preroll_ad_asset_hostname && t.ad_asset_url) {
                                                    var i = ee(h(t.ad_asset_url), 2),
                                                        o = i[0],
                                                        s = i[1];
                                                    this.pm.data.view_preroll_ad_asset_domain = s, this.pm.data.view_preroll_ad_asset_hostname = o
                                                }
                                            }
                                            this.pm.data.ad_asset_url = null == t ? void 0 : t.ad_asset_url, this.pm.data.ad_tag_url = null == t ? void 0 : t.ad_tag_url, this.pm.data.ad_creative_id = null == t ? void 0 : t.ad_creative_id, this.pm.data.ad_id = null == t ? void 0 : t.ad_id, this.pm.data.ad_universal_id = null == t ? void 0 : t.ad_universal_id
                                        }
                                    }], er(r.prototype, e), t && er(r, t), Object.defineProperty(r, "prototype", {
                                        writable: !1
                                    }), r
                                }();

                            function eo(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var es = (tr = function e(t) {
                                ! function(e, t) {
                                    if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                }(this, e);
                                var r, a, i = function() {
                                        t.disableRebufferTracking || r && (y(t.data, "view_waiting_rebuffer_duration", _.now() - r), r = !1, n().clearInterval(a))
                                    },
                                    o = !1,
                                    s = function() {
                                        o = !1, i()
                                    };
                                t.on("waiting", function() {
                                    o && (t.disableRebufferTracking || (y(t.data, "view_waiting_rebuffer_count", 1), r = _.now(), a = n().setInterval(function() {
                                        if (r) {
                                            var e = _.now();
                                            y(t.data, "view_waiting_rebuffer_duration", e - r), r = e
                                        }
                                    }, 250)))
                                }), t.on("playing", function() {
                                    i(), o = !0
                                }), t.on("pause", s), t.on("seeking", s)
                            }, ta && eo(tr.prototype, ta), tn && eo(tr, tn), Object.defineProperty(tr, "prototype", {
                                writable: !1
                            }), tr);

                            function el(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var eu = (ti = function e(t) {
                                    var r = this;
                                    ! function(e, t) {
                                        if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                    }(this, e);
                                    var a = function() {
                                            r.lastWallClockTime = _.now(), t.on("before*", n)
                                        },
                                        n = function(e) {
                                            var a = _.now(),
                                                n = r.lastWallClockTime;
                                            r.lastWallClockTime = a, a - n > 3e4 && (t.emit("devicesleep", {
                                                viewer_time: n
                                            }), Object.assign(t.data, {
                                                viewer_time: n
                                            }), t.send("devicesleep"), t.emit("devicewake", {
                                                viewer_time: a
                                            }), Object.assign(t.data, {
                                                viewer_time: a
                                            }), t.send("devicewake"))
                                        };
                                    t.one("playbackheartbeat", a), t.on("playbackheartbeatend", function() {
                                        t.off("before*", n), t.one("playbackheartbeat", a)
                                    })
                                }, to && el(ti.prototype, to), ts && el(ti, ts), Object.defineProperty(ti, "prototype", {
                                    writable: !1
                                }), ti),
                                ed = r(375),
                                ec = r(655),
                                ef = r.n(ec),
                                ep = "muxData",
                                e_ = function() {
                                    var e;
                                    try {
                                        e = ed.parse(ef().get(ep) || "")
                                    } catch (t) {
                                        e = {}
                                    }
                                    return e
                                },
                                ev = function(e) {
                                    try {
                                        ef().set(ep, ed.stringify(e), {
                                            expires: 7300
                                        })
                                    } catch (e) {}
                                },
                                eh = function() {
                                    var e = e_();
                                    return e.mux_viewer_id = e.mux_viewer_id || i(), e.msn = e.msn || Math.random(), ev(e), {
                                        mux_viewer_id: e.mux_viewer_id,
                                        mux_sample_number: e.msn
                                    }
                                },
                                em = function() {
                                    var e;
                                    switch (ey()) {
                                        case "cellular":
                                            e = "cellular";
                                            break;
                                        case "ethernet":
                                            e = "wired";
                                            break;
                                        case "wifi":
                                            e = "wifi";
                                            break;
                                        case void 0:
                                            break;
                                        default:
                                            e = "other"
                                    }
                                    return e
                                },
                                ey = function() {
                                    var e = n().navigator,
                                        t = e && (e.connection || e.mozConnection || e.webkitConnection);
                                    return t && t.type
                                };
                            em.getConnectionFromAPI = ey;
                            var eb = ew({
                                    a: "env",
                                    b: "beacon",
                                    c: "custom",
                                    d: "ad",
                                    e: "event",
                                    f: "experiment",
                                    i: "internal",
                                    m: "mux",
                                    n: "response",
                                    p: "player",
                                    q: "request",
                                    r: "retry",
                                    s: "session",
                                    t: "timestamp",
                                    u: "viewer",
                                    v: "video",
                                    w: "page",
                                    x: "view",
                                    y: "sub"
                                }),
                                eg = ew({
                                    ad: "ad",
                                    ag: "aggregate",
                                    ap: "api",
                                    al: "application",
                                    ar: "architecture",
                                    as: "asset",
                                    au: "autoplay",
                                    av: "average",
                                    bi: "bitrate",
                                    br: "break",
                                    bw: "browser",
                                    by: "bytes",
                                    ca: "cached",
                                    cb: "cancel",
                                    cc: "codec",
                                    cd: "code",
                                    cg: "category",
                                    ch: "changed",
                                    cl: "canceled",
                                    cn: "config",
                                    co: "count",
                                    ce: "counter",
                                    cp: "complete",
                                    cr: "creative",
                                    ct: "content",
                                    cu: "current",
                                    cx: "connection",
                                    cz: "context",
                                    dg: "downscaling",
                                    dm: "domain",
                                    dn: "cdn",
                                    do: "downscale",
                                    dr: "drm",
                                    dp: "dropped",
                                    du: "duration",
                                    dv: "device",
                                    ec: "encoding",
                                    ed: "edge",
                                    en: "end",
                                    eg: "engine",
                                    em: "embed",
                                    er: "error",
                                    es: "errorcode",
                                    et: "errortext",
                                    ee: "event",
                                    ev: "events",
                                    ex: "expires",
                                    ep: "experiments",
                                    fa: "failed",
                                    fi: "first",
                                    fm: "family",
                                    ft: "format",
                                    fp: "fps",
                                    fq: "frequency",
                                    fr: "frame",
                                    fs: "fullscreen",
                                    ha: "has",
                                    hb: "holdback",
                                    he: "headers",
                                    ho: "host",
                                    hn: "hostname",
                                    ht: "height",
                                    id: "id",
                                    ii: "init",
                                    in: "instance",
                                    ip: "ip",
                                    is: "is",
                                    ke: "key",
                                    la: "language",
                                    lb: "labeled",
                                    le: "level",
                                    li: "live",
                                    ld: "loaded",
                                    lo: "load",
                                    ls: "lists",
                                    lt: "latency",
                                    ma: "max",
                                    md: "media",
                                    me: "message",
                                    mf: "manifest",
                                    mi: "mime",
                                    ml: "midroll",
                                    mm: "min",
                                    mn: "manufacturer",
                                    mo: "model",
                                    mx: "mux",
                                    ne: "newest",
                                    nm: "name",
                                    no: "number",
                                    on: "on",
                                    os: "os",
                                    pa: "paused",
                                    pb: "playback",
                                    pd: "producer",
                                    pe: "percentage",
                                    pf: "played",
                                    pg: "program",
                                    ph: "playhead",
                                    pi: "plugin",
                                    pl: "preroll",
                                    pn: "playing",
                                    po: "poster",
                                    pr: "preload",
                                    ps: "position",
                                    pt: "part",
                                    py: "property",
                                    ra: "rate",
                                    rd: "requested",
                                    re: "rebuffer",
                                    rf: "rendition",
                                    rm: "remote",
                                    ro: "ratio",
                                    rp: "response",
                                    rq: "request",
                                    rs: "requests",
                                    sa: "sample",
                                    se: "session",
                                    sk: "seek",
                                    sm: "stream",
                                    so: "source",
                                    sq: "sequence",
                                    sr: "series",
                                    st: "start",
                                    su: "startup",
                                    sv: "server",
                                    sw: "software",
                                    ta: "tag",
                                    tc: "tech",
                                    te: "text",
                                    tg: "target",
                                    th: "throughput",
                                    ti: "time",
                                    tl: "total",
                                    to: "to",
                                    tt: "title",
                                    ty: "type",
                                    ug: "upscaling",
                                    un: "universal",
                                    up: "upscale",
                                    ur: "url",
                                    us: "user",
                                    va: "variant",
                                    vd: "viewed",
                                    vi: "video",
                                    ve: "version",
                                    vw: "view",
                                    vr: "viewer",
                                    wd: "width",
                                    wa: "watch",
                                    wt: "waiting"
                                });

                            function ew(e) {
                                var t = {};
                                for (var r in e) e.hasOwnProperty(r) && (t[e[r]] = r);
                                return t
                            }

                            function eE(e) {
                                var t = {},
                                    r = {};
                                return Object.keys(e).forEach(function(a) {
                                    var n = !1;
                                    if (e.hasOwnProperty(a) && void 0 !== e[a]) {
                                        var i = a.split("_"),
                                            o = i[0],
                                            s = eb[o];
                                        s || (f.info("Data key word `" + i[0] + "` not expected in " + a), s = o + "_"), i.splice(1).forEach(function(e) {
                                            "url" === e && (n = !0), eg[e] ? s += eg[e] : Number(e) && Math.floor(Number(e)) === Number(e) ? s += e : (f.info("Data key word `" + e + "` not expected in " + a), s += "_" + e + "_")
                                        }), n ? r[s] = e[a] : t[s] = e[a]
                                    }
                                }), Object.assign(t, r)
                            }
                            var eT = {
                                    maxBeaconSize: 300,
                                    maxQueueLength: 3600,
                                    baseTimeBetweenBeacons: 1e4,
                                    maxPayloadKBSize: 500
                                },
                                ek = ["hb", "requestcompleted", "requestfailed", "requestcanceled"],
                                eO = function(e) {
                                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                                    this._beaconUrl = e || "https://img.litix.io", this._eventQueue = [], this._postInFlight = !1, this._failureCount = 0, this._sendTimeout = !1, this._options = Object.assign({}, eT, t)
                                };
                            eO.prototype.queueEvent = function(e, t) {
                                var r = Object.assign({}, t);
                                return (this._eventQueue.length <= this._options.maxQueueLength || "eventrateexceeded" === e) && (this._eventQueue.push(r), this._sendTimeout || this._startBeaconSending(), this._eventQueue.length <= this._options.maxQueueLength)
                            }, eO.prototype.flushEvents = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                                e && 1 === this._eventQueue.length ? this._eventQueue.pop() : (this._eventQueue.length && this._sendBeaconQueue(), this._startBeaconSending())
                            }, eO.prototype.destroy = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                                this.destroyed = !0, e ? this._clearBeaconQueue() : this.flushEvents(), n().clearTimeout(this._sendTimeout)
                            }, eO.prototype._clearBeaconQueue = function() {
                                var e = this._eventQueue.length > this._options.maxBeaconSize ? this._eventQueue.length - this._options.maxBeaconSize : 0,
                                    t = this._eventQueue.slice(e);
                                e > 0 && Object.assign(t[t.length - 1], eE({
                                    mux_view_message: "event queue truncated"
                                }));
                                var r = this._createPayload(t);
                                eD(this._beaconUrl, r, !0, function() {})
                            }, eO.prototype._sendBeaconQueue = function() {
                                var e = this;
                                if (!this._postInFlight) {
                                    var t = this._eventQueue.slice(0, this._options.maxBeaconSize);
                                    this._eventQueue = this._eventQueue.slice(this._options.maxBeaconSize), this._postInFlight = !0;
                                    var r = this._createPayload(t),
                                        a = _.now();
                                    eD(this._beaconUrl, r, !1, function(r, n) {
                                        n ? (e._eventQueue = t.concat(e._eventQueue), e._failureCount += 1, f.info("Error sending beacon: " + n)) : e._failureCount = 0, e._roundTripTime = _.now() - a, e._postInFlight = !1
                                    })
                                }
                            }, eO.prototype._getNextBeaconTime = function() {
                                if (!this._failureCount) return this._options.baseTimeBetweenBeacons;
                                var e = Math.pow(2, this._failureCount - 1);
                                return (1 + (e *= Math.random())) * this._options.baseTimeBetweenBeacons
                            }, eO.prototype._startBeaconSending = function() {
                                var e = this;
                                n().clearTimeout(this._sendTimeout), this.destroyed || (this._sendTimeout = n().setTimeout(function() {
                                    e._eventQueue.length && e._sendBeaconQueue(), e._startBeaconSending()
                                }, this._getNextBeaconTime()))
                            }, eO.prototype._createPayload = function(e) {
                                var t, r, a, n = this,
                                    i = {
                                        transmission_timestamp: Math.round(_.now())
                                    };
                                this._roundTripTime && (i.rtt_ms = Math.round(this._roundTripTime));
                                var o = function() {
                                        a = (t = JSON.stringify({
                                            metadata: i,
                                            events: r || e
                                        })).length / 1024
                                    },
                                    s = function() {
                                        return a <= n._options.maxPayloadKBSize
                                    };
                                return o(), s() || (f.info("Payload size is too big (" + a + " kb). Removing unnecessary events."), r = e.filter(function(e) {
                                    return -1 === ek.indexOf(e.e)
                                }), o()), s() || (f.info("Payload size still too big (" + a + " kb). Cropping fields.."), r.forEach(function(e) {
                                    for (var t in e) {
                                        var r = e[t];
                                        "string" == typeof r && r.length > 51200 && (e[t] = r.substring(0, 51200))
                                    }
                                }), o()), t
                            };
                            var eD = function(e, t, r, a) {
                                if (r && navigator && navigator.sendBeacon && navigator.sendBeacon(e, t)) a();
                                else if (n().fetch) n().fetch(e, {
                                    method: "POST",
                                    body: t,
                                    headers: {
                                        "Content-Type": "text/plain"
                                    },
                                    keepalive: !0
                                }).then(function(e) {
                                    return a(null, e.ok ? null : "Error")
                                }).catch(function(e) {
                                    return a(null, e)
                                });
                                else {
                                    if (n().XMLHttpRequest) {
                                        var i = new(n()).XMLHttpRequest;
                                        return i.onreadystatechange = function() {
                                            if (4 === i.readyState) return a(null, 200 !== i.status ? "error" : void 0)
                                        }, i.open("POST", e), i.setRequestHeader("Content-Type", "text/plain"), void i.send(t)
                                    }
                                    a()
                                }
                            };

                            function ex(e, t) {
                                (null == t || t > e.length) && (t = e.length);
                                for (var r = 0, a = Array(t); r < t; r++) a[r] = e[r];
                                return a
                            }

                            function eR(e, t) {
                                var r = Object.keys(e);
                                if (Object.getOwnPropertySymbols) {
                                    var a = Object.getOwnPropertySymbols(e);
                                    t && (a = a.filter(function(t) {
                                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                                    })), r.push.apply(r, a)
                                }
                                return r
                            }

                            function eA(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var r = null != arguments[t] ? arguments[t] : {};
                                    t % 2 ? eR(Object(r), !0).forEach(function(t) {
                                        eq(e, t, r[t])
                                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : eR(Object(r)).forEach(function(t) {
                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                                    })
                                }
                                return e
                            }

                            function eS(e) {
                                return (eS = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                                    return typeof e
                                } : function(e) {
                                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                                })(e)
                            }

                            function eP(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }

                            function eq(e, t, r) {
                                return t in e ? Object.defineProperty(e, t, {
                                    value: r,
                                    enumerable: !0,
                                    configurable: !0,
                                    writable: !0
                                }) : e[t] = r, e
                            }
                            var eL = ["env_key", "view_id", "view_sequence_number", "player_sequence_number", "beacon_domain", "player_playhead_time", "viewer_time", "mux_api_version", "event", "video_id", "player_instance_id"],
                                eI = ["adplay", "adplaying", "adpause", "adfirstquartile", "admidpoint", "adthirdquartile", "adended", "adresponse"],
                                ej = ["viewstart", "error", "ended", "viewend"],
                                eC = function() {
                                    var e, t;

                                    function r(e, t) {
                                        var a, i, o, s, l, u, d, c, f, p, _, v, h, m, y, b, g, w, E, T = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                                        (function(e, t) {
                                            if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                        })(this, r), eq(this, "previousBeaconData", null), eq(this, "lastEventTime", 0), eq(this, "rateLimited", !1), this.mux = e, this.envKey = t, this.options = T, this.eventQueue = new eO((a = this.envKey, o = (i = this.options).beaconCollectionDomain, s = i.beaconDomain, o ? "https://" + o : (a = a || "inferred").match(/^[a-z0-9]+$/) ? "https://" + a + "." + (s || "litix.io") : "https://img.litix.io/a.gif")), this.sampleRate = null !== (l = this.options.sampleRate) && void 0 !== l ? l : 1, this.disableCookies = null !== (u = this.options.disableCookies) && void 0 !== u && u, this.respectDoNotTrack = null !== (d = this.options.respectDoNotTrack) && void 0 !== d && d, this.previousBeaconData = null, this.lastEventTime = 0, this.rateLimited = !1, this.pageLevelData = {
                                            mux_api_version: this.mux.API_VERSION,
                                            mux_embed: this.mux.NAME,
                                            mux_embed_version: this.mux.VERSION,
                                            viewer_application_name: null === (c = this.options.platform) || void 0 === c ? void 0 : c.name,
                                            viewer_application_version: null === (f = this.options.platform) || void 0 === f ? void 0 : f.version,
                                            viewer_application_engine: null === (p = this.options.platform) || void 0 === p ? void 0 : p.layout,
                                            viewer_device_name: null === (_ = this.options.platform) || void 0 === _ ? void 0 : _.product,
                                            viewer_device_category: "",
                                            viewer_device_manufacturer: null === (v = this.options.platform) || void 0 === v ? void 0 : v.manufacturer,
                                            viewer_os_family: null === (h = this.options.platform) || void 0 === h || null === (m = h.os) || void 0 === m ? void 0 : m.family,
                                            viewer_os_architecture: null === (y = this.options.platform) || void 0 === y || null === (b = y.os) || void 0 === b ? void 0 : b.architecture,
                                            viewer_os_version: null === (g = this.options.platform) || void 0 === g || null === (w = g.os) || void 0 === w ? void 0 : w.version,
                                            viewer_connection_type: em(),
                                            page_url: null === n() || void 0 === n() || null === (E = n().location) || void 0 === E ? void 0 : E.href
                                        }, this.viewerData = this.disableCookies ? {} : eh()
                                    }
                                    return e = [{
                                        key: "send",
                                        value: function(e, t) {
                                            var r;
                                            if (e && null != t && t.view_id) {
                                                if (this.respectDoNotTrack && p()) return f.info("Not sending `" + e + "` because Do Not Track is enabled");
                                                if (!t || "object" !== eS(t)) return f.error("A data object was expected in send() but was not provided");
                                                var a, n, o = this.disableCookies ? {} : (a = e_(), n = _.now(), a.session_start && (a.sst = a.session_start, delete a.session_start), a.session_id && (a.sid = a.session_id, delete a.session_id), a.session_expires && (a.sex = a.session_expires, delete a.session_expires), (!a.sex || a.sex < n) && (a.sid = i(), a.sst = n), a.sex = n + 15e5, ev(a), {
                                                        session_id: a.sid,
                                                        session_start: a.sst,
                                                        session_expires: a.sex
                                                    }),
                                                    s = eA(eA(eA(eA(eA({}, this.pageLevelData), t), o), this.viewerData), {}, {
                                                        event: e,
                                                        env_key: this.envKey
                                                    });
                                                s.user_id && (s.viewer_user_id = s.user_id, delete s.user_id);
                                                var l = (null !== (r = s.mux_sample_number) && void 0 !== r ? r : 0) >= this.sampleRate,
                                                    u = eE(this._deduplicateBeaconData(e, s));
                                                if (this.lastEventTime = this.mux.utils.now(), l) return f.info("Not sending event due to sample rate restriction", e, s, u);
                                                if (this.envKey || f.info("Missing environment key (envKey) - beacons will be dropped if the video source is not a valid mux video URL", e, s, u), !this.rateLimited) {
                                                    if (f.info("Sending event", e, s, u), this.rateLimited = !this.eventQueue.queueEvent(e, u), this.mux.WINDOW_UNLOADING && "viewend" === e) this.eventQueue.destroy(!0);
                                                    else if (this.mux.WINDOW_HIDDEN && "hb" === e ? this.eventQueue.flushEvents(!0) : ej.indexOf(e) >= 0 && this.eventQueue.flushEvents(), this.rateLimited) return s.event = "eventrateexceeded", u = eE(s), this.eventQueue.queueEvent(s.event, u), f.error("Beaconing disabled due to rate limit.")
                                                }
                                            }
                                        }
                                    }, {
                                        key: "destroy",
                                        value: function() {
                                            this.eventQueue.destroy(!1)
                                        }
                                    }, {
                                        key: "_deduplicateBeaconData",
                                        value: function(e, t) {
                                            var r = this,
                                                a = {},
                                                n = t.view_id;
                                            if ("-1" === n || "viewstart" === e || "viewend" === e || !this.previousBeaconData || this.mux.utils.now() - this.lastEventTime >= 6e5) a = eA({}, t), n && (this.previousBeaconData = a), n && "viewend" === e && (this.previousBeaconData = null);
                                            else {
                                                var i = 0 === e.indexOf("request");
                                                Object.entries(t).forEach(function(t) {
                                                    var n = function(e) {
                                                            if (Array.isArray(e)) return e
                                                        }(t) || function(e, t) {
                                                            var r = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                                            if (null != r) {
                                                                var a, n, i = [],
                                                                    o = !0,
                                                                    s = !1;
                                                                try {
                                                                    for (r = r.call(e); !(o = (a = r.next()).done) && (i.push(a.value), !t || i.length !== t); o = !0);
                                                                } catch (e) {
                                                                    s = !0, n = e
                                                                } finally {
                                                                    try {
                                                                        o || null == r.return || r.return()
                                                                    } finally {
                                                                        if (s) throw n
                                                                    }
                                                                }
                                                                return i
                                                            }
                                                        }(t, 2) || function(e, t) {
                                                            if (e) {
                                                                if ("string" == typeof e) return ex(e, t);
                                                                var r = Object.prototype.toString.call(e).slice(8, -1);
                                                                return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? ex(e, t) : void 0
                                                            }
                                                        }(t, 2) || function() {
                                                            throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                                        }(),
                                                        o = n[0],
                                                        s = n[1];
                                                    r.previousBeaconData && (s !== r.previousBeaconData[o] || eL.indexOf(o) > -1 || r.objectHasChanged(i, o, s, r.previousBeaconData[o]) || r.eventRequiresKey(e, o)) && (a[o] = s, r.previousBeaconData[o] = s)
                                                })
                                            }
                                            return a
                                        }
                                    }, {
                                        key: "objectHasChanged",
                                        value: function(e, t, r, a) {
                                            return !(!e || 0 !== t.indexOf("request_") || "request_response_headers" !== t && "object" === eS(r) && "object" === eS(a) && Object.keys(r || {}).length === Object.keys(a || {}).length)
                                        }
                                    }, {
                                        key: "eventRequiresKey",
                                        value: function(e, t) {
                                            return "renditionchange" === e && 0 === t.indexOf("video_source_") || !(0 !== t.indexOf("ad_id") || !eI.includes(e))
                                        }
                                    }], eP(r.prototype, e), t && eP(r, t), Object.defineProperty(r, "prototype", {
                                        writable: !1
                                    }), r
                                }();

                            function eN(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var eM = (tl = function e(t) {
                                ! function(e, t) {
                                    if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                }(this, e);
                                var r = 0,
                                    a = 0,
                                    n = 0,
                                    i = 0,
                                    o = 0,
                                    s = 0,
                                    l = 0;
                                t.on("requestcompleted", function(e, s) {
                                    var l, u, d = s.request_start,
                                        c = s.request_response_start,
                                        f = s.request_response_end,
                                        p = s.request_bytes_loaded;
                                    if (i++, c ? (l = c - d, u = f - c) : u = f - d, u > 0 && p > 0) {
                                        var _ = p / u * 8e3;
                                        o++, a += p, n += u, t.data.view_min_request_throughput = Math.min(t.data.view_min_request_throughput || 1 / 0, _), t.data.view_average_request_throughput = a / n * 8e3, t.data.view_request_count = i, l > 0 && (r += l, t.data.view_max_request_latency = Math.max(t.data.view_max_request_latency || 0, l), t.data.view_average_request_latency = r / o)
                                    }
                                }), t.on("requestfailed", function(e, r) {
                                    i++, s++, t.data.view_request_count = i, t.data.view_request_failed_count = s
                                }), t.on("requestcanceled", function(e, r) {
                                    i++, l++, t.data.view_request_count = i, t.data.view_request_canceled_count = l
                                })
                            }, tu && eN(tl.prototype, tu), td && eN(tl, td), Object.defineProperty(tl, "prototype", {
                                writable: !1
                            }), tl);

                            function eH(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }
                            var eU = (tc = function e(t) {
                                var r = this;
                                (function(e, t) {
                                    if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                })(this, e), t.on("before*", function(e, a) {
                                    var n = a.viewer_time,
                                        i = _.now(),
                                        o = r._lastEventTime;
                                    if (r._lastEventTime = i, o && i - o > 36e5) {
                                        var s = Object.keys(t.data).reduce(function(e, r) {
                                            var a, n;
                                            return 0 === r.indexOf("video_") ? Object.assign(e, (a = {}, n = t.data[r], r in a ? Object.defineProperty(a, r, {
                                                value: n,
                                                enumerable: !0,
                                                configurable: !0,
                                                writable: !0
                                            }) : a[r] = n, a)) : e
                                        }, {});
                                        t.mux.log.info("Received event after at least an hour inactivity, creating a new view"), t.emit("viewinit", Object.assign({
                                            viewer_time: n
                                        }, s)), t.playbackHeartbeat._playheadShouldBeProgressing && "play" !== e.type && "adbreakstart" !== e.type && (t.emit("play", {
                                            viewer_time: n
                                        }), "playing" !== e.type && t.emit("playing", {
                                            viewer_time: n
                                        }))
                                    }
                                })
                            }, tf && eH(tc.prototype, tf), tp && eH(tc, tp), Object.defineProperty(tc, "prototype", {
                                writable: !1
                            }), tc);

                            function eB(e) {
                                return (eB = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                                    return typeof e
                                } : function(e) {
                                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                                })(e)
                            }

                            function eF(e, t) {
                                (null == t || t > e.length) && (t = e.length);
                                for (var r = 0, a = Array(t); r < t; r++) a[r] = e[r];
                                return a
                            }

                            function eV(e, t) {
                                for (var r = 0; r < t.length; r++) {
                                    var a = t[r];
                                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
                                }
                            }

                            function eW(e, t) {
                                return (eW = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                                    return e.__proto__ = t, e
                                })(e, t)
                            }

                            function eG(e) {
                                if (void 0 === e) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return e
                            }

                            function eQ(e) {
                                return (eQ = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
                                    return e.__proto__ || Object.getPrototypeOf(e)
                                })(e)
                            }
                            var eJ = ["viewstart", "ended", "loadstart", "pause", "play", "playing", "ratechange", "waiting", "adplay", "adpause", "adended", "aderror", "adplaying", "adrequest", "adresponse", "adbreakstart", "adbreakend", "adfirstquartile", "admidpoint", "adthirdquartile", "rebufferstart", "rebufferend", "seeked", "error", "hb", "requestcompleted", "requestfailed", "requestcanceled", "renditionchange"],
                                eK = function(e) {
                                    ! function(e, t) {
                                        if ("function" != typeof t && null !== t) throw TypeError("Super expression must either be null or a function");
                                        e.prototype = Object.create(t && t.prototype, {
                                            constructor: {
                                                value: e,
                                                writable: !0,
                                                configurable: !0
                                            }
                                        }), Object.defineProperty(e, "prototype", {
                                            writable: !1
                                        }), t && eW(e, t)
                                    }(o, e);
                                    var t, r, a, n = (t = function() {
                                        if ("undefined" == typeof Reflect || !Reflect.construct || Reflect.construct.sham) return !1;
                                        if ("function" == typeof Proxy) return !0;
                                        try {
                                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                                        } catch (e) {
                                            return !1
                                        }
                                    }(), function() {
                                        var e, r = eQ(o);
                                        if (t) {
                                            var a = eQ(this).constructor;
                                            e = Reflect.construct(r, arguments, a)
                                        } else e = r.apply(this, arguments);
                                        return function(e, t) {
                                            if (t && ("object" === eB(t) || "function" == typeof t)) return t;
                                            if (void 0 !== t) throw TypeError("Derived constructors may only return object or undefined");
                                            return eG(e)
                                        }(this, e)
                                    });

                                    function o(e, t, r) {
                                        (function(e, t) {
                                            if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                                        })(this, o), (a = n.call(this)).DOM_CONTENT_LOADED_EVENT_END = m.domContentLoadedEventEnd(), a.NAVIGATION_START = m.navigationStart(), a.mux = e, a.id = t, (r = Object.assign({
                                            debug: !1,
                                            minimumRebufferDuration: 250,
                                            sustainedRebufferThreshold: 1e3,
                                            playbackHeartbeatTime: 25,
                                            beaconDomain: "litix.io",
                                            sampleRate: 1,
                                            disableCookies: !1,
                                            respectDoNotTrack: !1,
                                            disableRebufferTracking: !1,
                                            disablePlayheadRebufferTracking: !1,
                                            errorTranslator: function(e) {
                                                return e
                                            }
                                        }, r)).data = r.data || {}, r.data.property_key && (r.data.env_key = r.data.property_key, delete r.data.property_key), f.setLevel(r.debug ? "debug" : "warn"), a.getPlayheadTime = r.getPlayheadTime, a.getStateData = r.getStateData || function() {
                                            return {}
                                        }, a.getAdData = r.getAdData || function() {}, a.minimumRebufferDuration = r.minimumRebufferDuration, a.sustainedRebufferThreshold = r.sustainedRebufferThreshold, a.playbackHeartbeatTime = r.playbackHeartbeatTime, a.disableRebufferTracking = r.disableRebufferTracking, a.disableRebufferTracking && a.mux.log.warn("Disabling rebuffer tracking. This should only be used in specific circumstances as a last resort when your player is known to unreliably track rebuffering."), a.disablePlayheadRebufferTracking = r.disablePlayheadRebufferTracking, a.errorTranslator = r.errorTranslator, a.playbackEventDispatcher = new eC(e, r.data.env_key, r), a.data = {
                                            player_instance_id: i(),
                                            mux_sample_rate: r.sampleRate,
                                            beacon_domain: r.beaconCollectionDomain ? r.beaconCollectionDomain : r.beaconDomain
                                        }, a.data.view_sequence_number = 1, a.data.player_sequence_number = 1, a.oldEmit = a.emit, a.emit = function(e, t) {
                                            t = Object.assign({
                                                viewer_time: this.mux.utils.now()
                                            }, t), this.oldEmit(e, t)
                                        };
                                        var a, s = (function() {
                                            void 0 === this.data.view_start && (this.data.view_start = this.mux.utils.now(), this.emit("viewstart"))
                                        }).bind(eG(a));
                                        a.on("viewinit", function(e, t) {
                                            this._resetVideoData(), this._resetViewData(), this._resetErrorData(), this._updateStateData(), Object.assign(this.data, t), this._initializeViewData(), this.one("play", s), this.one("adbreakstart", s)
                                        });
                                        var l = (function(e) {
                                            this.emit("viewend"), this.send("viewend"), this.emit("viewinit", e)
                                        }).bind(eG(a));
                                        if (a.on("videochange", function(e, t) {
                                                l(t)
                                            }), a.on("programchange", function(e, t) {
                                                this.data.player_is_paused && this.mux.log.warn("The `programchange` event is intended to be used when the content changes mid playback without the video source changing, however the video is not currently playing. If the video source is changing please use the videochange event otherwise you will lose startup time information."), l(Object.assign(t, {
                                                    view_program_changed: !0
                                                })), s(), this.emit("play"), this.emit("playing")
                                            }), a.on("fragmentchange", function(e, t) {
                                                this.currentFragmentPDT = t.currentFragmentPDT, this.currentFragmentStart = t.currentFragmentStart
                                            }), a.on("destroy", a.destroy), "undefined" != typeof window && "function" == typeof window.addEventListener && "function" == typeof window.removeEventListener) {
                                            var u = function() {
                                                var e = void 0 !== a.data.view_start;
                                                a.mux.WINDOW_HIDDEN = "hidden" === document.visibilityState, e && a.mux.WINDOW_HIDDEN && (a.data.player_is_paused || a.emit("hb"))
                                            };
                                            window.addEventListener("visibilitychange", u, !1);
                                            var d = function(e) {
                                                e.persisted || a.destroy()
                                            };
                                            window.addEventListener("pagehide", d, !1), a.on("destroy", function() {
                                                window.removeEventListener("visibilitychange", u), window.removeEventListener("pagehide", d)
                                            })
                                        }
                                        return a.on("playerready", function(e, t) {
                                            Object.assign(this.data, t)
                                        }), eJ.forEach(function(e) {
                                            a.on(e, function(t, r) {
                                                0 !== e.indexOf("ad") && this._updateStateData(), Object.assign(this.data, r), this._sanitizeData()
                                            }), a.on("after" + e, function() {
                                                ("error" !== e || this.errorTracker.viewErrored) && this.send(e)
                                            })
                                        }), a.on("viewend", function(e, t) {
                                            Object.assign(a.data, t)
                                        }), a.one("playerready", function(e) {
                                            var t = this.mux.utils.now();
                                            this.data.player_init_time && (this.data.player_startup_time = t - this.data.player_init_time), !this.mux.PLAYER_TRACKED && this.NAVIGATION_START && (this.mux.PLAYER_TRACKED = !0, (this.data.player_init_time || this.DOM_CONTENT_LOADED_EVENT_END) && (this.data.page_load_time = Math.min(this.data.player_init_time || 1 / 0, this.DOM_CONTENT_LOADED_EVENT_END || 1 / 0) - this.NAVIGATION_START)), this.send("playerready"), delete this.data.player_startup_time, delete this.data.page_load_time
                                        }), a.longResumeTracker = new eU(eG(a)), a.errorTracker = new N(eG(a)), new eu(eG(a)), a.seekingTracker = new Z(eG(a)), a.playheadTime = new V(eG(a)), a.playbackHeartbeat = new j(eG(a)), new X(eG(a)), a.watchTimeTracker = new H(eG(a)), new B(eG(a)), a.adTracker = new ei(eG(a)), new J(eG(a)), new G(eG(a)), new z(eG(a)), new es(eG(a)), new eM(eG(a)), r.hlsjs && a.addHLSJS(r), r.dashjs && a.addDashJS(r), a.emit("viewinit", r.data), a
                                    }
                                    return r = [{
                                        key: "destroy",
                                        value: function() {
                                            this._destroyed || (this._destroyed = !0, void 0 !== this.data.view_start && (this.emit("viewend"), this.send("viewend")), this.playbackEventDispatcher.destroy(), this.removeHLSJS(), this.removeDashJS(), window.clearTimeout(this._heartBeatTimeout))
                                        }
                                    }, {
                                        key: "send",
                                        value: function(e) {
                                            if (this.data.view_id) {
                                                var t = Object.assign({}, this.data);
                                                if (void 0 === t.video_source_is_live && (t.player_source_duration === 1 / 0 || t.video_source_duration === 1 / 0 ? t.video_source_is_live = !0 : (t.player_source_duration > 0 || t.video_source_duration > 0) && (t.video_source_is_live = !1)), t.video_source_is_live || ["player_program_time", "player_manifest_newest_program_time", "player_live_edge_program_time", "player_program_time", "video_holdback", "video_part_holdback", "video_target_duration", "video_part_target_duration"].forEach(function(e) {
                                                        t[e] = void 0
                                                    }), t.video_source_url = t.video_source_url || t.player_source_url, t.video_source_url) {
                                                    var r, a = function(e) {
                                                            if (Array.isArray(e)) return e
                                                        }(r = h(t.video_source_url)) || function(e, t) {
                                                            var r = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                                            if (null != r) {
                                                                var a, n, i = [],
                                                                    o = !0,
                                                                    s = !1;
                                                                try {
                                                                    for (r = r.call(e); !(o = (a = r.next()).done) && (i.push(a.value), !t || i.length !== t); o = !0);
                                                                } catch (e) {
                                                                    s = !0, n = e
                                                                } finally {
                                                                    try {
                                                                        o || null == r.return || r.return()
                                                                    } finally {
                                                                        if (s) throw n
                                                                    }
                                                                }
                                                                return i
                                                            }
                                                        }(r, 2) || function(e, t) {
                                                            if (e) {
                                                                if ("string" == typeof e) return eF(e, t);
                                                                var r = Object.prototype.toString.call(e).slice(8, -1);
                                                                return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? eF(e, t) : void 0
                                                            }
                                                        }(r, 2) || function() {
                                                            throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                                        }(),
                                                        n = a[0],
                                                        i = a[1];
                                                    t.video_source_domain = i, t.video_source_hostname = n
                                                }
                                                delete t.ad_request_id, this.playbackEventDispatcher.send(e, t), this.data.view_sequence_number++, this.data.player_sequence_number++, this._restartHeartBeat(), "viewend" === e && (this.mux.log.warn("Ending view, any future events will be ignored unless a programchange or videochange occurs."), delete this.data.view_id)
                                            }
                                        }
                                    }, {
                                        key: "_updateStateData",
                                        value: function() {
                                            Object.assign(this.data, this.getStateData()), this.playheadTime._updatePlayheadTime(), this._sanitizeData()
                                        }
                                    }, {
                                        key: "_sanitizeData",
                                        value: function() {
                                            var e = this;
                                            ["player_width", "player_height", "video_source_width", "video_source_height", "player_playhead_time", "video_source_bitrate"].forEach(function(t) {
                                                var r = parseInt(e.data[t], 10);
                                                e.data[t] = isNaN(r) ? void 0 : r
                                            }), ["player_source_url", "video_source_url"].forEach(function(t) {
                                                if (e.data[t]) {
                                                    var r = e.data[t].toLowerCase();
                                                    0 !== r.indexOf("data:") && 0 !== r.indexOf("blob:") || (e.data[t] = "MSE style URL")
                                                }
                                            })
                                        }
                                    }, {
                                        key: "_resetVideoData",
                                        value: function(e, t) {
                                            var r = this;
                                            Object.keys(this.data).forEach(function(e) {
                                                0 === e.indexOf("video_") && delete r.data[e]
                                            })
                                        }
                                    }, {
                                        key: "_resetViewData",
                                        value: function() {
                                            var e = this;
                                            Object.keys(this.data).forEach(function(t) {
                                                0 === t.indexOf("view_") && delete e.data[t]
                                            }), this.data.view_sequence_number = 1
                                        }
                                    }, {
                                        key: "_resetErrorData",
                                        value: function(e, t) {
                                            delete this.data.player_error_code, delete this.data.player_error_message
                                        }
                                    }, {
                                        key: "_initializeViewData",
                                        value: function() {
                                            var e = this,
                                                t = this.data.view_id = i(),
                                                r = function() {
                                                    t === e.data.view_id && y(e.data, "player_view_count", 1)
                                                };
                                            this.data.player_is_paused ? this.one("play", r) : r()
                                        }
                                    }, {
                                        key: "_restartHeartBeat",
                                        value: function() {
                                            var e = this;
                                            window.clearTimeout(this._heartBeatTimeout), this.errorTracker.viewErrored || (this._heartBeatTimeout = window.setTimeout(function() {
                                                e.data.player_is_paused || e.emit("hb")
                                            }, 1e4))
                                        }
                                    }, {
                                        key: "addHLSJS",
                                        value: function(e) {
                                            e.hlsjs ? this.hlsjs ? this.mux.log.warn("An instance of HLS.js is already being monitored for this player.") : (this.hlsjs = e.hlsjs, function(e, t, r) {
                                                var a = arguments.length > 4 ? arguments[4] : void 0,
                                                    n = e.log,
                                                    i = e.utils.secondsToMs,
                                                    o = function(e) {
                                                        var t, r = parseInt(a.version);
                                                        return 1 === r && null !== e.programDateTime && (t = e.programDateTime), 0 === r && null !== e.pdt && (t = e.pdt), t
                                                    };
                                                if (m.exists()) {
                                                    var s = function(r, a) {
                                                            return e.emit(t, r, a)
                                                        },
                                                        l = function(e, t) {
                                                            var r = t.levels,
                                                                a = t.audioTracks,
                                                                n = t.url,
                                                                i = t.stats,
                                                                o = t.networkDetails,
                                                                l = t.sessionData,
                                                                u = {},
                                                                d = {};
                                                            r.forEach(function(e, t) {
                                                                u[t] = {
                                                                    width: e.width,
                                                                    height: e.height,
                                                                    bitrate: e.bitrate,
                                                                    attrs: e.attrs
                                                                }
                                                            }), a.forEach(function(e, t) {
                                                                d[t] = {
                                                                    name: e.name,
                                                                    language: e.lang,
                                                                    bitrate: e.bitrate
                                                                }
                                                            });
                                                            var c = k(i),
                                                                f = c.bytesLoaded,
                                                                p = c.requestStart,
                                                                _ = c.responseStart,
                                                                h = c.responseEnd;
                                                            s("requestcompleted", T(T({}, w(l)), {}, {
                                                                request_event_type: e,
                                                                request_bytes_loaded: f,
                                                                request_start: p,
                                                                request_response_start: _,
                                                                request_response_end: h,
                                                                request_type: "manifest",
                                                                request_hostname: v(n),
                                                                request_response_headers: O(o),
                                                                request_rendition_lists: {
                                                                    media: u,
                                                                    audio: d,
                                                                    video: {}
                                                                }
                                                            }))
                                                        };
                                                    r.on(a.Events.MANIFEST_LOADED, l);
                                                    var u = function(e, t) {
                                                        var r = t.details,
                                                            a = t.level,
                                                            n = t.networkDetails,
                                                            l = k(t.stats),
                                                            u = l.bytesLoaded,
                                                            d = l.requestStart,
                                                            c = l.responseStart,
                                                            f = l.responseEnd,
                                                            p = r.fragments[r.fragments.length - 1],
                                                            _ = o(p) + i(p.duration);
                                                        s("requestcompleted", {
                                                            request_event_type: e,
                                                            request_bytes_loaded: u,
                                                            request_start: d,
                                                            request_response_start: c,
                                                            request_response_end: f,
                                                            request_current_level: a,
                                                            request_type: "manifest",
                                                            request_hostname: v(r.url),
                                                            request_response_headers: O(n),
                                                            video_holdback: r.holdBack && i(r.holdBack),
                                                            video_part_holdback: r.partHoldBack && i(r.partHoldBack),
                                                            video_part_target_duration: r.partTarget && i(r.partTarget),
                                                            video_target_duration: r.targetduration && i(r.targetduration),
                                                            video_source_is_live: r.live,
                                                            player_manifest_newest_program_time: isNaN(_) ? void 0 : _
                                                        })
                                                    };
                                                    r.on(a.Events.LEVEL_LOADED, u);
                                                    var d = function(e, t) {
                                                        var r = t.details,
                                                            a = t.networkDetails,
                                                            n = k(t.stats);
                                                        s("requestcompleted", {
                                                            request_event_type: e,
                                                            request_bytes_loaded: n.bytesLoaded,
                                                            request_start: n.requestStart,
                                                            request_response_start: n.responseStart,
                                                            request_response_end: n.responseEnd,
                                                            request_type: "manifest",
                                                            request_hostname: v(r.url),
                                                            request_response_headers: O(a)
                                                        })
                                                    };
                                                    r.on(a.Events.AUDIO_TRACK_LOADED, d);
                                                    var c = function(e, t) {
                                                        var a = t.stats,
                                                            n = t.networkDetails,
                                                            i = t.frag,
                                                            o = k(a = a || i.stats),
                                                            l = o.bytesLoaded,
                                                            u = o.requestStart,
                                                            d = o.responseStart,
                                                            c = o.responseEnd,
                                                            f = O(n),
                                                            p = null == f ? void 0 : f["x-request-id"],
                                                            _ = {
                                                                request_event_type: e,
                                                                request_bytes_loaded: l,
                                                                request_start: u,
                                                                request_response_start: d,
                                                                request_response_end: c,
                                                                request_hostname: n ? v(n.responseURL) : void 0,
                                                                request_id: p,
                                                                request_response_headers: f,
                                                                request_media_duration: i.duration,
                                                                request_url: null == n ? void 0 : n.responseURL
                                                            };
                                                        "main" === i.type ? (_.request_type = "media", _.request_current_level = i.level, _.request_video_width = (r.levels[i.level] || {}).width, _.request_video_height = (r.levels[i.level] || {}).height, _.request_labeled_bitrate = (r.levels[i.level] || {}).bitrate) : _.request_type = i.type, s("requestcompleted", _)
                                                    };
                                                    r.on(a.Events.FRAG_LOADED, c);
                                                    var f = function(e, t) {
                                                        var r = t.frag,
                                                            a = r.start;
                                                        s("fragmentchange", {
                                                            currentFragmentPDT: o(r),
                                                            currentFragmentStart: i(a)
                                                        })
                                                    };
                                                    r.on(a.Events.FRAG_CHANGED, f);
                                                    var p = function(e, t) {
                                                        var r, n = t.type,
                                                            i = t.details,
                                                            o = t.response,
                                                            l = t.fatal,
                                                            u = t.frag,
                                                            d = (null == u ? void 0 : u.url) || t.url || "";
                                                        i !== a.ErrorDetails.MANIFEST_LOAD_ERROR && i !== a.ErrorDetails.MANIFEST_LOAD_TIMEOUT && i !== a.ErrorDetails.FRAG_LOAD_ERROR && i !== a.ErrorDetails.FRAG_LOAD_TIMEOUT && i !== a.ErrorDetails.LEVEL_LOAD_ERROR && i !== a.ErrorDetails.LEVEL_LOAD_TIMEOUT && i !== a.ErrorDetails.AUDIO_TRACK_LOAD_ERROR && i !== a.ErrorDetails.AUDIO_TRACK_LOAD_TIMEOUT && i !== a.ErrorDetails.SUBTITLE_LOAD_ERROR && i !== a.ErrorDetails.SUBTITLE_LOAD_TIMEOUT && i !== a.ErrorDetails.KEY_LOAD_ERROR && i !== a.ErrorDetails.KEY_LOAD_TIMEOUT || s("requestfailed", {
                                                            request_error: i,
                                                            request_url: d,
                                                            request_hostname: v(d),
                                                            request_type: i === a.ErrorDetails.FRAG_LOAD_ERROR || i === a.ErrorDetails.FRAG_LOAD_TIMEOUT ? "media" : i === a.ErrorDetails.AUDIO_TRACK_LOAD_ERROR || i === a.ErrorDetails.AUDIO_TRACK_LOAD_TIMEOUT ? "audio" : i === a.ErrorDetails.SUBTITLE_LOAD_ERROR || i === a.ErrorDetails.SUBTITLE_LOAD_TIMEOUT ? "subtitle" : i === a.ErrorDetails.KEY_LOAD_ERROR || i === a.ErrorDetails.KEY_LOAD_TIMEOUT ? "encryption" : "manifest",
                                                            request_error_code: null == o ? void 0 : o.code,
                                                            request_error_text: null == o ? void 0 : o.text
                                                        }), l && s("error", {
                                                            player_error_code: n,
                                                            player_error_message: i,
                                                            player_error_context: "".concat(d ? "url: ".concat(d, "\n") : "") + "".concat(o && (o.code || o.text) ? "response: ".concat(o.code, ", ").concat(o.text, "\n") : "") + "".concat(t.reason ? "failure reason: ".concat(t.reason, "\n") : "") + "".concat(t.level ? "level: ".concat(t.level, "\n") : "") + "".concat(t.parent ? "parent stream controller: ".concat(t.parent, "\n") : "") + "".concat(t.buffer ? "buffer length: ".concat(t.buffer, "\n") : "") + "".concat(t.error ? "error: ".concat(t.error, "\n") : "") + "".concat(t.event ? "event: ".concat(t.event, "\n") : "") + "".concat(t.err ? "error message: ".concat(null === (r = t.err) || void 0 === r ? void 0 : r.message, "\n") : "")
                                                        })
                                                    };
                                                    r.on(a.Events.ERROR, p);
                                                    var _ = function(e, t) {
                                                        var r = t.frag,
                                                            a = r && r._url || "";
                                                        s("requestcanceled", {
                                                            request_event_type: e,
                                                            request_url: a,
                                                            request_type: "media",
                                                            request_hostname: v(a)
                                                        })
                                                    };
                                                    r.on(a.Events.FRAG_LOAD_EMERGENCY_ABORTED, _);
                                                    var h = function(e, t) {
                                                        var a = t.level,
                                                            i = r.levels[a];
                                                        if (i && i.attrs && i.attrs.BANDWIDTH) {
                                                            var o, l = i.attrs.BANDWIDTH,
                                                                u = parseFloat(i.attrs["FRAME-RATE"]);
                                                            isNaN(u) || (o = u), l ? s("renditionchange", {
                                                                video_source_fps: o,
                                                                video_source_bitrate: l,
                                                                video_source_width: i.width,
                                                                video_source_height: i.height,
                                                                video_source_rendition_name: i.name,
                                                                video_source_codec: null == i ? void 0 : i.videoCodec
                                                            }) : n.warn("missing BANDWIDTH from HLS manifest parsed by HLS.js")
                                                        }
                                                    };
                                                    r.on(a.Events.LEVEL_SWITCHED, h), r._stopMuxMonitor = function() {
                                                        r.off(a.Events.MANIFEST_LOADED, l), r.off(a.Events.LEVEL_LOADED, u), r.off(a.Events.AUDIO_TRACK_LOADED, d), r.off(a.Events.FRAG_LOADED, c), r.off(a.Events.FRAG_CHANGED, f), r.off(a.Events.ERROR, p), r.off(a.Events.FRAG_LOAD_EMERGENCY_ABORTED, _), r.off(a.Events.LEVEL_SWITCHED, h), r.off(a.Events.DESTROYING, r._stopMuxMonitor), delete r._stopMuxMonitor
                                                    }, r.on(a.Events.DESTROYING, r._stopMuxMonitor)
                                                } else n.warn("performance timing not supported. Not tracking HLS.js.")
                                            }(this.mux, this.id, e.hlsjs, {}, e.Hls || window.Hls)) : this.mux.log.warn("You must pass a valid hlsjs instance in order to track it.")
                                        }
                                    }, {
                                        key: "removeHLSJS",
                                        value: function() {
                                            var e;
                                            this.hlsjs && ((e = this.hlsjs) && "function" == typeof e._stopMuxMonitor && e._stopMuxMonitor(), this.hlsjs = void 0)
                                        }
                                    }, {
                                        key: "addDashJS",
                                        value: function(e) {
                                            e.dashjs ? this.dashjs ? this.mux.log.warn("An instance of Dash.js is already being monitored for this player.") : (this.dashjs = e.dashjs, function(e, t, r) {
                                                var a = e.log;
                                                if (r && r.on) {
                                                    var n = function(r, a) {
                                                            return e.emit(t, r, a)
                                                        },
                                                        i = function(e) {
                                                            var t = e.type,
                                                                r = (e.data || {}).url;
                                                            n("requestcompleted", {
                                                                request_event_type: t,
                                                                request_start: 0,
                                                                request_response_start: 0,
                                                                request_response_end: 0,
                                                                request_bytes_loaded: -1,
                                                                request_type: "manifest",
                                                                request_hostname: v(r),
                                                                request_url: r
                                                            })
                                                        };
                                                    r.on("manifestLoaded", i);
                                                    var o = {},
                                                        s = function(e) {
                                                            var t = e.type,
                                                                a = e.fragmentModel,
                                                                i = (e.chunk || {}).mediaInfo || {},
                                                                s = i.type,
                                                                l = i.bitrateList,
                                                                u = {};
                                                            (l = l || []).forEach(function(e, t) {
                                                                u[t] = {}, u[t].width = e.width, u[t].height = e.height, u[t].bitrate = e.bandwidth, u[t].attrs = {}
                                                            }), "video" === s ? o.video = u : "audio" === s ? o.audio = u : o.media = u;
                                                            var d = R(a, r),
                                                                c = d.requestStart,
                                                                f = d.requestResponseStart,
                                                                p = d.requestResponseEnd,
                                                                _ = d.requestResponseHeaders,
                                                                v = d.requestMediaDuration;
                                                            n("requestcompleted", {
                                                                request_event_type: t,
                                                                request_start: c,
                                                                request_response_start: f,
                                                                request_response_end: p,
                                                                request_bytes_loaded: -1,
                                                                request_type: s + "_init",
                                                                request_response_headers: _,
                                                                request_hostname: d.requestHostname,
                                                                request_url: d.requestUrl,
                                                                request_media_duration: v,
                                                                request_rendition_lists: o
                                                            })
                                                        };
                                                    r.on("initFragmentLoaded", s);
                                                    var l = function(e) {
                                                        var t = e.type,
                                                            a = e.fragmentModel,
                                                            i = e.chunk || {},
                                                            o = i.mediaInfo,
                                                            s = i.start,
                                                            l = (o || {}).type,
                                                            u = R(a, r),
                                                            d = u.requestStart,
                                                            c = u.requestResponseStart,
                                                            f = u.requestResponseEnd,
                                                            p = u.requestBytesLoaded,
                                                            _ = u.requestResponseHeaders,
                                                            v = u.requestMediaDuration,
                                                            h = u.requestHostname,
                                                            m = u.requestUrl,
                                                            y = A(l, r),
                                                            b = y.currentLevel,
                                                            g = y.renditionWidth,
                                                            w = y.renditionHeight,
                                                            E = y.renditionBitrate;
                                                        n("requestcompleted", {
                                                            request_event_type: t,
                                                            request_start: d,
                                                            request_response_start: c,
                                                            request_response_end: f,
                                                            request_bytes_loaded: p,
                                                            request_type: l,
                                                            request_response_headers: _,
                                                            request_hostname: h,
                                                            request_url: m,
                                                            request_media_start_time: s,
                                                            request_media_duration: v,
                                                            request_current_level: b,
                                                            request_labeled_bitrate: E,
                                                            request_video_width: g,
                                                            request_video_height: w
                                                        })
                                                    };
                                                    r.on("mediaFragmentLoaded", l);
                                                    var u = {
                                                            video: void 0,
                                                            audio: void 0,
                                                            totalBitrate: void 0
                                                        },
                                                        d = function() {
                                                            if (u.video && "number" == typeof u.video.bitrate) {
                                                                if (u.video.width && u.video.height) {
                                                                    var e = u.video.bitrate;
                                                                    return u.audio && "number" == typeof u.audio.bitrate && (e += u.audio.bitrate), e !== u.totalBitrate ? (u.totalBitrate = e, {
                                                                        video_source_bitrate: e,
                                                                        video_source_height: u.video.height,
                                                                        video_source_width: u.video.width,
                                                                        video_source_codec: S(u.video.codec)
                                                                    }) : void 0
                                                                }
                                                                a.warn("have bitrate info for video but missing width/height")
                                                            }
                                                        },
                                                        c = function(e, t, i) {
                                                            if ("number" == typeof e.newQuality) {
                                                                var o = e.mediaType;
                                                                if ("audio" === o || "video" === o) {
                                                                    var s = r.getBitrateInfoListFor(o).find(function(t) {
                                                                        return t.qualityIndex === e.newQuality
                                                                    });
                                                                    if (s && "number" == typeof s.bitrate) {
                                                                        u[o] = x(x({}, s), {}, {
                                                                            codec: r.getCurrentTrackFor(o).codec
                                                                        });
                                                                        var l = d();
                                                                        l && n("renditionchange", l)
                                                                    } else a.warn("missing bitrate info for ".concat(o))
                                                                }
                                                            } else a.warn("missing evt.newQuality in qualityChangeRendered event", e)
                                                        };
                                                    r.on("qualityChangeRendered", c);
                                                    var f = function(e) {
                                                        var t = e.request,
                                                            r = e.mediaType;
                                                        n("requestcanceled", {
                                                            request_event_type: (t = t || {}).type + "_" + t.action,
                                                            request_url: t.url,
                                                            request_type: r,
                                                            request_hostname: v(t.url)
                                                        })
                                                    };
                                                    r.on("fragmentLoadingAbandoned", f);
                                                    var p = function(e) {
                                                        var t, r, a = e.error,
                                                            i = (null == a || null === (t = a.data) || void 0 === t ? void 0 : t.request) || {},
                                                            o = (null == a || null === (r = a.data) || void 0 === r ? void 0 : r.response) || {};
                                                        27 === (null == a ? void 0 : a.code) && n("requestfailed", {
                                                            request_error: i.type + "_" + i.action,
                                                            request_url: i.url,
                                                            request_hostname: v(i.url),
                                                            request_type: i.mediaType,
                                                            request_error_code: o.status,
                                                            request_error_text: o.statusText
                                                        });
                                                        var s = "".concat(null != i && i.url ? "url: ".concat(i.url, "\n") : "") + "".concat(null != o && o.status || null != o && o.statusText ? "response: ".concat(null == o ? void 0 : o.status, ", ").concat(null == o ? void 0 : o.statusText, "\n") : "");
                                                        n("error", {
                                                            player_error_code: null == a ? void 0 : a.code,
                                                            player_error_message: null == a ? void 0 : a.message,
                                                            player_error_context: s
                                                        })
                                                    };
                                                    r.on("error", p), r._stopMuxMonitor = function() {
                                                        r.off("manifestLoaded", i), r.off("initFragmentLoaded", s), r.off("mediaFragmentLoaded", l), r.off("qualityChangeRendered", c), r.off("error", p), r.off("fragmentLoadingAbandoned", f), delete r._stopMuxMonitor
                                                    }
                                                } else a.warn("Invalid dash.js player reference. Monitoring blocked.")
                                            }(this.mux, this.id, e.dashjs)) : this.mux.log.warn("You must pass a valid dashjs instance in order to track it.")
                                        }
                                    }, {
                                        key: "removeDashJS",
                                        value: function() {
                                            var e;
                                            this.dashjs && ((e = this.dashjs) && "function" == typeof e._stopMuxMonitor && e._stopMuxMonitor(), this.dashjs = void 0)
                                        }
                                    }], eV(o.prototype, r), a && eV(o, a), Object.defineProperty(o, "prototype", {
                                        writable: !1
                                    }), o
                                }(L),
                                ez = r(153),
                                eY = r.n(ez);

                            function eX(e) {
                                return (eX = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                                    return typeof e
                                } : function(e) {
                                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                                })(e)
                            }

                            function e$(e, t) {
                                return function(e) {
                                    if (Array.isArray(e)) return e
                                }(e) || function(e, t) {
                                    var r = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                    if (null != r) {
                                        var a, n, i = [],
                                            o = !0,
                                            s = !1;
                                        try {
                                            for (r = r.call(e); !(o = (a = r.next()).done) && (i.push(a.value), !t || i.length !== t); o = !0);
                                        } catch (e) {
                                            s = !0, n = e
                                        } finally {
                                            try {
                                                o || null == r.return || r.return()
                                            } finally {
                                                if (s) throw n
                                            }
                                        }
                                        return i
                                    }
                                }(e, t) || function(e, t) {
                                    if (e) {
                                        if ("string" == typeof e) return eZ(e, t);
                                        var r = Object.prototype.toString.call(e).slice(8, -1);
                                        return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? eZ(e, t) : void 0
                                    }
                                }(e, t) || function() {
                                    throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                }()
                            }

                            function eZ(e, t) {
                                (null == t || t > e.length) && (t = e.length);
                                for (var r = 0, a = Array(t); r < t; r++) a[r] = e[r];
                                return a
                            }
                            var e0, e1, e2, e3, e5, e8, e4, e6, e7, e9, te, tt, tr, ta, tn, ti, to, ts, tl, tu, td, tc, tf, tp, t_, tv = ["loadstart", "pause", "play", "playing", "seeking", "seeked", "timeupdate", "ratechange", "stalled", "waiting", "error", "ended"],
                                th = {
                                    1: "MEDIA_ERR_ABORTED",
                                    2: "MEDIA_ERR_NETWORK",
                                    3: "MEDIA_ERR_DECODE",
                                    4: "MEDIA_ERR_SRC_NOT_SUPPORTED"
                                };
                            n() && n().WeakMap && (t_ = new WeakMap);
                            var tm = function(e) {
                                return this.buffer = "", this.manifest = {
                                    segments: [],
                                    serverControl: {},
                                    sessionData: {}
                                }, this.currentUri = {}, this.process(e), this.manifest
                            };
                            tm.prototype.process = function(e) {
                                var t;
                                for (this.buffer += e, t = this.buffer.indexOf("\n"); t > -1; t = this.buffer.indexOf("\n")) this.processLine(this.buffer.substring(0, t)), this.buffer = this.buffer.substring(t + 1)
                            }, tm.prototype.processLine = function(e) {
                                var t = e.indexOf(":"),
                                    r = tk(e, t),
                                    a = r[0],
                                    n = 2 === r.length ? tg(r[1]) : void 0;
                                if ("#" !== a[0]) this.currentUri.uri = a, this.manifest.segments.push(this.currentUri), !this.manifest.targetDuration || "duration" in this.currentUri || (this.currentUri.duration = this.manifest.targetDuration), this.currentUri = {};
                                else switch (a) {
                                    case "#EXT-X-TARGETDURATION":
                                        if (!isFinite(n) || n < 0) return;
                                        this.manifest.targetDuration = n, this.setHoldBack();
                                        break;
                                    case "#EXT-X-PART-INF":
                                        ty(this.manifest, r), this.manifest.partInf.partTarget && (this.manifest.partTargetDuration = this.manifest.partInf.partTarget), this.setHoldBack();
                                        break;
                                    case "#EXT-X-SERVER-CONTROL":
                                        ty(this.manifest, r), this.setHoldBack();
                                        break;
                                    case "#EXTINF":
                                        0 === n ? this.currentUri.duration = .01 : n > 0 && (this.currentUri.duration = n);
                                        break;
                                    case "#EXT-X-PROGRAM-DATE-TIME":
                                        var i = new Date(n);
                                        this.manifest.dateTimeString || (this.manifest.dateTimeString = n, this.manifest.dateTimeObject = i), this.currentUri.dateTimeString = n, this.currentUri.dateTimeObject = i;
                                        break;
                                    case "#EXT-X-VERSION":
                                        ty(this.manifest, r);
                                        break;
                                    case "#EXT-X-SESSION-DATA":
                                        var o = w(tO(r[1]));
                                        Object.assign(this.manifest.sessionData, o)
                                }
                            }, tm.prototype.setHoldBack = function() {
                                var e = this.manifest,
                                    t = e.serverControl,
                                    r = e.targetDuration,
                                    a = e.partTargetDuration;
                                if (t) {
                                    var n = "holdBack",
                                        i = "partHoldBack",
                                        o = r && 3 * r,
                                        s = a && 2 * a;
                                    r && !t.hasOwnProperty(n) && (t[n] = o), o && t[n] < o && (t[n] = o), a && !t.hasOwnProperty(i) && (t[i] = 3 * a), a && t[i] < s && (t[i] = s)
                                }
                            };
                            var ty = function(e, t) {
                                    var r, a = tb(t[0].replace("#EXT-X-", ""));
                                    tT(t[1]) ? (r = {}, r = Object.assign(tE(t[1]), r)) : r = tg(t[1]), e[a] = r
                                },
                                tb = function(e) {
                                    return e.toLowerCase().replace(/-(\w)/g, function(e) {
                                        return e[1].toUpperCase()
                                    })
                                },
                                tg = function(e) {
                                    if ("yes" === e.toLowerCase() || "no" === e.toLowerCase()) return "yes" === e.toLowerCase();
                                    var t = -1 !== e.indexOf(":") ? e : parseFloat(e);
                                    return isNaN(t) ? e : t
                                },
                                tw = function(e) {
                                    var t = {},
                                        r = e.split("=");
                                    return r.length > 1 && (t[tb(r[0])] = tg(r[1])), t
                                },
                                tE = function(e) {
                                    for (var t = e.split(","), r = {}, a = 0; t.length > a; a++) r = Object.assign(tw(t[a]), r);
                                    return r
                                },
                                tT = function(e) {
                                    return e.indexOf("=") > -1
                                },
                                tk = function(e, t) {
                                    return -1 === t ? [e] : [e.substring(0, t), e.substring(t + 1)]
                                },
                                tO = function(e) {
                                    var t = {};
                                    if (e) {
                                        var r = e.search(",");
                                        return [e.slice(0, r), e.slice(r + 1)].forEach(function(e, r) {
                                            for (var a = e.replace(/['"]+/g, "").split("="), n = 0; n < a.length; n++) "DATA-ID" === a[n] && (t["DATA-ID"] = a[1 - n]), "VALUE" === a[n] && (t.VALUE = a[1 - n])
                                        }), {
                                            data: t
                                        }
                                    }
                                },
                                tD = {
                                    safeCall: function(e, t, r, a) {
                                        var n = a;
                                        if (e && "function" == typeof e[t]) try {
                                            n = e[t].apply(e, r)
                                        } catch (e) {
                                            f.info("safeCall error", e)
                                        }
                                        return n
                                    },
                                    safeIncrement: y,
                                    getComputedStyle: function(e, t) {
                                        var r;
                                        if (e && t && n() && "function" == typeof n().getComputedStyle) return t_ && t_.has(e) && (r = t_.get(e)), r || (r = n().getComputedStyle(e, null), t_ && t_.set(e, r)), r.getPropertyValue(t)
                                    },
                                    secondsToMs: function(e) {
                                        return Math.floor(1e3 * e)
                                    },
                                    assign: Object.assign,
                                    headersStringToObject: g,
                                    extractHostnameAndDomain: h,
                                    extractHostname: v,
                                    manifestParser: tm,
                                    generateShortID: o,
                                    generateUUID: i,
                                    now: _.now
                                };

                            function tx(e, t) {
                                (null == t || t > e.length) && (t = e.length);
                                for (var r = 0, a = Array(t); r < t; r++) a[r] = e[r];
                                return a
                            }
                            var tR = {},
                                tA = function e(t) {
                                    var r = arguments;
                                    "string" == typeof t ? e.hasOwnProperty(t) ? n().setTimeout(function() {
                                        r = Array.prototype.splice.call(r, 1), e[t].apply(null, r)
                                    }, 0) : f.warn("`" + t + "` is an unknown task") : "function" == typeof t ? n().setTimeout(function() {
                                        t(e)
                                    }, 0) : f.warn("`" + t + "` is invalid.")
                                },
                                tS = {
                                    loaded: _.now(),
                                    NAME: "mux-embed",
                                    VERSION: "4.22.0",
                                    API_VERSION: "2.1",
                                    PLAYER_TRACKED: !1,
                                    monitor: function(e, t) {
                                        return function(e, t, r) {
                                            var a = e$(l(t), 3),
                                                n = a[0],
                                                i = a[1],
                                                o = a[2],
                                                s = e.log,
                                                u = e.utils.getComputedStyle,
                                                d = e.utils.secondsToMs;
                                            if (!n) return s.error("No element was found with the `" + i + "` query selector.");
                                            if ("video" !== o && "audio" !== o) return s.error("The element of `" + i + "` was not a media element.");
                                            n.mux && (n.mux.destroy(), delete n.mux, s.warn("Already monitoring this video element, replacing existing event listeners")), (r = Object.assign({
                                                automaticErrorTracking: !0
                                            }, r)).data = Object.assign({
                                                player_software: "HTML5 Video Element",
                                                player_mux_plugin_name: "VideoElementMonitor",
                                                player_mux_plugin_version: e.VERSION
                                            }, r.data), r.getPlayheadTime = function() {
                                                return d(n.currentTime)
                                            }, r.getStateData = function() {
                                                var e, t, a = this.hlsjs && this.hlsjs.url,
                                                    i = this.dashjs && eX("function" === this.dashjs.getSource) && this.dashjs.getSource(),
                                                    o = {
                                                        player_is_paused: n.paused,
                                                        player_playhead_time: d(n.currentTime),
                                                        player_width: parseInt(u(n, "width")),
                                                        player_height: parseInt(u(n, "height")),
                                                        player_autoplay_on: n.autoplay,
                                                        player_preload_on: n.preload,
                                                        player_language_code: n.lang,
                                                        player_is_fullscreen: eY() && !!(eY().fullscreenElement || eY().webkitFullscreenElement || eY().mozFullScreenElement || eY().msFullscreenElement),
                                                        video_poster_url: n.poster,
                                                        video_source_url: a || i || n.currentSrc,
                                                        video_source_duration: d(n.duration),
                                                        video_source_height: n.videoHeight,
                                                        video_source_width: n.videoWidth,
                                                        view_dropped_frame_count: null === (e = n) || void 0 === e || null === (t = e.getVideoPlaybackQuality) || void 0 === t ? void 0 : t.call(e).droppedVideoFrames
                                                    },
                                                    s = r.getPlayheadTime();
                                                if (n.getStartDate && s > 0) {
                                                    var l = n.getStartDate();
                                                    if (l && "function" == typeof l.getTime && l.getTime()) {
                                                        var c = l.getTime();
                                                        if (o.player_program_time = c + s, n.seekable.length > 0) {
                                                            var f = c + n.seekable.end(n.seekable.length - 1);
                                                            o.player_live_edge_program_time = f
                                                        }
                                                    }
                                                }
                                                return o
                                            }, n.mux = n.mux || {}, n.mux.deleted = !1, n.mux.emit = function(t, r) {
                                                e.emit(i, t, r)
                                            };
                                            var c = function() {
                                                s.error("The monitor for this video element has already been destroyed.")
                                            };
                                            n.mux.destroy = function() {
                                                Object.keys(n.mux.listeners).forEach(function(e) {
                                                    n.removeEventListener(e, n.mux.listeners[e], !1)
                                                }), delete n.mux.listeners, n.mux.destroy = c, n.mux.swapElement = c, n.mux.emit = c, n.mux.addHLSJS = c, n.mux.addDashJS = c, n.mux.removeHLSJS = c, n.mux.removeDashJS = c, n.mux.deleted = !0, e.emit(i, "destroy")
                                            }, n.mux.swapElement = function(t) {
                                                var r = e$(l(t), 3),
                                                    a = r[0],
                                                    i = r[1],
                                                    o = r[2];
                                                return a ? "video" !== o && "audio" !== o ? e.log.error("The element of `" + i + "` was not a media element.") : (a.muxId = n.muxId, delete n.muxId, a.mux = a.mux || {}, a.mux.listeners = Object.assign({}, n.mux.listeners), delete n.mux.listeners, Object.keys(a.mux.listeners).forEach(function(e) {
                                                    n.removeEventListener(e, a.mux.listeners[e], !1), a.addEventListener(e, a.mux.listeners[e], !1)
                                                }), a.mux.swapElement = n.mux.swapElement, a.mux.destroy = n.mux.destroy, delete n.mux, void(n = a)) : e.log.error("No element was found with the `" + i + "` query selector.")
                                            }, n.mux.addHLSJS = function(t) {
                                                e.addHLSJS(i, t)
                                            }, n.mux.addDashJS = function(t) {
                                                e.addDashJS(i, t)
                                            }, n.mux.removeHLSJS = function() {
                                                e.removeHLSJS(i)
                                            }, n.mux.removeDashJS = function() {
                                                e.removeDashJS(i)
                                            }, e.init(i, r), e.emit(i, "playerready"), n.paused || (e.emit(i, "play"), n.readyState > 2 && e.emit(i, "playing")), n.mux.listeners = {}, tv.forEach(function(t) {
                                                ("error" !== t || r.automaticErrorTracking) && (n.mux.listeners[t] = function() {
                                                    var r = {};
                                                    if ("error" === t) {
                                                        if (!n.error || 1 === n.error.code) return;
                                                        r.player_error_code = n.error.code, r.player_error_message = th[n.error.code] || n.error.message
                                                    }
                                                    e.emit(i, t, r)
                                                }, n.addEventListener(t, n.mux.listeners[t], !1))
                                            })
                                        }(tA, e, t)
                                    },
                                    destroyMonitor: function(e) {
                                        var t, r = (function(e) {
                                            if (Array.isArray(e)) return e
                                        }(t = l(e)) || function(e, t) {
                                            var r = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                                            if (null != r) {
                                                var a, n, i = [],
                                                    o = !0,
                                                    s = !1;
                                                try {
                                                    for (r = r.call(e); !(o = (a = r.next()).done) && (i.push(a.value), !t || i.length !== t); o = !0);
                                                } catch (e) {
                                                    s = !0, n = e
                                                } finally {
                                                    try {
                                                        o || null == r.return || r.return()
                                                    } finally {
                                                        if (s) throw n
                                                    }
                                                }
                                                return i
                                            }
                                        }(t, 1) || function(e, t) {
                                            if (e) {
                                                if ("string" == typeof e) return tx(e, t);
                                                var r = Object.prototype.toString.call(e).slice(8, -1);
                                                return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? tx(e, t) : void 0
                                            }
                                        }(t, 1) || function() {
                                            throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                                        }())[0];
                                        r && r.mux && "function" == typeof r.mux.destroy ? r.mux.destroy() : f.error("A video element monitor for `" + e + "` has not been initialized via `mux.monitor`.")
                                    },
                                    addHLSJS: function(e, t) {
                                        var r = s(e);
                                        tR[r] ? tR[r].addHLSJS(t) : f.error("A monitor for `" + r + "` has not been initialized.")
                                    },
                                    addDashJS: function(e, t) {
                                        var r = s(e);
                                        tR[r] ? tR[r].addDashJS(t) : f.error("A monitor for `" + r + "` has not been initialized.")
                                    },
                                    removeHLSJS: function(e) {
                                        var t = s(e);
                                        tR[t] ? tR[t].removeHLSJS() : f.error("A monitor for `" + t + "` has not been initialized.")
                                    },
                                    removeDashJS: function(e) {
                                        var t = s(e);
                                        tR[t] ? tR[t].removeDashJS() : f.error("A monitor for `" + t + "` has not been initialized.")
                                    },
                                    init: function(e, t) {
                                        p() && t && t.respectDoNotTrack && f.info("The browser's Do Not Track flag is enabled - Mux beaconing is disabled.");
                                        var r = s(e);
                                        tR[r] = new eK(tA, r, t)
                                    },
                                    emit: function(e, t, r) {
                                        var a = s(e);
                                        tR[a] ? (tR[a].emit(t, r), "destroy" === t && delete tR[a]) : f.error("A monitor for `" + a + "` has not been initialized.")
                                    },
                                    checkDoNotTrack: p,
                                    log: f,
                                    utils: tD,
                                    events: {
                                        PLAYER_READY: "playerready",
                                        VIEW_INIT: "viewinit",
                                        VIDEO_CHANGE: "videochange",
                                        PLAY: "play",
                                        PAUSE: "pause",
                                        PLAYING: "playing",
                                        TIME_UPDATE: "timeupdate",
                                        SEEKING: "seeking",
                                        SEEKED: "seeked",
                                        REBUFFER_START: "rebufferstart",
                                        REBUFFER_END: "rebufferend",
                                        ERROR: "error",
                                        ENDED: "ended",
                                        RENDITION_CHANGE: "renditionchange",
                                        ORIENTATION_CHANGE: "orientationchange",
                                        AD_REQUEST: "adrequest",
                                        AD_RESPONSE: "adresponse",
                                        AD_BREAK_START: "adbreakstart",
                                        AD_PLAY: "adplay",
                                        AD_PLAYING: "adplaying",
                                        AD_PAUSE: "adpause",
                                        AD_FIRST_QUARTILE: "adfirstquartile",
                                        AD_MID_POINT: "admidpoint",
                                        AD_THIRD_QUARTILE: "adthirdquartile",
                                        AD_ENDED: "adended",
                                        AD_BREAK_END: "adbreakend",
                                        AD_ERROR: "aderror",
                                        REQUEST_COMPLETED: "requestcompleted",
                                        REQUEST_FAILED: "requestfailed",
                                        REQUEST_CANCELLED: "requestcanceled"
                                    },
                                    WINDOW_HIDDEN: !1,
                                    WINDOW_UNLOADING: !1
                                };
                            Object.assign(tA, tS), void 0 !== n() && "function" == typeof n().addEventListener && n().addEventListener("pagehide", function(e) {
                                e.persisted || (tA.WINDOW_UNLOADING = !0)
                            }, !1);
                            var tP = tA
                        },
                        655: function(e, t, r) {
                            var a;

                            function n(e) {
                                return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                                    return typeof e
                                } : function(e) {
                                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                                })(e);
                                /*!
                                 * JavaScript Cookie v2.1.3
                                 * https://github.com/js-cookie/js-cookie
                                 *
                                 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
                                 * Released under the MIT license
                                 */
                            }! function(i) {
                                var o = !1;
                                if (void 0 === (a = "function" == typeof i ? i.call(t, r, t, e) : i) || (e.exports = a), o = !0, "object" === n(t) && (e.exports = i(), o = !0), !o) {
                                    var s = window.Cookies,
                                        l = window.Cookies = i();
                                    l.noConflict = function() {
                                        return window.Cookies = s, l
                                    }
                                }
                            }(function() {
                                var e = function() {
                                    for (var e = 0, t = {}; e < arguments.length; e++) {
                                        var r = arguments[e];
                                        for (var a in r) t[a] = r[a]
                                    }
                                    return t
                                };
                                return function t(r) {
                                    function a(t, n, i) {
                                        var o;
                                        if ("undefined" != typeof document) {
                                            if (arguments.length > 1) {
                                                if ("number" == typeof(i = e({
                                                        path: "/"
                                                    }, a.defaults, i)).expires) {
                                                    var s = new Date;
                                                    s.setMilliseconds(s.getMilliseconds() + 864e5 * i.expires), i.expires = s
                                                }
                                                try {
                                                    o = JSON.stringify(n), /^[\{\[]/.test(o) && (n = o)
                                                } catch (e) {}
                                                return n = r.write ? r.write(n, t) : encodeURIComponent(String(n)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent), t = (t = (t = encodeURIComponent(String(t))).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent)).replace(/[\(\)]/g, escape), document.cookie = [t, "=", n, i.expires ? "; expires=" + i.expires.toUTCString() : "", i.path ? "; path=" + i.path : "", i.domain ? "; domain=" + i.domain : "", i.secure ? "; secure" : ""].join("")
                                            }
                                            t || (o = {});
                                            for (var l = document.cookie ? document.cookie.split("; ") : [], u = /(%[0-9A-Z]{2})+/g, d = 0; d < l.length; d++) {
                                                var c = l[d].split("="),
                                                    f = c.slice(1).join("=");
                                                '"' === f.charAt(0) && (f = f.slice(1, -1));
                                                try {
                                                    var p = c[0].replace(u, decodeURIComponent);
                                                    if (f = r.read ? r.read(f, p) : r(f, p) || f.replace(u, decodeURIComponent), this.json) try {
                                                        f = JSON.parse(f)
                                                    } catch (e) {}
                                                    if (t === p) {
                                                        o = f;
                                                        break
                                                    }
                                                    t || (o[p] = f)
                                                } catch (e) {}
                                            }
                                            return o
                                        }
                                    }
                                    return a.set = a, a.get = function(e) {
                                        return a.call(a, e)
                                    }, a.getJSON = function() {
                                        return a.apply({
                                            json: !0
                                        }, [].slice.call(arguments))
                                    }, a.defaults = {}, a.remove = function(t, r) {
                                        a(t, "", e(r, {
                                            expires: -1
                                        }))
                                    }, a.withConverter = t, a
                                }(function() {})
                            })
                        },
                        153: function(e, t, r) {
                            var a, n = void 0 !== r.g ? r.g : "undefined" != typeof window ? window : {},
                                i = r(558);
                            "undefined" != typeof document ? a = document : (a = n["__GLOBAL_DOCUMENT_CACHE@4"]) || (a = n["__GLOBAL_DOCUMENT_CACHE@4"] = i), e.exports = a
                        },
                        48: function(e, t, r) {
                            var a;
                            a = "undefined" != typeof window ? window : void 0 !== r.g ? r.g : "undefined" != typeof self ? self : {}, e.exports = a
                        },
                        640: function(e, t, r) {
                            var a, n;
                            void 0 === (n = "function" == typeof(a = function() {
                                var e = function() {},
                                    t = "undefined",
                                    r = typeof window !== t && typeof window.navigator !== t && /Trident\/|MSIE /.test(window.navigator.userAgent),
                                    a = ["trace", "debug", "info", "warn", "error"];

                                function n(e, t) {
                                    var r = e[t];
                                    if ("function" == typeof r.bind) return r.bind(e);
                                    try {
                                        return Function.prototype.bind.call(r, e)
                                    } catch (t) {
                                        return function() {
                                            return Function.prototype.apply.apply(r, [e, arguments])
                                        }
                                    }
                                }

                                function i() {
                                    console.log && (console.log.apply ? console.log.apply(console, arguments) : Function.prototype.apply.apply(console.log, [console, arguments])), console.trace && console.trace()
                                }

                                function o(t, r) {
                                    for (var n = 0; n < a.length; n++) {
                                        var i = a[n];
                                        this[i] = n < t ? e : this.methodFactory(i, t, r)
                                    }
                                    this.log = this.debug
                                }

                                function s(e, r, a) {
                                    return function() {
                                        typeof console !== t && (o.call(this, r, a), this[e].apply(this, arguments))
                                    }
                                }

                                function l(a, o, l) {
                                    var u;
                                    return "debug" === (u = a) && (u = "log"), typeof console !== t && ("trace" === u && r ? i : void 0 !== console[u] ? n(console, u) : void 0 !== console.log ? n(console, "log") : e) || s.apply(this, arguments)
                                }

                                function u(e, r, n) {
                                    var i, s = this;
                                    r = null == r ? "WARN" : r;
                                    var u = "loglevel";

                                    function d() {
                                        var e;
                                        if (typeof window !== t && u) {
                                            try {
                                                e = window.localStorage[u]
                                            } catch (e) {}
                                            if (typeof e === t) try {
                                                var r = window.document.cookie,
                                                    a = r.indexOf(encodeURIComponent(u) + "="); - 1 !== a && (e = /^([^;]+)/.exec(r.slice(a))[1])
                                            } catch (e) {}
                                            return void 0 === s.levels[e] && (e = void 0), e
                                        }
                                    }
                                    "string" == typeof e ? u += ":" + e : "symbol" == typeof e && (u = void 0), s.name = e, s.levels = {
                                        TRACE: 0,
                                        DEBUG: 1,
                                        INFO: 2,
                                        WARN: 3,
                                        ERROR: 4,
                                        SILENT: 5
                                    }, s.methodFactory = n || l, s.getLevel = function() {
                                        return i
                                    }, s.setLevel = function(r, n) {
                                        if ("string" == typeof r && void 0 !== s.levels[r.toUpperCase()] && (r = s.levels[r.toUpperCase()]), !("number" == typeof r && r >= 0 && r <= s.levels.SILENT)) throw "log.setLevel() called with invalid level: " + r;
                                        if (i = r, !1 !== n && function(e) {
                                                var r = (a[e] || "silent").toUpperCase();
                                                if (typeof window !== t && u) {
                                                    try {
                                                        return void(window.localStorage[u] = r)
                                                    } catch (e) {}
                                                    try {
                                                        window.document.cookie = encodeURIComponent(u) + "=" + r + ";"
                                                    } catch (e) {}
                                                }
                                            }(r), o.call(s, r, e), typeof console === t && r < s.levels.SILENT) return "No console available for logging"
                                    }, s.setDefaultLevel = function(e) {
                                        r = e, d() || s.setLevel(e, !1)
                                    }, s.resetLevel = function() {
                                        s.setLevel(r, !1),
                                            function() {
                                                if (typeof window !== t && u) {
                                                    try {
                                                        return void window.localStorage.removeItem(u)
                                                    } catch (e) {}
                                                    try {
                                                        window.document.cookie = encodeURIComponent(u) + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC"
                                                    } catch (e) {}
                                                }
                                            }()
                                    }, s.enableAll = function(e) {
                                        s.setLevel(s.levels.TRACE, e)
                                    }, s.disableAll = function(e) {
                                        s.setLevel(s.levels.SILENT, e)
                                    };
                                    var c = d();
                                    null == c && (c = r), s.setLevel(c, !1)
                                }
                                var d = new u,
                                    c = {};
                                d.getLogger = function(e) {
                                    if ("symbol" != typeof e && "string" != typeof e || "" === e) throw TypeError("You must supply a name when creating a logger.");
                                    var t = c[e];
                                    return t || (t = c[e] = new u(e, d.getLevel(), d.methodFactory)), t
                                };
                                var f = typeof window !== t ? window.log : void 0;
                                return d.noConflict = function() {
                                    return typeof window !== t && window.log === d && (window.log = f), d
                                }, d.getLoggers = function() {
                                    return c
                                }, d.default = d, d
                            }) ? a.call(t, r, t, e) : a) || (e.exports = n)
                        },
                        375: function(e, t) {
                            "use strict";
                            var r = Object.prototype.hasOwnProperty;

                            function a(e) {
                                try {
                                    return decodeURIComponent(e.replace(/\+/g, " "))
                                } catch (e) {
                                    return null
                                }
                            }

                            function n(e) {
                                try {
                                    return encodeURIComponent(e)
                                } catch (e) {
                                    return null
                                }
                            }
                            t.stringify = function(e, t) {
                                var a, i, o = [];
                                for (i in "string" != typeof(t = t || "") && (t = "?"), e)
                                    if (r.call(e, i)) {
                                        if ((a = e[i]) || null != a && !isNaN(a) || (a = ""), i = n(i), a = n(a), null === i || null === a) continue;
                                        o.push(i + "=" + a)
                                    }
                                return o.length ? t + o.join("&") : ""
                            }, t.parse = function(e) {
                                for (var t, r = /([^=?#&]+)=?([^&]*)/g, n = {}; t = r.exec(e);) {
                                    var i = a(t[1]),
                                        o = a(t[2]);
                                    null === i || null === o || i in n || (n[i] = o)
                                }
                                return n
                            }
                        },
                        558: function() {}
                    },
                    t = {};

                function r(a) {
                    var n = t[a];
                    if (void 0 !== n) return n.exports;
                    var i = t[a] = {
                        exports: {}
                    };
                    return e[a].call(i.exports, i, i.exports, r), i.exports
                }
                return r.n = function(e) {
                    var t = e && e.__esModule ? function() {
                        return e.default
                    } : function() {
                        return e
                    };
                    return r.d(t, {
                        a: t
                    }), t
                }, r.d = function(e, t) {
                    for (var a in t) r.o(t, a) && !r.o(e, a) && Object.defineProperty(e, a, {
                        enumerable: !0,
                        get: t[a]
                    })
                }, r.g = function() {
                    if ("object" == typeof globalThis) return globalThis;
                    try {
                        return this || Function("return this")()
                    } catch (e) {
                        if ("object" == typeof window) return window
                    }
                }(), r.o = function(e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t)
                }, r(80)
            }()
        },
        14574: function(e, t, r) {
            "use strict";
            r.d(t, {
                Z: function() {
                    return es
                }
            });
            var a = r(2784),
                n = r(13980),
                i = r(57615),
                o = r(4238),
                s = class extends Error {
                    constructor(e, t = s.MEDIA_ERR_CUSTOM, r) {
                        var a;
                        super(e), this.name = "MediaError", this.code = t, this.fatal = null != r ? r : t >= s.MEDIA_ERR_NETWORK && t <= s.MEDIA_ERR_ENCRYPTED, this.message || (this.message = null != (a = s.defaultMessages[this.code]) ? a : "")
                    }
                },
                l = s;
            l.MEDIA_ERR_ABORTED = 1, l.MEDIA_ERR_NETWORK = 2, l.MEDIA_ERR_DECODE = 3, l.MEDIA_ERR_SRC_NOT_SUPPORTED = 4, l.MEDIA_ERR_ENCRYPTED = 5, l.MEDIA_ERR_CUSTOM = 100, l.defaultMessages = {
                1: "You aborted the media playback",
                2: "A network error caused the media download to fail.",
                3: "A media error caused playback to be aborted. The media could be corrupt or your browser does not support this format.",
                4: "An unsupported error occurred. The server or network failed, or your browser does not support this format.",
                5: "The media is encrypted and there are no keys to decrypt it."
            };
            var u = e => null == e,
                d = (e, t) => !u(t) && e in t,
                c = {
                    ANY: "any",
                    MUTED: "muted"
                },
                f = {
                    VOD: "on-demand",
                    ON_DEMAND: "on-demand",
                    LIVE: "live",
                    LL_LIVE: "ll-live",
                    DVR: "live:dvr",
                    LL_DVR: "ll-live:dvr"
                },
                p = {
                    MSE: "mse",
                    NATIVE: "native"
                },
                _ = {
                    HEADER: "header",
                    QUERY: "query",
                    NONE: "none"
                },
                v = (Object.values(_), {
                    M3U8: "application/vnd.apple.mpegurl",
                    MP4: "video/mp4"
                }),
                h = {
                    HLS: v.M3U8
                },
                m = (Object.keys(h), [...Object.values(v), "hls", "HLS"]),
                y = (e, t, r, a, n = e) => {
                    n.addEventListener(t, r, a), e.addEventListener("teardown", () => {
                        n.removeEventListener(t, r)
                    }, {
                        once: !0
                    })
                },
                b = e => {
                    let t = e.indexOf("?");
                    return t < 0 ? [e] : [e.slice(0, t), e.slice(t)]
                },
                g = e => {
                    let t = e.type;
                    if (t) {
                        let e = t.toUpperCase();
                        return d(e, h) ? h[e] : t
                    }
                    let {
                        src: r
                    } = e;
                    return r ? w(r) : ""
                },
                w = e => {
                    let t = "";
                    try {
                        t = new URL(e).pathname
                    } catch {
                        console.error("invalid url")
                    }
                    let r = t.lastIndexOf(".");
                    if (r < 0) return "";
                    let a = t.slice(r + 1).toUpperCase();
                    return d(a, v) ? v[a] : ""
                },
                E = Object.values(c),
                T = e => "boolean" == typeof e || "string" == typeof e && E.includes(e),
                k = ({
                    autoplay: e
                }, t, r) => {
                    let a = !1,
                        n = !1,
                        i = T(e) ? e : !!e,
                        s = () => {
                            a || y(t, "playing", () => {
                                a = !0
                            }, {
                                once: !0
                            })
                        };
                    if (s(), y(t, "loadstart", () => {
                            a = !1, s(), O(t, i)
                        }, {
                            once: !0
                        }), y(t, "loadstart", () => {
                            r || (n = !Number.isFinite(t.duration)), O(t, i)
                        }, {
                            once: !0
                        }), r && r.once(o.Events.LEVEL_LOADED, (e, t) => {
                            var r;
                            n = null != (r = t.details.live) && r
                        }), !i) {
                        let e = () => {
                            !n || (null != r && r.liveSyncPosition ? t.currentTime = r.liveSyncPosition : Number.isFinite(t.seekable.end(0)) && (t.currentTime = t.seekable.end(0)))
                        };
                        r && y(t, "play", () => {
                            "metadata" === t.preload ? r.once(o.Events.LEVEL_UPDATED, e) : e()
                        }, {
                            once: !0
                        })
                    }
                    return e => {
                        a || O(t, i = T(e) ? e : !!e)
                    }
                },
                O = (e, t) => {
                    if (!t) return;
                    let r = e.muted,
                        a = () => e.muted = r;
                    switch (t) {
                        case c.ANY:
                            e.play().catch(() => {
                                e.muted = !0, e.play().catch(a)
                            });
                            break;
                        case c.MUTED:
                            e.muted = !0, e.play().catch(a);
                            break;
                        default:
                            e.play().catch(() => {})
                    }
                },
                D = ({
                    preload: e,
                    src: t
                }, r, a) => {
                    let n = e => {
                        null != e && ["", "none", "metadata", "auto"].includes(e) ? r.setAttribute("preload", e) : r.removeAttribute("preload")
                    };
                    if (!a) return n(e), n;
                    let i = !1,
                        o = !1,
                        s = a.config.maxBufferLength,
                        l = a.config.maxBufferSize,
                        u = e => {
                            n(e);
                            let t = null != e ? e : r.preload;
                            o || "none" === t || ("metadata" === t ? (a.config.maxBufferLength = 1, a.config.maxBufferSize = 1) : (a.config.maxBufferLength = s, a.config.maxBufferSize = l), d())
                        },
                        d = () => {
                            !i && t && (i = !0, a.loadSource(t))
                        };
                    return y(r, "play", () => {
                        o = !0, a.config.maxBufferLength = s, a.config.maxBufferSize = l, d()
                    }, {
                        once: !0
                    }), u(e), u
                };

            function x(e, t, r, a, n) {
                let i = document.createElement("track");
                return i.kind = t, i.label = r, a && (i.srclang = a), n && (i.id = n), i.track.mode = ["subtitles", "captions"].includes(t) ? "disabled" : "hidden", i.setAttribute("data-removeondestroy", ""), e.append(i), i.track
            }
            var R = "cuepoints",
                A = Object.freeze({
                    label: R
                }),
                S = (e, {
                    label: t = R
                } = A) => {
                    var r;
                    return null == (r = Array.from(e.querySelectorAll("track")).find(e => e.track.label === t && "metadata" === e.track.kind)) ? void 0 : r.track
                };
            async function P(e, t, r = A) {
                let a = S(e, r);
                if (!a) {
                    let {
                        label: t = R
                    } = r;
                    (a = x(e, "metadata", t)).mode = "hidden", await new Promise(e => setTimeout(() => e(void 0), 0))
                }
                return "hidden" !== a.mode && (a.mode = "hidden"), [...t].sort(({
                    time: e
                }, {
                    time: t
                }) => t - e).forEach(({
                    time: t,
                    value: r
                }) => {
                    var n, i;
                    let o = Array.prototype.findIndex.call(null == a ? void 0 : a.cues, e => e.startTime >= t),
                        s = null == (n = null == a ? void 0 : a.cues) ? void 0 : n[o],
                        l = s ? s.startTime : Number.isFinite(e.duration) ? e.duration : Number.MAX_SAFE_INTEGER,
                        u = null == (i = null == a ? void 0 : a.cues) ? void 0 : i[o - 1];
                    u && (u.endTime = t);
                    let d = new VTTCue(t, l, JSON.stringify(null != r ? r : null));
                    a.addCue(d)
                }), a
            }
            var q = e => ({
                time: e.startTime,
                value: JSON.parse(e.text)
            });
            async function L(e, t = A) {
                return new Promise(r => {
                    y(e, "loadstart", async () => {
                        let a = await P(e, [], t);
                        y(e, "cuechange", () => {
                            let t = function(e, t = {
                                label: R
                            }) {
                                var r;
                                let a = S(e, t);
                                if (null != (r = null == a ? void 0 : a.activeCues) && r.length) return q(a.activeCues[0])
                            }(e);
                            if (t) {
                                let r = new CustomEvent("cuepointchange", {
                                    composed: !0,
                                    bubbles: !0,
                                    detail: t
                                });
                                e.dispatchEvent(r)
                            }
                        }, {}, a), r(a)
                    })
                })
            }
            var I, j, C, N = -1 !== (null != (j = null == (I = null == globalThis ? void 0 : globalThis.navigator) ? void 0 : I.userAgent) ? j : "").toLowerCase().indexOf("android"),
                M = new WeakMap,
                H = "mux.com",
                U = null == (C = o.isSupported) ? void 0 : C.call(o),
                B = () => i.utils.now(),
                F = i.utils.generateUUID,
                V = (e, {
                    domain: t = H,
                    maxResolution: r = ""
                } = {}) => {
                    if (!e) return;
                    let [a, n = ""] = b(e), i = new URL(`https://stream.${t}/${a}.m3u8${n}`);
                    return r && i.searchParams.set("max_resolution", r), i.toString()
                },
                W = e => {
                    if (!e) return;
                    let [t] = e.split("?");
                    return t || void 0
                },
                G = e => {
                    if (!e || !e.startsWith("https://stream.")) return;
                    let [t] = new URL(e).pathname.slice(1).split(".m3u8");
                    return t || void 0
                },
                Q = e => {
                    var t, r, a;
                    return null != (t = null == e ? void 0 : e.metadata) && t.video_id ? e.metadata.video_id : $(e) && null != (a = null != (r = W(e.playbackId)) ? r : G(e.src)) ? a : e.src
                },
                J = (e, t, r) => {
                    K(t, r);
                    let {
                        metadata: a = {}
                    } = e, {
                        view_session_id: n = F()
                    } = a, i = Q(e);
                    a.view_session_id = n, a.video_id = i, e.metadata = a, M.set(t, {});
                    let o = Y(e, t);
                    Z(e, t, o), ee(e, t, o), L(t);
                    let s = k(e, t, o),
                        l = D(e, t, o);
                    return {
                        engine: o,
                        setAutoplay: s,
                        setPreload: l
                    }
                },
                K = (e, t) => {
                    let r = null == t ? void 0 : t.engine;
                    r && (r.detachMedia(), r.destroy()), (null == e ? void 0 : e.mux) && !e.mux.deleted && (e.mux.destroy(), delete e.mux), e && (e.removeAttribute("src"), e.load(), e.removeEventListener("error", er), e.removeEventListener("error", ea), e.removeEventListener("durationchange", et), M.delete(e), e.dispatchEvent(new Event("teardown")))
                };

            function z(e, t) {
                var r;
                let a = g(e);
                if (a !== v.M3U8) return !0;
                let n = !a || null == (r = t.canPlayType(a)) || r,
                    {
                        preferPlayback: i
                    } = e,
                    o = i === p.MSE,
                    s = i === p.NATIVE;
                return n && (s || !(U && (o || N)))
            }
            var Y = (e, t) => {
                    let {
                        debug: r,
                        streamType: a,
                        startTime: n = -1,
                        metadata: i,
                        preferCmcd: s
                    } = e, l = g(e) === v.M3U8, u = z(e, t);
                    if (l && !u && U) {
                        let e = X(a),
                            t = s !== _.NONE ? {
                                useHeaders: s === _.HEADER,
                                sessionId: i.view_session_id,
                                contentId: i.video_id
                            } : void 0;
                        return new o({
                            debug: r,
                            startPosition: n,
                            cmcd: t,
                            backBufferLength: 30,
                            renderTextTracksNatively: !1,
                            liveDurationInfinity: !0,
                            ...e
                        })
                    }
                },
                X = e => [f.LIVE, f.DVR].includes(e) ? {
                    backBufferLength: 8
                } : [f.LL_LIVE, f.LL_DVR].includes(e) ? {
                    backBufferLength: 4,
                    maxFragLookUpTolerance: .001
                } : {},
                $ = ({
                    playbackId: e,
                    src: t,
                    customDomain: r
                }) => {
                    if (e) return !0;
                    if ("string" != typeof t) return !1;
                    let a = null == window ? void 0 : window.location.href,
                        n = new URL(t, a).hostname.toLocaleLowerCase();
                    return n.includes(H) || !!r && n.includes(r.toLocaleLowerCase())
                },
                Z = (e, t, r) => {
                    var a;
                    let {
                        envKey: n
                    } = e, s = $(e);
                    if (n || s) {
                        let {
                            playerInitTime: s,
                            playerSoftwareName: l,
                            playerSoftwareVersion: u,
                            beaconCollectionDomain: d,
                            debug: c,
                            disableCookies: f
                        } = e, p = { ...e.metadata,
                            video_title: (null == (a = null == e ? void 0 : e.metadata) ? void 0 : a.video_title) || void 0
                        }, _ = t => "string" != typeof t.player_error_code && ("function" == typeof e.errorTranslator ? e.errorTranslator(t) : t);
                        i.monitor(t, {
                            debug: c,
                            beaconCollectionDomain: d,
                            hlsjs: r,
                            Hls: r ? o : void 0,
                            automaticErrorTracking: !1,
                            errorTranslator: _,
                            disableCookies: f,
                            data: { ...n ? {
                                    env_key: n
                                } : {},
                                player_software_name: l,
                                player_software: l,
                                player_software_version: u,
                                player_init_time: s,
                                ...p
                            }
                        })
                    }
                },
                ee = (e, t, r) => {
                    var a;
                    let n = z(e, t),
                        {
                            src: i
                        } = e;
                    t && n ? ("string" == typeof i ? (t.setAttribute("src", i), e.startTime && ((null != (a = M.get(t)) ? a : {}).startTime = e.startTime, t.addEventListener("durationchange", et, {
                        once: !0
                    }))) : t.removeAttribute("src"), t.addEventListener("error", er), t.addEventListener("error", ea), t.addEventListener("emptied", () => {
                        t.querySelectorAll("track[data-removeondestroy]").forEach(e => {
                            e.remove()
                        })
                    }, {
                        once: !0
                    })) : r && i ? (r.on(o.Events.ERROR, (e, r) => {
                        let a = {
                                [o.ErrorTypes.NETWORK_ERROR]: l.MEDIA_ERR_NETWORK,
                                [o.ErrorTypes.MEDIA_ERROR]: l.MEDIA_ERR_DECODE
                            },
                            n = new l("", a[r.type]);
                        n.fatal = r.fatal, n.data = r, t.dispatchEvent(new CustomEvent("error", {
                            detail: n
                        }))
                    }), t.addEventListener("error", ea), function(e, t) {
                        t.on(o.Events.NON_NATIVE_TEXT_TRACKS_FOUND, (r, {
                            tracks: a
                        }) => {
                            a.forEach(r => {
                                var a;
                                let n = null != (a = r.subtitleTrack) ? a : r.closedCaptions,
                                    i = t.subtitleTracks.findIndex(({
                                        lang: e,
                                        name: t,
                                        type: a
                                    }) => e == (null == n ? void 0 : n.lang) && t === r.label && a.toLowerCase() === r.kind);
                                x(e, r.kind, r.label, null == n ? void 0 : n.lang, `${r.kind}${i}`)
                            })
                        });
                        let r = () => {
                            var r;
                            if (!t.subtitleTracks.length) return;
                            let a = Array.from(e.textTracks).find(e => e.id && "showing" === e.mode && ["subtitles", "captions"].includes(e.kind)),
                                n = `${null==(r=t.subtitleTracks[t.subtitleTrack])?void 0:r.type.toLowerCase()}${t.subtitleTrack}`;
                            if (a && (t.subtitleTrack < 0 || (null == a ? void 0 : a.id) !== n)) {
                                let e = t.subtitleTracks.findIndex(({
                                    lang: e,
                                    name: t,
                                    type: r
                                }) => e == a.language && t === a.label && r.toLowerCase() === a.kind);
                                t.subtitleTrack = e
                            }
                            a && (null == a ? void 0 : a.id) === n && a.cues && Array.from(a.cues).forEach(e => {
                                a.addCue(e)
                            })
                        };
                        e.textTracks.addEventListener("change", r), t.on(o.Events.CUES_PARSED, (t, {
                            track: r,
                            cues: a
                        }) => {
                            let n = e.textTracks.getTrackById(r);
                            if (!n) return;
                            let i = "disabled" === n.mode;
                            i && (n.mode = "hidden"), a.forEach(e => {
                                var t;
                                null != (t = n.cues) && t.getCueById(e.id) || n.addCue(e)
                            }), i && (n.mode = "disabled")
                        }), t.once(o.Events.DESTROYING, () => {
                            e.textTracks.removeEventListener("change", r), e.querySelectorAll("track[data-removeondestroy]").forEach(e => {
                                e.remove()
                            })
                        });
                        let a = () => {
                            Array.from(e.textTracks).forEach(t => {
                                var r, a;
                                if (!["subtitles", "caption"].includes(t.kind) && "thumbnails" === t.label) {
                                    if (!(null != (r = t.cues) && r.length)) {
                                        let t = e.querySelector('track[label="thumbnails"]'),
                                            r = null != (a = null == t ? void 0 : t.getAttribute("src")) ? a : "";
                                        null == t || t.removeAttribute("src"), setTimeout(() => {
                                            null == t || t.setAttribute("src", r)
                                        }, 0)
                                    }
                                    "hidden" !== t.mode && (t.mode = "hidden")
                                }
                            })
                        };
                        t.once(o.Events.MANIFEST_LOADED, a), t.once(o.Events.MEDIA_ATTACHED, a)
                    }(t, r), r.attachMedia(t)) : console.error("It looks like the video you're trying to play will not work on this system! If possible, try upgrading to the newest versions of your browser or software.")
                };

            function et(e) {
                var t;
                let r = e.target,
                    a = null == (t = M.get(r)) ? void 0 : t.startTime;
                if (a && function(e, t, r) {
                        t && r > t && (r = t);
                        for (let t = 0; t < e.length; t++)
                            if (e.start(t) <= r && e.end(t) >= r) return !0;
                        return !1
                    }(r.seekable, r.duration, a)) {
                    let e = "auto" === r.preload;
                    e && (r.preload = "none"), r.currentTime = a, e && (r.preload = "auto")
                }
            }
            async function er(e) {
                if (!e.isTrusted) return;
                e.stopImmediatePropagation();
                let t = e.target;
                if (!(null != t && t.error)) return;
                let {
                    message: r,
                    code: a
                } = t.error, n = new l(r, a);
                if (t.src && (a !== l.MEDIA_ERR_DECODE || void 0 !== a)) try {
                    let {
                        status: e
                    } = await fetch(t.src);
                    n.data = {
                        response: {
                            code: e
                        }
                    }
                } catch {}
                t.dispatchEvent(new CustomEvent("error", {
                    detail: n
                }))
            }

            function ea(e) {
                var t, r;
                if (!(e instanceof CustomEvent) || !(e.detail instanceof l)) return;
                let a = e.target,
                    n = e.detail;
                n && n.fatal && ((null != (t = M.get(a)) ? t : {}).error = n, null == (r = a.mux) || r.emit("error", {
                    player_error_code: n.code,
                    player_error_message: n.message
                }))
            }
            var en = (...e) => {
                    let t = (0, a.useRef)(null);
                    return (0, a.useEffect)(() => {
                        e.forEach(e => {
                            e && ("function" == typeof e ? e(t.current) : e.current = t.current)
                        })
                    }, [e]), t
                },
                ei = (() => {
                    try {
                        return "0.7.7"
                    } catch {}
                    return "UNKNOWN"
                })(),
                eo = a.forwardRef((e, t) => {
                    var r;
                    let {
                        playbackId: n,
                        src: i,
                        children: o,
                        autoPlay: s,
                        preload: l,
                        ...u
                    } = e, [d] = (0, a.useState)(B()), [c, f] = (0, a.useState)(null != (r = V(n)) ? r : i), p = (0, a.useRef)(void 0), _ = en((0, a.useRef)(null), t);
                    return (0, a.useEffect)(() => {
                        var e;
                        f(null != (e = V(n)) ? e : i)
                    }, [i, n]), (0, a.useEffect)(() => {
                        let t = { ...e,
                                src: c,
                                playerInitTime: d,
                                playerSoftwareName: "mux-video-react",
                                playerSoftwareVersion: ei,
                                autoplay: s
                            },
                            r = _.current;
                        return r && (p.current = J(t, r, p.current)), () => {
                            K(r, p.current), r = void 0, p.current = void 0
                        }
                    }, [c]), (0, a.useEffect)(() => {
                        var e;
                        null == (e = p.current) || e.setAutoplay(s)
                    }, [s]), (0, a.useEffect)(() => {
                        var e;
                        null == (e = p.current) || e.setPreload(l)
                    }, [l]), a.createElement("video", {
                        ref: _,
                        ...u
                    }, o)
                });
            eo.propTypes = {
                envKey: n.string,
                debug: n.bool,
                disableCookies: n.bool,
                metadata: n.any,
                beaconCollectionDomain: n.string,
                playbackId: n.string,
                playerInitTime: n.number,
                preferPlayback: n.oneOf(Object.values(p)),
                type: n.oneOf(m),
                streamType: n.oneOf(Object.values(f)),
                startTime: n.number
            };
            var es = eo
        }
    }
]);