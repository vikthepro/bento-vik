(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [739], {
        37596: function(t, e, i) {
            "use strict";
            i.d(e, {
                o: function() {
                    return l
                }
            });
            var n = i(52322),
                o = i(6185),
                r = i.n(o),
                s = i(6277),
                a = i(2784),
                d = i(1547);
            let l = t => {
                let {
                    href: e,
                    color: i
                } = t, [o, l] = (0, a.useState)(null), [c, u] = (0, a.useState)(!1), [h, p] = (0, a.useState)(!1), f = (255 - (0, d.Z)(i).getBrightness()) / 255, m = r()(.73, .19, .85, .4)(f), g = {
                    hover: i ? (0, d.Z)("#000").setAlpha(.03 + .3 * m).toRgbString() : "rgba(0, 0, 0, 0.08)",
                    active: i ? (0, d.Z)("#000").setAlpha(.1 + .4 * m).toRgbString() : "rgba(0, 0, 0, 0.12)"
                };
                return (0, a.useEffect)(() => {
                    if (o) {
                        let t = o.closest(".bento-grid__item:not(.bento-grid__item--editable)[data-id]");
                        if (t) {
                            let e = () => p(!0),
                                i = () => p(!1),
                                n = () => u(!0),
                                o = () => u(!1);
                            return t.addEventListener("mousedown", n), t.ownerDocument.addEventListener("mouseup", o), t.ownerDocument.addEventListener("dragend", o), document.addEventListener("mouseup", o), document.addEventListener("dragend", o), t.addEventListener("mouseenter", e), t.addEventListener("mouseleave", i), () => {
                                t.removeEventListener("mousedown", n), t.ownerDocument.removeEventListener("mouseup", o), t.ownerDocument.removeEventListener("dragend", o), document.removeEventListener("mouseup", o), document.removeEventListener("dragend", o), t.removeEventListener("mouseenter", e), t.removeEventListener("mouseleave", i)
                            }
                        }
                    }
                }, [o]), (0, n.jsxs)("div", {
                    ref: l,
                    className: "pointer-events-none absolute inset-0 rounded-[inherit] p-[14px]",
                    children: [(0, n.jsx)("div", {
                        className: (0, s.Z)("absolute inset-0 rounded-[inherit] transition-colors duration-150 ease-in-out"),
                        style: {
                            background: c ? g.active : h ? g.hover : void 0
                        }
                    }), (0, n.jsx)("div", {
                        className: (0, s.Z)("pointer-events-none absolute top-[12px] right-[12px] rounded-full border-[2px] backdrop-blur-[8px] transition-all duration-150 ease-in-out s-[26px]", !h && "border-white/[0.20]", h && "border-white/[0.40]")
                    }), (0, n.jsx)("div", {
                        className: "absolute top-[14px] right-[14px] flex items-center justify-center rounded-full bg-black/20 backdrop-blur-[8px] s-[22px]",
                        children: (0, n.jsx)("svg", {
                            width: "10",
                            height: "10",
                            viewBox: "0 0 10 10",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: (0, n.jsx)("path", {
                                d: "M3.25403 1.46875C2.83987 1.46875 2.5041 1.80446 2.50403 2.21862C2.50396 2.63289 2.83977 2.96875 3.25403 2.96875H5.94325L1.47358 7.43842C1.18068 7.73131 1.18068 8.20619 1.47358 8.49908C1.76647 8.79197 2.24134 8.79197 2.53424 8.49908L7.00299 4.03033L7.00314 6.71982C7.00316 7.13345 7.34024 7.46875 7.75387 7.46875C8.16752 7.46875 8.50108 7.13342 8.50108 6.71978V2.21875C8.50108 1.80454 8.16529 1.46875 7.75108 1.46875H3.25403Z",
                                fill: "white"
                            })
                        })
                    }, e)]
                })
            }
        },
        50106: function(t, e, i) {
            "use strict";
            i.d(e, {
                OF: function() {
                    return c
                },
                _e: function() {
                    return u
                },
                jj: function() {
                    return h
                },
                oV: function() {
                    return l
                }
            });
            var n = i(91334),
                o = i(47312),
                r = i(84090),
                s = i(18559),
                a = i(66563),
                d = i(2784);

            function l(t) {
                let [, e] = (0, n.U)(), i = (0, d.useCallback)(i => {
                    e({
                        type: "set-bento-item-partial",
                        bento: {
                            id: t.id,
                            caption: i
                        }
                    }), a.f.setCaption(t.id, (0, s.V)(i, (0, o.K)()))
                }, [t, e]);
                return i
            }

            function c(t) {
                let [, e] = (0, n.U)(), i = (0, d.useCallback)(() => {
                    e({
                        type: "set-bento-item-partial",
                        bento: {
                            id: t.id,
                            crop: void 0
                        }
                    })
                }, [t, e]), o = (0, d.useCallback)(i => {
                    e({
                        type: "set-bento-item-partial",
                        bento: {
                            id: t.id,
                            url: i,
                            crop: void 0
                        }
                    })
                }, [t, e]);
                return {
                    urlPreCommit: i,
                    urlCommit: o
                }
            }

            function u(t) {
                var e, i;
                let n = (0, r.$)();
                return null !== (i = null === (e = t.crop) || void 0 === e ? void 0 : e[n]) && void 0 !== i ? i : {
                    offsetX: 0,
                    offsetY: 0
                }
            }

            function h(t) {
                let [, e] = (0, n.U)(), i = (0, r.$)(), o = (0, d.useCallback)((n, o) => {
                    e({
                        type: "set-bento-item-partial",
                        bento: {
                            id: t.id,
                            crop: { ...t.crop,
                                [i]: {
                                    offsetX: n,
                                    offsetY: o
                                }
                            }
                        }
                    })
                }, [t, e, i]);
                return o
            }
        },
        65213: function(t, e, i) {
            "use strict";
            let n;
            i.d(e, {
                DM: function() {
                    return M
                },
                p8: function() {
                    return P
                },
                iJ: function() {
                    return T
                }
            });
            var o = i(52322),
                r = i(91334),
                s = i(2784),
                a = i(71842),
                d = i(13361),
                l = i(45195),
                c = i.n(l),
                u = i(6277),
                h = i(24920),
                p = i(84090),
                f = i(51630),
                m = i(1547),
                g = i(37067),
                v = i(18559),
                y = i(18509),
                w = i(34364);
            let x = () => (n || (n = "performance" in window ? performance.now.bind(performance) : Date.now), n());

            function b(t, e, i) {
                let n = i || {};
                return new Promise(i => (function(t, e, i) {
                    let n, o, r, s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 800,
                        a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : t => 1 + --t * t * t * t * t,
                        d = arguments.length > 5 ? arguments[5] : void 0,
                        l = arguments.length > 6 ? arguments[6] : void 0,
                        c = arguments.length > 7 ? arguments[7] : void 0,
                        u = arguments.length > 8 ? arguments[8] : void 0;
                    n = t.scrollLeft, o = t.scrollTop, r = (e, i) => {
                            t.scrollLeft = Math.ceil(e), t.scrollTop = Math.ceil(i)
                        },
                        function t(e) {
                            let i = x(),
                                n = Math.min((i - e.startTime) / e.duration, 1),
                                o = e.ease(n),
                                r = Math.sign(e.x - e.startX),
                                s = Math.sign(e.y - e.startY),
                                a = r * e.paddingX,
                                d = s * e.paddingTop,
                                l = s * e.paddingBottom,
                                c = e.startY < e.y ? e.y + l : e.y + d,
                                u = e.x + a,
                                h = e.startX + (u - e.startX) * o,
                                p = e.startY + (c - e.startY) * o;
                            e.method(h, p), h !== u || p !== c ? requestAnimationFrame(() => t(e)) : e.cb()
                        }({
                            scrollable: t,
                            method: r,
                            startTime: x(),
                            startX: n,
                            startY: o,
                            x: 0,
                            y: i,
                            duration: s,
                            ease: a,
                            paddingX: d,
                            paddingTop: l,
                            paddingBottom: c,
                            cb: u
                        })
                })(t, 0, Math.min(e, t.scrollHeight - t.clientHeight), n.duration, n.ease, 0, 0, 0, () => i(void 0)))
            }
            var E = i(37596),
                _ = i(16954),
                C = i(50921),
                k = i(32543);
            let M = ["#fff", "#FAFAFA", "#5AB2E6", "#2292E2", "#2768B1", "#F6C823", "#F89F21", "#F96F20", "#494949", "#000", "#E6B1F3", "#E487D7", "#DD5ABB", "#A6F9E8", "#3EB59D", "#1B7865"],
                S = t => t.startsWith('"') || t.startsWith("“"),
                L = t => /^(→|←|↑|↓){1,2}$/u.test(t),
                D = t => {
                    let e = t.matchAll(RegExp("(\xa9|\xae|[ -㌀]|\ud83c[퀀-\udfff]|\ud83d[퀀-\udfff]|\ud83e[퀀-\udfff])", "g")),
                        i = e.next(),
                        n = "",
                        o = 0;
                    for (; i && !i.done;) n += i.value[0], o++, i = e.next();
                    let r = 0;
                    return (r = Intl && Intl.Segmenter ? [...new Intl.Segmenter().segment(n)].length : o) >= 1 && r <= 2 && 0 === n.localeCompare(t)
                },
                T = t => S(t) ? "quote" : L(t) ? "symbol" : D(t) ? "emoji" : "none",
                P = t => {
                    var e;
                    let {
                        className: i,
                        children: n,
                        data: l,
                        onClick: x,
                        pos: M,
                        ...S
                    } = t, [{
                        editing: L,
                        editable: D,
                        profile: P
                    }, A] = (0, r.U)(), H = (0, s.useMemo)(() => (0, d.C)(), []), W = (0, s.useRef)(!1), N = (0, p.$)(), I = (0, h.f6)(l.style, N), [Z, j] = (0, s.useState)(!1), [z, B, F] = (0, w.W)(t => [t.focused, t.setFocused, t.unsetFocused]), R = (0, s.useRef)(void 0), Y = (0, m.Z)(null !== (e = l.bg) && void 0 !== e ? e : "#fff"), X = 190 > Y.getBrightness(), q = X ? "#fff" : "#000", [O, U] = (0, s.useState)(T((0, v.V)(l.content, H))), V = (0, h.f6)(M, N), J = (0, _.X)(l.href), $ = (0, y.H)(), G = {
                        primary: Y.getBrightness() > 200 ? "#000" : Y.clone().saturate(90).darken(40).toString(),
                        bg: Y.toString(),
                        hover: Y.toString(),
                        active: Y.toString()
                    }, Q = X ? Y.clone().lighten(40 > Y.getBrightness() ? 10 : 5) : Y.clone().darken(Y.getBrightness() > 200 ? 6 : 5), [K, tt] = (0, s.useState)(!l.content || (0, v.J)(l.content, H)), te = (0, h.f6)(l.halign, N), ti = (0, h.f6)(l.valign, N);
                    "center" === te && "quote" === O && (te = "left"), "top" !== ti && "quote" === O && (ti = "top"), "middle" !== ti && "1x4" === I && (ti = "middle");
                    let tn = (0, f.jE)({
                        content: l.content,
                        extensions: H,
                        editable: !1,
                        onTransaction(t) {
                            t.transaction.before.nodeSize !== t.transaction.doc.nodeSize && b(t.editor.view.dom.closest("[data-widget-clip]"), 1e4)
                        }
                    }, []);
                    (0, s.useEffect)(() => {
                        if (tn) {
                            let t = setInterval(() => {
                                    tn.commands.setTextSelection(9999999)
                                }, 20),
                                e = setTimeout(() => {
                                    clearInterval(t)
                                }, 1e3);
                            return () => {
                                clearInterval(t), clearTimeout(e)
                            }
                        }
                    }, [tn]), (0, s.useLayoutEffect)(() => {
                        if (tn) {
                            if (z === l.id) "touch" !== $ && tn.isFocused || (tn.setEditable(!0), tn.view.focus(), tn.commands.setTextSelection(9999999)), setTimeout(() => {
                                b(tn.view.dom.closest("[data-widget-clip]"), 5e3)
                            }, 0);
                            else {
                                let t = tn.view.dom.closest("[data-widget-clip]");
                                b(t, 0), "touch" === $ && tn.setEditable(!1)
                            }
                        }
                    }, [z, $, l.id, tn]), (0, s.useEffect)(() => {
                        if (tn && W.current) {
                            j(!0);
                            let t = setInterval(() => {
                                    tn.commands.setTextSelection(0)
                                }, 100),
                                e = setTimeout(() => {
                                    tn.commands.setTextSelection(0), j(!1), clearInterval(t)
                                }, 700);
                            return () => {
                                clearInterval(t), clearTimeout(e)
                            }
                        }
                        tn && (W.current = !0)
                    }, [I, tn]), (0, s.useEffect)(() => {
                        tn && tn.commands.setTextSelection(0)
                    }, [te, tn]);
                    let to = () => {
                            "touch" !== $ && L && (tn && z !== l.id && (tn.setEditable(!0), tn.view.focus(), tn.commands.setTextSelection(9999999)), B(l.id))
                        },
                        tr = (0, s.useCallback)(t => {
                            let {
                                editor: e
                            } = t;
                            tt(e.isEmpty), U(T(e.getText())), R.current && clearTimeout(R.current), R.current = setTimeout(() => {
                                A({
                                    type: "set-bento-item-partial",
                                    bento: {
                                        id: l.id,
                                        content: e.getJSON()
                                    }
                                })
                            }, 500)
                        }, [A, l]);
                    (0, g.F)(tn, tr);
                    let ts = (0, s.useCallback)(() => {
                        "touch" !== $ && (tn && tn.setEditable(!1), F(l.id))
                    }, [tn, F, l.id, $]);
                    return (0, s.useEffect)(() => {
                        if (z === l.id) {
                            let t = t => {
                                "Escape" === t.key && ts()
                            };
                            return null == tn || tn.view.dom.addEventListener("keydown", t), () => {
                                null == tn || tn.view.dom.removeEventListener("keydown", t)
                            }
                        }
                    }, [z, l.id, tn, ts]), (0, o.jsxs)(a.$, { ...S,
                        as: !L && l.href ? "a" : "div",
                        href: L ? void 0 : l.href,
                        clickable: !L && !!l.href,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        scrollable: z === l.id && L,
                        rounding: "1x4" === I ? "sm" : "4x4" === I ? "lg" : "md",
                        className: (0, u.Z)(c()["rich-text-widget"], c()["rich-text-widget--".concat(I)], c()["rich-text-widget--".concat($)], c()["rich-text-widget--mode-".concat(O)], Z && c()["rich-text-widget--transitioning"], L && c()["rich-text-widget--editing"], z === l.id && c()["rich-text-widget--focused"], c()["rich-text-widget--valign-".concat(ti)], c()["rich-text-widget--halign-".concat(te)]),
                        snapContent: !0,
                        "data-style": I,
                        colors: G,
                        tabIndex: 5,
                        onClick: t => {
                            if (null == x || x(t), !L && l.href && !D) {
                                var e;
                                let i = t.target;
                                (0, C.U)().click(P.handle, l.id, N), (0, k.c)().track("BENTO_LINK_CLICKED", {
                                    widgetType: "rich-text",
                                    href: l.href,
                                    platformName: null !== (e = null == J ? void 0 : J.name) && void 0 !== e ? e : "Generic",
                                    gridDevice: N,
                                    widgetSize: I,
                                    positionX: V.x,
                                    positionY: V.y,
                                    richButton: !!(null == i ? void 0 : i.closest("[data-rich-button]"))
                                })
                            }
                        },
                        children: [(0, o.jsx)("div", {
                            className: c()["fake-hover"],
                            style: {
                                "--bg": Q
                            }
                        }), (0, o.jsx)("div", {
                            className: c().padding,
                            style: {
                                color: q
                            },
                            children: (0, o.jsxs)("div", {
                                className: (0, u.Z)(c().container),
                                style: {
                                    "--bg": Q,
                                    "--text": q
                                },
                                onClick: to,
                                children: [(0, o.jsx)(f.kg, {
                                    editor: tn,
                                    onBlur: ts
                                }), L && z !== l.id && K && (0, o.jsx)("div", {
                                    className: "absolute opacity-30",
                                    children: "Add note..."
                                })]
                            })
                        }), l.href && (0, o.jsx)(E.o, {
                            href: l.href,
                            color: G.bg
                        }, "link-indicator")]
                    })
                }
        },
        71842: function(t, e, i) {
            "use strict";
            i.d(e, {
                $: function() {
                    return l
                }
            });
            var n = i(52322),
                o = i(57985),
                r = i(6277),
                s = i(7777),
                a = i.n(s),
                d = i(16954);
            let l = t => {
                var e, i, s;
                let {
                    className: l,
                    children: c,
                    as: u = "div",
                    rounding: h = "md",
                    editing: p = !1,
                    bordered: f = !0,
                    elevated: m = !0,
                    hoverElevated: g = !0,
                    selected: v = !1,
                    clickable: y = !1,
                    snapContent: w = !1,
                    scrollable: x = !1,
                    userSelect: b = !1,
                    attentionMode: E = "none",
                    clipped: _ = !0,
                    colors: C = {
                        primary: "#55ACEE"
                    },
                    gridIndex: k,
                    ...M
                } = t, S = (0, o.A)(t => t.mode), L = (0, d.X)(M.href);
                return (0, n.jsxs)(u, {
                    className: (0, r.Z)(a().widget, a()["widget--rounding-".concat(h)], p && a()["widget--editing"], f && a()["widget--bordered"], m && a()["widget--elevated"], b && a()["widget--no-select"], g && a()["widget--hover-elevated"], (v || "highlight" === E) && a()["widget--selected"], y && a()["widget--clickable"], x && a()["widget--scrollable"], a()["widget--attention-".concat(E)], a()["widget--highlight-".concat(S)], !_ && l),
                    style: {
                        "--widget-color": C.primary,
                        "--widget-color-bg": C.bg,
                        "--widget-color-hover": null !== (e = C.hover) && void 0 !== e ? e : C.bg,
                        "--widget-color-active": null !== (s = null !== (i = C.active) && void 0 !== i ? i : C.hover) && void 0 !== s ? s : C.bg
                    },
                    ...M,
                    "data-widget-content-container": !0,
                    tabIndex: "a" === u ? k : void 0,
                    rel: "".concat(M.rel).concat((null == L ? void 0 : L.name) === "Mastodon Link" ? " me" : ""),
                    children: [!_ && c, _ && (0, n.jsx)("div", {
                        className: (0, r.Z)(a().widget__clip, "no-scrollbar"),
                        "data-widget-clip": !0,
                        children: (0, n.jsx)("div", {
                            className: (0, r.Z)(a().widget__content, w && a()["widget__content--snap"], l),
                            children: c
                        })
                    }), (0, n.jsx)("div", {
                        className: a().widget__border
                    }), (0, n.jsx)("div", {
                        className: a()["widget__border-highlight"]
                    })]
                })
            }
        },
        66937: function(t, e, i) {
            "use strict";
            i.d(e, {
                X: function() {
                    return o
                }
            });
            var n = i(52322);
            let o = t => {
                let {
                    size: e = 16,
                    className: i
                } = t;
                return (0, n.jsx)("svg", {
                    width: e,
                    height: e,
                    className: i,
                    viewBox: "0 0 18 18",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, n.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M11.6 2H6.4C5.24689 2 4.50235 2.00156 3.93567 2.04785C3.39235 2.09225 3.19091 2.1676 3.09202 2.21799C2.71569 2.40973 2.40973 2.71569 2.21799 3.09202C2.1676 3.19091 2.09225 3.39235 2.04785 3.93567C2.00156 4.50235 2 5.24689 2 6.4V11.2961L4.34151 9.24724C4.70597 8.92834 5.24655 8.91642 5.62471 9.21895L7.4258 10.6598L11.7929 6.29271C12.1673 5.91831 12.7686 5.90064 13.1644 6.25241L16 8.77296V6.4C16 5.24689 15.9984 4.50235 15.9521 3.93567C15.9078 3.39235 15.8324 3.19091 15.782 3.09202C15.5903 2.71569 15.2843 2.40973 14.908 2.21799C14.8091 2.1676 14.6077 2.09225 14.0643 2.04785C13.4977 2.00156 12.7531 2 11.6 2ZM0.0240504 13.7186C-0.00338973 13.5957 -0.00725765 13.469 0.0119773 13.3454C0 12.8499 0 12.276 0 11.6V6.4C0 4.15979 0 3.03969 0.435974 2.18404C0.819467 1.43139 1.43139 0.819467 2.18404 0.435974C3.03969 0 4.15979 0 6.4 0H11.6C13.8402 0 14.9603 0 15.816 0.435974C16.5686 0.819467 17.1805 1.43139 17.564 2.18404C18 3.03969 18 4.15979 18 6.4V10.9933V11.0071V11.6C18 13.8402 18 14.9603 17.564 15.816C17.1805 16.5686 16.5686 17.1805 15.816 17.564C14.9603 18 13.8402 18 11.6 18H6.4C4.15979 18 3.03969 18 2.18404 17.564C1.43139 17.1805 0.819467 16.5686 0.435974 15.816C0.165964 15.286 0.0631784 14.6547 0.0240504 13.7186ZM16 11.6V11.4489L12.5404 8.37366L8.20712 12.7069C7.84682 13.0672 7.27321 13.099 6.87532 12.7807L5.02876 11.3034L2.03733 13.9209C2.04055 13.97 2.04405 14.0178 2.04785 14.0643C2.09225 14.6077 2.1676 14.8091 2.21799 14.908C2.40973 15.2843 2.71569 15.5903 3.09202 15.782C3.19091 15.8324 3.39235 15.9078 3.93567 15.9521C4.50235 15.9984 5.24689 16 6.4 16H11.6C12.7531 16 13.4977 15.9984 14.0643 15.9521C14.6077 15.9078 14.8091 15.8324 14.908 15.782C15.2843 15.5903 15.5903 15.2843 15.782 14.908C15.8324 14.8091 15.9078 14.6077 15.9521 14.0643C15.9984 13.4977 16 12.7531 16 11.6ZM5.5 7C6.32843 7 7 6.32843 7 5.5C7 4.67157 6.32843 4 5.5 4C4.67157 4 4 4.67157 4 5.5C4 6.32843 4.67157 7 5.5 7Z",
                        fill: "currentColor"
                    })
                })
            }
        },
        10372: function(t, e, i) {
            "use strict";
            i.d(e, {
                T: function() {
                    return v
                }
            });
            var n = i(52322),
                o = i(2784),
                r = i(28970),
                s = i(52271),
                a = i(24920);

            function d(t, e) {
                var i, n;
                let o, r;
                let s = "x",
                    a = 999999,
                    d = 999999;
                if (e && t) {
                    let i = e.width / e.height,
                        n = t.offsetWidth / t.offsetHeight;
                    o = t.offsetWidth, r = t.offsetHeight, i > n ? (o = t.offsetHeight * i, r = t.offsetHeight) : (s = "y", r = t.offsetWidth / i, o = t.offsetWidth), a = (o - t.offsetWidth) / 2, d = (r - t.offsetHeight) / 2
                }
                return {
                    frameWidth: null !== (i = null == t ? void 0 : t.offsetWidth) && void 0 !== i ? i : 0,
                    frameHeight: null !== (n = null == t ? void 0 : t.offsetHeight) && void 0 !== n ? n : 0,
                    maxOffsetX: a,
                    maxOffsetY: d,
                    w: o,
                    h: r,
                    axis: s
                }
            }
            var l = i(6185),
                c = i.n(l);

            function u(t, e, i, n, o, r) {
                t.beginPath(), t.moveTo(e + r, i), t.arcTo(e + n, i, e + n, i + o, r), t.arcTo(e + n, i + o, e, i + o, r), t.arcTo(e, i + o, e, i, r), t.arcTo(e, i, e + n, i, r), t.closePath()
            }

            function h(t, e, i) {
                if (!t) return;
                let n = function(t, e) {
                    var i, n, o, r, s, l;
                    let {
                        axis: c,
                        maxOffsetX: u,
                        maxOffsetY: h,
                        w: p,
                        h: f
                    } = d(t, e), m = null == t ? void 0 : t.querySelector("[data-movable]"), g = Number(null !== (i = null == m ? void 0 : m.getAttribute("data-offset-x")) && void 0 !== i ? i : 0), v = Number(null !== (n = null == m ? void 0 : m.getAttribute("data-offset-y")) && void 0 !== n ? n : 0), y = Number(null !== (o = null == m ? void 0 : m.getAttribute("data-overshoot-x")) && void 0 !== o ? o : 0), w = Number(null !== (r = null == m ? void 0 : m.getAttribute("data-overshoot-y")) && void 0 !== r ? r : 0);
                    return {
                        offsetX: "x" === c ? (0, a.uZ)(g, -u, u) : 0,
                        offsetY: "y" === c ? (0, a.uZ)(v, -h, h) : 0,
                        frameWidth: null !== (s = null == t ? void 0 : t.offsetWidth) && void 0 !== s ? s : 0,
                        frameHeight: null !== (l = null == t ? void 0 : t.offsetHeight) && void 0 !== l ? l : 0,
                        maxOffsetX: u,
                        maxOffsetY: h,
                        w: p,
                        h: f,
                        axis: c,
                        overshootX: y,
                        overshootY: w
                    }
                }(t, e);
                ! function(t, e) {
                    let i = t.querySelector("[data-positioning-container]"),
                        n = t.querySelector("[data-movable]"),
                        o = t.querySelector("canvas"),
                        r = t.closest("[data-media-container]");
                    if (!n) throw Error("Noo");
                    let {
                        offsetX: s,
                        offsetY: a,
                        maxOffsetX: d,
                        maxOffsetY: l,
                        w: c,
                        h
                    } = e, p = 1 + .03 * Math.abs(e.overshootX), f = 1 - .0075 * Math.abs(e.overshootX), m = 1 + .03 * Math.abs(e.overshootY), g = 1 - .0075 * Math.abs(e.overshootY);
                    if (n.style.position = "absolute", n.style.top = "50%", n.style.left = "50%", n.style.transform = "translate(calc(-50% + ".concat(s * d, "px), calc(-50% + ").concat(a * l, "px))"), n.style.width = c ? c + "px" : "", n.style.height = h ? h + "px" : "", n.style.minWidth = "100%", n.style.minHeight = "100%", n.style.maxWidth = "unset", n.style.maxHeight = "unset", r) {
                        let t = "1" === n.getAttribute("data-overshoot-x-dir") ? 1 : -1,
                            i = "1" === n.getAttribute("data-overshoot-y-dir") ? 1 : -1;
                        r.style.transformOrigin = "".concat(t > 0 ? "left" : "right", " ").concat(i > 0 ? "top" : "bottom"), r.style.transform = "translate(".concat(6 * e.overshootX, "px, ").concat(6 * e.overshootY, "px) scaleX(").concat(g * p, ") scaleY(").concat(f * m, ")")
                    }
                    i && (i.style.transform = "translate(calc(-50% + ".concat(s * d, "px), calc(-50% + ").concat(a * l, "px))"), i.style.width = n.clientWidth + "px", i.style.height = n.clientHeight + "px"), o && (o.width = 1 * n.offsetWidth, o.height = 1 * n.offsetHeight, o.style.width = n.offsetWidth + "px", o.style.height = n.offsetHeight + "px", function(t, e) {
                        let i = t.getContext("2d");
                        if (i) {
                            i.clearRect(0, 0, t.width, t.height), i.fillStyle = "rgba(255, 255, 255, 0.6)";
                            let n = Number(getComputedStyle(t).borderRadius.replace("px", ""));
                            u(i, -1, -1, t.width + 2, t.height + 2, 1 * n), i.save(), i.clip(), i.fillRect(0, 0, t.width, t.height), i.restore(), u(i, t.width / 2 + (-e.offsetX * e.maxOffsetX - e.frameWidth / 2) * 1, t.height / 2 + (-e.offsetY * e.maxOffsetY - e.frameHeight / 2) * 1, 1 * e.frameWidth, 1 * e.frameHeight, 1 * n), i.save(), i.clip(), i.clearRect(0, 0, t.width, i.canvas.height), i.restore()
                        }
                    }(o, e))
                }(t, n),
                function(t, e, i) {
                    if (!t) return;
                    let n = t.querySelector("[data-movable]"),
                        o = getComputedStyle(t).borderRadius;
                    n && (i ? "x" === e.axis ? t.style.clipPath = "inset(0px ".concat((-e.offsetX * e.maxOffsetX - (n.offsetWidth - e.frameWidth) / 2) * 1.3, "px 0px ").concat((e.offsetX * e.maxOffsetX - (n.offsetWidth - e.frameWidth) / 2) * 1.3, "px round ").concat(null != o ? o : "24px", ")") : t.style.clipPath = "inset(".concat((e.offsetY * e.maxOffsetY - (n.offsetHeight - e.frameHeight) / 2) * 1.3, "px 0px ").concat((-e.offsetY * e.maxOffsetY - (n.offsetHeight - e.frameHeight) / 2) * 1.3, "px 0px round ").concat(null != o ? o : "24px", ")") : t.style.clipPath = "inset(0px round ".concat(null != o ? o : "24px", ")"))
                }(t, n, i)
            }

            function p(t, e) {
                let i = t.querySelector("[data-positioning-container]"),
                    n = t.querySelector("[data-movable]");
                t.querySelector("canvas");
                let o = t.closest("[data-media-container]"),
                    r = [n, o, i].filter(t => !!t);
                e ? r.forEach(t => {
                    t.style.transition = "transform 0.5s cubic-bezier(0.1, 1.94, 0.43, 1)"
                }) : r.forEach(t => {
                    t.style.transition = ""
                })
            }
            let f = c()(0, .98, .24, .97);
            var m = i(1920),
                g = i(70433);
            let v = t => {
                var e;
                let {
                    children: i,
                    dimensions: l,
                    editable: c = !1,
                    id: u,
                    offsetX: v,
                    offsetY: y,
                    onChange: w,
                    onLoad: x,
                    withCanvas: b = !1
                } = t, [E, _] = (0, o.useState)(null), [C, k] = (0, o.useState)(null);
                return ! function(t, e, i, n, l, c, u) {
                    let m = (0, r.c)(t => t.setCropping),
                        g = (0, o.useRef)({
                            x: null != l ? l : 0,
                            y: null != c ? c : 0
                        }),
                        v = (0, o.useRef)(void 0);
                    (0, o.useEffect)(() => {
                        t && e && i && (t.setAttribute("data-offset-x", "".concat(l)), t.setAttribute("data-offset-y", "".concat(c)), h(e, i, n))
                    }, [t, e, i, l, c]), (0, o.useEffect)(() => {
                        if (t && e && n) {
                            let o = new s.J(t, {
                                mode: "bento-image"
                            });
                            return o.on("pointerDown", () => {
                                m(!0), t.setAttribute("data-overshoot-active", "false"), v.current && clearTimeout(v.current), p(e, !1)
                            }), o.on("pointerUp", () => {
                                m(!1), t.setAttribute("data-overshoot-active", "true"), t.setAttribute("data-overshoot-x", "0"), t.setAttribute("data-overshoot-y", "0"), v.current && clearTimeout(v.current), p(e, !0), v.current = setTimeout(() => {
                                    p(e, !1)
                                }, 800), h(e, i, n)
                            }), o.on("dragStart", (n, o) => {
                                var r, s;
                                let {
                                    axis: l,
                                    maxOffsetX: c,
                                    maxOffsetY: u
                                } = d(e, i), h = Number(null !== (r = t.getAttribute("data-offset-x")) && void 0 !== r ? r : 0), p = Number(null !== (s = t.getAttribute("data-offset-y")) && void 0 !== s ? s : 0);
                                g.current = {
                                    x: (0, a.uZ)(h, -c, c),
                                    y: (0, a.uZ)(p, -u, u)
                                }
                            }), o.on("dragMove", (o, r, s) => {
                                let {
                                    axis: l,
                                    maxOffsetX: c,
                                    maxOffsetY: u
                                } = d(e, i), p = {
                                    x: (g.current.x * c + s.x) / c,
                                    y: (g.current.y * u + s.y) / u
                                }, m = {
                                    x: (0, a.uZ)((g.current.x * c + s.x) / c, -1, 1),
                                    y: (0, a.uZ)((g.current.y * u + s.y) / u, -1, 1)
                                };
                                if (t.removeAttribute("data-target-x"), t.removeAttribute("data-target-y"), "x" === l) {
                                    t.setAttribute("data-offset-x", "".concat(m.x));
                                    let e = (p.x - m.x) / 40;
                                    t.setAttribute("data-overshoot-x-dir", Math.sign(e) > 0 ? "1" : "-1"), t.setAttribute("data-overshoot-x", "".concat(f((0, a.uZ)(Math.abs(e), 0, 1)) * Math.sign(e)))
                                } else {
                                    t.setAttribute("data-offset-y", "".concat(m.y));
                                    let e = (p.y - m.y) / 40;
                                    t.setAttribute("data-overshoot-y-dir", Math.sign(e) > 0 ? "1" : "-1"), t.setAttribute("data-overshoot-y", "".concat(f((0, a.uZ)(Math.abs(e), 0, 1)) * Math.sign(e)))
                                }
                                h(e, i, n)
                            }), o.on("dragEnd", (e, i) => {
                                var n, o;
                                m(!1);
                                let r = Number(null !== (n = t.getAttribute("data-offset-x")) && void 0 !== n ? n : 0),
                                    s = Number(null !== (o = t.getAttribute("data-offset-y")) && void 0 !== o ? o : 0);
                                null == u || u(r, s)
                            }), () => {
                                o.destroy()
                            }
                        }
                    }, [t, e, i, n])
                }(E, C, l, c, v, y, w), e = C, (0, m.Z)(() => {
                    if (e && l) {
                        e.style.transition = "clip-path 0.2s ease-in-out";
                        let t = setTimeout(() => {
                            e.style.transition = "none"
                        }, 200);
                        return () => {
                            clearTimeout(t)
                        }
                    }
                }, [c]), (0, m.Z)(() => {
                    if (u && E && e && l) {
                        let t = !0,
                            i = () => {
                                h(e, l, c)
                            },
                            n = () => {
                                t || (i(), requestAnimationFrame(n))
                            },
                            o = e => {
                                e.detail.id === u && (t = !1, n())
                            },
                            r = e => {
                                e.detail.id === u && (t = !0)
                            };
                        window.addEventListener("bento:grid:widget:resize:start", o), window.addEventListener("bento:grid:widget:resize:end", r), i();
                        let s = (0, g.$)();
                        return window.addEventListener("resize", i), null == s || s.addEventListener("resize", i), E.addEventListener("resize", i), E.addEventListener("load", i), E.addEventListener("viewenter", i), E.addEventListener("error", i), E.addEventListener("loadeddata", i), E.addEventListener("loadstart", i), () => {
                            t = !0, window.removeEventListener("resize", i), null == s || s.removeEventListener("resize", i), E.removeEventListener("resize", i), E.removeEventListener("load", i), E.removeEventListener("viewenter", i), E.removeEventListener("error", i), E.removeEventListener("loadeddata", i), E.removeEventListener("loadstart", i), window.removeEventListener("bento:grid:widget:resize:start", o), window.removeEventListener("bento:grid:widget:resize:end", r)
                        }
                    }
                }, [l, e, u, E, c]), (0, o.useEffect)(() => {
                    if (C && l) {
                        let t = setTimeout(() => {
                            C.dispatchEvent(new CustomEvent("bento:croppable:prepared")), C.prepared = !0
                        }, 100);
                        return () => {
                            clearTimeout(t)
                        }
                    }
                }, [C, l]), (0, n.jsx)(n.Fragment, {
                    children: (0, n.jsxs)("div", {
                        className: "absolute inset-0 rounded-[inherit]",
                        ref: k,
                        style: {
                            transform: "translateZ(0)"
                        },
                        "data-croppable": !0,
                        children: [l && (0, n.jsx)(n.Fragment, {
                            children: (0, o.cloneElement)(i, {
                                ref: _,
                                vRef: _,
                                "data-movable": !0,
                                style: {
                                    cursor: c ? "move" : void 0
                                }
                            })
                        }), b && (0, n.jsx)("div", {
                            className: "pointer-events-none absolute left-1/2 top-1/2 rounded-[inherit]",
                            "data-positioning-container": !0,
                            children: (0, n.jsx)("canvas", {
                                className: "absolute left-0 top-0 rounded-[inherit]",
                                style: {
                                    boxShadow: c ? "inset 0px 0px 0px 1px rgba(0,0,0,0.1)" : void 0
                                }
                            })
                        })]
                    })
                })
            }
        },
        64553: function(t, e, i) {
            "use strict";
            i.d(e, {
                k: function() {
                    return r
                }
            });
            var n = i(52322),
                o = i(6277);
            let r = t => {
                let {
                    className: e,
                    white: i = !1
                } = t;
                return (0, n.jsx)("div", {
                    className: (0, o.Z)("pointer-events-none absolute inset-0 rounded-[inherit]", !i && "phantom-border", i && "phantom-border-white", e)
                })
            }
        },
        64999: function(t, e, i) {
            "use strict";
            i.d(e, {
                L: function() {
                    return r
                }
            });
            var n = i(52322),
                o = i(6277);
            let r = t => {
                let {
                    className: e
                } = t;
                return (0, n.jsx)("div", {
                    className: (0, o.Z)("flex-1", e)
                })
            }
        },
        28970: function(t, e, i) {
            "use strict";
            i.d(e, {
                c: function() {
                    return o
                }
            });
            var n = i(40624);
            let o = (0, n.Ue)(t => ({
                cropping: !1,
                setCropping: e => {
                    t({
                        cropping: e
                    })
                }
            }))
        },
        57985: function(t, e, i) {
            "use strict";
            i.d(e, {
                A: function() {
                    return o
                }
            });
            var n = i(40624);
            let o = (0, n.Ue)(t => ({
                highlighting: void 0,
                mode: "partial",
                setHighlighting: function(e) {
                    let i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "partial";
                    "function" == typeof e ? t(t => ({
                        highlighting: e(t.highlighting),
                        mode: null != i ? i : "partial"
                    })) : t({
                        highlighting: e,
                        mode: null != i ? i : "partial"
                    })
                }
            }))
        },
        91334: function(t, e, i) {
            "use strict";
            i.d(e, {
                A: function() {
                    return C
                },
                U: function() {
                    return k
                }
            });
            var n = i(84510),
                o = i(24920),
                r = i(1753);

            function s(t, e) {
                return { ...t,
                    profile: { ...t.profile,
                        ...e
                    }
                }
            }
            var a = i(94775),
                d = i(8362),
                l = i(98478),
                c = i(33541),
                u = i(32845),
                h = i(84326);

            function p(t, e, i) {
                let n = (0, a.EM)(e.profile.bento),
                    o = (0, d.ru)((0, l.f)(n, i), i),
                    p = (0, a.EM)(t.profile.bento),
                    f = (0, d.ru)((0, l.f)(p, i), i),
                    m = f.reduce((t, e) => {
                        if ("section-header" === e.type) return t;
                        let n = !o.find(t => t.id === e.id),
                            h = n ? void 0 : (0, c.C)(e.id, o),
                            p = (0, c.C)(e.id, f);
                        return h !== p || n ? function(t, e, i, n) {
                            let o = (0, a.EM)(t.profile.bento),
                                h = t.profile.bento.items.find(t => t.data.id === e);
                            if (!h) return t;
                            let p = (0, d.ru)((0, l.f)(o, n), n),
                                f = p.find(t => t.id === e);
                            if (!f) return t;
                            let m = (0, c.H)(i, p),
                                g = (0, u.dc)(m.end, p, f.dim.h),
                                v = (0, r.BW)(f.dim, g.filter(t => t.id !== e), i, n),
                                y = (0, d.ru)(g.map(t => t.id !== e ? t : { ...t,
                                    pos: v
                                }), n);
                            return s(t, {
                                bento: { ...t.profile.bento,
                                    items: t.profile.bento.items.map(t => {
                                        let e = y.find(e => e.id === t.data.id);
                                        if (!e) return t;
                                        if (!e.pos) throw Error("No position provided in layout update");
                                        return { ...t,
                                            position: { ...t.position,
                                                [n]: {
                                                    x: e.pos.x,
                                                    y: e.pos.y
                                                }
                                            }
                                        }
                                    })
                                }
                            })
                        }(t, e.id, p, "mobile" === i ? "desktop" : "mobile") : t
                    }, t);
                return function(t, e) {
                    let i = (0, a.EM)(t.profile.bento),
                        n = "mobile" === e ? "desktop" : "mobile",
                        o = (0, d.ru)((0, l.f)(i, e), e),
                        r = (0, d.ru)((0, l.f)(i, n), n),
                        c = o.filter(t => "section-header" === t.type).map(t => ({
                            id: t.id,
                            pos: t.pos.y
                        })).sort((t, e) => t.pos - e.pos).map(t => t.id),
                        u = (0, h.D)(r),
                        p = [],
                        f = {
                            id: void 0,
                            items: [],
                            start: 0,
                            end: 0
                        };
                    for (let t of u) "section-header" === t.type ? (f.end = Math.max(t.pos.y, f.end), p.push(f), f = {
                        id: t.id,
                        items: [t],
                        start: t.pos.y,
                        end: t.pos.y + 1
                    }) : (f.items.push(t), f.end = t.pos.y + 1);
                    p.push(f), p = p.filter(t => !!t.id);
                    let m = p.sort((t, e) => c.indexOf(t.id) - c.indexOf(e.id)),
                        g = p.reduce((t, e) => Math.min(t, e.start), 1e4),
                        v = t => m.filter(e => c.indexOf(e.id) < c.indexOf(t)).reduce((t, e) => t + e.end - e.start, g),
                        y = m.map(t => {
                            let e = c.indexOf(t.id);
                            return -1 === e ? 0 : v(t.id) - t.start
                        });
                    if (y.every(t => 0 === t)) return t;
                    m.forEach((t, e) => {
                        t.items.forEach(t => {
                            t.pos.y += y[e]
                        })
                    });
                    let w = m.flatMap(t => t.items);
                    return s(t, {
                        bento: { ...t.profile.bento,
                            items: t.profile.bento.items.map(t => {
                                var e, i, o;
                                let r = w.find(e => e.id === t.data.id);
                                return r ? { ...t,
                                    position: { ...t.position,
                                        [n]: {
                                            x: null !== (o = null !== (i = null === (e = t.position[n]) || void 0 === e ? void 0 : e.x) && void 0 !== i ? i : r.pos.x) && void 0 !== o ? o : 0,
                                            y: r.pos.y
                                        }
                                    }
                                } : t
                            })
                        }
                    })
                }(m, i)
            }

            function f(t, e, i) {
                var n, o;
                let r = t => ({ ...t,
                        [i]: null !== (o = null !== (n = t[i]) && void 0 !== n ? n : t.mobile) && void 0 !== o ? o : t.desktop
                    }),
                    a = t => {
                        switch (t.type) {
                            case "link":
                            case "media":
                            case "rich-text":
                                return { ...t,
                                    style: r(t.style)
                                };
                            case "section-header":
                            case "ghost":
                            case "ghost-materialized":
                                return t;
                            default:
                                throw Error("Unhandled widget type")
                        }
                    },
                    d = s(t, {
                        bento: { ...t.profile.bento,
                            items: t.profile.bento.items.map(t => {
                                let n = e.find(e => e.id === t.data.id);
                                if (!n) return t;
                                if (!n.pos) throw Error("No position provided in layout update");
                                return { ...t,
                                    data: a(t.data),
                                    position: { ...t.position,
                                        [i]: {
                                            x: n.pos.x,
                                            y: n.pos.y
                                        }
                                    }
                                }
                            })
                        }
                    });
                return p(d, t, i)
            }
            var m = i(10799);

            function g(t, e, i, n) {
                let c = {
                        mobile: (0, a.sq)(t.profile.bento, "mobile"),
                        desktop: (0, a.sq)(t.profile.bento, "desktop")
                    },
                    u = (0, a.xm)((0, a.iJ)(e), e, i),
                    h = (0, d.ru)((0, l.f)(c, i), i),
                    g = f(t, h, i),
                    v = (0, r.ju)(u, h, i, n, !1);
                if ((0, m.Lr)(e)) throw Error("Cant add ghost data with this reducer");
                switch (e.type) {
                    case "link":
                    case "media":
                        if (!e.style[i]) throw Error("No style for device")
                }
                let y = {
                        data: e,
                        position: (0, o.um)(v, i)
                    },
                    w = s(g, {
                        bento: { ...g.profile.bento,
                            items: [...g.profile.bento.items, y]
                        }
                    });
                return p(w, t, i)
            }
            var v = i(46679),
                y = i(49961);

            function w(t) {
                return { ...t,
                    history: [t.profile, ...t.history.slice(t.historyPointer)].slice(0, 10),
                    historyPointer: 0
                }
            }
            var x = i(36330);
            let b = (t, e) => {
                    var i, n, r, c, u, h, y;
                    switch (e.type) {
                        case "set-editor-field":
                            return i = e.field, n = e.value, { ...t,
                                [i]: n
                            };
                        case "set-profile-field":
                            return s(t, {
                                [e.field]: e.value
                            });
                        case "add-bento-item":
                            return w(g(t, e.bento, e.device, e.viewSlice));
                        case "add-bento-items":
                            return w((r = e.bentos, c = e.device, r.reduce((t, e) => g(t, e, c), t)));
                        case "set-bento-item":
                            return w((u = e.bento, s(t, {
                                bento: { ...t.profile.bento,
                                    items: t.profile.bento.items.map(t => {
                                        let e = t.data.id === u.id;
                                        return e ? { ...t,
                                            data: u
                                        } : t
                                    })
                                }
                            })));
                        case "set-bento-item-partial":
                            return w((h = e.bento, s(t, {
                                bento: { ...t.profile.bento,
                                    items: t.profile.bento.items.map(t => {
                                        let e = t.data.id === h.id;
                                        return e ? { ...t,
                                            data: { ...t.data,
                                                ...h
                                            }
                                        } : t
                                    })
                                }
                            })));
                        case "delete-bento-item":
                            return w(function(t, e) {
                                let i = s(t, {
                                    bento: { ...t.profile.bento,
                                        items: t.profile.bento.items.filter(t => t.data.id !== e)
                                    }
                                });
                                return function(t) {
                                    let e = {
                                            mobile: (0, a.sq)(t.profile.bento, "mobile"),
                                            desktop: (0, a.sq)(t.profile.bento, "desktop")
                                        },
                                        i = (0, l.f)(e, "mobile"),
                                        n = (0, l.f)(e, "desktop"),
                                        o = (0, d.ru)(i, "mobile"),
                                        r = (0, d.ru)(n, "desktop");
                                    return (0, v.F_)(o), (0, v.F_)(r), f(f(t, o, "mobile"), r, "desktop")
                                }(i)
                            }(t, e.id));
                        case "update-layout":
                            return w(f(t, e.layout, e.device));
                        case "save":
                            return { ...t,
                                saved: t.profile
                            };
                        case "resetToSave":
                            return t.saved ? { ...t,
                                profile: t.saved
                            } : t;
                        case "undo":
                            return function(t) {
                                let e = t.historyPointer + 1;
                                return { ...t,
                                    profile: t.history.length > e ? t.history[e] : t.profile,
                                    historyPointer: Math.min(e, t.history.length - 1)
                                }
                            }(t);
                        case "redo":
                            return function(t) {
                                let e = t.historyPointer - 1;
                                return { ...t,
                                    profile: e >= 0 && t.history.length > 0 ? t.history[e] : t.profile,
                                    historyPointer: Math.max(e, 0)
                                }
                            }(t);
                        case "commit":
                            return y = e.profile, { ...t,
                                original: y
                            };
                        case "add-ghost":
                            return function(t, e) {
                                let i = {
                                        data: e,
                                        position: e.pos
                                    },
                                    n = s(t, {
                                        bento: { ...t.profile.bento,
                                            items: [...t.profile.bento.items, i]
                                        }
                                    });
                                return n
                            }(t, e.ghost);
                        case "add-ghosts":
                            return function(t) {
                                let e = s(t, {
                                    bento: function(t) {
                                        let e = (0, x.L)(t, 6);
                                        return { ...t,
                                            items: [...t.items, ...e]
                                        }
                                    }(t.profile.bento)
                                });
                                return e
                            }(t);
                        case "remove-ghost":
                            return function(t, e) {
                                let i = s(t, {
                                    bento: { ...t.profile.bento,
                                        items: t.profile.bento.items.filter(t => !("ghost" === t.data.type && t.data.id === e.id))
                                    }
                                });
                                return i
                            }(t, e.ghost);
                        case "remove-ghosts":
                            return function(t) {
                                let e = s(t, {
                                    bento: { ...t.profile.bento,
                                        items: t.profile.bento.items.filter(t => "ghost" !== t.data.type)
                                    }
                                });
                                return e
                            }(t);
                        case "replace-bento-ghost":
                            return w(function(t, e, i) {
                                let n = t.profile.bento.items.find(t => (0, m.mz)(t) && t.data.id === e.id);
                                if (!n) throw Error("Ghost doesnt exist");
                                let r = {
                                        data: e,
                                        position: (0, o.um)(n.position[i], i)
                                    },
                                    a = s(t, {
                                        bento: { ...t.profile.bento,
                                            items: [...t.profile.bento.items.filter(t => t.data.id !== e.id), r]
                                        }
                                    });
                                return p(a, t, i)
                            }(t, e.bento, e.device));
                        case "materialize-bento-ghost":
                            return function(t, e, i) {
                                let n = t.profile.bento.items.find(t => "ghost" === t.data.type && t.data.id === e.id);
                                if (!n) throw Error("Ghost doesnt exist");
                                let r = { ...t.profile.bento,
                                        items: [...t.profile.bento.items.filter(t => t.data.id !== e.id), { ...n,
                                            data: { ...n.data,
                                                type: "ghost-materialized"
                                            }
                                        }]
                                    },
                                    c = {
                                        mobile: (0, a.sq)(r, "mobile"),
                                        desktop: (0, a.sq)(r, "desktop")
                                    },
                                    u = (0, d.ru)((0, l.f)(c, i), i),
                                    h = s(t, {
                                        bento: { ...t.profile.bento,
                                            items: r.items.map(t => {
                                                var e, n;
                                                return "ghost-materialized" !== t.data.type ? t : { ...t,
                                                    position: (0, o.um)(null !== (n = null === (e = u.find(e => e.id === t.data.id)) || void 0 === e ? void 0 : e.pos) && void 0 !== n ? n : t.position[i], i)
                                                }
                                            })
                                        }
                                    });
                                return p(h, t, i)
                            }(t, e.bento, e.device);
                        default:
                            throw Error()
                    }
                },
                E = {
                    handle: "",
                    name: "",
                    bio: {},
                    ogImage: void 0,
                    bento: {
                        version: "v2",
                        items: []
                    }
                },
                [_, C] = (0, n.Z)(b, {
                    id: void 0,
                    profile: E,
                    history: [],
                    historyPointer: 0,
                    original: E,
                    publishing: !1,
                    previewing: !1,
                    stage: "created"
                }),
                k = () => {
                    let {
                        user: t
                    } = (0, y.aC)(), [e, i] = _(), n = !!(null == t ? void 0 : t.id) && t.id === e.id;
                    return [{ ...e,
                        editable: n,
                        editing: n && !e.previewing
                    }, i]
                }
        },
        36330: function(t, e, i) {
            "use strict";
            i.d(e, {
                L: function() {
                    return h
                }
            });
            var n = i(24920),
                o = i(8362),
                r = i(99864),
                s = i(1753),
                a = i(98478);
            let d = (t, e) => {
                    let i = l((0, a.f)(t, "mobile"), "mobile", e),
                        n = l((0, a.f)(t, "desktop"), "desktop", e);
                    return e.map(t => ({
                        id: t.id,
                        dim: {
                            mobile: i.find(e => e.id === t.id).dim,
                            desktop: n.find(e => e.id === t.id).dim
                        },
                        pos: {
                            mobile: i.find(e => e.id === t.id).pos,
                            desktop: n.find(e => e.id === t.id).pos
                        }
                    }))
                },
                l = (t, e, i) => {
                    let a = (0, r.D)(e),
                        d = (0, o.ru)(t, e),
                        l = (0, s.tJ)(d, e),
                        c = [{
                            h: 2,
                            w: 2
                        }, {
                            h: 4,
                            w: 2
                        }, {
                            h: 2,
                            w: 4
                        }, {
                            h: 4,
                            w: 4
                        }],
                        u = [],
                        h = [...i];
                    for (; h.length > 0;) {
                        let t = h.shift(),
                            i = [],
                            o = 0;
                        for (let t = 0; t < l.length; t++) {
                            let e = l[t].map((t, e) => e).filter(e => !l[t][e]);
                            if (e.length > 0) {
                                if (t === l.length - 1 || e.some(e => !l[t + 1][e])) {
                                    o = t;
                                    break
                                }
                            } else t === l.length - 1 && (l[o = t + 1] = Array(a).fill(!1))
                        }
                        for (let t of c)
                            for (let e = 0; e <= a - t.w; e += 2) {
                                let n = !1;
                                for (let i = 0; i < t.w; i++) {
                                    for (let r = 0; r < t.h && !(o + r >= l.length); r++)
                                        if (l[o + r] || (l[o + r] = Array(a).fill(!1)), l[o + r][e + i]) {
                                            n = !0;
                                            break
                                        }
                                    if (n) break
                                }
                                n || i.push({
                                    dim: t,
                                    pos: {
                                        x: e,
                                        y: o
                                    }
                                })
                            }
                        let r = (0, n.Li)(i);
                        if (r || (r = {
                                dim: {
                                    h: 2,
                                    w: 2
                                },
                                pos: (0, s.ju)({
                                    h: 4,
                                    w: 2
                                }, d, e, void 0, !0)
                            }), !r.pos) throw Error("No pos");
                        u.push({
                            id: t.id,
                            dim: r.dim,
                            pos: r.pos
                        });
                        for (let t = 0; t < r.dim.w; t++)
                            for (let e = 0; e < r.dim.h; e++) l[r.pos.y + e] || (l[r.pos.y + e] = Array(a).fill(!1)), l[r.pos.y + e][r.pos.x + t] = !0
                    }
                    return u
                };
            var c = i(94775),
                u = i(97008);

            function h(t, e) {
                let i = {
                        mobile: (0, c.sq)(t, "mobile"),
                        desktop: (0, c.sq)(t, "desktop")
                    },
                    o = ["image", "video", "map", "link", "spotify", "note"],
                    r = e => t.items.some(t => {
                        switch (e) {
                            case "image":
                                return "media" === t.data.type && "image" === t.data.variant;
                            case "video":
                                return "media" === t.data.type && "video" === t.data.variant;
                            case "map":
                                return "link" === t.data.type && (0, u._N)(t.data.href);
                            case "link":
                                return !1;
                            case "spotify":
                                return "link" === t.data.type && (0, u.JU)(t.data.href);
                            case "note":
                                return "rich-text" === t.data.type
                        }
                    }),
                    s = o.filter(t => !r(t)),
                    a = o.filter(t => r(t)),
                    l = (0, n.rx)([...(0, n.TV)(s), ...(0, n.TV)(a.filter(t => "map" !== t))], Math.ceil(e / o.length) + 1).filter((t, e, i) => "link" !== t || i.indexOf(t) === e).slice(0, e),
                    h = l.map(t => ({
                        id: (0, n.x0)(),
                        variant: t
                    })),
                    p = d(i, h.map(t => ({
                        id: t.id
                    }))),
                    f = p.map(t => ({
                        id: t.id,
                        type: "ghost",
                        variant: h.find(e => e.id === t.id).variant,
                        dim: t.dim,
                        pos: t.pos
                    })),
                    m = f.map(t => ({
                        data: t,
                        position: t.pos
                    }));
                return m
            }
        },
        47312: function(t, e, i) {
            "use strict";
            i.d(e, {
                K: function() {
                    return d
                }
            });
            var n = i(99631),
                o = i(74704),
                r = i(32259),
                s = i(67780),
                a = i(88360);
            let d = t => [a.y, s.Z, o.Z, n.Z, r.Z.configure({
                placeholder: null != t ? t : "Caption..."
            })]
        },
        13361: function(t, e, i) {
            "use strict";
            i.d(e, {
                C: function() {
                    return _
                }
            });
            var n = i(6776),
                o = i(96458),
                r = i(99631),
                s = i(74704),
                a = i(64652),
                d = i(32259),
                l = i(67780),
                c = i(33539);
            let u = c.vc.create({
                    name: "overflowChar",
                    addOptions: () => ({
                        multicolor: !1,
                        HTMLAttributes: {}
                    }),
                    parseHTML: () => [{
                        tag: "overflowChar"
                    }],
                    renderHTML(t) {
                        let {
                            HTMLAttributes: e
                        } = t;
                        return ["overflowChar", (0, c.P1)(this.options.HTMLAttributes, e), 0]
                    },
                    addCommands() {
                        return {
                            setoverflowChar: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.setMark(this.name)
                            },
                            toggleHighlight: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.toggleMark(this.name)
                            },
                            unsetHighlight: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.unsetMark(this.name)
                            }
                        }
                    }
                }),
                h = c.hj.create({
                    name: "limited",
                    addExtensions: () => [u],
                    addOptions: () => ({
                        containerSelector: void 0,
                        padding: 0
                    }),
                    onTransaction(t) {
                        let {
                            transaction: e
                        } = t;
                        if (e.getMeta("automatic")) return;
                        let i = this.editor.state.tr.setMeta("automatic", !0).setMeta("addToHistory", !1),
                            {
                                highlight: n,
                                overflowChar: o
                            } = this.editor.schema.marks;
                        if (!n || !o) return;
                        let r = this.options.containerSelector ? this.editor.view.dom.closest(this.options.containerSelector) : this.editor.view.dom;
                        if (!r) return;
                        this.editor.view.dispatch(i.removeMark(0, this.editor.state.doc.content.size, n).removeMark(0, this.editor.state.doc.content.size, o)), i = this.editor.state.tr.setMeta("automatic", !0).setMeta("addToHistory", !1);
                        let s = r.getBoundingClientRect(),
                            a = this.editor.view.dom.getBoundingClientRect(),
                            d = this.options.padding + 20 > s.height ? s.height - 20 : this.options.padding,
                            l = {
                                left: a.left + a.width - 26,
                                top: a.top + s.height - 4 - 10 - d
                            },
                            c = this.editor.view.posAtCoords(l),
                            u = this.editor.view.posAtCoords({ ...l,
                                left: l.left + 20
                            });
                        if (!(null == c ? void 0 : c.pos) || c.pos >= this.editor.state.doc.content.size - 1) {
                            this.editor.view.dispatch(i.removeMark(0, this.editor.state.doc.content.size, n).removeMark(0, this.editor.state.doc.content.size, o));
                            return
                        }
                        if (!e.doc) return;
                        let h = e.doc.nodeSize;
                        h && (u && u.pos >= h - 4 || this.editor.view.dispatch(i.removeMark(0, c.pos - 1, o).removeMark(0, c.pos, n).addMark(c.pos, h - 2, n.create()).addMark(c.pos - 1, c.pos, o.create()).removeMark(c.pos, h - 2, o)))
                    }
                }),
                p = /(?:^|\s)((?:\*)((?:[^*]+))(?:\*))$/,
                f = /(?:^|\s)((?:\*)((?:[^*]+))(?:\*))/g,
                m = c.vc.create({
                    name: "bold",
                    addOptions: () => ({
                        HTMLAttributes: {}
                    }),
                    parseHTML: () => [{
                        tag: "strong"
                    }, {
                        tag: "b",
                        getAttrs: t => "normal" !== t.style.fontWeight && null
                    }, {
                        style: "font-weight",
                        getAttrs: t => /^(bold(er)?|[5-9]\d{2,})$/.test(t) && null
                    }],
                    renderHTML(t) {
                        let {
                            HTMLAttributes: e
                        } = t;
                        return ["strong", (0, c.P1)(this.options.HTMLAttributes, e), 0]
                    },
                    addCommands() {
                        return {
                            setBold: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.setMark(this.name)
                            },
                            toggleBold: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.toggleMark(this.name)
                            },
                            unsetBold: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.unsetMark(this.name)
                            }
                        }
                    },
                    addKeyboardShortcuts() {
                        return {
                            "Mod-b": () => this.editor.commands.toggleBold(),
                            "Mod-B": () => this.editor.commands.toggleBold()
                        }
                    },
                    addInputRules() {
                        return [(0, c.Cf)({
                            find: p,
                            type: this.type
                        })]
                    },
                    addPasteRules() {
                        return [(0, c.K9)({
                            find: f,
                            type: this.type
                        })]
                    }
                }),
                g = /(?:^|\s)((?:_)((?:[^_]+))(?:_))$/,
                v = /(?:^|\s)((?:_)((?:[^_]+))(?:_))/g,
                y = c.vc.create({
                    name: "italic",
                    addOptions: () => ({
                        HTMLAttributes: {}
                    }),
                    parseHTML: () => [{
                        tag: "em"
                    }, {
                        tag: "i",
                        getAttrs: t => "normal" !== t.style.fontStyle && null
                    }, {
                        style: "font-style=italic"
                    }],
                    renderHTML(t) {
                        let {
                            HTMLAttributes: e
                        } = t;
                        return ["em", (0, c.P1)(this.options.HTMLAttributes, e), 0]
                    },
                    addCommands() {
                        return {
                            setItalic: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.setMark(this.name)
                            },
                            toggleItalic: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.toggleMark(this.name)
                            },
                            unsetItalic: () => t => {
                                let {
                                    commands: e
                                } = t;
                                return e.unsetMark(this.name)
                            }
                        }
                    },
                    addKeyboardShortcuts() {
                        return {
                            "Mod-i": () => this.editor.commands.toggleItalic(),
                            "Mod-I": () => this.editor.commands.toggleItalic()
                        }
                    },
                    addInputRules() {
                        return [(0, c.Cf)({
                            find: g,
                            type: this.type
                        })]
                    },
                    addPasteRules() {
                        return [(0, c.K9)({
                            find: v,
                            type: this.type
                        })]
                    }
                });
            var w = i(27191),
                x = i(52780);
            let b = t => {
                    let e = {
                        isQuote: !1,
                        citeStart: void 0
                    };
                    return e.isQuote = !!t.textBetween(1, 2).match(/["“]/), e.isQuote && t.descendants((i, n) => {
                        if (i === t.lastChild) {
                            let t = i.textContent.match(/^([-—].*)$/);
                            if (t) {
                                var o, r;
                                let s = null !== (r = null === (o = t[t.length - 1]) || void 0 === o ? void 0 : o.length) && void 0 !== r ? r : 0;
                                e.citeStart = n + i.nodeSize - s - 1
                            }
                        }
                    }), e
                },
                E = c.hj.create({
                    name: "auto-quote",
                    addOptions: () => ({
                        containerSelector: void 0,
                        padding: 0
                    }),
                    addProseMirrorPlugins: () => [new w.Sy({
                        key: new w.H$("add-quote"),
                        appendTransaction(t, e, i) {
                            let n = i.tr,
                                o = b(i.doc);
                            if (o.isQuote && o.citeStart) {
                                let t = i.doc.textBetween(o.citeStart, i.doc.nodeSize - 2);
                                if (t.startsWith("- ")) return n.replaceRangeWith(o.citeStart, o.citeStart + 2, i.schema.text("— ")), n;
                                if (t.startsWith("-")) return n.replaceRangeWith(o.citeStart, o.citeStart + 1, i.schema.text("— ")), n
                            }
                            return null
                        },
                        props: {
                            decorations: t => {
                                let {
                                    doc: e,
                                    selection: i
                                } = t, n = [], o = b(e);
                                if (o.isQuote) {
                                    var r;
                                    n.push(x.p.inline(1, 2, {
                                        class: "quote-symbol"
                                    })), o.citeStart && n.push(x.p.inline(o.citeStart, e.nodeSize, {
                                        class: "quote-cite"
                                    })), n.push(x.p.inline(2, null !== (r = o.citeStart) && void 0 !== r ? r : e.nodeSize, {
                                        class: "quote-text"
                                    }))
                                }
                                return x.EH.create(e, n)
                            }
                        }
                    })]
                }),
                _ = t => [o.Z, l.Z, s.Z, r.Z, a.ZP, E, h.configure({
                    containerSelector: "[data-item-content]",
                    padding: 40
                }), m, y, n.ZP.configure({
                    HTMLAttributes: {
                        class: "overflow-indicator"
                    }
                }), d.Z.configure({
                    placeholder(t) {
                        let {
                            editor: e
                        } = t;
                        return e.isFocused && e.state.doc.nodeSize <= 4 ? "Add note..." : ""
                    }
                })]
        },
        88360: function(t, e, i) {
            "use strict";
            i.d(e, {
                y: function() {
                    return o
                }
            });
            var n = i(96458);
            let o = n.Z.extend({
                content: "paragraph"
            })
        },
        34364: function(t, e, i) {
            "use strict";
            i.d(e, {
                W: function() {
                    return o
                }
            });
            var n = i(40624);
            let o = (0, n.Ue)((t, e) => ({
                focused: void 0,
                setFocused: e => t({
                    focused: e
                }),
                unsetFocused: i => {
                    e().focused === i && t({
                        focused: void 0
                    })
                }
            }))
        },
        37067: function(t, e, i) {
            "use strict";
            i.d(e, {
                F: function() {
                    return o
                }
            });
            var n = i(2784);

            function o(t, e) {
                (0, n.useEffect)(() => {
                    if (t && e) return t.on("update", e), () => {
                        t.off("update", e)
                    }
                }, [t, e])
            }
        },
        84090: function(t, e, i) {
            "use strict";
            i.d(e, {
                $: function() {
                    return o
                }
            });
            var n = i(88242);

            function o() {
                return (0, n.A)(t => t.device)
            }
        },
        16954: function(t, e, i) {
            "use strict";
            i.d(e, {
                X: function() {
                    return o
                }
            });
            var n = i(33126);

            function o(t) {
                if (t) return n.I.find(e => e.match(t))
            }
        },
        10799: function(t, e, i) {
            "use strict";

            function n(t) {
                return "".concat(t.h, "x").concat(t.w)
            }

            function o(t) {
                return !s(t.data)
            }

            function r(t) {
                return s(t.data)
            }

            function s(t) {
                return "ghost" === t.type || "ghost-materialized" === t.type
            }
            i.d(e, {
                Lr: function() {
                    return s
                },
                kQ: function() {
                    return n
                },
                mz: function() {
                    return r
                },
                zF: function() {
                    return o
                }
            })
        },
        51026: function(t, e, i) {
            "use strict";
            i.d(e, {
                m: function() {
                    return o
                }
            });
            var n = i(24920);
            let o = t => t && t.endsWith(".ico") ? (0, n.En)(t, {
                fm: "png"
            }) : t
        },
        70433: function(t, e, i) {
            "use strict";
            i.d(e, {
                $: function() {
                    return o
                },
                t: function() {
                    return n
                }
            });
            let n = () => {
                    var t;
                    let e = null === (t = document.querySelector("iframe[data-editor-iframe]")) || void 0 === t ? void 0 : t.contentDocument;
                    return e
                },
                o = () => {
                    var t;
                    let e = null === (t = document.querySelector("iframe[data-editor-iframe]")) || void 0 === t ? void 0 : t.contentWindow;
                    return e
                }
        },
        65753: function(t, e, i) {
            "use strict";

            function n(t) {
                var e = document.createElement("img");
                return e.src = t, new Promise((t, i) => {
                    let n = function() {
                        e.naturalWidth ? t({
                            width: e.naturalWidth,
                            height: e.naturalHeight,
                            aspectRatio: e.naturalWidth / e.naturalHeight
                        }) : requestAnimationFrame(n)
                    };
                    e.onerror = e.onabort = () => i(Error("Image failed to load")), requestAnimationFrame(n), n()
                })
            }
            i.d(e, {
                p: function() {
                    return n
                }
            })
        },
        18559: function(t, e, i) {
            "use strict";
            i.d(e, {
                J: function() {
                    return s
                },
                V: function() {
                    return r
                }
            });
            var n = i(33539),
                o = i(28638);
            let r = (t, e) => {
                    if (!t) return "";
                    if ("string" == typeof t) return t;
                    let i = !t.type,
                        r = (0, n.J1)(e),
                        s = o.NB.fromJSON(r, i ? {
                            type: r.topNodeType.name
                        } : t),
                        a = s.textBetween(0, s.nodeSize - 2, "\n");
                    return a
                },
                s = (t, e) => !r(t, e).trim()
        },
        69289: function(t, e, i) {
            "use strict";

            function n(t) {
                var e = document.createElement("video");
                return e.src = t, new Promise((t, i) => {
                    let n = function() {
                        e.videoWidth && t({
                            width: e.videoWidth,
                            height: e.videoHeight,
                            aspectRatio: e.videoWidth / e.videoHeight
                        })
                    };
                    e.onloadedmetadata = t => {
                        n()
                    }, e.onerror = e.onabort = () => i(Error("Video failed to load")), n()
                })
            }
            i.d(e, {
                j: function() {
                    return n
                }
            })
        },
        1428: function(t, e, i) {
            "use strict";
            i.d(e, {
                N: function() {
                    return d
                }
            });
            var n = i(93143),
                o = i(37523),
                r = i(60696),
                s = i(28879),
                a = i.n(s);

            function d(t) {
                let {
                    data: e,
                    mutate: i,
                    ...s
                } = (0, o.$)((0, n.mL)(t), {
                    dedupingInterval: 400,
                    refreshInterval(t) {
                        let e = t ? a()().diff(t.updatedAt, "seconds") : 0;
                        return t && t.status === r.EFetchStatus.COMPLETED ? 0 : e < 10 && t && t.status === r.EFetchStatus.FETCHING ? 333 : t && t.status === r.EFetchStatus.FAILED ? 3e4 : 1e3
                    }
                });
                return {
                    metadata: e,
                    ...s
                }
            }
        },
        52271: function(t, e, i) {
            "use strict";
            i.d(e, {
                J: function() {
                    return y
                }
            });
            var n = i(24920);

            function o(t) {
                let e = parseFloat(t);
                return -1 == t.indexOf("%") && !isNaN(e) && e
            }
            let r = ["paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "marginLeft", "marginRight", "marginTop", "marginBottom", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"];

            function s(t) {
                if ("string" == typeof t && (t = document.querySelector(t)), !(t && "object" == typeof t && t.nodeType) || !t) return;
                let e = getComputedStyle(t);
                if ("none" == e.display) {
                    let t;
                    return t = {
                        width: 0,
                        height: 0,
                        innerWidth: 0,
                        innerHeight: 0,
                        outerWidth: 0,
                        outerHeight: 0
                    }, r.forEach(e => {
                        t[e] = 0
                    }), t
                }
                let i = {};
                i.width = t.offsetWidth, i.height = t.offsetHeight;
                let n = i.isBorderBox = "border-box" == e.boxSizing;
                r.forEach(t => {
                    let n = parseFloat(e[t]);
                    i[t] = isNaN(n) ? 0 : n
                });
                let s = i.paddingLeft + i.paddingRight,
                    a = i.paddingTop + i.paddingBottom,
                    d = i.marginLeft + i.marginRight,
                    l = i.marginTop + i.marginBottom,
                    c = i.borderLeftWidth + i.borderRightWidth,
                    u = i.borderTopWidth + i.borderBottomWidth,
                    h = o(e.width);
                !1 !== h && (i.width = h + (n ? 0 : s + c));
                let p = o(e.height);
                return !1 !== p && (i.height = p + (n ? 0 : a + u)), i.innerWidth = i.width - (s + c), i.innerHeight = i.height - (a + u), i.outerWidth = i.width + d, i.outerHeight = i.height + l, i
            }
            let a = t => {
                    if (!t) return !1;
                    let e = t.scrollHeight > t.clientHeight,
                        i = window.getComputedStyle(t).overflowY;
                    return e && "auto" === i
                },
                d = t => {
                    var e;
                    let i = t.parentElement;
                    return a(t) ? t : i ? d(i) : null !== (e = t.ownerDocument.scrollingElement) && void 0 !== e ? e : t.ownerDocument.body
                };

            function l() {}
            let c = l.prototype;

            function u() {}
            c.on = function(t, e) {
                if (!t || !e) return this;
                let i = this._events = this._events || {},
                    n = i[t] = i[t] || [];
                return n.includes(e) || n.push(e), this
            }, c.once = function(t, e) {
                if (!t || !e) return this;
                this.on(t, e);
                let i = this._onceEvents = this._onceEvents || {};
                return (i[t] = i[t] || {})[e] = !0, this
            }, c.off = function(t, e) {
                let i = this._events && this._events[t];
                if (!i || !i.length) return this;
                let n = i.indexOf(e);
                return -1 != n && i.splice(n, 1), this
            }, c.emitEvent = function(t, e) {
                let i = this._events && this._events[t];
                if (!i || !i.length) return this;
                i = i.slice(0), e = e || [];
                let n = this._onceEvents && this._onceEvents[t];
                for (let o of i) n && n[o] && (this.off(t, o), delete n[o]), o.apply(this, e);
                return this
            }, c.allOff = function() {
                return delete this._events, delete this._onceEvents, this
            }; {
                let t, e, i = u.prototype = Object.create(l.prototype);
                i.handleEvent = function(t) {
                    let e = "on" + t.type;
                    this[e] && this[e](t)
                }, window.PointerEvent ? (t = "pointerdown", e = ["pointermove", "pointerup", "pointercancel"]) : (t = "mousedown", e = ["mousemove", "mouseup"]), i.touchActionValue = "none", i.bindHandles = function() {
                    this._bindHandles("addEventListener", this.touchActionValue)
                }, i.unbindHandles = function() {
                    this._bindHandles("removeEventListener", "")
                }, i._bindHandles = function(e, i) {
                    this.handles.forEach(n => {
                        n[e](t, this), n[e]("click", this), window.PointerEvent && (n.style.touchAction = i)
                    })
                }, i.bindActivePointerEvents = function() {
                    let t = this.getWindow(),
                        i = t.top;
                    e.forEach(e => {
                        t.addEventListener(e, this)
                    }), i && e.forEach(t => {
                        i.addEventListener(t, this)
                    })
                }, i.unbindActivePointerEvents = function() {
                    let t = this.getWindow(),
                        i = t.top;
                    e.forEach(e => {
                        t.removeEventListener(e, this)
                    }), i && e.forEach(t => {
                        i.removeEventListener(t, this)
                    })
                }, i.withPointer = function(t, e) {
                    e.pointerId === this.pointerIdentifier && this[t](e, e)
                }, i.withTouch = function(t, e) {
                    let i;
                    for (let t = 0; t < e.changedTouches.length; t++) {
                        let n = e.changedTouches[t];
                        n && n.identifier === this.pointerIdentifier && (i = n)
                    }
                    i && this[t](e, i)
                }, i.onmousedown = function(t) {
                    this.pointerDown(t, t)
                }, i.ontouchstart = function(t) {
                    this.pointerDown(t, t.changedTouches[0])
                }, i.onpointerdown = function(t) {
                    this.pointerDown(t, t)
                };
                let n = ["TEXTAREA", "INPUT", "SELECT", "OPTION"],
                    o = ["radio", "checkbox", "button", "submit", "image", "file"];
                i.pointerDown = function(t, e) {
                    if (!t.target) return;
                    this.iframe = void 0;
                    let i = t.target,
                        r = n.includes(i.nodeName),
                        s = o.includes(t.target.type);
                    !this.isPointerDown && !t.button && (!r || s) && this.canDrag(t.target) && (this.isPointerDown = !0, this.pointerIdentifier = void 0 !== e.pointerId ? e.pointerId : e.identifier, this.pointerDownPointer = {
                        pageX: e.pageX,
                        pageY: e.pageY
                    }, this.bindActivePointerEvents(), this.emitEvent("pointerDown", [t, e]))
                }, i.onmousemove = function(t) {
                    this.pointerMove(t, t)
                }, i.onpointermove = function(t) {
                    this.withPointer("pointerMove", t)
                }, i.ontouchmove = function(t) {
                    this.withTouch("pointerMove", t)
                }, i.getIframe = function(t) {
                    let e = this.getWindow().top;
                    if (!this.iframe) {
                        let i = Array.from(e.document.body.querySelectorAll("iframe"));
                        for (let n = 0; n < i.length; n++) {
                            let o = i[n];
                            if (o && o.contentDocument === t) {
                                this.iframe = o, this.iframeRect = o.getBoundingClientRect(), this.iframeComputedStyle = e.getComputedStyle(o);
                                break
                            }
                        }
                    }
                    return this.iframe ? {
                        iframe: this.iframe,
                        rect: this.iframeRect,
                        computedStyle: this.iframeComputedStyle
                    } : {
                        iframe: null,
                        rect: null,
                        computedStyle: null
                    }
                }, i.pointerMove = function(t, e) {
                    var i, n;
                    let o = this.getWindow(),
                        r = this.getWindow().top,
                        s = e.target,
                        a = this.getIframe(o.document),
                        d = (null == s ? void 0 : s.ownerDocument) === r.document,
                        l = a.rect,
                        c = null !== (n = null === (i = a.computedStyle) || void 0 === i ? void 0 : i.borderWidth) && void 0 !== n ? n : 0,
                        u = c ? parseInt(c.replace("px", "")) : 0,
                        h = l ? {
                            x: l.left + u,
                            y: l.top + u
                        } : {
                            x: 0,
                            y: 0
                        },
                        p = d ? h.x - o.document.body.scrollLeft : 0,
                        f = d ? h.y - o.document.body.scrollTop : 0,
                        m = {
                            x: e.pageX - this.pointerDownPointer.pageX - p,
                            y: e.pageY - this.pointerDownPointer.pageY - f
                        };
                    this.pointer = {
                        pageY: e.pageY,
                        pageX: e.pageX,
                        target: e.target
                    }, this.emitEvent("pointerMove", [t, e, m]), !this.isDragging && this.hasDragStarted(m) && this.canDrag(t.target) && this.dragStart(t, e), this.isDragging && this.dragMove(t, e, m)
                }, i.hasDragStarted = function(t) {
                    return Math.abs(t.x) > 3 || Math.abs(t.y) > 3
                }, i.canDrag = function(t) {
                    return !0
                }, i.dragStart = function(t, e) {
                    this.isDragging = !0, this.isPreventingClicks = !0, this.emitEvent("dragStart", [t, e])
                }, i.dragMove = function(t, e, i) {
                    this.emitEvent("dragMove", [t, e, i])
                }, i.onmouseup = function(t) {
                    this.pointerUp(t, t)
                }, i.onpointerup = function(t) {
                    this.withPointer("pointerUp", t)
                }, i.ontouchend = function(t) {
                    this.withTouch("pointerUp", t)
                }, i.pointerUp = function(t, e) {
                    this.pointerDone(), this.emitEvent("pointerUp", [t, e]), this.isDragging ? this.dragEnd(t, e) : this.staticClick(t, e)
                }, i.dragEnd = function(t, e) {
                    this.isDragging = !1, setTimeout(() => {
                        delete this.isPreventingClicks
                    }, 100), this.emitEvent("dragEnd", [t, e])
                }, i.pointerDone = function() {
                    this.isPointerDown = !1, delete this.pointerIdentifier, this.unbindActivePointerEvents(), this.emitEvent("pointerDone")
                }, i.onpointercancel = function(t) {
                    this.withPointer("pointerCancel", t)
                }, i.ontouchcancel = function(t) {
                    this.withTouch("pointerCancel", t)
                }, i.pointerCancel = function(t, e) {
                    this.pointerDone(), this.emitEvent("pointerCancel", [t, e])
                }, i.onclick = function(t) {
                    this.isPreventingClicks && (t.preventDefault(), t.stopPropagation())
                }, i.staticClick = function(t, e) {
                    let i = "mouseup" === t.type;
                    i && this.isIgnoringMouseUp || (this.emitEvent("staticClick", [t, e]), i && (this.isIgnoringMouseUp = !0, setTimeout(() => {
                        delete this.isIgnoringMouseUp
                    }, 400)))
                }
            }

            function h(t) {
                let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                    mode: "bento-grid"
                };
                this.element = "string" == typeof t ? document.querySelector(t) : t, this.options = {
                    mode: "bento-grid"
                }, this.option(e), this._create()
            }
            let p = h.prototype = Object.create(u.prototype);
            p.option = function(t) {
                this.options = { ...this.options,
                    ...t
                }
            };
            let f = ["relative", "absolute", "fixed"];
            p.getWindow = function() {
                return this.element.ownerDocument.defaultView
            }, p._create = function() {
                this.position = {}, this.rect = {
                    left: 0,
                    top: 0
                }, this._getPosition(), this.startPoint = {
                    x: 0,
                    y: 0
                }, this.dragPoint = {
                    x: 0,
                    y: 0
                }, this.startPosition = { ...this.position
                };
                let t = getComputedStyle(this.element);
                f.includes(t.position) || (this.element.style.position = "relative"), this.on("pointerDown", this.handlePointerDown), this.on("pointerUp", this.handlePointerUp), this.on("dragStart", this.handleDragStart), this.on("dragMove", this.handleDragMove), this.on("dragEnd", this.handleDragEnd), this.setHandles(), this.enable()
            }, p.setHandles = function() {
                let {
                    handle: t
                } = this.options;
                t && "string" == typeof t ? this.handles = [this.element.querySelector(t)] : t ? this.handles = [t] : null === t ? this.handles = [] : this.handles = [this.element]
            };
            let m = ["dragStart", "dragMove", "dragEnd"],
                g = p.emitEvent;

            function v(t, e) {
                let i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "round";
                return e ? Math[i = i || "round"](t / e) * e : t
            }
            p.emitEvent = function(t, e) {
                !this.isEnabled && m.includes(t) || g.call(this, t, e)
            }, p._getPosition = function() {
                let t = getComputedStyle(this.element),
                    e = this._getPositionCoord(t.left, "width"),
                    i = this._getPositionCoord(t.top, "height");
                this.position.x = isNaN(e) ? 0 : e, this.position.y = isNaN(i) ? 0 : i, this._addTransformPosition(t)
            }, p._getPositionCoord = function(t, e) {
                if (t.includes("%")) {
                    let i = s(this.element.parentNode);
                    return i ? parseFloat(t) / 100 * i[e] : 0
                }
                return parseInt(t, 10)
            }, p._addTransformPosition = function(t) {
                let e = t.transform;
                if (!e.startsWith("matrix")) return;
                let i = e.split(","),
                    n = e.startsWith("matrix3d") ? 12 : 4,
                    o = parseInt(i[n], 10),
                    r = parseInt(i[n + 1], 10);
                this.position.x += o, this.position.y += r
            }, p.handlePointerDown = function(t, e) {
                this.isEnabled && (this.pointerDownPointer = {
                    pageX: e.pageX,
                    pageY: e.pageY
                }, this.canDrag(t.target) && t.preventDefault(), this.rect = this.element.getBoundingClientRect(), this.bindActivePointerEvents(t), this.element.classList.add("is-pointer-down"))
            }, p.canDrag = function(t) {
                let e = null == t ? void 0 : t.closest('[contenteditable="true"]');
                return t && !e
            }, p.handleDragStart = function(t) {
                if (!this.isEnabled) return;
                this.positioningParent = void 0, this.scrollParent = void 0, this._getPosition(), this.measureContainment(), this.startPosition.x = this.position.x, this.startPosition.y = this.position.y, this.setLeftTop(), this.dragPoint.x = 0, this.dragPoint.y = 0, this.element.classList.add("is-dragging"), this.animate(), this.applyScroll(performance.now());
                let e = t.clientX,
                    i = t.clientY,
                    n = e - this.rect.left,
                    o = i - this.rect.top;
                if ("bento-grid" === this.options.mode) {
                    let t = this.element.querySelector("[data-item-content]");
                    t.style.transformOrigin = "".concat(n, "px ").concat(o, "px")
                }
            }, p.measureContainment = function() {
                let t = this.getContainer();
                if (!t) return;
                let e = s(this.element),
                    i = s(t);
                if (!e || !i) return;
                let {
                    borderLeftWidth: n,
                    borderRightWidth: o,
                    borderTopWidth: r,
                    borderBottomWidth: a
                } = i, d = this.element.getBoundingClientRect(), l = t.getBoundingClientRect(), c = this.relativeStartPosition = {
                    x: d.left - (l.left + n),
                    y: d.top - (l.top + r)
                };
                this.containSize = {
                    width: i.width - (n + o) - c.x - e.width,
                    height: i.height - (r + a) - c.y - e.height
                }
            }, p.getContainer = function() {
                let t = this.options.containment;
                if (t) return t
            }, p.getScrollParent = function() {
                return this.scrollParent || (this.scrollParent = d(this.element), this.scrollParentHeight = this.scrollParent.scrollHeight), this.scrollParent
            }, p.handleDragMove = function(t, e, i) {
                if (!this.isEnabled) return;
                this.moveVectorCached = i;
                let n = i.x,
                    o = i.y,
                    r = this.options.grid,
                    s = r && r[0],
                    a = r && r[1];
                n = v(n, s), o = v(o, a), n = this.containDrag("x", n, s), o = this.containDrag("y", o, a), n = "y" == this.options.axis ? 0 : n, o = "x" == this.options.axis ? 0 : o, this.position.x = this.startPosition.x + n, this.position.y = this.startPosition.y + o, this.dragPoint.x = n, this.dragPoint.y = o
            }, p.applyScroll = function(t) {
                if (!this.isDragging || "bento-grid" !== this.options.mode) return;
                let e = performance.now(),
                    i = (e - t) / 1e3,
                    o = this.getScrollParent();
                if (o) {
                    var r, s, a;
                    let t = o.clientWidth > 700 ? 100 : 200,
                        e = o.ownerDocument.defaultView,
                        d = (null === (r = this.pointer) || void 0 === r ? void 0 : null === (s = r.target) || void 0 === s ? void 0 : s.ownerDocument) !== o.ownerDocument || (null === (a = this.pointer) || void 0 === a ? void 0 : a.target) === o.ownerDocument.documentElement,
                        l = o.scrollTop,
                        c = d ? l - t + this.pointer.pageY : this.pointer.pageY,
                        u = c <= l + t,
                        h = o.clientHeight + o.scrollTop,
                        p = d ? h + (this.pointer.pageY - e.innerHeight) : this.pointer.pageY,
                        f = p >= h - 100,
                        m = (0, n.uZ)((p - (h - 100)) * .05, 0, 9) * i * 120,
                        g = (0, n.uZ)(-(.05 * ((c - (l + t)) * 1)), 0, 9) * i * 120,
                        v = o.scrollTop,
                        y = 0;
                    f ? y = m : u && (y = -g), o.scrollTop + y < this.scrollParentHeight - o.clientHeight + this.element.clientHeight && (o.scrollTop += y);
                    let w = o.scrollTop - v;
                    if ((f || u) && this.moveVectorCached && Math.abs(w) > 0) {
                        let t = {
                            x: this.moveVectorCached.x,
                            y: this.moveVectorCached.y + w
                        };
                        this.emitEvent("dragMove", [void 0, void 0, t])
                    }
                    d || (this.pointer.pageY = this.pointer.pageY + w), this.position.y = this.position.y + w, this.dragPoint.y = this.dragPoint.y + w
                }
                requestAnimationFrame(() => this.applyScroll(e))
            }, p.containDrag = function(t, e, i) {
                if (!this.options.containment) return e;
                let n = v(-this.relativeStartPosition[t], i, "ceil"),
                    o = this.containSize["x" == t ? "width" : "height"];
                return Math.max(n, Math.min(o = v(o, i, "floor"), e))
            }, p.handlePointerUp = function(t) {
                this.element.classList.remove("is-pointer-down")
            }, p.handleDragEnd = function(t) {
                this.isEnabled && (this.moveVectorCached = void 0, this.element.classList.remove("is-dragging"))
            }, p.animate = function() {
                this.isDragging && (this.positionDrag(), requestAnimationFrame(() => this.animate()))
            }, p.setLeftTop = function() {
                let {
                    x: t,
                    y: e
                } = this.position;
                "bento-grid" === this.options.mode && (this.element.style.transform = "translate(".concat(t, "px, ").concat(e, "px)"))
            }, p.positionDrag = function() {
                let {
                    x: t,
                    y: e
                } = this.startPosition, {
                    x: i,
                    y: n
                } = this.dragPoint;
                "bento-grid" === this.options.mode && (this.element.style.transform = "translate3d(".concat(t + i, "px, ").concat(e + n, "px, 0)"))
            }, p.setPosition = function(t, e) {
                this.position.x = t, this.position.y = e, this.setLeftTop()
            }, p.enable = function() {
                this.isEnabled || (this.isEnabled = !0, this.bindHandles())
            }, p.disable = function() {
                this.isEnabled && (this.isEnabled = !1, this.isDragging && this.dragEnd(), this.unbindHandles())
            }, p.destroy = function() {
                this.disable(), this.unbindHandles(), this.$element && this.$element.removeData("draggabilly")
            };
            let y = h
        },
        88242: function(t, e, i) {
            "use strict";
            i.d(e, {
                A: function() {
                    return o
                }
            });
            var n = i(40624);
            let o = (0, n.Ue)(t => ({
                engine: void 0,
                dragging: void 0,
                device: "desktop",
                setDevice: e => t(t => ({ ...t,
                    device: e
                })),
                setEngine: e => t(t => ({ ...t,
                    engine: e
                })),
                setDragging: e => t(t => ({ ...t,
                    dragging: e
                }))
            }))
        },
        8362: function(t, e, i) {
            "use strict";
            i.d(e, {
                ru: function() {
                    return l
                },
                I5: function() {
                    return u
                }
            });
            var n = i(24920),
                o = i(99864),
                r = i(98696),
                s = i(84326),
                a = i(1753);
            let d = (t, e, i) => {
                    let n = (0, a.tJ)(t, i),
                        r = [...t];
                    return (0, s.D)(e).forEach(t => {
                        var e, s;
                        let a = null !== (e = t.data.pos[i].x) && void 0 !== e ? e : 0,
                            d = null !== (s = t.data.pos[i].y) && void 0 !== s ? s : 0,
                            l = !1;
                        for (; !l;) {
                            let e = !0;
                            for (let r = 0; r < t.dim.h; r++)
                                for (let s = 0; s < t.dim.w; s++)(void 0 === n[d + r] || void 0 === n[d + r][a + s]) && (n[d + r] = Array((0, o.D)(i)).fill(!1)), !0 === n[d + r][a + s] && (e = !1);
                            e ? l = !0 : d++
                        }
                        for (let e = 0; e < t.dim.h; e++)
                            for (let i = 0; i < t.dim.w; i++) n[d + e][a + i] = !0;
                        r.push({ ...t,
                            pos: {
                                x: a,
                                y: d
                            }
                        })
                    }), r
                },
                l = (t, e) => {
                    let i = t.filter(t => "ghost" === t.type),
                        n = t.filter(t => "ghost" !== t.type),
                        o = (0, s.D)((0, r.F)(c(u(n, e), e))),
                        a = (0, s.D)((0, r.F)(c(d(o, i, e), e)));
                    return a
                },
                c = (t, e) => {
                    let i = (0, o.D)(e);
                    return t.map(t => ({ ...t,
                        pos: {
                            x: (0, n.uZ)(t.pos.x, 0, i - t.dim.w),
                            y: t.pos.y
                        }
                    }))
                },
                u = (t, e) => {
                    let i = (0, o.D)(e);
                    return t.map(t => ({ ...t,
                        dim: {
                            w: "dynamic" === t.mode ? i : t.dim.w,
                            h: t.dim.h
                        }
                    }))
                }
        },
        99864: function(t, e, i) {
            "use strict";
            i.d(e, {
                D: function() {
                    return n
                }
            });
            let n = t => "desktop" === t ? 8 : 4
        },
        98696: function(t, e, i) {
            "use strict";
            i.d(e, {
                F: function() {
                    return r
                }
            });
            var n = i(6357),
                o = i(84326);
            let r = t => {
                let e = (0, o.D)(t),
                    i = (0, n.N_)(t),
                    r = Array(i).fill(0);
                return e.map(t => {
                    let e = e => e >= t.pos.x && e < t.pos.x + t.dim.w,
                        i = r.filter((t, i) => e(i)),
                        n = i.reduce((t, e) => Math.max(t, e), 0);
                    return r = r.map((i, o) => e(o) ? n + t.dim.h : i), { ...t,
                        pos: { ...t.pos,
                            y: n
                        }
                    }
                })
            }
        },
        6357: function(t, e, i) {
            "use strict";
            i.d(e, {
                AQ: function() {
                    return n
                },
                N_: function() {
                    return o
                }
            });
            let n = t => t.reduce((t, e) => Math.max(t, e.pos.y + e.dim.h), 0),
                o = t => t.reduce((t, e) => Math.max(t, e.pos.x + e.dim.w), 0)
        },
        1753: function(t, e, i) {
            "use strict";
            i.d(e, {
                ju: function() {
                    return l
                },
                BW: function() {
                    return c
                },
                tJ: function() {
                    return d
                }
            });
            var n = i(8362),
                o = i(99864),
                r = i(6357),
                s = i(33541);
            let a = t => t.filter(t => "ghost" !== t.type),
                d = (t, e) => {
                    let i = (0, o.D)(e),
                        n = (0, r.AQ)(t) + 1,
                        s = Array(n).fill(null).map(t => Array(i).fill(!1));
                    for (let e of t) {
                        let t = e.pos.y,
                            i = t + e.dim.h,
                            n = e.pos.x,
                            o = n + e.dim.w;
                        for (let e = t; e < i; e++)
                            for (let t = n; t < o; t++) s[e][t] = !0
                    }
                    return s
                },
                l = function(t, e, i) {
                    var s, l;
                    let c = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0,
                        u = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                        h = (0, o.D)(i),
                        p = (0, n.ru)(u ? e : a(e), i),
                        f = (0, r.AQ)(p) + 1,
                        m = null !== (s = null == c ? void 0 : c.top) && void 0 !== s ? s : 0,
                        g = Math.min(null !== (l = null == c ? void 0 : c.bottom) && void 0 !== l ? l : 1e7, f - 1),
                        v = d(p, i);
                    for (let e = g - 1; e >= m; e--)
                        for (let i = 0; i <= h - t.w; i++) {
                            let n = !1;
                            for (let o = 0; o < t.w; o++) {
                                for (let r = 0; r < t.h && !(e + r >= Math.min(f, v.length)); r++)
                                    if (v[e + r][i + o]) {
                                        n = !0;
                                        break
                                    }
                                if (n) break
                            }
                            if (!n) return {
                                y: e,
                                x: i
                            }
                        }
                    return g + 2 > f ? {
                        x: 0,
                        y: f
                    } : {
                        x: Math.floor(h / 2),
                        y: Math.max(Math.floor((g - m) / 2) + m - 2, 0)
                    }
                },
                c = (t, e, i, n) => {
                    let r = (0, s.H)(i, e),
                        a = (0, o.D)(n),
                        l = d(e, n);
                    for (let e = r.start; e <= r.end + 1; e++)
                        for (let i = 0; i <= a - t.w; i++) {
                            let n = !1;
                            for (let o = 0; o < t.w; o++) {
                                for (let s = 0; s < t.h && !(e + s >= Math.min(r.end + 1, l.length)); s++)
                                    if (l[e + s][i + o]) {
                                        n = !0;
                                        break
                                    }
                                if (n) break
                            }
                            if (!n) return {
                                y: e,
                                x: i
                            }
                        }
                    return {
                        x: 0,
                        y: r.end
                    }
                }
        },
        46679: function(t, e, i) {
            "use strict";
            i.d(e, {
                F_: function() {
                    return o
                },
                ef: function() {
                    return s
                },
                sr: function() {
                    return a
                },
                zO: function() {
                    return r
                }
            });
            var n = i(99864);
            let o = t => {
                    t.forEach(t => {
                        if (!t.pos) throw Error("GridItem ".concat(t.id, " does not have a position/dimension"))
                    })
                },
                r = (t, e) => {
                    let i = (0, n.D)(e);
                    t.forEach(t => {
                        if ("dynamic" === t.mode && t.dim.w !== i) throw Error("GridItem ".concat(t.id, " is dynamic but not full width"));
                        if (t.dim.w > i) throw Error("GridItem ".concat(t.id, " width exceeds columns"))
                    })
                },
                s = t => {
                    t.forEach((t, e, i) => {
                        let n = i.find(e => e.pos.x === t.pos.x && e.pos.y === t.pos.y && e.id !== t.id);
                        if (n) throw Error("GridItem ".concat(t.id, " overlaps with ").concat(n.id, " width exceeds columns"))
                    })
                },
                a = t => {
                    let e = t.desktop,
                        i = t.mobile;
                    e.forEach(t => {
                        let e = i.find(e => e.id === t.id);
                        if (!e) throw Error("GridItem ".concat(t.id, " is not present on mobile but exists on desktop"))
                    }), i.forEach(t => {
                        let i = e.find(e => e.id === t.id);
                        if (!i) throw Error("GridItem ".concat(t.id, " is not present on desktop but exists on mobile"))
                    })
                }
        },
        32845: function(t, e, i) {
            "use strict";
            i.d(e, {
                dc: function() {
                    return u
                },
                ZB: function() {
                    return p
                }
            });
            let n = (t, e, i, n) => {
                    let o = n.filter(n => n.pos.y < t && n.pos.y + n.dim.h > t && n.pos.x < i && n.pos.x + n.dim.w > e);
                    return 0 === o.length
                },
                o = t => t < 67.5 && t >= 22.5 ? "SE" : t < 157.5 && t >= 112.5 ? "SW" : t < -22.5 && t >= -67.5 ? "NE" : t < -112.5 && t >= -157.5 ? "NW" : t < -67.5 && t >= -112.5 ? "N" : t < 22.5 && t >= -22.5 ? "E" : t < 112.5 && t >= 67.5 ? "S" : t < -157.5 || t >= 157.5 ? "W" : "N",
                r = (t, e, i) => i.map(i => {
                    let n = Math.max(t.x, i.pos.x),
                        o = Math.min(t.x + e.w, i.pos.x + i.dim.w),
                        r = Math.max(t.y, i.pos.y),
                        s = Math.min(t.y + e.h, i.pos.y + i.dim.h);
                    if (n >= o || r >= s) return;
                    let a = n - i.pos.x,
                        d = i.pos.x + i.dim.w - o,
                        l = r - i.pos.y,
                        c = i.pos.y + i.dim.h - s;
                    return {
                        item: i,
                        area: {
                            x: n,
                            y: r,
                            w: o - n,
                            h: s - r
                        },
                        gravityY: l - c,
                        gravityX: a - d
                    }
                }).filter(t => !!t),
                s = (t, e) => r(t.pos, t.dim, e.filter(e => e.id !== t.id)),
                a = (t, e, i) => {
                    let n = s(t, e);
                    if (0 === n.length) return t.pos.y;
                    let r = o(i),
                        a = n.reduce((t, e) => t && Math.sign(e.gravityY) === Math.sign(n[0].gravityY), !0),
                        d = n.reduce((t, e) => e.gravityY < 0 ? Math.min(t, e.item.pos.y) : e.gravityY > 0 ? Math.max(t, e.item.pos.y + e.item.dim.h - 1) : ["S", "SE", "SW"].includes(r) ? Math.max(t, e.item.pos.y + e.item.dim.h - 1) : ["N", "NE", "NW"].includes(r) ? Math.min(t, e.item.pos.y) : t, t.pos.y);
                    return a ? d : t.pos.y
                };
            var d = i(98696);
            let l = (t, e, i) => {
                    let n = t.map(t => ({
                            item: t,
                            amount: i
                        })),
                        o = t.map(t => ({
                            item: t,
                            amount: i
                        }));
                    for (; o.length > 0;) {
                        let t = [...o];
                        o = [], t.forEach(t => {
                            let i = t.item,
                                r = t.amount,
                                s = e.filter(t => {
                                    let e = t.pos.y > i.pos.y && t.pos.y < i.pos.y + i.dim.h + r,
                                        n = t.pos.x + t.dim.w > i.pos.x && t.pos.x < i.pos.x + i.dim.w;
                                    return e && n
                                });
                            s.forEach(t => {
                                let e = Math.max(t.pos.y - (i.pos.y + i.dim.h), 0),
                                    s = r - e;
                                n.push({
                                    item: t,
                                    amount: s
                                }), o.push({
                                    item: t,
                                    amount: s
                                })
                            })
                        })
                    }
                    return e.map(t => {
                        let e = n.filter(e => e.item.id === t.id),
                            i = e.reduce((t, e) => Math.max(t, e.amount), 0);
                        return 0 === i ? t : { ...t,
                            pos: { ...t.pos,
                                y: t.pos.y + i
                            }
                        }
                    })
                },
                c = (t, e, i, n, o) => {
                    let s = r({
                        x: e,
                        y: t
                    }, {
                        w: i - e,
                        h: o
                    }, n).map(t => t.item);
                    return l(s, n, o)
                },
                u = (t, e, i) => e.map(e => e.pos.y < t ? e : { ...e,
                    pos: { ...e.pos,
                        y: e.pos.y + i
                    }
                }),
                h = (t, e, i) => {
                    let r = { ...t,
                            pos: { ...t.pos,
                                y: a(t, e, i)
                            }
                        },
                        u = (0, d.F)(e),
                        p = s(r, u),
                        f = u.filter(t => t.id !== r.id),
                        m = f.concat(r),
                        g = p.filter(t => t.gravityY <= 0),
                        v = o(i);
                    return ["S", "SE", "SW"].includes(v) ? n(r.pos.y + 1, r.pos.x, r.pos.x + r.dim.w, f) ? c(r.pos.y + 1, r.pos.x, r.pos.x + r.dim.w, f, r.dim.h).concat({ ...r,
                        pos: { ...r.pos,
                            y: r.pos.y + 1
                        }
                    }) : e : ["N", "NE", "NW"].includes(v) ? n(r.pos.y, r.pos.x, r.pos.x + r.dim.w, f) ? h(r, e, i - 180) : e : n(r.pos.y, r.pos.x, r.pos.x + r.dim.w, f) ? l(g.map(t => t.item), m, r.dim.h) : n(r.pos.y + r.dim.h, r.pos.x, r.pos.x + r.dim.w, m) ? h({ ...t,
                        pos: { ...t.pos,
                            y: r.pos.y + 1
                        }
                    }, e, i) : e
                },
                p = (t, e, i, n) => {
                    let r = (0, d.F)(i),
                        a = o(n);
                    if ("E" === a || "W" === a) {
                        let n = s(e, r),
                            o = n.length > 0 && n.every(t => {
                                let e = t.area.h === t.item.dim.h && "ghost" !== t.item.type;
                                return e
                            });
                        if (o && t.pos.y === e.pos.y) {
                            if (n.some(i => Math.sign(i.gravityX) * Math.sign(e.pos.x - t.pos.x) < 0)) return i;
                            let o = n.reduce((t, e) => Math.min(t, e.item.pos.x), 1e3),
                                r = n.reduce((t, e) => Math.max(e.item.dim.w, t), 0),
                                s = n.find(t => t.item.dim.w === r),
                                a = e.pos.x > t.pos.x ? t.pos.x : t.pos.x + t.dim.w - s.item.dim.w,
                                d = e.pos.x > t.pos.x ? s.item.pos.x + s.item.dim.w - t.dim.w : s.item.pos.x;
                            return i.map(i => {
                                if (i.id === t.id) return { ...e,
                                    pos: { ...e.pos,
                                        x: d
                                    }
                                };
                                if (n.findIndex(t => t.item.id === i.id) >= 0) return { ...i,
                                    pos: { ...i.pos,
                                        x: a + (i.pos.x - o)
                                    }
                                };
                                let s = i.pos.x >= o && i.pos.x + i.dim.w <= o + r && i.pos.y >= t.pos.y && i.pos.y + i.dim.h <= t.pos.y + t.dim.h;
                                return s ? { ...i,
                                    pos: { ...i.pos,
                                        x: a + (i.pos.x - o)
                                    }
                                } : i
                            })
                        }
                    }
                    return h(e, r, n)
                }
        },
        98478: function(t, e, i) {
            "use strict";
            i.d(e, {
                X: function() {
                    return a
                },
                f: function() {
                    return d
                }
            });
            var n = i(8362),
                o = i(1753);
            let r = (t, e) => {
                    let i = [],
                        n = t.filter(t => !!t.pos),
                        r = t.filter(t => !t.pos);
                    return i.push(...n), r.forEach(t => {
                        i.push({ ...t,
                            pos: (0, o.ju)(t.dim, i, "mobile", void 0, "ghost" === t.type)
                        })
                    }), i
                },
                s = (t, e) => {
                    let i = [],
                        n = t.filter(t => !!t.pos),
                        r = t.filter(t => !t.pos);
                    return i.push(...n), r.forEach(t => {
                        i.push({ ...t,
                            pos: (0, o.ju)(t.dim, i, "desktop", void 0, "ghost" === t.type)
                        })
                    }), i
                },
                a = (t, e) => {
                    let i = Object.keys(e).map(t => parseInt(t));
                    return i.reduce((i, n) => t >= n ? e[n] : i, "desktop")
                },
                d = (t, e) => "desktop" === e ? s((0, n.I5)(t.desktop, "desktop"), (0, n.I5)(t.mobile, "mobile")) : r((0, n.I5)(t.mobile, "mobile"), (0, n.I5)(t.desktop, "desktop"))
        },
        94905: function(t, e, i) {
            "use strict";
            i.d(e, {
                d: function() {
                    return n
                }
            });
            let n = (t, e) => e.filter(e => e.pos.y === t)
        },
        33541: function(t, e, i) {
            "use strict";
            i.d(e, {
                C: function() {
                    return o
                },
                H: function() {
                    return r
                }
            });
            var n = i(84326);
            let o = (t, e) => {
                    let i;
                    let o = e.find(e => e.id === t);
                    if (!o) throw Error("Item with id ".concat(t, " not found"));
                    let r = (0, n.D)(e),
                        s = -1;
                    for (let t of r) "section-header" === t.type && t.pos.y < o.pos.y && t.pos.y > s && (i = t.id, s = t.pos.y);
                    return i
                },
                r = (t, e) => {
                    var i, o, r;
                    let s = e.find(e => e.id === t),
                        a = (0, n.D)(e),
                        d = {
                            start: null !== (i = null == s ? void 0 : s.pos.y) && void 0 !== i ? i : 0,
                            end: (null !== (o = null == s ? void 0 : s.pos.y) && void 0 !== o ? o : 0) + (null !== (r = null == s ? void 0 : s.dim.h) && void 0 !== r ? r : 0),
                            items: []
                        },
                        l = !1;
                    return a.forEach(e => {
                        if ("section-header" === e.type && e.id !== t && e.pos.y >= d.start) {
                            l = !0;
                            return
                        }
                        e.pos.y >= d.start && !l && (d.items.push(e), d.end = e.pos.y + e.dim.h)
                    }), d
                }
        },
        84326: function(t, e, i) {
            "use strict";
            i.d(e, {
                D: function() {
                    return n
                }
            });
            let n = t => t.sort((t, e) => t.pos.y - e.pos.y || t.pos.x - e.pos.x)
        },
        94775: function(t, e, i) {
            "use strict";
            i.d(e, {
                EM: function() {
                    return g
                },
                iJ: function() {
                    return l
                },
                sq: function() {
                    return m
                },
                xm: function() {
                    return h
                }
            });
            var n = i(99864),
                o = i(24920);
            let r = {
                    "1x4": 4,
                    "2x2": 2,
                    "4x4": 4,
                    "2x4": 4,
                    "4x2": 2
                },
                s = {
                    "1x4": 1,
                    "2x2": 2,
                    "4x4": 4,
                    "2x4": 2,
                    "4x2": 4
                },
                a = function(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "desktop";
                    switch (t.type) {
                        case "section-header":
                            return -1;
                        case "ghost":
                        case "ghost-materialized":
                            return t.dim[e].w;
                        default:
                            return r[(0, o.f6)(t.style, e)]
                    }
                },
                d = function(t) {
                    let e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "desktop";
                    switch (t.type) {
                        case "section-header":
                            return 1;
                        case "ghost":
                        case "ghost-materialized":
                            return t.dim[e].h;
                        default:
                            return s[(0, o.f6)(t.style, e)]
                    }
                },
                l = t => "section-header" === t.type ? "dynamic" : "fixed",
                c = t => "section-header" === t.type ? "section-header" : "widget",
                u = (t, e) => {
                    let i = (0, o.OX)(t.position, e);
                    if (i) return {
                        x: i.x,
                        y: i.y
                    }
                },
                h = (t, e, i) => ({
                    h: d(e, i),
                    w: "dynamic" === t ? (0, n.D)(i) : a(e, i)
                }),
                p = (t, e) => {
                    let {
                        data: i
                    } = t;
                    return {
                        id: i.id,
                        type: c(i),
                        mode: "dynamic",
                        pos: u(t, e),
                        dim: h("dynamic", t.data, e),
                        data: i
                    }
                },
                f = (t, e) => {
                    let {
                        data: i
                    } = t;
                    return {
                        id: i.id,
                        type: c(i),
                        mode: "fixed",
                        pos: u(t, e),
                        dim: h("fixed", t.data, e),
                        data: i
                    }
                },
                m = (t, e) => {
                    let i = t.items.filter(t => "ghost" === t.data.type || "ghost-materialized" === t.data.type),
                        n = t.items.filter(t => "ghost" !== t.data.type && "ghost-materialized" !== t.data.type),
                        o = n.map(t => "dynamic" === l(t.data) ? p(t, e) : f(t, e));
                    return i.filter(t => !!t.data.dim[e]).forEach(t => {
                        o.push({
                            id: t.data.id,
                            type: t.data.type,
                            data: t.data,
                            dim: {
                                h: t.data.dim[e].h,
                                w: t.data.dim[e].w
                            },
                            mode: "fixed",
                            pos: u(t, e)
                        })
                    }), o
                },
                g = t => ({
                    mobile: m(t, "mobile"),
                    desktop: m(t, "desktop")
                })
        },
        66563: function(t, e, i) {
            "use strict";
            i.d(e, {
                f: function() {
                    return d
                }
            });
            var n = i(97008),
                o = i(24920);
            let r = "default",
                s = t => ["added a link", "added a map", "added a section", "added a text widget", "added a video", "added an image"].includes(t),
                a = t => ["edited bio", "renamed a section", "set a caption"].includes(t),
                d = new class {
                    push(t) {
                        this.id++, this.actions.push(t)
                    }
                    movedWidget(t) {
                        this.push({
                            id: t,
                            action: "moved a widget"
                        })
                    }
                    removedWidget(t) {
                        this.push({
                            id: t,
                            action: "removed a widget"
                        })
                    }
                    resizedWidget(t) {
                        this.push({
                            id: t,
                            action: "resized a widget"
                        })
                    }
                    addedVideo(t) {
                        this.push({
                            id: t,
                            action: "added a video"
                        })
                    }
                    addedImage(t) {
                        this.push({
                            id: t,
                            action: "added an image"
                        })
                    }
                    addedRichText(t) {
                        this.push({
                            id: t,
                            action: "added a text widget"
                        })
                    }
                    addedSection(t) {
                        this.push({
                            id: t,
                            action: "added a section"
                        })
                    }
                    bioEdited() {
                        this.push({
                            id: r + "-bio",
                            action: "edited bio"
                        })
                    }
                    avatarChanged() {
                        this.push({
                            id: r + "-avatar",
                            action: "changed avatar"
                        })
                    }
                    renamedSection(t, e) {
                        this.push({
                            id: t,
                            action: "renamed a section",
                            payload: {
                                title: e
                            }
                        })
                    }
                    addedLink(t, e) {
                        let i = (0, o.w6)(e).topLevelHostname;
                        (0, n._N)(e) ? this.push({
                            id: t,
                            action: "added a map"
                        }): this.push({
                            id: t,
                            action: "added a link",
                            payload: {
                                hostname: i
                            }
                        })
                    }
                    setCaption(t, e) {
                        e ? this.push({
                            id: t,
                            action: "set a caption",
                            payload: {
                                caption: e
                            }
                        }) : this.push({
                            id: t,
                            action: "removed a caption",
                            payload: {
                                caption: e
                            }
                        })
                    }
                    collapsed() {
                        let t = [...new Set(this.actions.map(t => t.id))],
                            e = t.map(t => {
                                let e = this.actions.filter(e => e.id === t),
                                    i = t => t ? t.trim().replace(/\n/g, "").replace(/"/g, "'").slice(0, 30) + (t.length > 30 ? "..." : "") : void 0,
                                    n = e.filter(t => a(t.action)).pop(),
                                    o = s(e[0].action),
                                    r = !!n,
                                    d = "removed a widget" === e[e.length - 1].action;
                                if (e.some(t => "moved a widget" === t.action), e.some(t => "resized a widget" === t.action), (!d || !o) && !d) return e.filter((t, e, i) => (!a(t.action) || !o) && (a(t.action) ? -1 === i.findIndex((i, n) => i.action === t.action && n > e) : (!!d || "removed a widget" !== t.action) && i.findIndex(e => e.action === t.action) === e)).map(t => {
                                    var e, o, s, a, d, l, c;
                                    switch (t.action) {
                                        case "added a video":
                                            return "added a video" + (r ? ' with the caption "'.concat(i(null === (e = n.payload) || void 0 === e ? void 0 : e.caption), '"') : "");
                                        case "added an image":
                                            return "added an image" + (r ? ' with the caption "'.concat(i(null === (o = n.payload) || void 0 === o ? void 0 : o.caption), '"') : "");
                                        case "added a text widget":
                                            return "added a text widget";
                                        case "added a section":
                                            return "added a section" + (r ? ' with the title "'.concat(i(null === (s = n.payload) || void 0 === s ? void 0 : s.title), '"') : "");
                                        case "added a link":
                                            return "added a link widget linking to ".concat(null === (a = t.payload) || void 0 === a ? void 0 : a.hostname);
                                        case "added a map":
                                            return "added a map widget" + (r ? ' with the caption "'.concat(i(null === (d = n.payload) || void 0 === d ? void 0 : d.caption), '"') : "");
                                        case "edited bio":
                                            return "edited bio";
                                        case "renamed a section":
                                            return 'renamed a section to "'.concat(i(null === (l = t.payload) || void 0 === l ? void 0 : l.title), '"');
                                        case "set a caption":
                                            return 'set a caption to "'.concat(i(null === (c = t.payload) || void 0 === c ? void 0 : c.caption), '"');
                                        case "removed a caption":
                                        case "changed avatar":
                                        case "resized a widget":
                                            return;
                                        case "moved a widget":
                                            return "moved a widget";
                                        default:
                                            throw Error('Unknown action "' + t.action + '"')
                                    }
                                }).filter(t => !!t)
                            });
                        return e.filter(t => !!t).flat()
                    }
                    getEntries() {
                        return [...this.actions]
                    }
                    getActionsSummary() {
                        return this.collapsed()
                    }
                    getId() {
                        return this.id
                    }
                    getActionsSummaryText() {
                        let t = this.collapsed().map(t => "- ".concat(t)).join("\n");
                        return t
                    }
                    reset() {
                        this.actions = []
                    }
                    constructor(t) {
                        this.actions = null != t ? t : [], this.id = 0
                    }
                }
        },
        45195: function(t) {
            t.exports = {
                "rich-text-widget": "styles_rich-text-widget__ZjrrY",
                padding: "styles_padding__bEEwZ",
                container: "styles_container__ZHlJa",
                "rich-text-widget--1x4": "styles_rich-text-widget--1x4___J1gm",
                "rich-text-widget--transitioning": "styles_rich-text-widget--transitioning__Hn1G2",
                "rich-text-widget--editing": "styles_rich-text-widget--editing__DvjRj",
                "fake-hover": "styles_fake-hover__ErPv4",
                "rich-text-widget--4x4": "styles_rich-text-widget--4x4__Xfvde",
                "rich-text-widget--focused": "styles_rich-text-widget--focused__7LhuN",
                "rich-text-widget--mouse": "styles_rich-text-widget--mouse__P2xwM",
                "rich-text-widget--mode-emoji": "styles_rich-text-widget--mode-emoji__mY3cr",
                "rich-text-widget--mode-symbol": "styles_rich-text-widget--mode-symbol__aEAA0",
                "rich-text-widget--valign-middle": "styles_rich-text-widget--valign-middle__22XQQ",
                "rich-text-widget--valign-bottom": "styles_rich-text-widget--valign-bottom__4sX7T",
                "rich-text-widget--halign-left": "styles_rich-text-widget--halign-left__oOOJJ",
                "rich-text-widget--halign-center": "styles_rich-text-widget--halign-center__VC3oB",
                "rich-text-widget--halign-right": "styles_rich-text-widget--halign-right__xwRPR"
            }
        },
        7777: function(t) {
            t.exports = {
                widget: "styles_widget___JC_t",
                "widget--rounding-xs": "styles_widget--rounding-xs__9Bk59",
                "widget--rounding-sm": "styles_widget--rounding-sm__YoSgZ",
                "widget--rounding-md": "styles_widget--rounding-md__rZYhh",
                "widget--rounding-lg": "styles_widget--rounding-lg__bZFfd",
                "widget--selected": "styles_widget--selected__mnVxq",
                "widget--editing": "styles_widget--editing__RZiAA",
                "widget--no-select": "styles_widget--no-select__mfonZ",
                widget__clip: "styles_widget__clip__417b_",
                widget__content: "styles_widget__content__GAekn",
                "widget__content--snap": "styles_widget__content--snap__v7zti",
                widget__border: "styles_widget__border__mnIDF",
                "widget__border-highlight": "styles_widget__border-highlight__wP_ik",
                "widget--bordered": "styles_widget--bordered__eKEvv",
                "widget--elevated": "styles_widget--elevated__5whS8",
                "widget--hover-elevated": "styles_widget--hover-elevated__ru_L1",
                "widget--clickable": "styles_widget--clickable__zPkxQ",
                "widget--scrollable": "styles_widget--scrollable__jHT_1",
                "widget--attention-dim": "styles_widget--attention-dim__IZeoX",
                "widget--highlight-partial": "styles_widget--highlight-partial__40XJd",
                "widget--highlight-full": "styles_widget--highlight-full__as4Un"
            }
        }
    }
]);