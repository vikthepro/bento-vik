(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [616], {
        53778: function(e, t, i) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/[handle]", function() {
                return i(19399)
            }])
        },
        88285: function(e, t, i) {
            "use strict";
            i.d(t, {
                t: function() {
                    return n
                },
                w: function() {
                    return s
                }
            });
            var l = i(17385);
            let [s, n] = (0, l.Z)({
                map: void 0,
                marker: void 0
            })
        },
        68278: function(e, t, i) {
            "use strict";
            i.d(t, {
                Y: function() {
                    return s
                }
            });
            var l = i(52322);
            let s = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, l.jsx)("svg", {
                    width: t,
                    height: t,
                    className: i,
                    viewBox: "0 0 20 20",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, l.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M6.70726 5.70711C7.09778 5.31658 7.09778 4.68342 6.70726 4.29289C6.31673 3.90237 5.68357 3.90237 5.29304 4.29289L0.303336 9.2826C0.116245 9.46432 0 9.71858 0 10C0 10.2814 0.116249 10.5357 0.303346 10.7174L5.29304 15.7071C5.68357 16.0976 6.31673 16.0976 6.70726 15.7071C7.09778 15.3166 7.09778 14.6834 6.70726 14.2929L3.41436 11H19C19.5523 11 20 10.5523 20 10C20 9.44772 19.5523 9 19 9H3.41436L6.70726 5.70711Z",
                        fill: "currentColor"
                    })
                })
            }
        },
        3207: function(e, t, i) {
            "use strict";
            i.d(t, {
                r: function() {
                    return s
                }
            });
            var l = i(52322);
            let s = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, l.jsx)("svg", {
                    width: t,
                    height: t,
                    className: i,
                    viewBox: "0 0 16 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, l.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M7 14C10.866 14 14 10.866 14 7C14 3.13401 10.866 0 7 0C3.13401 0 0 3.13401 0 7C0 10.866 3.13401 14 7 14ZM10.7071 5.70711C11.0976 5.31658 11.0976 4.68342 10.7071 4.29289C10.3166 3.90237 9.68342 3.90237 9.29289 4.29289L6 7.58579L4.70711 6.29289C4.31658 5.90237 3.68342 5.90237 3.29289 6.29289C2.90237 6.68342 2.90237 7.31658 3.29289 7.70711L5.29289 9.70711C5.68342 10.0976 6.31658 10.0976 6.70711 9.70711L10.7071 5.70711Z",
                        fill: "currentColor"
                    })
                })
            }
        },
        73047: function(e, t, i) {
            "use strict";
            i.d(t, {
                u: function() {
                    return s
                }
            });
            var l = i(52322);
            let s = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    className: i,
                    viewBox: "0 0 16 17",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, l.jsx)("rect", {
                        y: "12.5",
                        width: "16",
                        height: "2",
                        rx: "1",
                        fill: "currentColor"
                    }), (0, l.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M6.8 4.5H9.2C10.0731 4.5 10.6076 4.50156 11.0075 4.53423C11.1938 4.54945 11.3065 4.56857 11.375 4.58469C11.4076 4.59236 11.4276 4.59879 11.4384 4.60265C11.4488 4.60636 11.4532 4.60858 11.454 4.60899C11.6422 4.70487 11.7951 4.85785 11.891 5.04601C11.8914 5.04681 11.8936 5.05118 11.8973 5.06158C11.9012 5.07241 11.9076 5.09244 11.9153 5.125C11.9314 5.19345 11.9505 5.30617 11.9658 5.49247C11.9984 5.89239 12 6.42692 12 7.3V11.5H14V7.3C14 5.61984 14 4.77976 13.673 4.13803C13.3854 3.57354 12.9265 3.1146 12.362 2.82698C11.7202 2.5 10.8802 2.5 9.2 2.5H6.8C5.11984 2.5 4.27976 2.5 3.63803 2.82698C3.07354 3.1146 2.6146 3.57354 2.32698 4.13803C2 4.77976 2 5.61984 2 7.3V11.5H4V7.3C4 6.42692 4.00156 5.89239 4.03423 5.49247C4.04945 5.30617 4.06857 5.19345 4.08469 5.125C4.09236 5.09244 4.09879 5.07241 4.10265 5.06158C4.10636 5.05118 4.10858 5.04681 4.10899 5.04601C4.20487 4.85785 4.35785 4.70487 4.54601 4.60899C4.54681 4.60858 4.55118 4.60636 4.56158 4.60265C4.57241 4.59879 4.59244 4.59236 4.625 4.58469C4.69345 4.56857 4.80617 4.54945 4.99247 4.53423C5.39239 4.50156 5.92692 4.5 6.8 4.5Z",
                        fill: "currentColor"
                    })]
                })
            }
        },
        97731: function(e, t, i) {
            "use strict";
            i.d(t, {
                x: function() {
                    return s
                }
            });
            var l = i(52322);
            let s = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, l.jsx)("svg", {
                    width: t,
                    height: t,
                    className: i,
                    viewBox: "0 0 18 18",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, l.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M3.95034 13.8492C5.12191 15.0208 7.02141 15.0208 8.19298 13.8492L9.6072 12.435C9.99772 12.0445 10.6309 12.0445 11.0214 12.435C11.4119 12.8256 11.4119 13.4587 11.0214 13.8492L9.6072 15.2635C7.65457 17.2161 4.48875 17.2161 2.53613 15.2635C0.583506 13.3108 0.583507 10.145 2.53613 8.19239L3.95034 6.77817C4.34087 6.38765 4.97403 6.38765 5.36455 6.77817C5.75508 7.1687 5.75508 7.80186 5.36455 8.19239L3.95034 9.6066C2.77877 10.7782 2.77877 12.6777 3.95034 13.8492ZM12.4356 9.6066L13.8498 8.19239C15.0214 7.02082 15.0214 5.12132 13.8498 3.94975C12.6783 2.77817 10.7788 2.77817 9.6072 3.94975L8.19298 5.36396C7.80246 5.75449 7.16929 5.75449 6.77877 5.36396C6.38824 4.97344 6.38824 4.34027 6.77877 3.94975L8.19298 2.53553C10.1456 0.582913 13.3114 0.582913 15.264 2.53553C17.2167 4.48816 17.2167 7.65398 15.264 9.6066L13.8498 11.0208C13.4593 11.4113 12.8261 11.4113 12.4356 11.0208C12.0451 10.6303 12.0451 9.99713 12.4356 9.6066ZM11.7285 7.48528C12.119 7.09476 12.119 6.46159 11.7285 6.07107C11.338 5.68054 10.7048 5.68054 10.3143 6.07107L6.07166 10.3137C5.68114 10.7042 5.68114 11.3374 6.07166 11.7279C6.46219 12.1184 7.09535 12.1184 7.48588 11.7279L11.7285 7.48528Z",
                        fill: "currentColor"
                    })
                })
            }
        },
        22447: function(e, t, i) {
            "use strict";
            i.d(t, {
                l: function() {
                    return s
                }
            });
            var l = i(52322);
            let s = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    className: i,
                    viewBox: "0 0 16 16",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, l.jsx)("g", {
                        "clip-path": "url(#clip0_6929_20189)",
                        children: (0, l.jsx)("path", {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M8.19825 7.64476L9.33897 10.2117L11.073 4.36251L5.26227 6.5365L8.19825 7.64476ZM6.71001 9.22073L2.06646 7.46792C1.20265 7.14185 1.20443 5.91929 2.0692 5.59575L12.2517 1.78611C13.0247 1.49692 13.7954 2.21568 13.5609 3.00694L10.4855 13.3809C10.2213 14.272 8.99038 14.3522 8.6129 13.5027L6.71001 9.22073Z",
                            fill: "currentColor"
                        })
                    }), (0, l.jsx)("defs", {
                        children: (0, l.jsx)("clipPath", {
                            id: "clip0_6929_20189",
                            children: (0, l.jsx)("rect", {
                                width: "16",
                                height: "16",
                                fill: "white"
                            })
                        })
                    })]
                })
            }
        },
        63598: function(e, t, i) {
            "use strict";
            i.d(t, {
                p: function() {
                    return s
                }
            });
            var l = i(52322);
            let s = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, l.jsxs)("svg", {
                    width: t,
                    height: t,
                    className: i,
                    viewBox: "0 0 17 17",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, l.jsx)("g", {
                        clipPath: "url(#clip0_2407_5104)",
                        children: (0, l.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M8.1 2.5H8.9C9.91309 2.5 10.5526 2.50156 11.0359 2.54104C11.4959 2.57862 11.6356 2.64035 11.681 2.66349C11.9632 2.8073 12.1927 3.03677 12.3365 3.31901C12.3596 3.36442 12.4214 3.50412 12.459 3.96407C12.4984 4.44737 12.5 5.08691 12.5 6.1V10.9C12.5 11.9131 12.4984 12.5526 12.459 13.0359C12.4214 13.4959 12.3596 13.6356 12.3365 13.681C12.1927 13.9632 11.9632 14.1927 11.681 14.3365C11.6356 14.3596 11.4959 14.4214 11.0359 14.459C10.5526 14.4984 9.91309 14.5 8.9 14.5H8.1C7.08691 14.5 6.44737 14.4984 5.96407 14.459C5.50412 14.4214 5.36442 14.3596 5.31901 14.3365C5.03677 14.1927 4.8073 13.9632 4.66349 13.681C4.64035 13.6356 4.57862 13.4959 4.54104 13.0359C4.50156 12.5526 4.5 11.9131 4.5 10.9V6.1C4.5 5.08691 4.50156 4.44737 4.54104 3.96407C4.57862 3.50412 4.64035 3.36442 4.66349 3.31901C4.8073 3.03677 5.03677 2.8073 5.31901 2.66349C5.36442 2.64035 5.50412 2.57862 5.96407 2.54104C6.44737 2.50156 7.08691 2.5 8.1 2.5ZM2.5 6.1C2.5 4.13982 2.5 3.15972 2.88148 2.41103C3.21703 1.75247 3.75247 1.21703 4.41103 0.881477C5.15972 0.5 6.13982 0.5 8.1 0.5H8.9C10.8602 0.5 11.8403 0.5 12.589 0.881477C13.2475 1.21703 13.783 1.75247 14.1185 2.41103C14.5 3.15972 14.5 4.13982 14.5 6.1V10.9C14.5 12.8602 14.5 13.8403 14.1185 14.589C13.783 15.2475 13.2475 15.783 12.589 16.1185C11.8403 16.5 10.8602 16.5 8.9 16.5H8.1C6.13982 16.5 5.15972 16.5 4.41103 16.1185C3.75247 15.783 3.21703 15.2475 2.88148 14.589C2.5 13.8403 2.5 12.8602 2.5 10.9V6.1ZM7.5 3.5C6.94772 3.5 6.5 3.94772 6.5 4.5C6.5 5.05228 6.94772 5.5 7.5 5.5H9.5C10.0523 5.5 10.5 5.05228 10.5 4.5C10.5 3.94772 10.0523 3.5 9.5 3.5H7.5Z",
                            fill: "currentColor"
                        })
                    }), (0, l.jsx)("defs", {
                        children: (0, l.jsx)("clipPath", {
                            id: "clip0_2407_5104",
                            children: (0, l.jsx)("rect", {
                                width: "16",
                                height: "16",
                                fill: "white",
                                transform: "translate(0.5 0.5)"
                            })
                        })
                    })]
                })
            }
        },
        6401: function(e, t, i) {
            "use strict";
            i.d(t, {
                M: function() {
                    return r
                }
            });
            var l = i(52322),
                s = i(26648),
                n = i.n(s),
                a = i(6277);
            let r = e => {
                let {
                    size: t,
                    className: i,
                    checkmarkSpeed: s,
                    checkmarkDelay: r
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, a.Z)(n()["animation-ctn"], i),
                    children: (0, l.jsx)("div", {
                        className: (0, a.Z)(n().icon, n()["icon--order-success"], n().svg),
                        children: (0, l.jsx)("svg", {
                            viewBox: "0 0 154 154",
                            xmlns: "http://www.w3.org/2000/svg",
                            width: t,
                            height: t,
                            children: (0, l.jsxs)("g", {
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "2",
                                children: [(0, l.jsx)("circle", {
                                    id: "colored",
                                    fill: "currentColor",
                                    cx: "77",
                                    cy: "77",
                                    r: "72",
                                    style: {
                                        strokeDasharray: "480px, 480px",
                                        strokeDashoffset: "960px"
                                    }
                                }), (0, l.jsx)("polyline", {
                                    className: "st0",
                                    stroke: "#fff",
                                    strokeWidth: "10",
                                    points: "43.5,77.8 63.7,97.9 112.2,49.4",
                                    style: {
                                        strokeDasharray: "100px, 100px",
                                        strokeDashoffset: "200px",
                                        animationDuration: s,
                                        animationDelay: r
                                    }
                                })]
                            })
                        })
                    })
                })
            }
        },
        30420: function(e, t, i) {
            "use strict";
            i.d(t, {
                q: function() {
                    return c
                }
            });
            var l = i(52322),
                s = i(10075),
                n = i(6277),
                a = i(2784),
                r = i(64553),
                o = i(60741),
                d = i.n(o);
            let c = (0, a.forwardRef)((e, t) => {
                let {
                    className: i,
                    src: a,
                    variant: o = "circle",
                    size: c,
                    whitePhantomBorder: u = !1,
                    ...x
                } = e;
                return (0, l.jsxs)("div", {
                    ref: t,
                    className: (0, n.Z)(d().avatar, d()["avatar--".concat(o)], i),
                    style: {
                        width: c
                    },
                    ...x,
                    children: [a && (0, l.jsx)("img", {
                        src: (0, s.E)(a),
                        alt: "avatar"
                    }), (0, l.jsx)(r.k, {
                        white: u
                    })]
                })
            });
            c.displayName = "Avatar"
        },
        56886: function(e, t, i) {
            "use strict";
            i.d(t, {
                W: function() {
                    return r
                }
            });
            var l = i(52322),
                s = i(2784),
                n = i(4048),
                a = i(45048);
            let r = e => {
                let [t, i] = (0, s.useState)(null), r = (0, s.useRef)(null);
                return (0, s.useEffect)(() => {
                    if (r.current && null !== t) {
                        var e;
                        let t = r.current.value.length;
                        r.current.setSelectionRange(t, t), null === (e = r.current) || void 0 === e || e.focus()
                    }
                }, [t]), (0, l.jsx)(n.I, { ...e,
                    ref: r,
                    addonRight: (0, l.jsx)(a.z, {
                        variant: "white",
                        className: "h-[calc(100%-1rem)] w-[60px] !rounded-[4px] !py-0 !text-xs text-black shadow-[0_1px_2px_rgba(0,0,0,0.08)]",
                        type: "button",
                        onClick: e => {
                            e.preventDefault(), e.stopPropagation(), i(null === t ? "text" : "text" === t ? "password" : "text")
                        },
                        children: null === t ? "Show" : "text" === t ? "Hide" : "Show"
                    }),
                    type: null != t ? t : "password"
                })
            }
        },
        24353: function(e, t, i) {
            "use strict";
            i.d(t, {
                O: function() {
                    return r
                }
            });
            var l = i(52322),
                s = i(6277),
                n = i(71692),
                a = i.n(n);

            function r(e) {
                let {
                    className: t,
                    height: i,
                    width: n,
                    rounding: r,
                    animated: o = !0,
                    ...d
                } = e;
                return (0, l.jsx)("div", {
                    className: (0, s.Z)(a().skeleton, o && a()["skeleton--animated"], t),
                    style: {
                        width: n,
                        height: i,
                        borderRadius: r
                    },
                    ...d
                })
            }
        },
        49254: function(e, t, i) {
            "use strict";
            i.d(t, {
                I: function() {
                    return d
                }
            });
            var l = i(52322),
                s = i(89372),
                n = i(54381),
                a = i(97109),
                r = i(6277),
                o = i(80958);
            let d = e => {
                let {
                    children: t,
                    className: i,
                    isHidden: d = !1
                } = e, c = (0, o.Lm)(), u = c < 580, {
                    direction: x
                } = (0, n.a)(), h = "forward" === x ? 1 : -1;
                return (0, l.jsx)(s.m.div, {
                    className: (0, r.Z)(i),
                    initial: {
                        opacity: 0,
                        x: (u ? 16 : 40) * h,
                        pointerEvents: "auto"
                    },
                    animate: {
                        opacity: d ? 0 : 1,
                        x: 0,
                        transition: {
                            delay: 0,
                            duration: .5,
                            ease: a.V
                        }
                    },
                    exit: {
                        opacity: 0,
                        x: (u ? -8 : -20) * h,
                        pointerEvents: "none",
                        transition: {
                            duration: .35,
                            ease: a.V
                        }
                    },
                    children: t
                })
            }
        },
        54381: function(e, t, i) {
            "use strict";
            i.d(t, {
                A: function() {
                    return n
                },
                a: function() {
                    return a
                }
            });
            var l = i(17385);
            let [s, n] = (0, l.Z)({
                step: 0,
                direction: "forward"
            });

            function a() {
                let [e, t] = s(), i = () => t(e => ({ ...e,
                    step: e.step + 1,
                    direction: "forward"
                })), l = () => t(e => ({ ...e,
                    step: e.step - 1,
                    direction: "backward"
                }));
                return { ...e,
                    goToNextStep: i,
                    goToPreviousStep: l
                }
            }
        },
        4637: function(e, t, i) {
            "use strict";
            i.d(t, {
                e: function() {
                    return o
                }
            });
            var l = i(52322),
                s = i(88241),
                n = i(2784),
                a = i(54381);
            let r = e => {
                    let {
                        children: t
                    } = e, {
                        step: i
                    } = (0, a.a)();
                    return (0, l.jsx)(s.M, {
                        mode: "wait",
                        initial: !1,
                        children: n.Children.map(t, (e, t) => t === i ? e : null)
                    })
                },
                o = e => {
                    let {
                        children: t
                    } = e;
                    return (0, l.jsx)(l.Fragment, {
                        children: (0, l.jsx)(r, {
                            children: t
                        })
                    })
                }
        },
        97109: function(e, t, i) {
            "use strict";
            i.d(t, {
                S: function() {
                    return s
                },
                V: function() {
                    return l
                }
            });
            let l = [.5, 1, .89, 1],
                s = [.42, 0, .25, 1]
        },
        59371: function(e, t, i) {
            "use strict";
            i.d(t, {
                j: function() {
                    return o
                }
            });
            var l = i(99631),
                s = i(74704),
                n = i(32259),
                a = i(67780),
                r = i(88360);
            let o = e => [r.y, a.Z, s.Z, l.Z, n.Z.configure({
                placeholder(t) {
                    var i, l;
                    let {
                        editor: s
                    } = t;
                    return null !== (l = null !== (i = s.storage.placeholder) && void 0 !== i ? i : e) && void 0 !== l ? l : "Caption..."
                }
            })]
        },
        19399: function(e, t, i) {
            "use strict";
            let l, s, n, a, r;
            i.r(t), i.d(t, {
                __N_SSG: function() {
                    return oR
                },
                default: function() {
                    return oB
                }
            });
            var o, d, c = i(52322),
                u = i(30235),
                x = i(97729),
                h = i.n(x),
                m = i(55351),
                p = i(17385);
            let [v, g] = (0, p.Z)({
                onboarding: !1,
                anyLinks: []
            });
            var f = i(49961),
                _ = i(24920),
                j = i(91334),
                w = i(73047),
                y = i(63598),
                b = i(45048),
                N = i(80958);

            function C() {
                let e = (0, N.Lm)(),
                    t = "desktop";
                return e < 1260 && (t = "mobile"), t
            }

            function k(e) {
                let {
                    device: t,
                    children: i
                } = e, l = C();
                return l !== t ? null : (0, c.jsx)(c.Fragment, {
                    children: i
                })
            }
            var E = i(4087),
                S = i(66276),
                L = i(40624);
            let I = (0, L.Ue)(e => ({
                device: "desktop",
                transitioning: !1,
                setTransitioning: t => e({
                    transitioning: t
                }),
                setDevice: t => e({
                    device: t
                })
            }));
            var D = i(90803),
                Z = i.n(D),
                z = i(32543),
                A = i(41244),
                F = i(6277),
                M = i(2784);
            let T = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, c.jsx)("svg", {
                    width: t,
                    height: t,
                    style: {
                        width: t,
                        height: t
                    },
                    className: i,
                    viewBox: "0 0 20 20",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: (0, c.jsx)("path", {
                        d: "M19.9417 3.91813C19.2081 4.24354 18.4195 4.46337 17.592 4.56226C18.4366 4.05601 19.0854 3.25436 19.3909 2.29909C18.6002 2.76796 17.7247 3.10831 16.7927 3.29175C16.0465 2.49668 14.9833 2 13.8064 2C11.547 2 9.71509 3.83149 9.71509 6.09059C9.71509 6.41122 9.75129 6.72345 9.82109 7.02284C6.42081 6.85227 3.40622 5.22364 1.38831 2.74871C1.03614 3.35287 0.83433 4.05551 0.83433 4.80523C0.83433 6.22448 1.55661 7.47655 2.65441 8.21011C1.98377 8.18887 1.35291 8.00484 0.801325 7.69848C0.80086 7.71552 0.80086 7.73267 0.80086 7.74991C0.80086 9.73186 2.21115 11.3851 4.08277 11.7612C3.73948 11.8547 3.37803 11.9047 3.00492 11.9047C2.74129 11.9047 2.48504 11.8789 2.23517 11.8312C2.75585 13.4564 4.26674 14.6391 6.05711 14.672C4.6569 15.7692 2.89285 16.4232 0.97595 16.4232C0.645714 16.4232 0.320066 16.4038 0 16.366C1.81062 17.5267 3.96113 18.2039 6.27159 18.2039C13.7969 18.2039 17.9122 11.9707 17.9122 6.56484C17.9122 6.38749 17.9082 6.21112 17.9004 6.03556C18.6996 5.45892 19.3932 4.73852 19.9417 3.91813Z",
                        fill: "white"
                    })
                })
            };
            var O = i(61707);
            let R = (0, M.forwardRef)((e, t) => {
                let {
                    size: i,
                    ...l
                } = e;
                return (0, c.jsx)(b.z, {
                    ref: t,
                    rounding: "full",
                    size: "none",
                    style: {
                        width: i,
                        height: i
                    },
                    ...l
                })
            });
            R.displayName = "CircularButton";
            var B = i(72331),
                H = i(39690),
                U = i.n(H);
            let V = e => {
                let {
                    className: t,
                    children: i,
                    open: l,
                    setOpen: s,
                    portal: n = !0,
                    ...a
                } = e, [r, o] = (0, M.useState)(!1);
                return (0, c.jsxs)(B.fC, {
                    open: null != l ? l : r,
                    onOpenChange: null != s ? s : o,
                    children: [n && (0, c.jsxs)(B.h_, {
                        children: [(0, c.jsx)(B.aV, {
                            className: (0, F.Z)(U().overlay)
                        }), (0, c.jsx)(B.VY, {
                            className: (0, F.Z)(U().content, t),
                            ...a,
                            children: i
                        })]
                    }), !n && (0, c.jsx)(B.VY, {
                        className: (0, F.Z)(U().content, t),
                        ...a,
                        children: i
                    })]
                })
            };
            B.x8;
            var P = i(89372),
                G = i(1341),
                W = i.n(G),
                J = i(64999);
            let Y = (0, P.m)(B.VY),
                q = e => {
                    let {
                        className: t,
                        contentClassName: i,
                        children: l,
                        open: s,
                        setOpen: n,
                        ...a
                    } = e, [r, o] = (0, M.useState)(!1);
                    C();
                    let d = () => {
                            (null != n ? n : o)(!1)
                        },
                        u = e => {
                            let t = e.target;
                            t && !t.closest("[data-sheet]") && d()
                        };
                    return (0, c.jsx)(B.fC, {
                        open: null != s ? s : r,
                        onOpenChange: null != n ? n : o,
                        children: (0, c.jsxs)(B.h_, {
                            children: [(0, c.jsx)(B.aV, {
                                className: (0, F.Z)(W().overlay, "no-scrollbar"),
                                "data-bento-menu": !0
                            }), (0, c.jsxs)(Y, {
                                className: (0, F.Z)(W().sheet, t),
                                onOpenAutoFocus: e => {
                                    e.preventDefault();
                                    let t = e.target;
                                    t.focus()
                                },
                                onClick: u,
                                ...a,
                                children: [(0, c.jsx)(J.L, {}), (0, c.jsx)("div", {
                                    className: (0, F.Z)(W().sheet__content, i),
                                    "data-sheet": !0,
                                    children: l
                                })]
                            })]
                        })
                    })
                };
            B.x8;
            var K = i(30420),
                X = i(64553),
                $ = i(24353),
                Q = i(80162),
                ee = i.n(Q);
            let et = e => {
                var t, i, l, s;
                let {
                    className: n,
                    tweet: a,
                    data: r,
                    handle: o
                } = e, [d, u] = (0, M.useState)(null), [x, h] = (0, M.useState)(!0), [m, p] = (0, M.useState)(!0);
                (0, M.useEffect)(() => {
                    if (d) {
                        let e = () => {
                            h(d.scrollTop > 0), p(d.scrollTop + d.clientHeight < d.scrollHeight)
                        };
                        return e(), d.addEventListener("scroll", e), d.addEventListener("resize", e), () => {
                            d.removeEventListener("scroll", e), d.removeEventListener("resize", e)
                        }
                    }
                }, [d]);
                let v = null == a ? void 0 : a.trim().split("\n\n").map(e => (0, c.jsx)("div", {
                    children: e.split(/(@\w+|#\w+|bento\.me[\/\w+]*)/g).map((e, t) => e ? e.startsWith("bento.me") || e.startsWith("@") || e.startsWith("#") ? (0, c.jsx)("span", {
                        className: "text-[#1F43FF]",
                        children: e
                    }) : (0, c.jsx)("span", {
                        children: e
                    }) : null)
                }));
                return (0, c.jsxs)("div", {
                    className: (0, F.Z)(n, "relative"),
                    children: [(0, c.jsxs)("div", {
                        className: (0, F.Z)("no-scrollbar relative overflow-auto xl:max-h-[450px]"),
                        ref: u,
                        children: [(0, c.jsxs)("div", {
                            className: "flex items-center",
                            children: [(0, c.jsx)(K.q, {
                                src: null !== (t = null == r ? void 0 : r.avatar) && void 0 !== t ? t : "/images/twitter-avatar.png",
                                size: 36,
                                className: "mr-2.5"
                            }), (0, c.jsxs)("div", {
                                children: [(0, c.jsx)("div", {
                                    className: "text-sm font-medium",
                                    children: null !== (i = null == r ? void 0 : r.userName) && void 0 !== i ? i : "Your Name"
                                }), (0, c.jsxs)("div", {
                                    className: "text-xs font-normal text-black/[0.56]",
                                    children: ["@", null !== (s = null !== (l = null == r ? void 0 : r.handle) && void 0 !== l ? l : o) && void 0 !== s ? s : "your-handle"]
                                })]
                            })]
                        }), (0, c.jsxs)("div", {
                            className: "mt-5 space-y-3 whitespace-pre-wrap leading-[24px]",
                            children: [v, !v && (0, c.jsxs)("div", {
                                className: "flex flex-col space-y-2",
                                children: [(0, c.jsx)($.O, {
                                    className: "h-[14px] w-[70%]",
                                    rounding: 4
                                }), (0, c.jsx)($.O, {
                                    className: "h-[14px] w-[90%]",
                                    rounding: 4
                                }), (0, c.jsx)($.O, {
                                    className: "h-[14px] w-[80%]",
                                    rounding: 4
                                }), (0, c.jsx)($.O, {
                                    className: "h-[14px] w-[96%]",
                                    rounding: 4
                                }), (0, c.jsx)($.O, {
                                    className: "h-[14px] w-[46%]",
                                    rounding: 4
                                })]
                            })]
                        }), (0, c.jsxs)("div", {
                            className: (0, F.Z)("relative mt-3 rounded-[6px]", !a && "hidden"),
                            children: [(0, c.jsx)("img", {
                                src: "".concat("https://api.bento.me", "/v1/og/").concat(o),
                                alt: "",
                                className: "w-full rounded-[inherit]"
                            }), (0, c.jsx)(X.k, {})]
                        })]
                    }), (0, c.jsx)("div", {
                        className: (0, F.Z)(ee().fade, ee()["fade--top"], x && ee()["fade--active"], "top-0")
                    }), (0, c.jsx)("div", {
                        className: (0, F.Z)(ee().fade, ee()["fade--bottom"], m && ee()["fade--active"], "bottom-0")
                    })]
                })
            };
            var ei = i(66563),
                el = i(97008),
                es = i(93143),
                en = i(37523),
                ea = i(60696),
                er = i(28879),
                eo = i.n(er);

            function ed(e) {
                let {
                    data: t,
                    mutate: i,
                    ...l
                } = (0, en.$)((0, es.cd)(e), {
                    dedupingInterval: 400,
                    refreshInterval(e) {
                        let t = e ? eo()().diff(e.updatedAt, "seconds") : 0;
                        if (!e || e.status !== ea.EFetchStatus.COMPLETED) {
                            var i;
                            return t < 10 && e && e.status === ea.EFetchStatus.FETCHING ? 333 : e && Object.keys(null !== (i = e.data) && void 0 !== i ? i : {}).length > 0 && e.status === ea.EFetchStatus.FAILED ? 6e4 : e && e.status === ea.EFetchStatus.FAILED ? 5e3 : 1e3
                        }
                        return 0
                    }
                });
                return {
                    richdata: t,
                    ...l
                }
            }
            let ec = [{
                    mood: "confident",
                    tweet: "Just made some major changes to my Bento and I have to say, I’m feeling pretty awesome about it. I’m sure everyone else is gonna be super jealous because I’m taking my link-in-bio game to the next level."
                }, {
                    mood: "witty",
                    tweet: "I just made some major updates to my Bento profile and let me tell you, it’s now the coolest thing since sliced bread! I mean, I’m not one to brag, but I totally transformed this page into something special. I’m not sure what I changed, but I know it looks awesome."
                }, {
                    mood: "genz",
                    tweet: "Yooo! Just updated my #Bento profile and it’s lit AF! I switched up the visuals, changed the color scheme and added some fire music. It’s a game changer and I’m loving the new look."
                }, {
                    mood: "deep",
                    tweet: "Just updated my Bento profile and it’s so cool! Life is all about stepping out of our comfort zone, trying something new and taking a chance to make tomorrow better than today."
                }, {
                    mood: "eminem",
                    tweet: "Just made some major changes to my Bento and I have to say, I’m feeling pretty awesome about it. I’m sure everyone else is gonna be super jealous because I’m taking my link-in-bio game to the next level."
                }, {
                    mood: "yoda",
                    tweet: "Just made some major changes to my Bento and I have to say, I’m feeling pretty awesome about it. I’m sure everyone else is gonna be super jealous because I’m taking my link-in-bio game to the next level."
                }, {
                    mood: "dazzling",
                    tweet: "Just made some major changes to my Bento and I have to say, I’m feeling pretty awesome about it. I’m sure everyone else is gonna be super jealous because I’m taking my link-in-bio game to the next level."
                }, {
                    mood: "comedian",
                    tweet: "Just made some major changes to my Bento and I have to say, I’m feeling pretty awesome about it. I’m sure everyone else is gonna be super jealous because I’m taking my link-in-bio game to the next level."
                }],
                eu = (0, L.Ue)((e, t) => ({
                    id: 0,
                    tweets: new Map,
                    setTweet: (t, i) => {
                        e(e => e.id > t ? e : (e.tweets.set(i.mood, i), {
                            tweets: e.tweets,
                            id: t
                        }))
                    }
                }));
            var ex = i(85303);
            let eh = e => {
                    let {
                        selected: t,
                        onClick: i,
                        src: l,
                        tooltip: s
                    } = e;
                    return (0, c.jsx)(S.pn, {
                        children: (0, c.jsx)(E.u, {
                            variant: "plain",
                            tooltip: (0, c.jsx)("div", {
                                className: (0, F.Z)(ee().tooltip),
                                children: s
                            }),
                            children: (0, c.jsx)(R, {
                                variant: "transparent",
                                className: (0, F.Z)("border-[2px] !p-[6px]", !t && "border-transparent", t && "border-[2px] border-black shadow-[0px_2px_4px_rgba(0,0,0,0.15)]"),
                                onClick: i,
                                children: (0, c.jsx)("img", {
                                    src: l,
                                    alt: "",
                                    className: "object-contain s-[28px]"
                                })
                            })
                        })
                    })
                },
                em = !1,
                ep = e => {
                    var t, i;
                    let {
                        onClose: l
                    } = e, [{
                        profile: s,
                        stage: n
                    }] = (0, j.U)(), [a, r] = (0, M.useState)("dazzling"), {
                        id: o,
                        tweets: d,
                        setTweet: u
                    } = eu(), x = ei.f.getId() === o ? null === (t = d.get(a)) || void 0 === t ? void 0 : t.tweet : void 0, h = x ? x + "\n\nbento.me/".concat(s.handle) : void 0, m = null === (i = s.bento.items.find(e => "link" === e.data.type && (0, el.L3)(e.data.href))) || void 0 === i ? void 0 : i.data, {
                        richdata: p
                    } = ed(null == m ? void 0 : m.href), v = e => {
                        let t = ei.f.getId();
                        d.get(e) || ex.hi.post((0, es.dH)(e), {
                            type: "created" === n ? "create" : "update",
                            entries: ei.f.getEntries()
                        }).then(e => e.data).then(e => {
                            if (e) u(t, e);
                            else throw Error("No tweet found")
                        }).catch(i => {
                            let l = ec.find(t => t.mood === e);
                            l && u(t, l)
                        })
                    };
                    return (0, M.useEffect)(() => {
                        em || (v(a), em = !0)
                    }, []), (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)("div", {
                            className: "flex items-center px-2.5",
                            children: [(0, c.jsx)("div", {
                                className: "text-xl font-semibold",
                                children: "Share your Bento"
                            }), (0, c.jsx)(J.L, {}), (0, c.jsx)(R, {
                                variant: "none",
                                className: "bg-black/[0.02] !p-2 hover:bg-black/[0.04] active:bg-black/[0.06]",
                                onClick: l,
                                children: (0, c.jsx)(O.b, {})
                            })]
                        }), (0, c.jsxs)("div", {
                            className: "mt-7 rounded-[20px] bg-white p-6 shadow-[0px_0px_1px_rgba(0,0,0,0.2),0px_2px_3px_rgba(0,0,0,0.04)] xl:min-h-[min(60vh,550px)]",
                            children: [(0, c.jsxs)("div", {
                                className: "flex flex-col items-start",
                                children: [(0, c.jsx)("div", {
                                    className: "text-sm text-black/60",
                                    children: "Make tweet sound:"
                                }), (0, c.jsxs)("div", {
                                    className: "mt-3 flex items-center space-x-1.5",
                                    children: [(0, c.jsx)(eh, {
                                        onClick: () => {
                                            (0, z.c)().track("SHARE_BENTO_MOOD_CLICKED", {
                                                mood: "dazzling"
                                            }), r("dazzling"), v("dazzling")
                                        },
                                        selected: "dazzling" === a,
                                        src: "/images/dazzling.png",
                                        tooltip: "Dazzling"
                                    }), (0, c.jsx)(eh, {
                                        onClick: () => {
                                            (0, z.c)().track("SHARE_BENTO_MOOD_CLICKED", {
                                                mood: "shakespeare"
                                            }), r("shakespeare"), v("shakespeare")
                                        },
                                        selected: "shakespeare" === a,
                                        src: "/images/shakespeare.png",
                                        tooltip: "Shakespeare"
                                    }), (0, c.jsx)(eh, {
                                        onClick: () => {
                                            (0, z.c)().track("SHARE_BENTO_MOOD_CLICKED", {
                                                mood: "deep"
                                            }), r("deep"), v("deep")
                                        },
                                        selected: "deep" === a,
                                        src: "/images/deep.png",
                                        tooltip: "#Deep"
                                    })]
                                })]
                            }), (0, c.jsx)("div", {
                                className: "my-4 h-[2px] w-full rounded-[1px] bg-black/[0.02]"
                            }), (0, c.jsx)(et, {
                                tweet: h,
                                data: null == p ? void 0 : p.data,
                                handle: s.handle,
                                className: "mt-1"
                            })]
                        }), (0, c.jsxs)("a", {
                            href: h ? "http://twitter.com/intent/tweet?text=".concat(encodeURIComponent(h)) : void 0,
                            rel: "noreferrer noopener",
                            target: "_blank",
                            className: "mt-7 flex h-[56px] w-full items-center justify-center space-x-2 rounded-[36px] border-[1px] border-black/[0.06] bg-[#55ACEE] text-xl font-semibold text-white shadow-[0px_2px_4px_rgba(0,0,0,0.08)] hover:bg-[#49A0E2] active:bg-[#4198DA]",
                            onClick: () => {
                                (0, z.c)().track("SHARE_BENTO_TWEET_CLICKED", {
                                    mood: a
                                })
                            },
                            children: [(0, c.jsx)(T, {
                                size: 20
                            }), " ", (0, c.jsx)("span", {
                                children: "Tweet"
                            })]
                        })]
                    })
                },
                ev = e => {
                    let {
                        open: t,
                        setOpen: i
                    } = e, l = C();
                    return (0, c.jsxs)(c.Fragment, {
                        children: ["desktop" === l && (0, c.jsx)(V, {
                            open: t,
                            setOpen: i,
                            className: "!max-w-[414px] overflow-hidden !rounded-[44px] !bg-[#F9F9F9] !px-6 !py-6 xl:!pt-8",
                            children: (0, c.jsx)(ep, {
                                onClose: () => i(!1)
                            })
                        }), "mobile" === l && (0, c.jsx)(q, {
                            open: t,
                            setOpen: i,
                            contentClassName: "!p-6 !bg-[#F9F9F9]",
                            children: (0, c.jsx)(ep, {
                                onClose: () => i(!1)
                            })
                        })]
                    })
                },
                eg = e => {
                    let {
                        content: t
                    } = e;
                    return (0, c.jsx)("div", {
                        className: "max-w-[114px] px-1 text-disclaimer text-black/60",
                        children: t
                    })
                },
                ef = e => {
                    let {} = e, [{
                        profile: t,
                        editing: i,
                        publishing: l
                    }] = (0, j.U)(), [s, n] = (0, M.useState)(!1);
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)(S.pn, {
                            children: (0, c.jsx)(E.u, {
                                delayDuration: 300,
                                disableHoverableContent: !0,
                                sideOffset: 8,
                                tooltip: (0, c.jsx)(eg, {
                                    content: "Share tweet"
                                }),
                                children: (0, c.jsxs)(b.z, {
                                    variant: "success",
                                    shine: !0,
                                    disabled: l,
                                    className: (0, F.Z)("h-[33px] w-[127px] !rounded-[6px] !p-0 !shadow-[0px_2px_3px_rgba(0,0,0,0.06)]"),
                                    onClick: () => {
                                        (0, z.c)().track("SHARE_BENTO_CLICKED"), n(!0)
                                    },
                                    children: [!l && "Share my Bento", l && (0, c.jsxs)(c.Fragment, {
                                        children: [(0, c.jsx)(A.T, {
                                            size: 12,
                                            className: "mr-2"
                                        }), "Saving..."]
                                    })]
                                })
                            })
                        }), (0, c.jsx)(ev, {
                            open: s,
                            setOpen: n
                        })]
                    })
                },
                e_ = e => {
                    let {
                        content: t
                    } = e;
                    return (0, c.jsx)("div", {
                        className: "max-w-[114px] px-1 text-center text-disclaimer text-black/60",
                        children: t
                    })
                };
            var ej = i(16233),
                ew = i.n(ej);
            let ey = e => {
                let {
                    selected: t,
                    highlight: i = "default",
                    shadow: l = "default",
                    children: s,
                    tooltip: n,
                    ...a
                } = e, [r, o] = (0, M.useState)(null);
                return (0, c.jsx)(S.pn, {
                    children: (0, c.jsx)(E.u, {
                        delayDuration: 300,
                        disableHoverableContent: !0,
                        sideOffset: 8,
                        tooltip: n ? (0, c.jsx)(e_, {
                            content: n
                        }) : void 0,
                        children: (0, c.jsx)("button", {
                            ref: o,
                            className: (0, F.Z)(ew().button, t && ew()["button--selected"]),
                            ...a,
                            children: (0, c.jsxs)("div", {
                                className: (0, F.Z)(ew().button__content, ew()["button__content--shadow-".concat(l)]),
                                children: [(0, c.jsx)("div", {
                                    className: (0, F.Z)(ew().gradient)
                                }), s, (0, c.jsx)("div", {
                                    className: (0, F.Z)(ew().border)
                                }), (0, c.jsx)("div", {
                                    className: (0, F.Z)(ew().highlight, ew()["highlight--".concat(i)])
                                })]
                            })
                        })
                    })
                })
            };
            var eb = i(97731);
            let eN = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("img", {
                        src: "/images/illustrations/image.png",
                        alt: "",
                        width: t,
                        height: t,
                        className: i
                    })
                },
                eC = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("img", {
                        src: "/images/illustrations/text.png",
                        alt: "",
                        width: t,
                        height: t,
                        className: i
                    })
                },
                ek = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("img", {
                        src: "/images/illustrations/map.png",
                        alt: "",
                        width: t,
                        height: t,
                        className: i
                    })
                },
                eE = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 24 24",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "4",
                            y: "12",
                            width: "7",
                            height: "8",
                            rx: "3",
                            fill: "#E3E3E3"
                        }), (0, c.jsx)("rect", {
                            x: "4.5",
                            y: "12.5",
                            width: "6",
                            height: "7",
                            rx: "2.5",
                            stroke: "black",
                            "stroke-opacity": "0.08"
                        }), (0, c.jsx)("rect", {
                            x: "13",
                            y: "12",
                            width: "7",
                            height: "8",
                            rx: "3",
                            fill: "#E3E3E3"
                        }), (0, c.jsx)("rect", {
                            x: "13.5",
                            y: "12.5",
                            width: "6",
                            height: "7",
                            rx: "2.5",
                            stroke: "black",
                            "stroke-opacity": "0.08"
                        }), (0, c.jsx)("rect", {
                            x: "4",
                            y: "4",
                            width: "12",
                            height: "5",
                            rx: "2.5",
                            fill: "url(#paint0_linear_7289_21481)"
                        }), (0, c.jsx)("defs", {
                            children: (0, c.jsxs)("linearGradient", {
                                id: "paint0_linear_7289_21481",
                                x1: "10",
                                y1: "4",
                                x2: "10",
                                y2: "9",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("stop", {
                                    "stop-color": "#5B5B5B"
                                }), (0, c.jsx)("stop", {
                                    offset: "1"
                                })]
                            })
                        })]
                    })
                };
            var eS = i(57807),
                eL = i(84090);
            let eI = "image/png,image/jpeg,image/x-png,image/gif,image/bmp,image/jpeg,image/webp,image/heic",
                eD = "video/mp4,video/x-m4v,video/quicktime,video/mpeg,video/ogg,video/x-msvideo";
            var eZ = i(88242),
                ez = i(85675);

            function eA() {
                let [, e] = (0, j.U)(), {
                    addMediaUpload: t
                } = (0, eS.r)(), i = (0, eZ.A)(e => e.engine), l = (0, eL.$)(), s = (0, M.useCallback)((s, n) => {
                    if (s) {
                        var a;
                        let r = (0, _.x0)(),
                            o = (0, ez.b)(s),
                            d = {
                                id: r,
                                type: "media",
                                style: (0, _.um)("2x2", l),
                                variant: o
                            };
                        (0, z.c)().track("WIDGET_ADDED", {
                            variant: o,
                            addMode: n,
                            type: "media"
                        }), "video" === o ? ei.f.addedVideo(r) : ei.f.addedImage(r), e({
                            type: "add-bento-item",
                            bento: d,
                            device: l,
                            viewSlice: null == i ? void 0 : null === (a = i.view) || void 0 === a ? void 0 : a.getViewSlice()
                        }), t(s, r).then(t => {
                            e({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: d.id,
                                    url: t
                                }
                            })
                        }).catch(() => {})
                    }
                }, [i, l, e, t]), n = (0, M.useCallback)(e => {
                    let t = document.createElement("input");
                    t.type = "file", t.accept = "".concat(eI, ",").concat(eD), t.multiple = !0, t.onchange = t => {
                        let i = t.target.files;
                        if (i)
                            for (let t = 0; t < i.length; t++) s(i[t], e)
                    }, t.click()
                }, [s]);
                return {
                    createMedia: s,
                    triggerMediaPicker: n
                }
            }
            var eF = i(34364),
                eM = i(18509);

            function eT() {
                let [, e] = (0, j.U)(), t = (0, eL.$)(), i = (0, eM.H)(), l = (0, eF.W)(e => e.setFocused), s = (0, eZ.A)(e => e.engine), n = n => {
                    var a;
                    (0, z.c)().track("WIDGET_ADDED", {
                        addMode: n,
                        type: "section-header"
                    });
                    let r = (0, _.x0)();
                    ei.f.addedSection(r), e({
                        type: "add-bento-item",
                        bento: {
                            id: r,
                            type: "section-header"
                        },
                        device: t,
                        viewSlice: null == s ? void 0 : null === (a = s.view) || void 0 === a ? void 0 : a.getViewSlice()
                    }), "mouse" === i && l(r)
                };
                return {
                    createSectionTitle: n
                }
            }

            function eO() {
                let [, e] = (0, j.U)(), t = (0, eL.$)(), i = (0, eZ.A)(e => e.engine), l = l => {
                    var s;
                    let n = (0, _.x0)(),
                        a = "https://www.google.com/maps/@52.5141272,13.406142,13.86z";
                    (0, z.c)().track("WIDGET_ADDED", {
                        addMode: l,
                        type: "link",
                        hostname: (0, _.w6)(a).hostname
                    }), ei.f.addedLink(n, a), e({
                        type: "add-bento-item",
                        bento: {
                            id: n,
                            type: "link",
                            href: a,
                            style: (0, _.um)("4x4", t),
                            overrides: {
                                mapCaption: "Berlin, Germany",
                                mapPlace: "Berlin, Germany"
                            }
                        },
                        device: t,
                        viewSlice: null == i ? void 0 : null === (s = i.view) || void 0 === s ? void 0 : s.getViewSlice()
                    })
                };
                return {
                    createMap: l
                }
            }

            function eR() {
                let [, e] = (0, j.U)(), t = (0, eL.$)(), i = (0, eM.H)(), l = (0, eZ.A)(e => e.engine), s = (0, eF.W)(e => e.setFocused), n = n => {
                    var a;
                    let r = (0, _.x0)();
                    (0, z.c)().track("WIDGET_ADDED", {
                        addMode: n,
                        type: "rich-text"
                    }), ei.f.addedRichText(r), e({
                        type: "add-bento-item",
                        bento: {
                            id: r,
                            type: "rich-text",
                            style: (0, _.um)("2x2", t),
                            halign: (0, _.um)("left", t),
                            valign: (0, _.um)("top", t)
                        },
                        device: t,
                        viewSlice: null == l ? void 0 : null === (a = l.view) || void 0 === a ? void 0 : a.getViewSlice()
                    }), "mouse" === i && s(r)
                };
                return {
                    createRichText: n
                }
            }
            var eB = i(16954);

            function eH(e) {
                let t = (0, eB.X)((0, _.Ac)(e)),
                    i = (null == t ? void 0 : t.transformLink) ? t.transformLink((0, _.Ac)(e)) : (0, _.Ac)(e);
                return {
                    href: i,
                    platform: t
                }
            }

            function eU() {
                let [, e] = (0, j.U)(), t = (0, eL.$)(), i = (0, eZ.A)(e => e.engine), l = (0, M.useCallback)((l, s, n) => {
                    var a;
                    if (!l) throw Error("No href provided");
                    let r = (0, _.x0)();
                    return ei.f.addedLink(r, l), (0, z.c)().track("WIDGET_ADDED", {
                        addMode: n,
                        type: "link",
                        hostname: (0, _.w6)(l).hostname
                    }), e({
                        type: "add-bento-item",
                        bento: {
                            id: r,
                            type: "link",
                            href: l,
                            style: (0, _.um)(null != s ? s : "2x2", t)
                        },
                        device: t,
                        viewSlice: null == i ? void 0 : null === (a = i.view) || void 0 === a ? void 0 : a.getViewSlice()
                    }), !0
                }, [i, e, t]), s = (0, M.useCallback)((e, t) => {
                    if (!(0, _.u$)(e)) return !1; {
                        let {
                            href: i,
                            platform: s
                        } = eH(e);
                        return l(i, null == s ? void 0 : s.defaultSize, t)
                    }
                }, [l]);
                return {
                    createLinkRaw: l,
                    createLink: s
                }
            }
            var eV = i(70433),
                eP = i(14734),
                eG = i.n(eP);
            let eW = e => {
                    let {
                        visible: t,
                        onClose: i
                    } = e, [l, s] = (0, M.useState)(!1), [n, a] = (0, M.useState)(null), [r, o] = (0, M.useState)(""), {
                        createLink: d
                    } = eU(), u = e => {
                        let t = d(e, "add-bar");
                        t ? i() : (s(!0), o(e))
                    }, x = () => {
                        r ? u(r) : navigator.clipboard.readText().then(e => {
                            e && u(e)
                        })
                    }, h = e => {
                        if (!e.clipboardData) return;
                        let t = e.clipboardData.getData("text").trim();
                        e.preventDefault(), e.stopPropagation(), t && u(t)
                    }, m = e => {
                        e.preventDefault(), r && u(r)
                    };
                    return (0, M.useEffect)(() => {
                        if (t) {
                            o(""), s(!1);
                            let e = (0, eV.$)(),
                                t = e => {
                                    "Escape" === e.key && (e.preventDefault(), e.stopPropagation(), i())
                                };
                            return window.addEventListener("keydown", t), null == e || e.addEventListener("keydown", t), () => {
                                window.removeEventListener("keydown", t), null == e || e.removeEventListener("keydown", t)
                            }
                        }
                    }, [t]), (0, M.useEffect)(() => {
                        t && n && n.focus()
                    }, [t, n]), (0, M.useEffect)(() => {
                        let e = e => {
                                let t = e.target,
                                    l = !!t.closest("[data-bento-menu]"),
                                    s = !!t.closest("button:not([data-link-button]):not([data-link-menu-button])");
                                (!l || s) && i()
                            },
                            t = (0, eV.$)();
                        return window.addEventListener("click", e), null == t || t.addEventListener("click", e), () => {
                            window.removeEventListener("click", e), null == t || t.removeEventListener("click", e)
                        }
                    }, []), (0, c.jsxs)("div", {
                        className: (0, F.Z)(eG()["link-bar"], t && eG()["link-bar--visible"]),
                        "data-bento-menu": !0,
                        children: [(0, c.jsx)("form", {
                            onSubmit: m,
                            children: (0, c.jsx)("input", {
                                ref: a,
                                value: r,
                                onChange: e => o(e.target.value),
                                className: "w-full rounded-[inherit] bg-transparent py-[12px] pl-3 pr-[70px] text-sm outline-none",
                                placeholder: "Enter Link",
                                onPaste: h
                            })
                        }), (0, c.jsx)("div", {
                            className: "absolute right-2",
                            children: (0, c.jsxs)("button", {
                                className: (0, F.Z)(eG().button, r && eG()["button--add"], !r && eG()["button--paste"]),
                                onClick: x,
                                "data-link-menu-button": !0,
                                children: [!r && "Paste", r && "Add"]
                            })
                        }), (0, c.jsx)("div", {
                            className: eG().highlight
                        })]
                    })
                },
                eJ = () => {
                    let [e, t] = I(e => [e.device, e.setDevice]), [{
                        onboarding: i
                    }] = v(), [l, s] = (0, M.useState)(!1), {
                        triggerMediaPicker: n
                    } = eA(), {
                        createSectionTitle: a
                    } = eT(), {
                        createGhost: r
                    } = function() {
                        let [, e] = (0, j.U)();
                        (0, eL.$)(), (0, eZ.A)(e => e.engine);
                        let t = () => {
                            e({
                                type: "add-ghosts"
                            })
                        };
                        return {
                            createGhost: t
                        }
                    }(), {
                        createMap: o
                    } = eO(), {
                        createRichText: d
                    } = eR();
                    return i ? null : (0, c.jsxs)(k, {
                        device: "desktop",
                        children: [(0, c.jsx)(eW, {
                            visible: l,
                            onClose: () => {
                                s(!1)
                            }
                        }), (0, c.jsxs)("div", {
                            className: Z()["floating-bar"],
                            "data-bento-menu": !0,
                            children: [(0, c.jsx)(ef, {}), (0, c.jsx)("div", {
                                className: Z().divider
                            }), (0, c.jsxs)("div", {
                                className: "flex items-center space-x-1",
                                children: [(0, c.jsx)(ey, {
                                    highlight: "strong",
                                    selected: l,
                                    tooltip: "Link",
                                    onClick: () => s(!l),
                                    "data-link-button": !0,
                                    children: (0, c.jsx)(eb.x, {
                                        size: 14
                                    })
                                }), (0, c.jsx)(ey, {
                                    tooltip: "Image & Video",
                                    shadow: "strong",
                                    onClick: () => n("add-bar"),
                                    children: (0, c.jsx)(eN, {
                                        size: 24
                                    })
                                }), (0, c.jsx)(ey, {
                                    tooltip: "Text",
                                    shadow: "strong",
                                    onClick: () => d("add-bar"),
                                    children: (0, c.jsx)(eC, {
                                        size: 24
                                    })
                                }), (0, c.jsx)(ey, {
                                    tooltip: "Map",
                                    shadow: "strong",
                                    onClick: () => o("add-bar"),
                                    children: (0, c.jsx)(ek, {
                                        size: 24
                                    })
                                }), (0, c.jsx)(ey, {
                                    highlight: "strong",
                                    tooltip: "Section Title",
                                    onClick: () => a("add-bar"),
                                    children: (0, c.jsx)(eE, {
                                        size: 24
                                    })
                                })]
                            }), (0, c.jsx)("div", {
                                className: Z().divider
                            }), (0, c.jsxs)("div", {
                                className: "flex items-center space-x-1",
                                children: [(0, c.jsx)(S.pn, {
                                    children: (0, c.jsx)(E.u, {
                                        delayDuration: 300,
                                        disableHoverableContent: !0,
                                        sideOffset: 8,
                                        tooltip: (0, c.jsx)(e_, {
                                            content: "Edit how your Bento looks on computers"
                                        }),
                                        children: (0, c.jsx)(b.z, {
                                            icon: (0, c.jsx)(w.u, {}),
                                            variant: "desktop" === e ? "primary" : "white",
                                            onClick: () => {
                                                (0, z.c)().track("SWITCHED_DEVICE", {
                                                    device: "desktop"
                                                }), t("desktop")
                                            },
                                            className: "h-[33px] w-[50px] !rounded-[6px]"
                                        })
                                    })
                                }), (0, c.jsx)(S.pn, {
                                    children: (0, c.jsx)(E.u, {
                                        delayDuration: 300,
                                        disableHoverableContent: !0,
                                        sideOffset: 8,
                                        tooltip: (0, c.jsx)(e_, {
                                            content: "Edit how your Bento looks on phones"
                                        }),
                                        children: (0, c.jsx)(b.z, {
                                            icon: (0, c.jsx)(y.p, {}),
                                            variant: "mobile" === e ? "primary" : "transparent",
                                            onClick: () => {
                                                (0, z.c)().track("SWITCHED_DEVICE", {
                                                    device: "mobile"
                                                }), t("mobile")
                                            },
                                            className: "h-[33px] w-[50px] !rounded-[6px]"
                                        })
                                    })
                                })]
                            }), (0, c.jsx)("div", {
                                className: Z().highlight
                            })]
                        })]
                    })
                };
            var eY = i(95157),
                eq = i.n(eY),
                eK = i(23114),
                eX = i(88241),
                e$ = i(97109),
                eQ = i(18674),
                e0 = i.n(eQ);
            let e1 = e => {
                let {
                    children: t,
                    className: i
                } = e, [l, s] = (0, M.useState)(null), [n, a] = (0, M.useState)(0), [r, o] = (0, M.useState)(0);
                return (0, M.useEffect)(() => {
                    if (l) {
                        let e = window.visualViewport,
                            t = () => {
                                e && (o(e.height), a(e.offsetTop))
                            };
                        return t(), null == e || e.addEventListener("resize", t), null == e || e.addEventListener("scroll", t), () => {
                            null == e || e.removeEventListener("resize", t), null == e || e.removeEventListener("scroll", t)
                        }
                    }
                }, [l]), (0, c.jsxs)(c.Fragment, {
                    children: [(0, c.jsx)("div", {
                        ref: s,
                        className: (0, F.Z)("invisible fixed h-full w-full")
                    }), (0, c.jsx)("div", {
                        className: (0, F.Z)(e0().container, i),
                        style: {
                            position: "fixed",
                            left: 0,
                            right: 0,
                            top: n,
                            height: r
                        },
                        children: t
                    })]
                })
            };
            var e2 = i(46079),
                e4 = i.n(e2);
            let e5 = e => {
                    let {
                        visible: t,
                        onClose: i
                    } = e, [l, s] = (0, M.useState)(!1), [n, a] = (0, M.useState)(null), [r, o] = (0, M.useState)(!1), [d, u] = (0, M.useState)(""), {
                        createLink: x
                    } = eU(), h = e => {
                        let t = x(e, "add-bar");
                        return t ? (i(), !0) : (s(!0), u(e), !1)
                    }, m = () => {
                        d ? h(d) : navigator.clipboard.readText().then(e => {
                            e && h(e)
                        })
                    }, p = e => {
                        if (!e.clipboardData) return;
                        let t = e.clipboardData.getData("text").trim();
                        e.preventDefault(), e.stopPropagation(), t && h(t)
                    }, v = e => {
                        e.preventDefault(), d && h(d)
                    }, g = () => {
                        o(!1)
                    };
                    return (0, M.useEffect)(() => {
                        if (t) {
                            u(""), s(!1);
                            let e = (0, eV.$)(),
                                t = e => {
                                    "Escape" === e.key && (e.preventDefault(), e.stopPropagation(), i())
                                };
                            return window.addEventListener("keydown", t), null == e || e.addEventListener("keydown", t), () => {
                                window.removeEventListener("keydown", t), null == e || e.removeEventListener("keydown", t)
                            }
                        }
                    }, [t]), (0, M.useEffect)(() => {
                        t && n && n.focus()
                    }, [t, n]), (0, M.useEffect)(() => {
                        let e = e => {
                                let t = e.target,
                                    l = !!t.closest("[data-bento-menu]"),
                                    s = !!t.closest("button:not([data-link-button]):not([data-link-menu-button])");
                                (!l || s) && i()
                            },
                            t = (0, eV.$)();
                        return window.addEventListener("click", e), null == t || t.addEventListener("click", e), () => {
                            window.removeEventListener("click", e), null == t || t.removeEventListener("click", e)
                        }
                    }, []), (0, M.useEffect)(() => {
                        if (r) return (0, eV.t)(), document.addEventListener("focusout", g), () => {
                            document.removeEventListener("focusout", g)
                        }
                    }, [r]), (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("div", {
                            className: (0, F.Z)("fixed inset-0 z-[50] transition-colors ease-in-out", !t && "!pointer-events-none duration-300", t && "!pointer-events-auto bg-black/20 duration-[800ms]")
                        }), (0, c.jsx)(e1, {
                            className: (0, F.Z)("z-[51]"),
                            children: (0, c.jsx)(eX.M, {
                                children: t && (0, c.jsxs)(P.m.div, {
                                    animate: {
                                        opacity: 1,
                                        transition: {
                                            duration: .3,
                                            ease: e$.V,
                                            delay: .6
                                        }
                                    },
                                    initial: {
                                        opacity: 0
                                    },
                                    exit: {
                                        opacity: 0,
                                        pointerEvents: "none",
                                        transition: {
                                            duration: .3,
                                            ease: e$.V,
                                            delay: 0
                                        }
                                    },
                                    className: (0, F.Z)(e4()["link-bar"], t && e4()["link-bar--visible"]),
                                    "data-bento-menu": !0,
                                    children: [(0, c.jsx)("form", {
                                        onSubmit: v,
                                        children: (0, c.jsx)("input", {
                                            ref: a,
                                            value: d,
                                            onFocus: () => o(!0),
                                            onBlur: g,
                                            onChange: e => u(e.target.value),
                                            className: "w-full rounded-[inherit] bg-transparent py-[12px] pl-3 pr-[70px] outline-none",
                                            placeholder: "Enter Link",
                                            onPaste: p
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: "absolute right-2",
                                        children: (0, c.jsxs)("button", {
                                            className: (0, F.Z)(e4().button, d && e4()["button--add"], !d && e4()["button--paste"]),
                                            onClick: m,
                                            "data-link-menu-button": !0,
                                            children: [!d && "Paste", d && "Add"]
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: e4().highlight
                                    })]
                                }, "rein")
                            })
                        })]
                    })
                },
                e9 = (0, L.Ue)((e, t) => ({
                    clearOnUnlock: !1,
                    locked: !1,
                    hoveredId: void 0,
                    selectedId: void 0,
                    toggleSelectedId: i => {
                        t().selectedId === i ? e({
                            selectedId: void 0
                        }) : e({
                            selectedId: i
                        })
                    },
                    setSelectedId: t => {
                        e({
                            selectedId: t
                        })
                    },
                    setHoveredId: i => {
                        !i && t().locked ? e({
                            clearOnUnlock: !0
                        }) : i === t().hoveredId || t().locked ? i === t().hoveredId && e({
                            clearOnUnlock: !1
                        }) : e({
                            hoveredId: i,
                            clearOnUnlock: !1,
                            locked: !1
                        })
                    },
                    setLocked: i => {
                        !i && t().clearOnUnlock ? e({
                            locked: i,
                            hoveredId: void 0
                        }) : e({
                            locked: i
                        })
                    }
                })),
                e7 = () => {
                    let [e, t] = (0, M.useState)(!1), [i, l] = (0, M.useState)(null), [{
                        onboarding: s
                    }] = v(), [n, a] = (0, M.useState)(!1), {
                        triggerMediaPicker: r
                    } = eA(), {
                        createSectionTitle: o
                    } = eT(), {
                        createMap: d
                    } = eO(), {
                        createRichText: u
                    } = eR(), x = e9(e => e.selectedId), h = (0, eK.q)(0, {
                        stiffness: 75,
                        damping: 14,
                        mass: 1
                    }), m = (0, eZ.A)(e => e.engine);
                    return (0, M.useEffect)(() => {
                        setTimeout(() => {
                            t(!0)
                        }, 3e3)
                    }, []), (0, M.useEffect)(() => {
                        let e = null == m ? void 0 : m.view.getContainer(),
                            t = null == e ? void 0 : e.ownerDocument.defaultView;
                        if (t) {
                            let e = () => {
                                let e = t.document.body.scrollHeight - t.document.body.clientHeight - t.scrollY,
                                    i = (0, _.uZ)(e / 112, 0, 1),
                                    l = 1 - i;
                                h.set(l >= 0 ? -120 * l : 0)
                            };
                            return t.addEventListener("scroll", e), () => {
                                t.removeEventListener("scroll", e), h.set(0)
                            }
                        }
                    }, [m, h]), (0, c.jsx)(eX.M, {
                        initial: !1,
                        children: !s && !x && (0, c.jsx)(P.m.div, {
                            ref: l,
                            animate: {
                                opacity: 1
                            },
                            style: {
                                y: h
                            },
                            exit: {
                                opacity: 0
                            },
                            initial: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3,
                                ease: e$.V
                            },
                            onAnimationComplete: e => {
                                i && 1 === e.opacity && i.classList.add(eq()["force-full-opacity"])
                            },
                            onAnimationStart: e => {
                                i && i.classList.remove(eq()["force-full-opacity"])
                            },
                            children: (0, c.jsxs)(k, {
                                device: "mobile",
                                children: [(0, c.jsx)(e5, {
                                    visible: n,
                                    onClose: () => {
                                        a(!1)
                                    }
                                }), (0, c.jsxs)("div", {
                                    className: (0, F.Z)(eq()["floating-bar"], e && eq()["floating-bar--initialized"]),
                                    "data-bento-menu": !0,
                                    children: [(0, c.jsxs)("div", {
                                        className: "flex items-center space-x-3",
                                        children: [(0, c.jsx)(ey, {
                                            highlight: "strong",
                                            selected: n,
                                            tooltip: "Link",
                                            onClick: () => a(!n),
                                            "data-link-button": !0,
                                            children: (0, c.jsx)(eb.x, {
                                                size: 14
                                            })
                                        }), (0, c.jsx)(ey, {
                                            tooltip: "Image & Video",
                                            shadow: "strong",
                                            onClick: () => r("add-bar"),
                                            children: (0, c.jsx)(eN, {
                                                size: 24
                                            })
                                        }), (0, c.jsx)(ey, {
                                            tooltip: "Text",
                                            shadow: "strong",
                                            onClick: () => u("add-bar"),
                                            children: (0, c.jsx)(eC, {
                                                size: 24
                                            })
                                        }), (0, c.jsx)(ey, {
                                            tooltip: "Map",
                                            shadow: "strong",
                                            onClick: () => d("add-bar"),
                                            children: (0, c.jsx)(ek, {
                                                size: 24
                                            })
                                        }), (0, c.jsx)(ey, {
                                            highlight: "strong",
                                            tooltip: "Section Title",
                                            onClick: () => o("add-bar"),
                                            children: (0, c.jsx)(eE, {
                                                size: 24
                                            })
                                        })]
                                    }), (0, c.jsx)("div", {
                                        className: eq().highlight
                                    })]
                                })]
                            })
                        }, "flot")
                    }, "animpres")
                };
            var e3 = i(52534),
                e6 = i.n(e3),
                e8 = i(28316);
            let te = e => {
                    var t, i;
                    let {
                        children: l,
                        frameDevice: s
                    } = e, [n, a] = (0, M.useState)(null), [r, o] = (0, M.useState)(!1), d = null == n ? void 0 : null === (t = n.contentWindow) || void 0 === t ? void 0 : null === (i = t.document) || void 0 === i ? void 0 : i.body, u = e => {
                        if (!e) return "None";
                        let t = e.getAttribute("bento-id");
                        if (t) return t;
                        let i = (0, _.x0)();
                        return e.setAttribute("bento-id", i), i
                    }, x = e => {
                        if (!n || !n.contentDocument || "undefined" == typeof document) return !1;
                        let t = n.contentDocument,
                            i = t.head.querySelector('[bento-id="'.concat(e, '"]'));
                        return null != i
                    }, h = () => {
                        if (!n || !n.contentDocument || "undefined" == typeof document) return;
                        let e = n.contentDocument;
                        e.body.style.maxWidth = "100vw";
                        let t = document.getElementsByTagName("link"),
                            i = document.getElementsByTagName("style"),
                            l = e.getElementsByTagName("head").item(0);
                        if (l) {
                            var s, a, d, c, h, m, p;
                            let n = [];
                            for (let e = 0, i = t.length; e < i; e += 1) {
                                let i = t[e],
                                    a = u(i);
                                if (n.push(a), !x(a) && i) {
                                    let e = document.createElement("link");
                                    e.setAttribute("bento-id", a);
                                    let t = i.attributes;
                                    for (let i = 0, l = t.length; i < l; i += 1) {
                                        let l = t[i];
                                        l && e.setAttribute(l.nodeName, null !== (s = l.nodeValue) && void 0 !== s ? s : "")
                                    }
                                    l.appendChild(e)
                                }
                            }
                            for (let t = 0, s = i.length; t < s; t += 1) {
                                let s = u(i[t]);
                                if (n.push(s), x(s)) {
                                    let l = e.head.querySelector('[bento-id="'.concat(s, '"]'));
                                    l && (l.innerHTML = null !== (h = null === (c = i[t]) || void 0 === c ? void 0 : c.innerHTML) && void 0 !== h ? h : "")
                                } else {
                                    let n = e.createElement("style");
                                    n.setAttribute("bento-id", s), n.innerHTML = null !== (d = null === (a = i[t]) || void 0 === a ? void 0 : a.innerHTML) && void 0 !== d ? d : "", l.appendChild(n)
                                }
                            }
                            let r = Array.from(l.getElementsByTagName("link")),
                                o = Array.from(l.getElementsByTagName("style"));
                            r.forEach(e => !n.includes(null !== (m = e.getAttribute("bento-id")) && void 0 !== m ? m : "") && e.remove()), o.forEach(e => !n.includes(null !== (p = e.getAttribute("bento-id")) && void 0 !== p ? p : "") && e.remove()), r.forEach(e => {
                                e && "preload" === e.getAttribute("rel") && (l.appendChild(e.cloneNode()), e.remove())
                            })
                        }
                        document.dispatchEvent(new CustomEvent("bento:iframe:load")), r || o(!0)
                    };
                    return (0, M.useEffect)(() => {
                        if (n) {
                            let e = new MutationObserver(() => {
                                h()
                            });
                            return h(), e.observe(document.head, {
                                childList: !0,
                                subtree: !0
                            }), () => {
                                e.disconnect()
                            }
                        }
                    }, [n]), (0, c.jsx)("iframe", {
                        ref: a,
                        "data-editor-iframe": !0,
                        onLoad: () => {
                            o(!0), h()
                        },
                        style: {
                            visibility: r ? "visible" : "hidden"
                        },
                        className: (0, F.Z)(e6().frame),
                        children: d && (0, e8.createPortal)((0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(eM.C, {}), r && l]
                        }), d)
                    })
                },
                tt = e => {
                    var t;
                    let {
                        children: l,
                        className: s
                    } = e, {
                        user: n
                    } = (0, f.aC)(), [a, r] = (0, M.useState)(null), [o, d] = (0, M.useState)(null), [u, x] = (0, M.useState)(null), h = C(), m = (0, eZ.A)(e => e.engine), p = (0, N.AS)(), v = (0, N.AS)(), [g, _] = (0, M.useState)(!1), {
                        device: j,
                        setTransitioning: w
                    } = I(), y = "desktop" === h ? j : "desktop", b = "mobile" === y ? 452 + ((null == m ? void 0 : null === (t = m.debug) || void 0 === t ? void 0 : t.isDebugging()) ? 200 : 0) : void 0, [k, E] = (0, M.useState)(() => null != b ? b : p), S = "desktop" !== y ? "min(80vh, 900px)" : void 0;
                    return (0, M.useEffect)(() => {
                        let e = null == a ? void 0 : a.querySelector("iframe");
                        if (e) {
                            if ("mobile" === j) {
                                var t, i, l;
                                null === (t = e.contentDocument) || void 0 === t || t.body.classList.add("no-scrollbar"), null === (i = null === (l = e.contentDocument) || void 0 === l ? void 0 : l.body.parentElement) || void 0 === i || i.classList.add("no-scrollbar")
                            } else {
                                let t = setTimeout(() => {
                                    var t, i, l;
                                    null === (t = e.contentDocument) || void 0 === t || t.body.classList.remove("no-scrollbar"), null === (i = null === (l = e.contentDocument) || void 0 === l ? void 0 : l.body.parentElement) || void 0 === i || i.classList.remove("no-scrollbar")
                                }, 400);
                                return () => {
                                    clearTimeout(t)
                                }
                            }
                        }
                    }, [a, j]), (0, M.useEffect)(() => {
                        w(!0);
                        let e = setTimeout(() => {
                            w(!1)
                        }, 500);
                        return () => {
                            clearTimeout(e)
                        }
                    }, [j, w]), (0, M.useEffect)(() => {
                        if ("desktop" === h && a) {
                            let e = null == a ? void 0 : a.querySelector("iframe"),
                                t = null == e ? void 0 : e.contentDocument.body;
                            if (t) {
                                t.style.transition = "opacity 0.15s ease-in-out", t.style.opacity = "0";
                                let e = setTimeout(() => {
                                    t.style.opacity = "1"
                                }, 270);
                                return () => {
                                    clearTimeout(e)
                                }
                            }
                        }
                    }, [j]), (0, M.useEffect)(() => {
                        if (o && u && a) {
                            let e, t;
                            let l = async () => {
                                let l = (await i.e(509).then(i.t.bind(i, 27509, 23))).default;
                                e = new l(o, {
                                    axis: "x"
                                }), t = new l(u, {
                                    axis: "x"
                                });
                                let s = a.offsetWidth;
                                e.on("dragStart", (e, t) => {
                                    s = a.offsetWidth, _(!0)
                                }), e.on("dragMove", (e, t, i) => {
                                    a && (a.style.width = "".concat(Math.round(s - 2 * i.x), "px"), u.style.right = "calc(50% - ".concat(a.style.width, " / 2 - 32px)"), u.style.removeProperty("transform"), u.style.removeProperty("left"), E(a.offsetWidth))
                                }), e.on("dragEnd", () => {
                                    _(!1)
                                }), t.on("dragStart", (e, t) => {
                                    s = a.offsetWidth, _(!0)
                                }), t.on("dragMove", (e, t, i) => {
                                    a && (a.style.width = "".concat(Math.round(s + 2 * i.x), "px"), o.style.left = "calc(50% - ".concat(a.style.width, " / 2 - 32px)"), o.style.removeProperty("transform"), E(a.offsetWidth))
                                }), t.on("dragEnd", () => {
                                    _(!1), u.style.right = "calc(50% - ".concat(a.style.width, " / 2 - 32px)"), u.style.removeProperty("left"), u.style.removeProperty("transform")
                                })
                            };
                            return l(), () => {
                                null == e || e.destroy(), null == t || t.destroy()
                            }
                        }
                    }, [o, u, a]), (0, M.useEffect)(() => {
                        E(null != b ? b : p)
                    }, [b]), (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("div", {
                            className: (0, F.Z)(e6()["frame-container"], e6()["frame-container--".concat(y)], !g && e6()["frame-container--animated"], g && "pointer-events-none", s),
                            style: {
                                width: b ? "".concat(b, "px") : void 0,
                                height: null != S ? S : v
                            },
                            ref: r,
                            children: (0, c.jsx)(te, {
                                frameDevice: y,
                                children: l
                            })
                        }), (null == n ? void 0 : n.admin) && (0, c.jsx)(eX.M, {
                            children: "desktop" !== y && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsxs)(P.m.div, {
                                    animate: {
                                        opacity: 1
                                    },
                                    initial: {
                                        opacity: 0
                                    },
                                    transition: {
                                        delay: 3
                                    },
                                    className: "fixed top-4 rounded-lg bg-white px-2 py-1 text-xs font-semibold",
                                    id: "frame-width",
                                    children: [k - 24, "px"]
                                }), (0, c.jsx)(P.m.div, {
                                    animate: {
                                        opacity: 1
                                    },
                                    initial: {
                                        opacity: 0
                                    },
                                    transition: {
                                        delay: 3
                                    },
                                    className: "fixed bottom-1/2 -translate-y-full",
                                    children: (0, c.jsx)("div", {
                                        className: (0, F.Z)("h-8 w-1 cursor-ew-resize rounded-full bg-black", !g && "transition-all duration-[300ms]"),
                                        ref: d,
                                        style: {
                                            left: "calc(50% - ".concat((null != b ? b : 0) / 2, "px - 32px)")
                                        },
                                        draggable: !0
                                    })
                                }), (0, c.jsx)(P.m.div, {
                                    animate: {
                                        opacity: 1
                                    },
                                    initial: {
                                        opacity: 0
                                    },
                                    transition: {
                                        delay: 3
                                    },
                                    className: "fixed bottom-1/2 -translate-y-full",
                                    children: (0, c.jsx)("div", {
                                        className: (0, F.Z)("h-8 w-1 cursor-ew-resize rounded-full bg-black", !g && "transition-all duration-[300ms]"),
                                        ref: x,
                                        style: {
                                            right: "calc(50% - ".concat((null != b ? b : 0) / 2, "px - 32px)")
                                        },
                                        draggable: !0
                                    })
                                })]
                            })
                        })]
                    })
                };
            var ti = i(10799),
                tl = i(6837),
                ts = i(62202);
            let tn = e => {
                let {
                    size: t = 16,
                    className: i
                } = e;
                return (0, c.jsxs)("svg", {
                    width: t,
                    height: t,
                    className: i,
                    viewBox: "0 0 24 24",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [(0, c.jsx)("circle", {
                        cx: "12",
                        cy: "12",
                        r: "12",
                        fill: "#4EDD76"
                    }), (0, c.jsx)("circle", {
                        cx: "12",
                        cy: "12",
                        r: "11.5",
                        stroke: "black",
                        strokeOpacity: "0.06"
                    }), (0, c.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M18.2071 7.79289C18.5976 8.18342 18.5976 8.81658 18.2071 9.20711L11.2071 16.2071C10.8166 16.5976 10.1834 16.5976 9.79289 16.2071L5.79289 12.2071C5.40237 11.8166 5.40237 11.1834 5.79289 10.7929C6.18342 10.4024 6.81658 10.4024 7.20711 10.7929L10.5 14.0858L16.7929 7.79289C17.1834 7.40237 17.8166 7.40237 18.2071 7.79289Z",
                        fill: "white"
                    })]
                })
            };
            var ta = i(85953),
                tr = i.n(ta);
            let to = e => {
                    let {
                        children: t,
                        id: i,
                        visible: l,
                        icon: s
                    } = e, n = e => {
                        ts.Am.dismiss(i), e.preventDefault()
                    };
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(tr().container, l && tr()["container--visible"]),
                        onClick: n,
                        children: ["none" !== s && (0, c.jsx)("div", {
                            className: tr().icon,
                            children: (0, c.jsx)(tn, {
                                size: 24
                            })
                        }), (0, c.jsx)("div", {
                            className: tr().content,
                            children: t
                        })]
                    })
                },
                td = () => {
                    let [{
                        id: e,
                        original: t
                    }] = (0, j.U)(), {
                        publish: i,
                        trueProfile: l
                    } = function() {
                        let {
                            user: e
                        } = (0, f.aC)(), [{
                            profile: t,
                            id: i,
                            publishing: l
                        }, s] = (0, j.U)(), n = { ...t,
                            bento: { ...t.bento,
                                items: t.bento.items.filter(ti.zF)
                            }
                        }, {
                            trigger: a,
                            isMutating: r
                        } = (0, tl.wp)(null == e ? void 0 : e.id), o = async () => {
                            if (e && i) return s({
                                type: "set-editor-field",
                                field: "publishing",
                                value: !0
                            }), await a({
                                bento: n.bento,
                                bio: n.bio,
                                image: n.image,
                                name: n.name
                            }).finally(() => {
                                s({
                                    type: "set-editor-field",
                                    field: "publishing",
                                    value: !1
                                }), s({
                                    type: "commit",
                                    profile: n
                                })
                            })
                        };
                        return {
                            publish: o,
                            loading: l,
                            trueProfile: n
                        }
                    }(), {
                        user: s
                    } = (0, f.aC)(), n = JSON.stringify(l), a = n !== JSON.stringify(t);
                    (0, M.useEffect)(() => {
                        if (e === (null == s ? void 0 : s.id) && a) {
                            let e = setTimeout(() => {
                                i().catch(e => {
                                    ts.ZP.custom(e => (0, c.jsx)(to, {
                                        id: e.id,
                                        visible: e.visible,
                                        children: "Couldn't save Bento. Try again, or refresh the page."
                                    }))
                                })
                            }, 500);
                            return () => {
                                clearTimeout(e)
                            }
                        }
                    }, [a, n, e, null == s ? void 0 : s.id])
                };
            var tc = i(22699),
                tu = i.n(tc),
                tx = i(46679),
                th = i(8362),
                tm = i(98478);
            (o = d || (d = {})).ON_LAYOUT_CHANGE = "onlayoutchange", o.ON_DEVICE_CHANGED = "ondevicechanged", o.ON_DRAG_START = "ondragstart", o.ON_DRAG_END = "ondragend";
            class tp extends tu() {
                setDevice(e) {
                    e !== this.device && (this.device = e, this.settings = this.responsiveSettings[e], this.items = void 0, this.emit(d.ON_DEVICE_CHANGED, this.device))
                }
                getItems() {
                    if (!this.items) {
                        let e = (0, tm.f)(this.data, this.device);
                        this.items = (0, th.ru)(e, this.device)
                    }
                    return (0, tx.F_)(this.items), (0, tx.zO)(this.items, this.device), (0, tx.ef)(this.items), this.items
                }
                setItems(e) {
                    this.data[this.device] = e, this.items = void 0, this.render()
                }
                commit() {
                    this.debug.log("[GridEngine] Committing items...");
                    let e = this.getItems(),
                        t = this.device;
                    JSON.stringify(e) !== this.previousCommit && (this.previousCommit = JSON.stringify(e), this.emit(d.ON_LAYOUT_CHANGE, e, t))
                }
                updateData(e) {
                    this.data = {
                        desktop: [...e.desktop],
                        mobile: [...e.mobile]
                    }, this.items = void 0, this.previousCommit = JSON.stringify(this.getItems()), (0, tx.sr)(this.data), this.render()
                }
                setEditable(e) {
                    this.editable = e, this.swap.refresh()
                }
                render() {
                    this.view.render(), this.debug.render()
                }
                destroy() {
                    this.view.destroy(), this.swap.destroy(), this.debug.destroy(), this.removeAllListeners()
                }
                constructor(e, t, i, l, s, n, a, r) {
                    super(), this.data = e, this.breakpoints = t, this.responsiveSettings = i, this.editable = l, this.view = s, this.swap = n, this.animation = a, this.debug = r, this.device = "desktop", this.previousCommit = void 0, this.breakpoints = t, this.view.setEngine(this), this.swap.setEngine(this), this.animation.setEngine(this), this.debug.setEngine(this), this.device = this.view.getDevice(), this.settings = i[this.device], this.swap.refresh(), (0, tx.sr)(this.data), this.render()
                }
            }
            var tv = i(6357),
                tg = i(94905),
                tf = i(99864);
            let t_ = {
                    "section-header": {
                        mobile: 24,
                        desktop: 40
                    }
                },
                tj = {
                    "section-header": {
                        mobile: -20,
                        desktop: -30
                    }
                },
                tw = (e, t) => {
                    var i, l;
                    return null !== (l = null === (i = t_[e.type]) || void 0 === i ? void 0 : i[t]) && void 0 !== l ? l : 0
                },
                ty = (e, t) => {
                    var i, l;
                    return null !== (l = null === (i = tj[e.type]) || void 0 === i ? void 0 : i[t]) && void 0 !== l ? l : 0
                };
            class tb {
                getDevice() {
                    if (!this.engine) throw Error("No engine");
                    return (0, tm.X)(this.win.innerWidth, this.engine.breakpoints)
                }
                onResize() {
                    if (!this.engine) throw Error("No engine");
                    let e = this.getDevice();
                    e !== this.engine.device && this.engine.setDevice(e), this.engine.render()
                }
                setEngine(e) {
                    this.engine = e, this._resizeHandler = this.onResize.bind(this), this.win.addEventListener("resize", this._resizeHandler)
                }
                getCellSize() {
                    if (!this.engine) throw Error("No engine");
                    let {
                        device: e
                    } = this.engine, {
                        spacing: t
                    } = this.engine.settings;
                    return (this.container.clientWidth + t) / (0, tf.D)(e) - t
                }
                getDimSize(e, t) {
                    if (!this.engine) throw Error("No engine");
                    let {
                        device: i
                    } = this.engine, {
                        spacing: l
                    } = this.engine.settings;
                    return {
                        width: this.getCellSize() * t + l * (t - 1),
                        height: this.getCellSize() * e + l * (e - 1)
                    }
                }
                getViewSlice() {
                    if (!this.engine) throw Error("No engine");
                    let e = this.engine.settings.spacing,
                        t = this.win.document.body,
                        i = this.container.getBoundingClientRect(),
                        l = t.scrollTop + i.top,
                        s = t.scrollTop - l,
                        n = s + Math.min(this.win.innerHeight, i.bottom),
                        a = this.heights.findIndex(e => e.start >= s),
                        r = this.heights.findIndex(t => t.end >= n - 2 * e);
                    return {
                        top: -1 === a ? 0 : a,
                        bottom: -1 === r ? this.heights.length : r
                    }
                }
                gridPosToView(e) {
                    if (!this.engine) throw Error("No engine");
                    let t = this.engine.settings.spacing,
                        i = this.getCellSize(),
                        l = 0;
                    return l = e.y < this.heights.length ? this.heights[e.y].start : this.heights.length > 0 ? this.heights[this.heights.length - 1].end + t + (i + t) * (e.y - this.heights.length) : (i + t) * e.y, {
                        vx: e.x * (i + t),
                        vy: l
                    }
                }
                getGridHeight() {
                    return 0 === this.heights.length ? 0 : this.heights[this.heights.length - 1].end
                }
                getHeights() {
                    return this.heights
                }
                getContainer() {
                    return this.container
                }
                lock(e) {
                    this.locked.push(e), this.render()
                }
                unlock(e) {
                    this.locked = this.locked.filter(t => t !== e), this.render()
                }
                getEl(e) {
                    return this.container.querySelector('[data-id="'.concat(e, '"]'))
                }
                render() {
                    if (!this.engine) throw Error("No engine");
                    let e = this.engine.getItems(),
                        {
                            device: t
                        } = this.engine,
                        {
                            spacing: i
                        } = this.engine.settings;
                    if (this.snapshot.device === t && this.snapshot.spacing === i && this.snapshot.containerWidth === this.container.clientWidth && this.snapshot.items === e && JSON.stringify(this.snapshot.locked) === JSON.stringify(this.locked)) return;
                    this.snapshot = {
                        device: t,
                        spacing: i,
                        containerWidth: this.container.clientWidth,
                        items: e,
                        locked: [...this.locked]
                    }, this.engine.debug.log("[ViewModule] Rendering Grid (Device: ".concat(this.engine.device, " with spacing ").concat(i, ")..."));
                    let l = Math.abs(this.containerSize - this.container.clientWidth) >= 1;
                    this.containerSize = this.container.clientWidth;
                    let s = (0, tv.AQ)(e);
                    this.heights = [];
                    let n = [],
                        a = this.getCellSize();
                    for (let r = 0; r < s; r++) {
                        let s = (0, tg.d)(r, e),
                            o = r > 0 ? this.heights[r - 1] : {
                                start: 0,
                                end: 0,
                                spacingBottom: 0,
                                spacingTop: 0
                            },
                            d = {
                                start: o.end + (r > 0 ? i : 0) + o.spacingBottom,
                                end: o.end + (r > 0 ? i : 0) + o.spacingBottom + a,
                                spacingBottom: 0 === s.length ? 0 : s.reduce((e, i) => Math.max(ty(i, t), e), -1e4),
                                spacingTop: 0
                            };
                        s.forEach(e => {
                            this.engine.animation.register(e.id);
                            let s = this.getEl(e.id),
                                c = e.pos,
                                u = e.dim,
                                x = tw(e, t),
                                h = r > 0 ? o.end + i + x + o.spacingBottom : 0,
                                m = (a + i) * c.x,
                                p = a * u.w + i * (u.w - 1),
                                v = a * u.h + i * (u.h - 1),
                                g = this.locked.includes(e.id);
                            if (!s) return;
                            let f = s.style.transform;
                            s.style.position = "absolute", s.style.left = "0px", s.style.top = "0px";
                            let _ = 67.5 * u.w + 40 * (u.w - 1),
                                j = 67.5 * u.h + 40 * (u.h - 1);
                            s.style.width = p + "px", s.style.setProperty("--widget-unit-w", "".concat(p / _)), s.style.setProperty("--widget-unit-h", "".concat(v / j)), s.style.setProperty("--widget-width-val", "".concat(p)), s.style.setProperty("--widget-width", p + "px"), s.style.height = "fixed" === e.mode ? v + "px" : "auto", s.style.setProperty("--widget-height-val", "fixed" === e.mode ? "".concat(v) : null), s.style.setProperty("--widget-height", "fixed" === e.mode ? v + "px" : "auto"), s.style.minHeight = "fixed" === e.mode ? "none" : "50px", s.style.display = "flex", s.style.flexDirection = "column";
                            let w = {
                                    type: e.type,
                                    id: e.id,
                                    width: p,
                                    height: v,
                                    left: m,
                                    top: h,
                                    locked: g
                                },
                                y = this.states.find(t => t.id === e.id);
                            if (!this.initialized || l || g) g || this.initialized ? g || (s.style.transform = "translate(".concat(m, "px, ").concat(h, "px)")) : this.engine.animation.onInitial(w);
                            else if (y) {
                                let t = 5 > Math.abs(y.width - w.width) && 5 > Math.abs(y.height - w.height),
                                    i = 5 > Math.abs(y.left - w.left) && 5 > Math.abs(y.top - w.top),
                                    l = !w.locked && y.locked,
                                    s = y.type !== w.type;
                                s ? (this.engine.animation.unregister(e.id), this.engine.animation.register(e.id), this.engine.animation.onUnghosted(y, w)) : t || i ? t ? i ? l && this.engine.animation.onUnlocked(w, f) : this.engine.animation.onPositionChanged(y, w, f) : this.engine.animation.onDimensionChanged(y, w) : this.engine.animation.onDimensionAndPositionChanged(y, w, f)
                            } else this.engine.animation.onAdded(w);
                            n.push(w), "dynamic" === e.mode && (d = { ...d,
                                start: h,
                                end: h + s.clientHeight,
                                spacingTop: x
                            })
                        }), this.heights.push(d)
                    }
                    let r = "desktop" === this.engine.device ? 150 : 50;
                    this.container.style.height = "".concat(this.getGridHeight() + i + r, "px"), this.states = n, this.initialized = !0
                }
                destroy() {
                    this.win.removeEventListener("resize", this._resizeHandler)
                }
                constructor(e) {
                    this.container = e, this.heights = [], this.states = [], this.containerSize = 0, this.initialized = !1, this.locked = [], this.snapshot = {
                        device: "desktop",
                        spacing: 0,
                        containerWidth: 0,
                        items: [],
                        locked: []
                    }, this.win = this.container.ownerDocument.defaultView, this.containerSize = e.clientWidth
                }
            }
            class tN {
                setEngine(e) {
                    this.engine = e
                }
                log() {
                    for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                    this.debug && console.log(...t)
                }
                isDebugging() {
                    return this.debug
                }
                getDebugContainer() {
                    let e = this.container.ownerDocument,
                        t = e.querySelector("[data-debug=true]"),
                        i = this.container.getBoundingClientRect();
                    return t ? (t.style.top = i.top + e.body.scrollTop + "px", t.style.left = i.left + "px", t.style.width = i.width + "px", t.style.height = i.height + "px") : ((t = e.createElement("div")).setAttribute("data-debug", "true"), t.style.pointerEvents = "none", t.style.position = "absolute", t.style.top = i.top + e.body.scrollTop + "px", t.style.left = i.left + "px", t.style.width = i.width + "px", t.style.height = i.height + "px", e.body.appendChild(t)), t
                }
                removeDebugContainer() {
                    let e = this.container.ownerDocument,
                        t = e.querySelector("[data-debug=true]");
                    t && t.remove()
                }
                drawDebugBox(e, t, i) {
                    let l = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 30,
                        s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 30;
                    if (!this.debug) return;
                    let n = this.getDebugContainer(),
                        a = n.querySelector('[data-debug=true] [data-id="'.concat(e, '"]'));
                    a || ((a = document.createElement("div")).setAttribute("mouse", "true"), a.setAttribute("data-id", e), a.style.pointerEvents = "none", n.appendChild(a)), a.style.width = l + "px", a.style.height = s + "px", a.style.borderRadius = "24px", a.style.background = "#f9f9f9", a.style.position = "absolute", a.style.left = t + "px", a.style.top = i + "px"
                }
                debugDrawHeights(e) {
                    if (!this.engine || !this.debug) return;
                    let {
                        spacing: t
                    } = this.engine.settings, i = this.getDebugContainer(), l = Array.from(i.querySelectorAll("[data-debug=true] [debug-line]"));
                    for (let e of l) e.remove();
                    let s = function(e, t) {
                            let l = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
                                s = document.createElement("div");
                            s.setAttribute("debug-line", "true"), s.style.position = "absolute", s.style.top = e + "px", s.style.left = "-10px", s.style.width = "calc(100% + 20px)", s.style.height = "1px", s.style.borderTop = "1px solid ".concat(t), s.style.opacity = "0.2", i.appendChild(s);
                            let n = document.createElement("div");
                            n.setAttribute("debug-line", "true"), n.innerHTML = "<span>".concat(l, '</span> <span style="width:50px;display:inline-block;text-align:right;font-variant-numeric:tabular-nums">').concat(e, "px</span>"), n.style.position = "absolute", n.style.top = e + "px", n.style.left = "-12px", n.style.fontSize = "8px", n.style.color = t, n.style.fontWeight = "500", n.style.transform = "translateX(-100%) translateY(-50%)", i.appendChild(n)
                        },
                        n = function(e, t) {
                            let l = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
                                s = document.createElement("div");
                            s.setAttribute("debug-line", "true"), s.style.position = "absolute", s.style.top = "-10px", s.style.left = e + "px", s.style.width = "1px", s.style.height = "calc(100% + 20px)", s.style.borderLeft = "1px solid ".concat(t), s.style.opacity = "0.2", i.appendChild(s);
                            let n = document.createElement("div");
                            n.setAttribute("debug-line", "true"), n.innerHTML = "<span>".concat(l, '</span> <span style="width:50px;display:inline-block;text-align:right;font-variant-numeric:tabular-nums">').concat(e, "px</span>"), n.style.position = "absolute", n.style.left = e + "px", n.style.top = "-12px", n.style.fontSize = "8px", n.style.color = t, n.style.fontWeight = "500", n.style.transform = "translateX(-100%) translateY(-50%)", i.appendChild(n)
                        },
                        a = (e, t, l, s) => {
                            let n = document.createElement("div");
                            n.setAttribute("debug-line", "true"), n.style.position = "absolute", n.style.left = e + "px", n.style.top = t + "px", n.style.width = l + "px", n.style.height = s + "px", n.style.background = "#aaa", n.style.opacity = "0.2", i.appendChild(n)
                        },
                        r = (0, tf.D)(this.engine.device),
                        o = this.engine.view.getCellSize(),
                        d = 0;
                    for (let i of e) {
                        s(i.start, "#eb4d4b", "(Row ".concat(d, ")")), s(i.end, "#30336b");
                        for (let e = 0; e < r; e++) a((o + t) * e, i.start, o, i.end - i.start);
                        d++
                    }
                    for (let e = 0; e < r; e++) n((o + t) * e, "#eb4d4b"), n((o + t) * e + o, "#30336b")
                }
                render() {
                    if (!this.engine) throw Error("No engine");
                    if (!this.debug) {
                        this.removeDebugContainer();
                        return
                    }
                    this.debugDrawHeights(this.engine.view.getHeights())
                }
                destroy() {}
                constructor(e) {
                    this.container = e, this.debug = !1
                }
            }
            var tC = i(52271),
                tk = i(98696),
                tE = i(32845);
            class tS {
                setEngine(e) {
                    this.engine = e
                }
                refresh() {
                    if (!this.engine) throw Error("No engine");
                    this.engine.editable ? this.createHandles() : this.deleteHandles()
                }
                refreshId(e) {
                    if (!this.engine) throw Error("No engine");
                    if (this.engine.editable) {
                        let t = this.engine.view.getContainer().querySelector('[data-id="'.concat(e, '"]'));
                        t && this.createHandle(t)
                    }
                }
                setDragHandle(e) {
                    this.dragHandleSelector = e, this.deleteHandles(), this.refresh()
                }
                createHandles() {
                    if (!this.engine) throw Error("No engine");
                    let e = this.engine.view.getContainer().querySelectorAll("[data-id]");
                    e.forEach(e => {
                        this.createHandle(e)
                    });
                    let t = this.handles.filter(e => !e.element);
                    t.forEach(e => e.destroy()), this.handles = this.handles.filter(e => !!e.element)
                }
                createHandle(e) {
                    if (!this.engine) return;
                    let t = e.getAttribute("data-id"),
                        i = this.engine.getItems().find(e => e.id === t);
                    if (!t || !i || "ghost" === i.type || "ghost-materialized" === i.type || this.handles.find(t => t.element === e)) return;
                    let l = new tC.J(e, {
                        handle: this.dragHandleSelector,
                        mode: "bento-grid"
                    });
                    l.on("dragStart", (e, i) => this.handleDragStart(t, l)), l.on("dragEnd", (e, i) => this.handleDragEnd(t, l)), l.on("dragMove", (e, i, s) => this.handleDrag(t, s, l)), this.handles.push(l), e.classList.add("bento-grid__item--editable")
                }
                deleteHandles() {
                    if (!this.engine) throw Error("No engine");
                    this.handles.forEach(e => e.destroy()), this.handles = [];
                    let e = this.engine.view.getContainer().querySelectorAll("[data-id]");
                    e.forEach(e => {
                        e.classList.remove("bento-grid__item--editable")
                    })
                }
                getGridPosition(e, t, i, l) {
                    if (!this.engine) throw Error("No engine");
                    let s = this.engine.settings.spacing,
                        n = (0, tf.D)(this.engine.device),
                        a = this.engine.view.getCellSize(),
                        r = this.engine.view.getHeights(),
                        o = (0, _.uZ)(Math.floor(e / (a + s)), 0, n);
                    for (let e = 0; e < r.length; e++) {
                        let i = r[e],
                            n = i.spacingBottom,
                            a = n < 0,
                            d = this.dir.y > 0 ? s : 0,
                            c = a ? Math.max(n - 10, -(i.end - i.start - 10)) : 0;
                        if (t >= i.start - d && t <= i.end + c) return {
                            x: o,
                            y: e
                        };
                        if (t < i.start - d) return {
                            x: o,
                            y: l
                        }
                    }
                    return {
                        x: o,
                        y: r.length
                    }
                }
                handleDragStart(e, t) {
                    if (!this.engine) throw Error("No engine");
                    t.element && t.element.classList.add("bento-grid__item--dragging"), this.moveVector = {
                        x: 0,
                        y: 0
                    }, this.engine.animation.onDragStart(e), this.engine.view.lock(e), this.timeouts[e] && clearTimeout(this.timeouts[e]), this.engine.emit(d.ON_DRAG_START, e)
                }
                handleDragEnd(e, t) {
                    if (!this.engine) throw Error("No engine");
                    t.element && t.element.classList.remove("bento-grid__item--dragging");
                    let i = this.engine.getItems().find(t => t.id === e);
                    if (this.engine.animation.onDragEnd(e), this.engine.view.unlock(e), this.engine.commit(), i) {
                        var l;
                        (0, z.c)().track("WIDGET_MOVED", {
                            type: null === (l = i.data) || void 0 === l ? void 0 : l.type
                        }), ei.f.movedWidget(i.id)
                    }
                    this.timeouts[e] = setTimeout(() => {
                        this.deletePreview(e), this.timeouts[e] = void 0
                    }, 800), this.engine.emit(d.ON_DRAG_END, e)
                }
                handleDrag(e, t, i) {
                    if (!this.engine) throw Error("No engine");
                    this.engine.animation.onDrag(e, t);
                    let l = {
                            x: this.moveVector.x - t.x,
                            y: this.moveVector.y - t.y
                        },
                        s = Math.sqrt(l.x ** 2 + l.y ** 2),
                        n = {
                            x: this.moveVector2.x - t.x,
                            y: this.moveVector2.y - t.y
                        },
                        a = Math.sqrt(n.x ** 2 + n.y ** 2),
                        r = (0, tf.D)(this.engine.device);
                    if (a > 30) {
                        this.dir = {
                            x: t.x - this.moveVector2.x,
                            y: t.y - this.moveVector2.y
                        };
                        let e = Math.atan2(this.dir.y, this.dir.x);
                        this.angle = e * (180 / Math.PI), this.moveVector2 = t
                    }
                    if (s > 10) {
                        this.moveVector = t;
                        let l = this.engine.getItems().find(t => t.id === e);
                        if (!l) return;
                        let s = this.getGridPosition(i.position.x, i.position.y, l.pos.x, l.pos.y),
                            n = { ...s,
                                x: (0, _.uZ)(Math.round(.5 * s.x) / .5, 0, r - l.dim.w)
                            };
                        this.moveWidget(l.id, n), this.makePreview(l.id, i.element)
                    }
                }
                makePreview(e, t) {
                    if (!t) return;
                    if (!this.engine) throw Error("No engine");
                    let i = this.engine.view.getContainer(),
                        l = this.engine.getItems(),
                        s = l.find(t => t.id === e);
                    if (!s) return;
                    let n = t.querySelector("[data-widget-content-container]"),
                        a = i.querySelector('[data-bento-grid-preview="'.concat(e, '"]')),
                        r = this.engine.view.gridPosToView(s.pos),
                        o = !1;
                    if (!a) {
                        let e = i.ownerDocument;
                        (a = e.createElement("div")).style.boxShadow = "inset 0px 2px 4px rgba(0,0,0,0.04)", n && (a.style.borderRadius = "".concat(getComputedStyle(n).borderRadius)), o = !0
                    }
                    let d = t.clientWidth,
                        c = t.clientHeight;
                    a.style.position = "absolute", a.style.zIndex = "1", a.style.pointerEvents = "none", a.style.width = "".concat(d, "px"), a.style.height = "".concat(c, "px"), a.style.left = "".concat(r.vx, "px"), a.style.top = "".concat(r.vy, "px"), a.setAttribute("data-bento-grid-preview", e), a.classList.add("bento-grid__preview"), o && i.appendChild(a)
                }
                deletePreview(e) {
                    if (!this.engine) throw Error("No engine");
                    let t = this.engine.view.getContainer(),
                        i = t.querySelector('[data-bento-grid-preview="'.concat(e, '"]'));
                    i && i.remove()
                }
                moveWidget(e, t) {
                    if (!this.engine) throw Error("No engine");
                    let i = this.engine.getItems(),
                        l = i.find(t => t.id === e),
                        s = { ...l,
                            pos: t
                        };
                    if (s.pos.x === l.pos.x && s.pos.y === l.pos.y) return;
                    let n = (0, tE.ZB)(l, s, i, this.angle),
                        a = (0, tk.F)(n),
                        r = JSON.stringify(i) !== JSON.stringify(a);
                    r && this.engine.setItems(a)
                }
                destroy() {
                    this.handles.forEach(e => e.destroy())
                }
                constructor() {
                    this.handles = [], this.moveVector = {
                        x: 0,
                        y: 0
                    }, this.moveVector2 = {
                        x: 0,
                        y: 0
                    }, this.dir = {
                        x: 0,
                        y: 0
                    }, this.angle = 0, this.timeouts = {}
                }
            }
            var tL = i(1920),
                tI = i(46163),
                tD = i(32401);
            class tZ {
                setEngine(e) {
                    this.engine = e
                }
                getDragEl(e) {
                    if (!this.engine) throw Error("No engine");
                    return this.engine.view.getEl(e)
                }
                getContentEl(e) {
                    if (!this.engine) throw Error("No engine");
                    if (!this.contentEls[e]) {
                        var t;
                        this.contentEls[e] = null === (t = this.engine.view.getEl(e)) || void 0 === t ? void 0 : t.querySelector("[data-item-content]")
                    }
                    return this.contentEls[e]
                }
                unregister(e) {
                    this.registered[e] = !1, this.contentEls[e] = void 0
                }
                register(e) {
                    if (this.registered[e]) return;
                    this.registered[e] = !0;
                    let t = this.getDragEl(e),
                        i = this.getContentEl(e);
                    t && (t.style.willChange = "transform"), i && (i.style.willChange = "transform")
                }
                emitResizeStarted(e, t, i) {
                    window.dispatchEvent(new CustomEvent("bento:grid:widget:resize:start", {
                        detail: {
                            id: e,
                            before: t,
                            after: i
                        }
                    }))
                }
                emitResizeEnded(e, t, i) {
                    window.dispatchEvent(new CustomEvent("bento:grid:widget:resize:end", {
                        detail: {
                            id: e,
                            before: t,
                            after: i
                        }
                    }))
                }
                animateTransform(e, t, i) {
                    this.timeouts[e] && clearTimeout(this.timeouts[e]), t.style.transition = "transform 0.8s cubic-bezier(.29,1.28,.47,.99)", t.style.transform = i, this.timeouts[e] = setTimeout(() => {
                        t.style.transition = ""
                    }, 800)
                }
                onDragStart(e) {
                    if (!this.engine) throw Error("No engine");
                    this.moveVector = {
                        x: 0,
                        y: 0
                    };
                    let t = this.controls[e];
                    t && t.stop();
                    let i = this.getDragEl(e);
                    this.timeouts[e] && (clearTimeout(this.timeouts[e]), i && (i.style.transition = ""))
                }
                onDragEnd(e) {
                    if (!this.engine) throw Error("No engine");
                    this.moveVector = {
                        x: 0,
                        y: 0
                    };
                    let t = this.getContentEl(e);
                    t && (0, tI.j)([t], {
                        rotate: 0,
                        scale: 1
                    }, {
                        easing: (0, tD.S)()
                    })
                }
                onDrag(e, t) {
                    if (!this.engine) throw Error("No engine");
                    let i = this.getContentEl(e);
                    if (!i) return;
                    let l = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                    if (l) return;
                    let s = this.moveVector.x - t.x;
                    this.moveVector = t, this.controls[e] = (0, tI.j)([i], {
                        rotate: Math.sign(s) * Math.min(Math.abs(s) / 3, 45)
                    }, {
                        easing: (0, tD.S)()
                    })
                }
                onDimensionChanged(e, t) {
                    if (!this.engine) throw Error("No engine");
                    if (e.id !== t.id) throw Error("Id missmatch");
                    let i = t.id,
                        l = this.getDragEl(t.id);
                    if (l) {
                        if (this.timeouts[i]) {
                            var s, n;
                            null === (n = (s = this.emits)[i]) || void 0 === n || n.call(s), clearTimeout(this.timeouts[i + "emit"]), clearTimeout(this.timeouts[i])
                        }
                        l.style.transition = "width 0.8s cubic-bezier(.29,1.28,.47,.99), height 0.8s cubic-bezier(.29,1.28,.47,.99)", l.style.width = "".concat(t.width, "px"), l.style.height = "".concat(t.height, "px"), this.emitResizeStarted(i, e, t), this.emits[i] = () => {
                            this.emitResizeEnded(i, e, t)
                        }, this.timeouts[i + "emit"] = setTimeout(() => {
                            var e, t;
                            null === (t = (e = this.emits)[i]) || void 0 === t || t.call(e), this.emits[i] = void 0
                        }, 800), this.timeouts[i] = setTimeout(() => {
                            l.style.transition = ""
                        }, 800)
                    }
                }
                onPositionChanged(e, t, i) {
                    if (!this.engine) throw Error("No engine");
                    if (e.id !== t.id) throw Error("Id missmatch");
                    let l = this.getDragEl(t.id);
                    if (l) {
                        let e = this.controls[t.id];
                        e && e.stop(), this.animateTransform(t.id, l, "translate(".concat(t.left, "px, ").concat(t.top, "px)"))
                    }
                }
                onDimensionAndPositionChanged(e, t, i) {
                    if (!this.engine) throw Error("No engine");
                    if (e.id !== t.id) throw Error("Id missmatch");
                    let l = this.getDragEl(t.id);
                    if (l) {
                        var s, n, a;
                        this.controls[t.id] && (null === (s = this.controls[t.id]) || void 0 === s || s.stop()), this.timeouts[t.id] && (null === (a = (n = this.emits)[t.id]) || void 0 === a || a.call(n), clearTimeout(this.timeouts[t.id + "emit"]), clearTimeout(this.timeouts[t.id])), this.emitResizeStarted(e.id, e, t), this.controls[t.id] = (0, tI.j)([l], {
                            width: ["".concat(e.width, "px"), "".concat(t.width, "px")],
                            height: ["".concat(e.height, "px"), "".concat(t.height, "px")],
                            transform: "translate(".concat(t.left, "px, ").concat(t.top, "px)")
                        }, {
                            easing: [.25, 1, .5, 1],
                            duration: .5
                        }), this.emits[t.id] = () => {
                            this.emitResizeEnded(e.id, e, t)
                        }, this.timeouts[t.id + "emit"] = setTimeout(() => {
                            var e, i;
                            null === (i = (e = this.emits)[t.id]) || void 0 === i || i.call(e), this.emits[t.id] = void 0
                        }, 500)
                    }
                }
                onUnlocked(e, t) {
                    if (!this.engine) throw Error("No engine");
                    let i = this.getDragEl(e.id);
                    i && this.animateTransform(e.id, i, "translate(".concat(e.left, "px, ").concat(e.top, "px)"))
                }
                onInitial(e) {
                    if (!this.engine) throw Error("No engine");
                    let t = this.engine.view.getDevice(),
                        i = (0, tf.D)(t),
                        l = this.engine.view.getCellSize(),
                        s = this.engine.getItems().find(t => t.id === e.id),
                        n = this.getDragEl(e.id),
                        a = this.getContentEl(e.id),
                        r = e.left / (i * l),
                        o = e.top / (i * l),
                        d = .15 * r + .15 * o + ("mobile" === t ? .5 : .2);
                    a && (null == s || s.type, (0, tI.j)([a], {
                        opacity: [0, 1],
                        transform: ["scale(1) translateY(60px)", "scale(1) translateY(0px)"]
                    }, {
                        opacity: {
                            easing: [.42, 0, .25, 1],
                            delay: d,
                            duration: 1
                        },
                        transform: {
                            easing: [.2, 1.18, .47, 1],
                            delay: d,
                            duration: 1
                        }
                    })), n && (n.style.transform = "translate(".concat(e.left, "px, ").concat(e.top, "px)"))
                }
                onAdded(e) {
                    if (!this.engine) throw Error("No engine");
                    let t = this.engine.getItems().find(t => t.id === e.id),
                        i = this.getDragEl(e.id),
                        l = this.getContentEl(e.id);
                    l && (0, tI.j)([l], {
                        scale: [0, 1]
                    }, {
                        easing: (0, tD.S)()
                    }), i && (i.style.transform = "translate(".concat(e.left, "px, ").concat(e.top, "px)"), t && "ghost" !== t.type && (null == i || i.scrollIntoView({
                        behavior: "smooth",
                        block: "center"
                    })))
                }
                onUnghosted(e, t) {
                    if (!this.engine) throw Error("No engine");
                    let i = this.getDragEl(t.id);
                    if (i) {
                        let l = this.controls[t.id];
                        i.style.transform = "translate(".concat(e.left, "px, ").concat(e.top, "px)"), l && l.stop(), setTimeout(() => {
                            this.animateTransform(t.id, i, "translate(".concat(t.left, "px, ").concat(t.top, "px)"))
                        }, 0)
                    }
                }
                destroy() {}
                constructor() {
                    this.moveVector = {
                        x: 0,
                        y: 0
                    }, this.controls = {}, this.timeouts = {}, this.emits = {}, this.contentEls = {}, this.registered = {}
                }
            }
            let tz = e => {
                    let {
                        className: t,
                        children: i,
                        data: l,
                        breakpoints: s,
                        dragHandle: n,
                        settings: a,
                        editable: r,
                        onChange: o,
                        isMainEngine: u = !1
                    } = e, [x, h] = (0, M.useState)(null), [m, p] = (0, M.useState)(void 0), [v, g, f] = (0, eZ.A)(e => [e.setEngine, e.setDragging, e.setDevice]);
                    return (0, tL.Z)(() => {
                        if (x) {
                            let e = x,
                                t = x.ownerDocument,
                                i = t.defaultView;
                            if (!i) return;
                            e.style.opacity = "1";
                            let n = new tb(e),
                                o = new tS,
                                c = new tZ,
                                h = new tN(e),
                                m = new tp(l, s, a, r, n, o, c, h);
                            u && (v(m), f(m.device)), p(m), m.on(d.ON_DEVICE_CHANGED, f);
                            let g = () => {
                                m.render()
                            };
                            return document.addEventListener("bento:iframe:load", g), () => {
                                u && v(void 0), document.removeEventListener("bento:iframe:load", g), m.off(d.ON_DEVICE_CHANGED, f), m.destroy()
                            }
                        }
                    }, [x, u]), (0, M.useEffect)(() => {
                        m && (m.updateData(l), m.swap.refresh())
                    }, [l]), (0, M.useEffect)(() => {
                        m && m.setEditable(r)
                    }, [r]), (0, M.useEffect)(() => {
                        m && m.swap.setDragHandle(n)
                    }, [m, n]), (0, M.useEffect)(() => {
                        if (m) return m.on(d.ON_LAYOUT_CHANGE, o), () => {
                            m.off(d.ON_LAYOUT_CHANGE, o)
                        }
                    }, [o, m]), (0, M.useEffect)(() => {
                        if (m) {
                            let e = () => g(void 0);
                            return m.on(d.ON_DRAG_START, g), m.on(d.ON_DRAG_END, e), () => {
                                m.off(d.ON_DRAG_START, g), m.off(d.ON_DRAG_END, e)
                            }
                        }
                    }, [m, g]), (0, c.jsx)("div", {
                        className: (0, F.Z)(t, "bento-grid"),
                        children: (0, c.jsx)("div", {
                            ref: h,
                            className: "bento-grid__content",
                            style: {
                                opacity: 0
                            },
                            children: i
                        })
                    })
                },
                tA = e => {
                    let {
                        children: t,
                        className: i,
                        id: l,
                        onClick: s,
                        style: n,
                        ...a
                    } = e;
                    return (0, c.jsx)("div", {
                        className: (0, F.Z)("bento-grid__item"),
                        "data-id": l,
                        onClick: s,
                        style: n,
                        ...a,
                        children: (0, c.jsx)("div", {
                            "data-item-scale-content": !0,
                            className: (0, F.Z)("bento-item__scaler"),
                            children: (0, c.jsx)("div", {
                                "data-item-content": !0,
                                className: (0, F.Z)("bento-item__content", i),
                                children: t
                            })
                        })
                    })
                };
            var tF = i(94775);
            let tM = {
                    0: "mobile",
                    1260: "desktop"
                },
                tT = {
                    mobile: {
                        spacing: 24
                    },
                    desktop: {
                        spacing: 40
                    }
                };

            function tO() {
                let [{
                    profile: e
                }, t] = (0, j.U)(), i = (0, M.useCallback)((e, i) => {
                    t({
                        type: "update-layout",
                        device: i,
                        layout: e
                    })
                }, [t]), l = (0, M.useMemo)(() => ({
                    desktop: (0, tF.sq)(e.bento, "desktop"),
                    mobile: (0, tF.sq)(e.bento, "mobile")
                }), [e.bento]);
                return {
                    data: l,
                    breakpoints: tM,
                    settings: tT,
                    onChange: i
                }
            }
            var tR = i(57985),
                tB = i(71842),
                tH = i(1428),
                tU = i(51026),
                tV = i(32348),
                tP = i(47146),
                tG = i.n(tP);
            let tW = e => {
                var t;
                let {
                    className: i,
                    size: l = "medium",
                    platform: s,
                    metadata: n,
                    loading: a = !1
                } = e, [r, o] = (0, M.useState)(!1), d = a || n && "FETCHING" === n.status, u = (null == s ? void 0 : s.name) === "Bento Profile", x = !(null == n ? void 0 : n.touchIconUrl) && (null == n ? void 0 : n.faviconUrl) && !s, h = (0, tU.m)(u ? null == n ? void 0 : n.faviconUrl : null !== (t = null == n ? void 0 : n.touchIconUrl) && void 0 !== t ? t : null == n ? void 0 : n.faviconUrl);
                return (0, c.jsxs)("div", {
                    className: (0, F.Z)("relative", tG().icon, tG()["icon--".concat(l)], "small" !== l && x && !r && tG().favicon, i),
                    children: [s && !u && (0, M.createElement)(s.icon, {
                        className: "h-full w-full"
                    }), (!s || u) && (0, c.jsxs)(c.Fragment, {
                        children: [h && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(tV.J, {
                                src: h,
                                alt: "",
                                className: "h-full w-full rounded-[inherit]",
                                fallback: (0, c.jsx)(eb.x, {
                                    className: "h-full w-full p-2.5"
                                }),
                                onChange: e => o(e)
                            }), (0, c.jsx)(X.k, {})]
                        }), !h && d && (0, c.jsx)($.O, {
                            className: "h-full w-full rounded-[inherit]"
                        }), !h && !d && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(eb.x, {
                                className: "h-full w-full p-2.5"
                            }), (0, c.jsx)(X.k, {})]
                        })]
                    }), (0, c.jsx)(X.k, {})]
                })
            };
            var tJ = i(18543),
                tY = i.n(tJ);
            let tq = e => {
                    let {
                        className: t,
                        size: i = 18,
                        progress: l
                    } = e;
                    return (0, c.jsx)("div", {
                        className: (0, F.Z)(t),
                        children: (0, c.jsxs)("svg", {
                            className: tY()["progress-svg"],
                            width: i,
                            height: i,
                            viewBox: "0 0 200 200",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: [(0, c.jsx)("circle", {
                                r: "90",
                                cx: "100",
                                cy: "100",
                                fill: "transparent",
                                "stroke-dasharray": "565.48",
                                "stroke-dashoffset": "0"
                            }), (0, c.jsx)(P.m.circle, {
                                animate: {
                                    strokeDashoffset: 180 * Math.PI * (1 - (0, _.uZ)(l, 0, 1))
                                },
                                transition: {
                                    duration: .5,
                                    ease: e$.V
                                },
                                className: tY()["progress-bar"],
                                r: "90",
                                cx: "100",
                                cy: "100",
                                fill: "transparent",
                                strokeLinecap: "round",
                                "stroke-dasharray": "565.48"
                            })]
                        })
                    })
                },
                tK = e => {
                    var t;
                    let {
                        children: i,
                        url: l,
                        loading: s = !1,
                        upload: n
                    } = e, [a, r] = (0, M.useState)(!1);
                    return (0, c.jsxs)(c.Fragment, {
                        children: [l && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(tV.J, {
                                src: l,
                                alt: "",
                                className: "h-full w-full rounded-[inherit] object-cover",
                                fallback: (0, c.jsx)(c.Fragment, {}),
                                loading: "lazy",
                                onChange: r
                            }), !a && (0, c.jsx)(X.k, {})]
                        }), !l && s && (0, c.jsx)($.O, {
                            className: "h-full w-full flex-1 rounded-[inherit]"
                        }), n && (0, c.jsx)("div", {
                            className: "absolute left-4 top-4",
                            children: (0, c.jsx)(tq, {
                                progress: null !== (t = n.progress) && void 0 !== t ? t : 0
                            })
                        }), i]
                    })
                };
            var tX = i(79534),
                t$ = i.n(tX);
            let tQ = e => {
                    let {
                        className: t,
                        children: i
                    } = e;
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)("relative flex flex-col items-center justify-center rounded-[10px] border-[1px] border-black/[0.08] bg-black/[0.04] py-6 px-4 text-center text-xs text-black/[0.6]", t),
                        children: [(0, c.jsx)("div", {
                            children: "Seems like there’s no preview image."
                        }), i]
                    })
                },
                t0 = (0, L.Ue)(e => ({
                    editing: !1,
                    setEditing: t => e({
                        editing: t
                    })
                }));
            var t1 = i(51630);
            let t2 = e => {
                let {
                    editor: t,
                    onFocus: i,
                    onBlur: l,
                    className: s
                } = e, n = t0(e => e.setEditing), a = (0, M.useCallback)(e => {
                    null == i || i(e), n(!0)
                }, [i]), r = (0, M.useCallback)(e => {
                    null == l || l(e), n(!1)
                }, [l]);
                return (0, c.jsx)(t1.kg, {
                    editor: t,
                    onFocus: a,
                    onBlur: r,
                    className: s
                })
            };
            var t4 = i(37067),
                t5 = i(33539),
                t9 = i(28638);
            let t7 = e => {
                    let t = e.split("-");
                    return 1 === t.length ? t[0] : t[0] + t.slice(1).map(e => {
                        var t;
                        return (null === (t = e[0]) || void 0 === t ? void 0 : t.toUpperCase()) + e.slice(1)
                    }).join("")
                },
                t3 = e => {
                    if (!e) return;
                    let t = {};
                    return e.split(";").forEach(e => {
                        let [i, l] = e.split(":");
                        if (!i) return;
                        let s = t7(i.trim());
                        s && (t[s] = null == l ? void 0 : l.trim())
                    }), t
                };
            class t6 {
                setNode(e) {
                    this.node = e, this.type !== M.Fragment && (this.props.node = e)
                }
                setRootNode(e) {
                    this.root = e, this.type !== M.Fragment && (this.props.root = e)
                }
                addChild(e) {
                    this.children.push(e)
                }
                setDangerousInnerHTML(e) {
                    null == this.props && (this.props = {}), this.props.dangerouslySetInnerHTML = {
                        __html: e
                    }
                }
                toReactNode() {
                    var e, t;
                    let i = t3(this.props.style),
                        {
                            node: l,
                            root: s,
                            ...n
                        } = null !== (e = this.props) && void 0 !== e ? e : {
                            node: void 0
                        },
                        a = "string" == typeof this.type ? n : this.props,
                        r = this.type === M.Fragment;
                    return (0, M.createElement)(this.type, r ? {
                        key: this.props.key
                    } : { ...a,
                        key: this.props.key,
                        style: i
                    }, null !== (t = this.content) && void 0 !== t ? t : this.children.length > 0 ? this.children.map(e => e.toReactNode()) : void 0)
                }
                toString() {
                    return "Type: ".concat(this.type.toString(), ", props: ").concat(JSON.stringify(this.props), ", content: ").concat(JSON.stringify(this.content))
                }
                constructor(e, t, i) {
                    this.children = [], this.type = e, this.props = null != t ? t : {}, this.content = i, this.props.key = (0, _.x0)()
                }
            }

            function t8(e) {
                let t = {};
                for (let i in e) {
                    let {
                        reactRenderer: l,
                        toDOM: s
                    } = e[i].spec;
                    l ? t[i] = l : s && (t[i] = s)
                }
                return t
            }
            class ie {
                serializeFragment(e, t) {
                    let i = new t6(M.Fragment, null),
                        l = null,
                        s = i;
                    return e.forEach(e => {
                        if (l || e.marks.length) {
                            l || (l = []);
                            let t = 0,
                                n = 0;
                            for (; t < l.length && n < e.marks.length;) {
                                let i = e.marks[n];
                                if (!i || !this.marks[i.type.name]) {
                                    n++;
                                    continue
                                }
                                if (!i.eq(l[t]) || !1 === i.type.spec.spanning) break;
                                t += 2, n++
                            }
                            for (; t < l.length;) s = l.pop(), l.pop();
                            for (; n < e.marks.length;) {
                                let t = e.marks[n++],
                                    a = this.serializeMark(t, e.isInline);
                                if (a) {
                                    var i;
                                    l.push(t, s), s.addChild(a.node), s = null !== (i = a.contentNode) && void 0 !== i ? i : a.node
                                }
                            }
                        }
                        s.addChild(this.serializeNodeInner(e, t))
                    }), i
                }
                serializeNodeInner(e, t) {
                    let {
                        node: i,
                        contentNode: l
                    } = ie.renderSpec(this.nodes[e.type.name](e));
                    if (i.setNode(e), t && i.setRootNode(t), l) {
                        if (e.isLeaf) throw RangeError("Content hole not allowed in a leaf node spec (node: ".concat(e.type.name, ")"));
                        e.content.size > 0 && l.addChild(this.serializeFragment(e.content, t))
                    }
                    return i
                }
                serializeNode(e) {
                    let t = this.serializeNodeInner(e);
                    for (let l = e.marks.length - 1; l >= 0; l--) {
                        let s = this.serializeMark(e.marks[l], e.isInline);
                        if (s) {
                            var i;
                            (null !== (i = s.contentNode) && void 0 !== i ? i : s.node).addChild(t), t = s.node
                        }
                    }
                    return t
                }
                serializeMark(e, t) {
                    let i = this.marks[e.type.name];
                    if (i) return ie.renderSpec(i(e, t))
                }
                static domAttrsToReactProps(e) {
                    let t = {};
                    for (let i in e) null != e[i] && ("class" !== i ? t[i] = e[i] : t.className = e[i]);
                    return t
                }
                static domNodeToVirtualNode(e) {
                    if (null != e.tagName) {
                        let t = {};
                        e.getAttributeNames().forEach(i => {
                            t[i] = e.getAttribute(i)
                        });
                        let i = ie.domAttrsToReactProps(t),
                            l = new t6(e.tagName.toLowerCase(), i);
                        return l.setDangerousInnerHTML(e.innerHTML), {
                            node: l
                        }
                    }
                }
                static renderSpec(e) {
                    let t;
                    if ("string" == typeof e) return {
                        node: new t6(M.Fragment, null, e)
                    };
                    if (null != e.nodeType) {
                        let t = ie.domNodeToVirtualNode(e);
                        if (t) return t;
                        throw Error("Unknown structure. Can't serialize structure which has no tagname (probably isnt a DOM node in that case, so what is it?)")
                    }
                    if (e.dom && null != e.dom.nodeType) {
                        let t = ie.domNodeToVirtualNode(e.dom);
                        if (t) return t;
                        throw Error("Unknown structure. Can't serialize structure which has no tagname (probably isnt a DOM node in that case, so what is it?)")
                    }
                    let i = e[0],
                        l = {},
                        s = e[1],
                        n = 1;
                    s && "object" == typeof s && null == s.nodeType && !Array.isArray(s) && (n = 2, l = ie.domAttrsToReactProps(s));
                    let a = new t6(i, l);
                    for (let i = n; i < e.length; i++) {
                        let l = e[i];
                        if (0 === l) {
                            if (i < e.length - 1 || i > n) throw RangeError("Content hole must be the only child of its parent node");
                            return {
                                node: a,
                                contentNode: a
                            }
                        }
                        let {
                            node: s,
                            contentNode: r
                        } = ie.renderSpec(l);
                        if (a.addChild(s), t) {
                            if (r) throw RangeError("Multiple content holes");
                            t = r
                        }
                    }
                    return {
                        node: a,
                        contentNode: t
                    }
                }
                static fromSchema(e) {
                    return e.cached.ReactSerializer || (e.cached.ReactSerializer = new ie(this.nodesFromSchema(e), this.marksFromSchema(e)))
                }
                static nodesFromSchema(e) {
                    let t = t8(e.nodes);
                    return t.text || (t.text = e => e.text), t
                }
                static marksFromSchema(e) {
                    return t8(e.marks)
                }
                constructor(e, t) {
                    this.nodes = e || {}, this.marks = t || {}
                }
            }
            let it = (e, t, i) => {
                    let l = (0, t5.J1)(e),
                        s = t;
                    ((null == s ? void 0 : s.type) || s && "object" == typeof s && !s.type) && (s.type = l.topNodeType.name);
                    let n = t9.HY.fromJSON(l, null == s ? void 0 : s.content),
                        a = t9.NB.fromJSON(l, null != s ? s : {
                            type: l.topNodeType.name
                        });
                    return {
                        html: (0, c.jsx)("div", {
                            className: i,
                            children: ie.fromSchema(l).serializeFragment(n, a).toReactNode()
                        }),
                        node: a
                    }
                },
                ii = e => {
                    var t;
                    let {
                        className: i,
                        extensions: l,
                        value: s,
                        fallback: n,
                        showPlaceholder: a = !0
                    } = e, r = null !== (t = null != s ? s : n) && void 0 !== t ? t : "", o = (0, M.useMemo)(() => {
                        var e, t;
                        let i = null === (e = l.find(e => "placeholder" === e.name)) || void 0 === e ? void 0 : null === (t = e.options) || void 0 === t ? void 0 : t.placeholder,
                            s = "string" == typeof i ? i : void 0,
                            o = !1,
                            d = r && "string" == typeof r ? (0, c.jsx)(c.Fragment, {
                                children: r
                            }) : null;
                        if (!d && r) {
                            let e = it(l, r, "");
                            d = e.html, !e.node.textContent && a && (d = null != n ? n : s, o = !0)
                        }
                        return !d && a && (d = null != n ? n : s, o = !0), n && r === n && (o = !0), {
                            content: d,
                            isPlaceholder: o
                        }
                    }, [r, n, l, a]);
                    return (0, c.jsx)("div", {
                        className: (0, F.Z)(i, o.isPlaceholder && "text-black/30"),
                        children: o.content
                    })
                };
            var il = i(17657),
                is = i.n(il);
            let ia = e => {
                let {
                    className: t,
                    containerClassName: i,
                    extensions: l,
                    value: s,
                    fallback: n,
                    clickToActivate: a = !1,
                    floating: r = !1,
                    valueOnEmpty: o = !0,
                    focusInputOnMount: d = !1,
                    onEditor: u,
                    onActiveChange: x,
                    onChange: h,
                    onCommit: m
                } = e, [p, v] = (0, M.useState)(null), [g, f] = (0, M.useState)(!1), _ = null != s ? s : "", j = (0, t1.jE)({
                    extensions: l,
                    content: "string" == typeof _ ? "<p>".concat(_, "</p>") : _,
                    editable: !0
                });
                (0, M.useEffect)(() => {
                    j && (null == u || u(j))
                }, [j]), (0, M.useEffect)(() => {
                    null == j || j.commands.setContent("string" == typeof _ ? "<p>".concat(_, "</p>") : _)
                }, [g]);
                let w = (0, M.useCallback)(() => {
                    null == h || h(null == j ? void 0 : j.getJSON())
                }, [h, j]);
                (0, t4.F)(j, w);
                let y = (0, M.useCallback)(() => {
                        f(!0)
                    }, []),
                    b = (0, M.useCallback)(() => {
                        f(!1), null == m || m(null == j ? void 0 : j.getJSON())
                    }, [m, j]),
                    N = () => {
                        var e, t, i;
                        null == j || null === (e = j.view) || void 0 === e || e.focus();
                        let l = null !== (i = null == j ? void 0 : null === (t = j.view) || void 0 === t ? void 0 : t.hasFocus()) && void 0 !== i && i;
                        a && !l && (f(!0), setTimeout(() => {
                            var e;
                            null == j || null === (e = j.view) || void 0 === e || e.focus(), null == j || j.commands.setTextSelection(9999999)
                        }, 0))
                    },
                    C = (0, M.useCallback)(e => {
                        e.preventDefault(), g && e.stopPropagation(), N()
                    }, [a, j, g]);
                return (0, M.useEffect)(() => {
                    if (j && p) {
                        let e = p.ownerDocument.defaultView;
                        if (!e) return;
                        let t = e => {
                            "Enter" === e.key && j.view.hasFocus() && j.view.dom.blur(), "Escape" === e.key && j.view.hasFocus() && (j.commands.setContent(s), j.view.dom.blur())
                        };
                        return window.addEventListener("keydown", t), e.addEventListener("keydown", t), () => {
                            window.removeEventListener("keydown", t), e.removeEventListener("keydown", t)
                        }
                    }
                }, [j, p, s]), (0, M.useEffect)(() => {
                    null == x || x(g)
                }, [g, x]), (0, M.useEffect)(() => {
                    if (!g && j) {
                        let e = () => {
                            N()
                        };
                        return j.view.dom.addEventListener("managed-focus", e), () => {
                            j.view.dom.removeEventListener("managed-focus", e)
                        }
                    }
                }, [g, j]), (0, M.useEffect)(() => {
                    d && (f(!0), setTimeout(() => {
                        var e;
                        null == j || null === (e = j.view) || void 0 === e || e.focus(), null == j || j.commands.setTextSelection(9999999)
                    }, 0))
                }, [d, j]), (0, M.useEffect)(() => {
                    j && (j.storage.placeholder = n)
                }, [j, n]), (0, c.jsxs)("div", {
                    className: (0, F.Z)(is().container, r && is()["container--floating"], g && is()["container--input-active"], a && is()["container--click-to-activate"], i),
                    "data-text-button": !0,
                    ref: v,
                    onClick: C,
                    children: [(r || !g || !j) && (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsx)(ii, {
                            extensions: l,
                            fallback: n,
                            value: s,
                            className: (0, F.Z)(is().fallback, t)
                        })
                    }), (g || !a) && j && (0, c.jsx)("div", {
                        className: (0, F.Z)(is().input, t),
                        children: (0, c.jsx)(t2, {
                            editor: j,
                            onFocus: y,
                            onBlur: b
                        })
                    })]
                })
            };
            var ir = i(99631),
                io = i(74704),
                id = i(32259),
                ic = i(67780),
                iu = i(88360);
            let ix = e => [iu.y, ic.Z, io.Z, ir.Z, id.Z.configure({
                placeholder: null != e ? e : "Title..."
            })];
            var ih = i(18559);

            function im(e) {
                let [, t] = (0, j.U)(), i = (0, M.useCallback)(i => {
                    (0, z.c)().track("LINK_TEXT_OVERRIDE"), t({
                        type: "set-bento-item-partial",
                        bento: {
                            id: e.id,
                            overrides: { ...null == e ? void 0 : e.overrides,
                                title: i
                            }
                        }
                    })
                }, [e, t]);
                return i
            }

            function ip(e) {
                let [, t] = (0, j.U)(), i = (0, M.useCallback)(i => {
                    (0, z.c)().track("FIGMA_CHAT_SET"), t({
                        type: "set-bento-item-partial",
                        bento: {
                            id: e.id,
                            overrides: { ...null == e ? void 0 : e.overrides,
                                figmaChat: i
                            }
                        }
                    })
                }, [e, t]);
                return i
            }
            var iv = i(66937);
            let ig = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M2.18394 0.435873C2.98707 0.0266559 4.0232 0.00154138 5.9999 0V2.00004C5.06969 2.00093 4.43386 2.00704 3.93557 2.04775C3.39224 2.09215 3.19081 2.1675 3.09192 2.21789C2.71559 2.40963 2.40963 2.71559 2.21789 3.09192C2.1675 3.19081 2.09215 3.39224 2.04775 3.93557C2.00704 4.43386 2.00093 5.06969 2.00004 5.9999H0C0.00154138 4.0232 0.0266559 2.98707 0.435873 2.18394C0.819367 1.43129 1.43129 0.819367 2.18394 0.435873ZM11.9999 0V2.00004C12.9301 2.00093 13.5659 2.00704 14.0642 2.04775C14.6076 2.09215 14.809 2.1675 14.9079 2.21789C15.2842 2.40963 15.5902 2.71559 15.7819 3.09192C15.8323 3.19081 15.9077 3.39224 15.952 3.93557C15.9928 4.43386 15.9989 5.06969 15.9998 5.9999H17.9998C17.9983 4.0232 17.9731 2.98707 17.5639 2.18394C17.1804 1.43129 16.5685 0.819367 15.8159 0.435873C15.0127 0.0266559 13.9766 0.00154138 11.9999 0ZM14.0642 15.952C13.5659 15.9928 12.9301 15.9989 11.9999 15.9998V17.9998C13.9766 17.9983 15.0127 17.9731 15.8159 17.5639C16.5685 17.1804 17.1804 16.5685 17.5639 15.8159C17.9731 15.0127 17.9983 13.9766 17.9998 11.9999H15.9998C15.9989 12.9301 15.9928 13.5659 15.952 14.0642C15.9077 14.6076 15.8323 14.809 15.7819 14.9079C15.5902 15.2842 15.2842 15.5902 14.9079 15.7819C14.809 15.8323 14.6076 15.9077 14.0642 15.952ZM2.04775 14.0642C2.00704 13.5659 2.00093 12.9301 2.00004 11.9999H0C0.00154138 13.9766 0.0266559 15.0127 0.435873 15.8159C0.819367 16.5685 1.43129 17.1804 2.18394 17.5639C2.98707 17.9731 4.0232 17.9983 5.9999 17.9998V15.9998C5.06969 15.9989 4.43386 15.9928 3.93557 15.952C3.39224 15.9077 3.19081 15.8323 3.09192 15.7819C2.71559 15.5902 2.40963 15.2842 2.21789 14.9079C2.1675 14.809 2.09215 14.6076 2.04775 14.0642ZM13.2425 10.414C14.8046 8.8519 14.8046 6.31923 13.2425 4.75714C11.6804 3.19504 9.14773 3.19504 7.58564 4.75714C7.19511 5.14766 7.19511 5.78083 7.58564 6.17135C7.97616 6.56188 8.60932 6.56188 8.99985 6.17135C9.7809 5.3903 11.0472 5.3903 11.8283 6.17135C12.6093 6.9524 12.6093 8.21873 11.8283 8.99978C11.4378 9.3903 11.4378 10.0235 11.8283 10.414C12.2188 10.8045 12.852 10.8045 13.2425 10.414ZM8.99985 11.8282C8.2188 12.6093 6.95247 12.6093 6.17142 11.8282C5.39037 11.0472 5.39037 9.78083 6.17142 8.99978C6.56195 8.60925 6.56195 7.97609 6.17142 7.58557C5.7809 7.19504 5.14773 7.19504 4.75721 7.58557C3.19511 9.14766 3.19511 11.6803 4.75721 13.2424C6.31931 14.8045 8.85197 14.8045 10.4141 13.2424C10.8046 12.8519 10.8046 12.2187 10.4141 11.8282C10.0235 11.4377 9.39037 11.4377 8.99985 11.8282ZM8.99985 7.58557C9.39037 7.19504 10.0235 7.19504 10.4141 7.58557C10.8046 7.97609 10.8046 8.60925 10.4141 8.99978L8.99985 10.414C8.60932 10.8045 7.97616 10.8045 7.58564 10.414C7.19511 10.0235 7.19511 9.3903 7.58564 8.99978L8.99985 7.58557Z",
                            fill: "currentColor"
                        })
                    })
                },
                i_ = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M6 1C5.44772 1 5 1.44772 5 2C5 2.55228 5.44772 3 6 3H12C12.5523 3 13 2.55228 13 2C13 1.44772 12.5523 1 12 1H6ZM2 4C1.44772 4 1 4.44772 1 5C1 5.55228 1.44772 6 2 6H3V14C3 15.6569 4.34315 17 6 17H12C13.6569 17 15 15.6569 15 14V6H16C16.5523 6 17 5.55228 17 5C17 4.44772 16.5523 4 16 4H2ZM5 14V6H13V14C13 14.5523 12.5523 15 12 15H6C5.44772 15 5 14.5523 5 14Z",
                            fill: "currentColor"
                        })
                    })
                },
                ij = (0, M.forwardRef)((e, t) => {
                    let {
                        onPick: i,
                        disabled: l,
                        children: s,
                        className: n,
                        buttonClassName: a,
                        accept: r,
                        onMouseEnter: o,
                        onMouseLeave: d
                    } = e, [u, x] = (0, M.useState)();
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)("relative", n),
                        children: [(0, c.jsx)("input", {
                            ref: x,
                            className: "!pointer-events-none absolute h-0 w-0 opacity-0",
                            type: "file",
                            accept: r,
                            onChange: e => {
                                var t;
                                i(null === (t = e.target.files) || void 0 === t ? void 0 : t[0])
                            },
                            disabled: l,
                            onClick: e => {
                                e.stopPropagation()
                            }
                        }), (0, c.jsx)("button", {
                            ref: t,
                            className: (0, F.Z)(a),
                            onMouseEnter: o,
                            onMouseLeave: d,
                            onClick: e => {
                                null == u || u.click(), e.preventDefault()
                            },
                            children: s
                        })]
                    })
                });
            ij.displayName = "FileButton";
            var iw = i(19716),
                iy = i.n(iw);
            let ib = e => {
                let {
                    setImage: t,
                    resetImage: i,
                    deleteImage: l,
                    canReset: s,
                    withReset: n,
                    withDelete: a
                } = e, r = (0, eZ.A)(e => e.dragging), [o, d] = (0, M.useState)(!1), [u, x] = (0, M.useState)(!1), [h, m] = (0, M.useState)(!1), p = !r;
                return (0, c.jsxs)("div", {
                    className: (0, F.Z)(iy()["image-edit-bar"]),
                    children: [(0, c.jsx)(E.u, {
                        open: u && p,
                        tooltip: (0, c.jsx)("div", {
                            className: "max-w-[120px] text-center text-disclaimer text-black/60",
                            children: "Upload Custom Picture (Best 1200x630)"
                        }),
                        asChild: !0,
                        children: (0, c.jsx)(ij, {
                            onPick: e => {
                                null == t || t(e)
                            },
                            className: "flex",
                            onMouseEnter: () => x(!0),
                            onMouseLeave: () => x(!1),
                            buttonClassName: (0, F.Z)(iy().button),
                            accept: eI,
                            children: (0, c.jsx)(iv.X, {
                                size: 18
                            })
                        })
                    }), n && (0, c.jsx)(E.u, {
                        open: o && p,
                        tooltip: (0, c.jsx)("div", {
                            className: "text-disclaimer text-black/60",
                            children: s ? "Use Website Picture" : "No website image"
                        }),
                        children: (0, c.jsx)("button", {
                            onClick: e => {
                                s && (null == i || i()), e.preventDefault()
                            },
                            onMouseEnter: () => d(!0),
                            onMouseLeave: () => d(!1),
                            className: (0, F.Z)(iy().button, !s && iy()["button--disabled"]),
                            children: (0, c.jsx)(ig, {
                                size: 18
                            })
                        })
                    }), a && (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("div", {
                            className: "h-3 w-[2px] rounded-full bg-white/[0.18]"
                        }), (0, c.jsx)(E.u, {
                            open: h && p,
                            tooltip: (0, c.jsx)("div", {
                                className: "text-disclaimer text-action-red",
                                children: "Delete Picture"
                            }),
                            children: (0, c.jsx)("button", {
                                onClick: e => {
                                    null == l || l(), e.preventDefault()
                                },
                                onMouseEnter: () => m(!0),
                                onMouseLeave: () => m(!1),
                                className: (0, F.Z)(iy().button),
                                children: (0, c.jsx)(i_, {
                                    size: 18
                                })
                            })
                        })]
                    })]
                })
            };
            var iN = i(82746),
                iC = i.n(iN);
            let ik = e => {
                    let {
                        children: t,
                        className: i,
                        enabled: l,
                        menu: s,
                        ...n
                    } = e, a = (0, eZ.A)(e => e.dragging), [r, o] = (0, M.useState)(!1), d = r && !a && l;
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)(iC().frame, d && iC()["frame--enabled"], i),
                            onMouseEnter: () => o(!0),
                            onMouseLeave: () => o(!1),
                            ...n,
                            children: [t, (0, c.jsx)(eX.M, {
                                children: (0, c.jsx)(P.m.div, {
                                    className: iC().menu,
                                    style: {
                                        left: -10,
                                        top: -10
                                    },
                                    initial: {
                                        opacity: 0
                                    },
                                    animate: {
                                        opacity: d ? 1 : 0
                                    },
                                    exit: {
                                        opacity: 0
                                    },
                                    transition: {
                                        duration: .2,
                                        ease: e$.V
                                    },
                                    children: s
                                })
                            })]
                        })
                    })
                },
                iE = {
                    height: 600,
                    width: 600
                },
                iS = e => {
                    var t, i, l, s, n, a, r, o;
                    let {
                        data: d
                    } = e, u = (0, eL.$)(), x = (0, _.f6)(d.style, u), [{
                        editing: h
                    }] = (0, j.U)(), {
                        metadata: m,
                        loading: p
                    } = (0, tH.N)(d.href), v = (0, eB.X)(d.href), g = null == m ? void 0 : m.title, f = (0, M.useMemo)(() => ix(g), [g]), w = (0, ih.J)(null === (t = d.overrides) || void 0 === t ? void 0 : t.title, f) ? g : null !== (n = null === (i = d.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== n ? n : g, y = (0, _.w6)(d.href), {
                        getUpload: b
                    } = (0, eS.r)(), N = b(d.id), C = p || (null == m ? void 0 : m.status) === "FETCHING", k = im(d), E = function(e) {
                        let [, t] = (0, j.U)(), {
                            addMediaUpload: i
                        } = (0, eS.r)(), l = (0, M.useCallback)(l => {
                            l && ((0, z.c)().track("LINK_PREVIEW_OVERRIDE"), i(l, e.id).then(i => {
                                t({
                                    type: "set-bento-item-partial",
                                    bento: {
                                        id: e.id,
                                        overrides: { ...e.overrides,
                                            ogImage: i
                                        }
                                    }
                                })
                            }))
                        }, [e]);
                        return l
                    }(d), S = function(e) {
                        let [, t] = (0, j.U)(), i = (0, M.useCallback)(() => {
                            t({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: e.id,
                                    overrides: { ...e.overrides,
                                        ogImage: void 0
                                    }
                                }
                            })
                        }, [e]);
                        return i
                    }(d), L = function(e) {
                        let [, t] = (0, j.U)(), {
                            addMediaUpload: i
                        } = (0, eS.r)(), l = (0, M.useCallback)(() => {
                            (0, z.c)().track("LINK_PREVIEW_OVERRIDE_REMOVED"), t({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: e.id,
                                    overrides: { ...e.overrides,
                                        ogImage: ""
                                    }
                                }
                            })
                        }, [e]);
                        return l
                    }(d), I = (0, eM.H)(), D = null !== (a = null == m ? void 0 : m.imageUrl) && void 0 !== a ? a : null == m ? void 0 : m.screenshotUrl, Z = null !== (o = null !== (r = null == N ? void 0 : N.tmpUrl) && void 0 !== r ? r : null === (l = d.overrides) || void 0 === l ? void 0 : l.ogImage) && void 0 !== o ? o : D, A = Z;
                    return Z === (null === (s = d.overrides) || void 0 === s ? void 0 : s.ogImage) && (A = (0, _.En)(Z, {
                        w: 750,
                        h: 750
                    })), (0, c.jsxs)("div", {
                        className: (0, F.Z)(t$()["link-widget"], t$()["link-widget--".concat(x)]),
                        children: [(0, c.jsxs)("div", {
                            className: t$().description,
                            children: [(0, c.jsx)(tW, {
                                platform: v,
                                metadata: m,
                                loading: p,
                                size: "1x4" === x ? "small" : "medium"
                            }), (0, c.jsxs)("div", {
                                className: t$()["link-meta__container"],
                                children: [h && "mouse" === I && (0, c.jsx)(ia, {
                                    value: null != w ? w : y.hostname,
                                    extensions: f,
                                    className: (0, F.Z)(t$().title),
                                    containerClassName: t$()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: k
                                }), (!h || "mouse" !== I) && (0, c.jsx)(ii, {
                                    value: null != w ? w : y.hostname,
                                    extensions: f,
                                    className: t$().title
                                }), w && (0, c.jsx)("div", {
                                    className: t$().host,
                                    children: y.hostname.replace("www.", "")
                                })]
                            })]
                        }), (0, c.jsxs)(ik, {
                            className: t$().og,
                            enabled: h,
                            menu: h && "mouse" === I && (0, c.jsx)(ib, {
                                canReset: Z !== D,
                                withDelete: !!Z,
                                withReset: Z !== D || !Z,
                                setImage: E,
                                deleteImage: L,
                                resetImage: S
                            }, Z),
                            children: [(A || C) && (0, c.jsx)(tK, {
                                url: (0, _.En)(A, {
                                    width: iE.width,
                                    height: iE.height
                                }),
                                loading: C,
                                upload: N
                            }), !A && !C && h && (0, c.jsx)(tQ, {
                                className: (0, F.Z)(t$()["og-empty"], "h-full")
                            })]
                        })]
                    })
                };
            var iL = i(1520),
                iI = i.n(iL),
                iD = i(42747),
                iZ = i.n(iD);

            function iz() {
                let [{
                    editing: e
                }] = (0, j.U)(), t = (0, eM.H)(), i = i => {
                    if ("touch" === t && e) return;
                    let l = i.target,
                        s = l.closest("a");
                    if (s) {
                        let e = s.children[1],
                            t = getComputedStyle(s),
                            i = e ? getComputedStyle(e) : void 0;
                        s.style.transform = t.transform, s.style.background = t.background, s.style.boxShadow = t.boxShadow, i && (e.style.border = i.border, e.style.opacity = i.opacity), l.style.pointerEvents = "auto"
                    }
                }, l = i => {
                    if ("touch" === t && e) return;
                    let l = i.target,
                        s = l.closest("a");
                    if (s) {
                        let e = s.children[1];
                        s.style.transform = "", s.style.background = "", s.style.boxShadow = "", e && (e.style.border = "", e.style.opacity = ""), l.style.pointerEvents = ""
                    }
                };
                return {
                    onMouseEnter: i,
                    onMouseLeave: l
                }
            }
            let iA = e => {
                let {
                    data: t,
                    className: i
                } = e, l = iz();
                return (0, c.jsx)("div", {
                    "data-prevent-widget": !0,
                    "data-rich-button": !0,
                    role: "button",
                    className: (0, F.Z)(iZ()["follow-button"], i),
                    ...l,
                    children: "Follow"
                })
            };
            var iF = i(88702);
            let iM = [],
                iT = e => {
                    var t;
                    let {
                        className: i,
                        data: l,
                        columns: s,
                        alignment: n = "top",
                        withDates: a = !0,
                        loading: r = !0
                    } = e, o = null !== (t = null == l ? void 0 : l.contributions) && void 0 !== t ? t : iM, d = Math.min(s, o.length), u = null == o ? void 0 : o.map((e, t) => ({
                        week: e.week,
                        year: eo()(e.week, "YYYY-MM-DD").year(),
                        month: eo()(e.week, "YYYY-MM-DD").month(),
                        m: eo()(e.week).format("MMM"),
                        idx: t
                    })).filter((e, t, i) => i.findIndex(t => t.month === e.month && t.year === e.year) === t);
                    return (0, M.useMemo)(() => (0, c.jsxs)("div", {
                        className: i,
                        children: [r && (0, c.jsx)($.O, {
                            className: "h-full w-full rounded-[10px]"
                        }), !r && d > 0 && (0, c.jsxs)("svg", {
                            width: "100%",
                            height: "100%",
                            viewBox: "0 0 ".concat(20 * (d - 1) - 8, " ").concat(132),
                            fill: "none",
                            preserveAspectRatio: "".concat("top" === n ? "xMaxYMin" : "xMaxYMax", " meet"),
                            xmlns: "http://www.w3.org/2000/svg",
                            children: [a && u && u.filter(e => e.idx > o.length - d).map(e => (0, c.jsx)("text", {
                                x: (e.idx - (o.length - d)) * 20 - 8,
                                y: -8,
                                fontSize: 12,
                                textAnchor: "middle",
                                fill: "rgba(0,0,0,0.4)",
                                children: e.m
                            })), o.filter((e, t, i) => t > i.length - d).flatMap((e, t) => e.contributions.map((e, i) => (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)("rect", {
                                    x: 20 * t,
                                    y: 20 * i,
                                    width: 12,
                                    height: 12,
                                    rx: 2.5,
                                    fill: e.color
                                }), (0, c.jsx)("rect", {
                                    x: 20 * t + .5,
                                    y: 20 * i + .5,
                                    width: 11,
                                    height: 11,
                                    rx: 2,
                                    strokeWidth: 1,
                                    stroke: "rgba(0,0,0,0.04)"
                                })]
                            })))]
                        })]
                    }), [n, r, i, d, o, u, a])
                },
                iO = {
                    "1x4": 0,
                    "2x2": 0,
                    "2x4": 9,
                    "4x2": 8,
                    "4x4": 18
                },
                iR = e => {
                    var t, i, l, s, n;
                    let {
                        data: a
                    } = e, r = (0, eL.$)(), o = (0, _.f6)(a.style, r), [{
                        editing: d
                    }] = (0, j.U)(), {
                        richdata: u,
                        loading: x
                    } = ed(a.href), h = null == u ? void 0 : u.data, m = null !== (s = null == u ? void 0 : null === (t = u.data) || void 0 === t ? void 0 : t.name) && void 0 !== s ? s : "GitHub", p = (0, M.useMemo)(() => ix(m), [m]), v = (0, ih.J)(null === (i = a.overrides) || void 0 === i ? void 0 : i.title, p) ? m : null !== (n = null === (l = a.overrides) || void 0 === l ? void 0 : l.title) && void 0 !== n ? n : m, g = x || (null == u ? void 0 : u.status) === "FETCHING", f = im(a), w = (0, eM.H)();
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(iZ()["link-widget"], iZ()["link-widget--".concat(o)]),
                        children: [(0, c.jsxs)("div", {
                            className: iZ().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === o && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: iF.W,
                                    size: "1x4" === o ? "small" : "medium"
                                }), "4x4" === o && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(iA, {
                                        data: null == u ? void 0 : u.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: iZ()["link-meta__container"],
                                children: [d && "mouse" === w && (0, c.jsx)(ia, {
                                    value: null != v ? v : m,
                                    extensions: p,
                                    className: (0, F.Z)(iZ().title),
                                    containerClassName: iZ()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: f
                                }), (!d || "mouse" !== w) && (0, c.jsx)(ii, {
                                    value: null != v ? v : m,
                                    extensions: p,
                                    className: iZ().title
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(o) && (0, c.jsx)(iA, {
                                data: null == u ? void 0 : u.data,
                                className: (0, F.Z)(["2x4", "2x2"].includes(o) && "max-[389px]:!hidden")
                            })]
                        }), (0, c.jsxs)("div", {
                            className: iZ().graph,
                            children: ["4x4" === o && (0, c.jsx)(J.L, {}), (0, c.jsx)(iT, {
                                className: iZ().illustration,
                                data: h,
                                columns: iO[o],
                                alignment: "4x4" === o ? "bottom" : "top",
                                withDates: "4x4" === o,
                                loading: g
                            }), "4x2" === o && (0, c.jsx)(J.L, {}), ["4x4"].includes(o) && (null == h ? void 0 : h.totalContributions) && (0, c.jsxs)("div", {
                                className: "mt-4 text-xs text-black/60",
                                children: [h.totalContributions, " contributions in the last year"]
                            }), ["4x2"].includes(o) && (0, c.jsx)(iA, {
                                data: null == u ? void 0 : u.data
                            })]
                        })]
                    })
                };
            var iB = i(33989),
                iH = i.n(iB),
                iU = i(4134);
            let iV = e => {
                    let {
                        data: t,
                        className: i
                    } = e, l = iz();
                    return (0, c.jsxs)("div", {
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(iH()["follow-button"], "rounded-lg bg-[#4093EF] text-center font-bold text-white hover:bg-[#2875CA] active:bg-[#3383DC] active:text-white/80", i),
                        ...l,
                        children: ["Follow", (null == t ? void 0 : t.followers) != null && (0, c.jsxs)(c.Fragment, {
                            children: [" ", (0, c.jsx)("span", {
                                className: "ml-1 font-medium text-white/80",
                                children: (0, _.d)(t.followers)
                            })]
                        })]
                    })
                },
                iP = {
                    height: 150,
                    width: 150
                },
                iG = e => {
                    var t, i, l, s, n, a;
                    let {
                        data: r
                    } = e, o = (0, eL.$)(), d = (0, _.f6)(r.style, o), [{
                        editing: u
                    }] = (0, j.U)(), {
                        richdata: x,
                        loading: h
                    } = ed(r.href), m = null == x ? void 0 : x.data, p = null !== (n = (0, _.ew)(null == x ? void 0 : null === (t = x.data) || void 0 === t ? void 0 : t.userName, e => "@".concat(e))) && void 0 !== n ? n : "Instagram", v = (0, M.useMemo)(() => ix(p), [p]), g = (0, ih.J)(null === (i = r.overrides) || void 0 === i ? void 0 : i.title, v) ? p : null !== (a = null === (l = r.overrides) || void 0 === l ? void 0 : l.title) && void 0 !== a ? a : p, f = h || (null == x ? void 0 : x.status) === "FETCHING", w = im(r), y = (0, eM.H)(), b = (0, M.useId)(), N = (null == x ? void 0 : null === (s = x.data) || void 0 === s ? void 0 : s.posts) ? (0, _.A1)(x.data.posts.slice(0, 6), 6).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                        w: iP.width,
                        h: iP.height,
                        fit: "crop"
                    })) : (0, _.A1)([], 6), C = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(iH()["link-widget"], iH()["link-widget--".concat(d)]),
                        children: [(0, c.jsxs)("div", {
                            className: iH().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === d && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: iU.E,
                                    size: "1x4" === d ? "small" : "medium"
                                }), "4x4" === d && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(iV, {
                                        data: null == x ? void 0 : x.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: iH()["link-meta__container"],
                                children: [u && "mouse" === y && (0, c.jsx)(ia, {
                                    value: null != g ? g : p,
                                    extensions: v,
                                    className: (0, F.Z)(iH().title),
                                    containerClassName: iH()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: w
                                }), (!u || "mouse" !== y) && (0, c.jsx)(ii, {
                                    value: null != g ? g : p,
                                    extensions: v,
                                    className: iH().title
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(d) && (0, c.jsx)(iV, {
                                data: null == x ? void 0 : x.data,
                                className: (0, F.Z)(["2x4", "2x2"].includes(d) && "max-[389px]:!hidden")
                            })]
                        }), "4x4" === d && (0, c.jsx)(J.L, {}), !(null == m ? void 0 : m.isPrivate) && (N.length > 0 || u) && (0, c.jsx)("div", {
                            className: (0, F.Z)(iH()["post-grid"], f && iH()["post-grid--fetching"]),
                            children: N.map((e, t) => (0, c.jsxs)("div", {
                                children: [!f && e && (0, c.jsx)(tV.J, {
                                    src: e["1x"],
                                    srcSet: "".concat(e["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    fallback: C
                                }, "".concat(b, "-image-").concat(t)), f && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }))
                        }), "4x2" === d && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(iV, {
                                data: null == x ? void 0 : x.data
                            })]
                        })]
                    })
                };
            var iW = i(58003),
                iJ = i.n(iW);
            let iY = e => {
                let {
                    data: t
                } = e, i = iz();
                return (0, c.jsxs)("div", {
                    "data-prevent-widget": !0,
                    "data-rich-button": !0,
                    role: "button",
                    onClick: e => {
                        e.preventDefault(), (null == t ? void 0 : t.handle) && window.open("https://x.com/intent/user?screen_name=" + (null == t ? void 0 : t.handle), "_blank")
                    },
                    className: iJ()["follow-button"],
                    ...i,
                    children: ["Follow", (null == t ? void 0 : t.followers) != null && (0, c.jsxs)(c.Fragment, {
                        children: [" ", (0, c.jsx)("span", {
                            className: "ml-1 font-medium text-white/80",
                            children: (0, _.d)(t.followers)
                        })]
                    })]
                })
            };
            var iq = i(82525);
            let iK = {
                    height: 250
                },
                iX = e => {
                    var t, i, l;
                    let {
                        data: s
                    } = e, n = (0, eL.$)(), a = (0, _.f6)(s.style, n), [{
                        editing: r
                    }] = (0, j.U)(), {
                        richdata: o,
                        loading: d
                    } = ed(s.href), u = null == o ? void 0 : o.data, x = (0, _.ew)((0, _.kO)(s.href, 1), e => (0, _.bl)("@", e)), h = x ? "Twitter" : iq.I.getDisplayName(s.href), m = (0, M.useMemo)(() => ix(h), [h]), p = (0, ih.J)(null === (t = s.overrides) || void 0 === t ? void 0 : t.title, m) ? h : null !== (l = null === (i = s.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== l ? l : h, v = d || (null == o ? void 0 : o.status) === "FETCHING", g = im(s), f = (0, eM.H)(), w = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsx)("div", {
                        className: (0, F.Z)(iJ()["link-widget"], iJ()["link-widget--".concat(a)]),
                        children: (0, c.jsxs)("div", {
                            className: iJ().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", ["4x4", "2x4"].includes(a) && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: iq.I,
                                    size: "1x4" === a ? "small" : "medium"
                                }), ["4x4", "2x4"].includes(a) && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(iY, {
                                        data: null == o ? void 0 : o.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: iJ()["link-meta__container"],
                                children: [r && "mouse" === f && (0, c.jsx)(ia, {
                                    value: null != p ? p : h,
                                    extensions: m,
                                    className: (0, F.Z)(iJ().title),
                                    containerClassName: iJ()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: g
                                }), (!r || "mouse" !== f) && (0, c.jsx)(ii, {
                                    value: null != p ? p : h,
                                    extensions: m,
                                    className: iJ().title
                                }), "1x4" !== a && (0, c.jsx)("div", {
                                    className: iJ().handle,
                                    children: x
                                }), !["1x4", "2x2", "1x4"].includes(a) && (0, c.jsxs)(c.Fragment, {
                                    children: [!v && (null == u ? void 0 : u.bio) && (0, c.jsx)("div", {
                                        className: iJ().bio,
                                        children: null == u ? void 0 : u.bio
                                    }), v && (0, c.jsxs)("div", {
                                        className: iJ().bio,
                                        children: [(0, c.jsx)($.O, {
                                            className: "w-3/4",
                                            height: 14,
                                            rounding: 3
                                        }), (0, c.jsx)($.O, {
                                            className: "mt-1 w-[90%]",
                                            height: 14,
                                            rounding: 3
                                        }), "2x4" !== a && (0, c.jsx)($.O, {
                                            className: "mt-1 w-[60%]",
                                            height: 14,
                                            rounding: 3
                                        })]
                                    })]
                                })]
                            }), "4x4" === a && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), ((null == u ? void 0 : u.cover) || v) && (0, c.jsxs)("div", {
                                    className: iJ().cover,
                                    children: [(null == u ? void 0 : u.cover) && !v && (0, c.jsx)(tV.J, {
                                        src: (0, _.En)(u.cover, {
                                            h: iK.height
                                        }),
                                        srcSet: (0, _.En)(u.cover, {
                                            h: iK.height,
                                            dpr: 2
                                        }),
                                        alt: "",
                                        loading: "lazy",
                                        className: "h-full w-full rounded-[inherit] object-cover",
                                        fallback: w
                                    }), v && (0, c.jsx)($.O, {
                                        className: "aspect-[3] w-full rounded-[inherit]"
                                    }), (0, c.jsx)(X.k, {})]
                                })]
                            }), !["4x4", "2x4", "1x4"].includes(a) && (0, c.jsx)(iY, {
                                data: null == o ? void 0 : o.data
                            })]
                        })
                    })
                };
            var i$ = i(68713),
                iQ = i.n(i$);
            let i0 = e => {
                let {
                    data: t,
                    url: i
                } = e, l = iz();
                return (0, c.jsxs)("div", {
                    "data-prevent-widget": !0,
                    "data-rich-button": !0,
                    role: "button",
                    className: (0, F.Z)(iQ()["follow-button"], "rounded-full bg-[#FF0000] text-center font-bold text-white hover:bg-[#EB0404] active:bg-[#DE0000] active:text-white/90"),
                    onClick: e => {
                        e.preventDefault();
                        let t = new URL(i);
                        t.searchParams.append("sub_confirmation", "1"), window.open(t.toString(), "_blank")
                    },
                    ...l,
                    children: ["Subscribe", " ", (null == t ? void 0 : t.subscribers) != null && (0, c.jsx)("span", {
                        className: iQ().subs,
                        children: (0, _.d)(t.subscribers)
                    })]
                })
            };
            var i1 = i(64430);
            let i2 = {
                    height: 200
                },
                i4 = e => {
                    var t, i, l, s, n, a;
                    let {
                        data: r
                    } = e, o = (0, eL.$)(), d = (0, _.f6)(r.style, o), [{
                        editing: u
                    }] = (0, j.U)(), {
                        richdata: x,
                        loading: h
                    } = ed(r.href), m = null !== (n = null == x ? void 0 : null === (t = x.data) || void 0 === t ? void 0 : t.channelName) && void 0 !== n ? n : "Youtube", p = (0, M.useMemo)(() => ix(m), [m]), v = (0, ih.J)(null === (i = r.overrides) || void 0 === i ? void 0 : i.title, p) ? m : null !== (a = null === (l = r.overrides) || void 0 === l ? void 0 : l.title) && void 0 !== a ? a : m, g = h || (null == x ? void 0 : x.status) === "FETCHING", f = im(r), w = (0, eM.H)(), y = (0, M.useId)(), b = (null == x ? void 0 : null === (s = x.data) || void 0 === s ? void 0 : s.videos) ? (0, _.A1)(x.data.videos.slice(0, 4), 4).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                        h: i2.height,
                        fit: "crop"
                    })) : (0, _.A1)([], 4), N = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(iQ()["link-widget"], iQ()["link-widget--".concat(d)]),
                        children: [(0, c.jsxs)("div", {
                            className: iQ().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === d && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: i1.g,
                                    size: "1x4" === d ? "small" : "medium"
                                }), "4x4" === d && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(i0, {
                                        url: r.href,
                                        data: null == x ? void 0 : x.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: iQ()["link-meta__container"],
                                children: [u && "mouse" === w && (0, c.jsx)(ia, {
                                    value: null != v ? v : m,
                                    extensions: p,
                                    className: (0, F.Z)(iQ().title),
                                    containerClassName: iQ()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: f
                                }), (!u || "mouse" !== w) && (0, c.jsx)(ii, {
                                    value: null != v ? v : m,
                                    extensions: p,
                                    className: iQ().title
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(d) && (0, c.jsx)(i0, {
                                url: r.href,
                                data: null == x ? void 0 : x.data
                            })]
                        }), "4x4" === d && (0, c.jsx)(J.L, {}), (b.length > 0 || u) && (0, c.jsx)("div", {
                            className: (0, F.Z)(iQ()["youtube-grid"], g && iQ()["youtube-grid--loading"]),
                            children: b.map((e, t) => (0, c.jsxs)("div", {
                                children: [!g && e && (0, c.jsx)(tV.J, {
                                    src: e["1x"],
                                    srcSet: "".concat(e["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    fallback: N
                                }, "".concat(y, "-image-").concat(t)), g && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }))
                        }), "4x2" === d && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(i0, {
                                url: r.href,
                                data: null == x ? void 0 : x.data
                            })]
                        })]
                    })
                };
            var i5 = i(29021),
                i9 = i.n(i5),
                i7 = i(23947);
            let i3 = e => {
                    let {
                        data: t
                    } = e, i = iz();
                    return (0, c.jsx)("div", {
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(i9()["follow-button"], "rounded-full border-[1px] border-[#e7e7e9] bg-white text-center font-bold text-black hover:bg-[#FFFAFE] focus-visible:bg-[#FFFAFE] active:bg-[#FFF4FC] active:text-black"),
                        ...i,
                        children: "Follow"
                    })
                },
                i6 = {
                    height: 150,
                    width: 150
                },
                i8 = e => {
                    var t, i, l, s;
                    let {
                        data: n
                    } = e, a = (0, eL.$)(), r = (0, _.f6)(n.style, a), [{
                        editing: o
                    }] = (0, j.U)(), {
                        richdata: d,
                        loading: u
                    } = ed(n.href), x = "Dribbble", h = (0, M.useMemo)(() => ix(x), [x]), m = (0, ih.J)(null === (t = n.overrides) || void 0 === t ? void 0 : t.title, h) ? x : null !== (s = null === (i = n.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== s ? s : x, p = u || (null == d ? void 0 : d.status) === "FETCHING", v = im(n), g = (0, eM.H)(), f = (0, M.useId)(), w = (null == d ? void 0 : null === (l = d.data) || void 0 === l ? void 0 : l.posts) ? (0, _.A1)(d.data.posts.slice(0, 6), 6).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                        w: i6.width,
                        h: i6.height,
                        fit: "crop"
                    })) : (0, _.A1)([], 6), y = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(i9()["link-widget"], i9()["link-widget--".concat(r)]),
                        children: [(0, c.jsxs)("div", {
                            className: i9().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === r && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: i7.zK,
                                    size: "1x4" === r ? "small" : "medium"
                                }), "4x4" === r && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(i3, {
                                        data: null == d ? void 0 : d.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: i9()["link-meta__container"],
                                children: [o && "mouse" === g && (0, c.jsx)(ia, {
                                    value: null != m ? m : x,
                                    extensions: h,
                                    className: (0, F.Z)(i9().title),
                                    containerClassName: i9()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: v
                                }), (!o || "mouse" !== g) && (0, c.jsx)(ii, {
                                    value: null != m ? m : x,
                                    extensions: h,
                                    className: i9().title
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(r) && (0, c.jsx)(i3, {
                                data: null == d ? void 0 : d.data
                            })]
                        }), "4x4" === r && (0, c.jsx)(J.L, {}), (w.length > 0 || o) && (0, c.jsx)("div", {
                            className: (0, F.Z)(i9()["post-grid"], p && i9()["post-grid--fetching"]),
                            children: w.map((e, t) => (0, c.jsxs)("div", {
                                children: [!p && e && (0, c.jsx)(tV.J, {
                                    src: e["1x"],
                                    srcSet: "".concat(e["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    fallback: y
                                }, "".concat(f, "-image-").concat(t)), p && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }, t))
                        }), "4x2" === r && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(i3, {
                                data: null == d ? void 0 : d.data
                            })]
                        })]
                    })
                };
            var le = i(44821),
                lt = i.n(le);
            let li = e => {
                let {
                    data: t
                } = e, i = iz();
                return (0, c.jsxs)("div", {
                    "data-prevent-widget": !0,
                    "data-rich-button": !0,
                    role: "button",
                    className: (0, F.Z)(lt()["follow-button"], "rounded-[18px] bg-[#2F65EE] text-center font-bold text-white hover:bg-[#003ecb] focus-visible:bg-[#003ecb] active:bg-[#002f9a] active:text-white/80"),
                    ...i,
                    children: ["Follow", (null == t ? void 0 : t.followers) != null && (0, c.jsxs)(c.Fragment, {
                        children: [" ", (0, c.jsx)("span", {
                            className: "ml-1 font-normal text-white/80",
                            children: (0, _.d)(t.followers)
                        })]
                    })]
                })
            };
            var ll = i(15053);
            let ls = {
                    height: 150,
                    width: 150
                },
                ln = e => {
                    var t, i, l, s;
                    let {
                        data: n
                    } = e, a = (0, eL.$)(), r = (0, _.f6)(n.style, a), [{
                        editing: o
                    }] = (0, j.U)(), {
                        richdata: d,
                        loading: u
                    } = ed(n.href), x = "Behance", h = (0, M.useMemo)(() => ix(x), [x]), m = (0, ih.J)(null === (t = n.overrides) || void 0 === t ? void 0 : t.title, h) ? x : null !== (s = null === (i = n.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== s ? s : x, p = u || (null == d ? void 0 : d.status) === "FETCHING", v = im(n), g = (0, eM.H)(), f = (0, M.useId)(), w = (null == d ? void 0 : null === (l = d.data) || void 0 === l ? void 0 : l.posts) ? (0, _.A1)(d.data.posts.slice(0, 6), 6).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                        w: ls.width,
                        h: ls.height,
                        fit: "crop"
                    })) : (0, _.A1)([], 6), y = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(lt()["link-widget"], lt()["link-widget--".concat(r)]),
                        children: [(0, c.jsxs)("div", {
                            className: lt().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === r && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: ll.GF,
                                    size: "1x4" === r ? "small" : "medium"
                                }), "4x4" === r && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(li, {
                                        data: null == d ? void 0 : d.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: lt()["link-meta__container"],
                                children: [o && "mouse" === g && (0, c.jsx)(ia, {
                                    value: null != m ? m : x,
                                    extensions: h,
                                    className: (0, F.Z)(lt().title),
                                    containerClassName: lt()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: v
                                }), (!o || "mouse" !== g) && (0, c.jsx)(ii, {
                                    value: null != m ? m : x,
                                    extensions: h,
                                    className: lt().title
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(r) && (0, c.jsx)(li, {
                                data: null == d ? void 0 : d.data
                            })]
                        }), "4x4" === r && (0, c.jsx)(J.L, {}), (w.length > 0 || o) && (0, c.jsx)("div", {
                            className: (0, F.Z)(lt()["post-grid"], p && lt()["post-grid--fetching"]),
                            children: w.map((e, t) => (0, c.jsxs)("div", {
                                children: [!p && e && (0, c.jsx)(tV.J, {
                                    src: e["1x"],
                                    srcSet: "".concat(e["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    fallback: y
                                }, "".concat(f, "-image-").concat(t)), p && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }))
                        }), "4x2" === r && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(li, {
                                data: null == d ? void 0 : d.data
                            })]
                        })]
                    })
                };
            var la = i(72614),
                lr = i.n(la);
            let lo = e => {
                let {
                    data: t
                } = e, i = iz();
                return (0, c.jsxs)("div", {
                    "data-prevent-widget": !0,
                    "data-rich-button": !0,
                    role: "button",
                    className: (0, F.Z)(lr()["follow-button"], "rounded-[4px] bg-[#4497F7] text-center font-normal text-white hover:bg-[#007be5] focus-visible:bg-[#007be5] active:bg-[#007be5] active:text-white/80"),
                    ...i,
                    children: ["Follow", (null == t ? void 0 : t.followers) != null && (0, c.jsxs)(c.Fragment, {
                        children: [" ", (0, c.jsx)("span", {
                            className: "ml-1 font-normal text-white/80",
                            children: (0, _.d)(t.followers)
                        })]
                    })]
                })
            };
            var ld = i(63018),
                lc = i(11851);
            let lu = () => [iu.y, ic.Z, io.Z, ir.Z, lc.Z.configure({
                    limit: 14,
                    mode: "textSize"
                }), id.Z.configure({
                    emptyNodeClass: "is-empty",
                    placeholder: "Add Note..."
                })],
                lx = {
                    height: 107,
                    width: 167
                },
                lh = e => {
                    var t, i, s, n, a, r, o;
                    let {
                        data: d
                    } = e, u = (0, eL.$)(), x = (0, _.f6)(d.style, u), [{
                        editing: h
                    }] = (0, j.U)(), {
                        richdata: m,
                        loading: p
                    } = ed(d.href), v = "Figma", g = (0, M.useMemo)(() => ix(v), [v]), f = (0, ih.J)(null === (t = d.overrides) || void 0 === t ? void 0 : t.title, g) ? v : null !== (r = null === (i = d.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== r ? r : v, w = (0, _.ew)((0, el.Wz)(d.href), e => (0, _.bl)("@", e)), y = p || (null == m ? void 0 : m.status) === "FETCHING", b = im(d), N = (0, eM.H)(), C = lu(), k = (0, ih.J)(null === (s = d.overrides) || void 0 === s ? void 0 : s.figmaChat, C) ? "" : null !== (o = null === (n = d.overrides) || void 0 === n ? void 0 : n.figmaChat) && void 0 !== o ? o : "", E = ip(d), S = (0, M.useId)(), L = (null == m ? void 0 : null === (a = m.data) || void 0 === a ? void 0 : a.posts) ? (0, _.A1)(m.data.posts.slice(0, 4), 4).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                        w: lx.width,
                        h: lx.height,
                        fit: "crop"
                    })) : (0, _.A1)([], 4), I = (0, M.useRef)(null), D = (0, M.useRef)(null), [Z, z] = (0, M.useState)(!1), A = (0, eZ.A)(e => e.dragging), [T, O] = (0, M.useState)(!1), [R, B] = (0, M.useState)(!1), [H, U] = (0, M.useState)(!1);
                    (0, M.useEffect)(() => (U(!0), () => U(!1)), []), (0, M.useEffect)(() => {
                        A && z(!1)
                    }, [A]), (0, M.useEffect)(() => {
                        T && z(!1)
                    }, [T]), (0, M.useEffect)(() => {
                        var e, t, i, l, s, n;
                        let a = e => {
                                A || T || "desktop" !== u || R || z(!0)
                            },
                            r = e => {
                                z(!1)
                            },
                            o = e => {
                                A || T || "desktop" !== u || R || z(!0)
                            };
                        return null === (e = D.current) || void 0 === e || null === (t = e.parentElement) || void 0 === t || t.addEventListener("mouseenter", a), null === (i = D.current) || void 0 === i || null === (l = i.parentElement) || void 0 === l || l.addEventListener("mouseleave", r), null === (s = D.current) || void 0 === s || null === (n = s.parentElement) || void 0 === n || n.addEventListener("mouseover", o), () => {
                            var e, t, i, l, s, n;
                            null === (e = D.current) || void 0 === e || null === (t = e.parentElement) || void 0 === t || t.removeEventListener("mouseenter", a), null === (i = D.current) || void 0 === i || null === (l = i.parentElement) || void 0 === l || l.removeEventListener("mouseleave", r), null === (s = D.current) || void 0 === s || null === (n = s.parentElement) || void 0 === n || n.removeEventListener("mouseover", o)
                        }
                    }, [A, u, T, H, z, Z, R]), (0, M.useEffect)(() => {
                        let e = e => {
                                I.current && (I.current.style.transform = "translate(".concat(e.clientX + 5, "px, ").concat(e.clientY + 5, "px)"))
                            },
                            t = (0, eV.t)();
                        return t ? t.addEventListener("mousemove", e) : window.addEventListener("mousemove", e), () => {
                            t ? t.removeEventListener("mousemove", e) : window.removeEventListener("mousemove", e)
                        }
                    }, []), (0, M.useEffect)(() => {
                        let e = e => {
                                B(!0)
                            },
                            t = (0, eV.t)();
                        return t ? t.addEventListener("scroll", e) : document.addEventListener("scroll", e), () => {
                            t ? t.removeEventListener("scroll", e) : document.removeEventListener("scroll", e)
                        }
                    }, []), (0, M.useEffect)(() => {
                        R && (z(!1), window.setTimeout(() => {
                            setTimeout(() => {
                                B(!1)
                            })
                        }, 100))
                    }, [R]);
                    let V = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)("div", {
                            ref: D,
                            className: (0, F.Z)(lr()["link-widget"], lr()["link-widget--".concat(x)]),
                            children: [(0, c.jsxs)("div", {
                                className: lr().description,
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex items-start", "4x4" === x && "w-full"),
                                    children: [(0, c.jsx)(tW, {
                                        platform: ld.Ds,
                                        size: "1x4" === x ? "small" : "medium"
                                    }), "4x4" === x && (0, c.jsxs)(c.Fragment, {
                                        children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(lo, {
                                            data: null == m ? void 0 : m.data
                                        })]
                                    })]
                                }), (0, c.jsxs)("div", {
                                    className: lr()["link-meta__container"],
                                    children: [h && "mouse" === N && (0, c.jsx)(ia, {
                                        onActiveChange: e => {
                                            O(e)
                                        },
                                        value: null != f ? f : v,
                                        extensions: g,
                                        className: (0, F.Z)(lr().title),
                                        containerClassName: lr()["title-editor"],
                                        clickToActivate: !0,
                                        floating: !0,
                                        onCommit: b
                                    }), (!h || "mouse" !== N) && (0, c.jsx)(ii, {
                                        value: null != f ? f : v,
                                        extensions: g,
                                        className: lr().title
                                    }), "1x4" !== x && (0, c.jsx)("div", {
                                        className: lr().handle,
                                        children: w
                                    })]
                                }), !["4x2", "4x4", "1x4"].includes(x) && (0, c.jsx)(lo, {
                                    data: null == m ? void 0 : m.data
                                })]
                            }), "4x4" === x && (0, c.jsx)(J.L, {}), (L.length > 0 || h) && (0, c.jsx)("div", {
                                className: (0, F.Z)(lr()["post-grid"], y && lr()["post-grid--fetching"]),
                                children: L.map((e, t) => (0, c.jsxs)("div", {
                                    children: [!y && e && (0, c.jsx)(tV.J, {
                                        src: e["1x"],
                                        srcSet: "".concat(e["2x"], " 2x"),
                                        alt: "",
                                        loading: "lazy",
                                        fallback: V
                                    }, "".concat(S, "-image-").concat(t)), y && (0, c.jsx)($.O, {
                                        className: "h-full w-full rounded-[inherit]"
                                    }), (0, c.jsx)(X.k, {})]
                                }))
                            }), "4x2" === x && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(lo, {
                                    data: null == m ? void 0 : m.data
                                })]
                            })]
                        }), H && (h || k) ? (0, e8.createPortal)((0, c.jsx)("div", {
                            ref: I,
                            className: (0, F.Z)(lr()["figma-bubble-wrapper"]),
                            style: {
                                left: 10,
                                top: 14
                            },
                            onMouseEnter: () => {
                                A || T || "desktop" !== u || R || z(!0)
                            },
                            onMouseLeave: () => {
                                z(!1)
                            },
                            children: (0, c.jsx)(eX.M, {
                                children: Z && (0, c.jsxs)(P.m.div, {
                                    initial: {
                                        opacity: 0
                                    },
                                    animate: {
                                        opacity: 1,
                                        transition: {
                                            ease: "easeInOut",
                                            duration: .14,
                                            delay: .3
                                        }
                                    },
                                    exit: {
                                        opacity: 0,
                                        transition: {
                                            ease: "easeInOut",
                                            duration: .14
                                        }
                                    },
                                    className: (0, F.Z)(lr()["figma-bubble"]),
                                    children: [h && "mouse" === N && (0, c.jsx)(ia, {
                                        value: k,
                                        extensions: C,
                                        className: (0, F.Z)(lr()["figma-bubble-chat"]),
                                        clickToActivate: !0,
                                        focusInputOnMount: !0,
                                        onCommit: E,
                                        onChange: e => {
                                            clearTimeout(l), l = window.setTimeout(() => {
                                                E(e)
                                            }, 1e3)
                                        }
                                    }), (!h || "mouse" !== N) && (0, c.jsx)(ii, {
                                        value: k,
                                        extensions: ix(),
                                        className: lr()["figma-bubble-chat"]
                                    })]
                                })
                            })
                        }), document.body) : null]
                    })
                };
            var lm = i(94325),
                lp = i.n(lm);
            let lv = e => {
                let {
                    data: t
                } = e, i = iz();
                return (0, c.jsxs)("div", {
                    "data-prevent-widget": !0,
                    "data-rich-button": !0,
                    role: "button",
                    className: (0, F.Z)(lp()["follow-button"], "rounded-[4px] text-center font-semibold text-white"),
                    ...i,
                    children: ["Follow", (null == t ? void 0 : t.followers) != null && (0, c.jsxs)(c.Fragment, {
                        children: [" ", (0, c.jsx)("span", {
                            className: "ml-1 font-normal text-white/80",
                            children: (0, _.d)(t.followers)
                        })]
                    })]
                })
            };
            var lg = i(309),
                lf = i(60190);
            let l_ = {
                    height: 211,
                    width: 140
                },
                lj = e => {
                    var t, i, l, s;
                    let {
                        data: n
                    } = e, a = (0, eL.$)(), r = (0, _.f6)(n.style, a), [{
                        editing: o
                    }] = (0, j.U)(), {
                        richdata: d,
                        loading: u
                    } = ed(n.href), x = "TikTok", h = (0, _.ew)((0, lf.aN)(n.href), e => (0, _.bl)("@", e)), m = (0, M.useMemo)(() => ix(x), [x]), p = (0, ih.J)(null === (t = n.overrides) || void 0 === t ? void 0 : t.title, m) ? x : null !== (s = null === (i = n.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== s ? s : x, v = u || (null == d ? void 0 : d.status) === "FETCHING", g = im(n), f = (0, eM.H)(), w = (0, M.useId)(), y = (null == d ? void 0 : null === (l = d.data) || void 0 === l ? void 0 : l.posts) ? (0, _.A1)(d.data.posts.slice(0, 3), 3).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                        w: l_.width,
                        h: l_.height,
                        fit: "crop"
                    })) : (0, _.A1)([], 3), b = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(lp()["link-widget"], lp()["link-widget--".concat(r)]),
                        children: [(0, c.jsxs)("div", {
                            className: lp().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === r && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: lg.F,
                                    size: "1x4" === r ? "small" : "medium"
                                }), "4x4" === r && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(lv, {
                                        data: null == d ? void 0 : d.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: lp()["link-meta__container"],
                                children: [o && "mouse" === f && (0, c.jsx)(ia, {
                                    value: null != p ? p : x,
                                    extensions: m,
                                    className: (0, F.Z)(lp().title),
                                    containerClassName: lp()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: g
                                }), (!o || "mouse" !== f) && (0, c.jsx)(ii, {
                                    value: null != p ? p : x,
                                    extensions: m,
                                    className: lp().title
                                }), "1x4" !== r && (0, c.jsx)("div", {
                                    className: lp().handle,
                                    children: h
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(r) && (0, c.jsx)(lv, {
                                data: null == d ? void 0 : d.data
                            })]
                        }), "4x4" === r && (0, c.jsx)(J.L, {}), (y.length > 0 || o) && (0, c.jsx)("div", {
                            className: (0, F.Z)(lp()["post-grid"], v && lp()["post-grid--fetching"]),
                            children: y.map((e, t) => (0, c.jsxs)("div", {
                                children: [!v && e && (0, c.jsx)(tV.J, {
                                    src: e["1x"],
                                    srcSet: "".concat(e["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    fallback: b
                                }, "".concat(w, "-image-").concat(t)), v && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }))
                        }), "4x2" === r && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(lv, {
                                data: null == d ? void 0 : d.data
                            })]
                        })]
                    })
                };
            var lw = i(63411),
                ly = i.n(lw);
            let lb = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: t,
                        height: t,
                        className: i,
                        fill: "none",
                        viewBox: "0 0 16 16",
                        children: (0, c.jsx)("path", {
                            stroke: "currentColor",
                            strokeLinecap: "round",
                            strokeWidth: "2",
                            d: "M7.293 5.05L8 5.757l.707-.707L9.88 3.88A3 3 0 1114.12 8.12L8 14.243 1.879 8.12A3 3 0 116.12 3.88L7.293 5.05z"
                        })
                    })
                },
                lN = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: t,
                        height: t,
                        className: i,
                        fill: "none",
                        viewBox: "0 0 17 17",
                        children: [(0, c.jsx)("mask", {
                            id: "path-1-inside-1_6138_16108",
                            fill: "#fff",
                            children: (0, c.jsx)("rect", {
                                width: "11",
                                height: "11",
                                x: "1.5",
                                y: "4.5",
                                rx: "1"
                            })
                        }), (0, c.jsx)("rect", {
                            width: "11",
                            height: "11",
                            x: "1.5",
                            y: "4.5",
                            stroke: "currentColor",
                            strokeWidth: "4",
                            mask: "url(#path-1-inside-1_6138_16108)",
                            rx: "1"
                        }), (0, c.jsx)("path", {
                            fill: "currentColor",
                            d: "M5.5 1.5a1 1 0 00-1 1v1h9v9h1a1 1 0 001-1v-9a1 1 0 00-1-1h-9z"
                        })]
                    })
                },
                lC = e => {
                    let {
                        data: t
                    } = e, i = iz();
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(ly()["action-buttons"], "flex flex-row gap-3"),
                        children: [(0, c.jsxs)("div", {
                            "data-prevent-widget": !0,
                            "data-rich-button": !0,
                            role: "button",
                            className: (0, F.Z)(ly()["like-button"], "flex w-[59.5px] flex-row items-center justify-center gap-1.5 rounded-[4px] border border-black/10 text-center font-semibold text-white text-black/40"),
                            ...i,
                            children: [(0, c.jsx)(lb, {
                                size: 16,
                                className: "inline text-black"
                            }), (null == t ? void 0 : t.likes) ? (0, c.jsx)("span", {
                                className: "whitespace-nowrap",
                                children: (0, _.d)(null == t ? void 0 : t.likes)
                            }) : null]
                        }), (0, c.jsxs)("div", {
                            "data-prevent-widget": !0,
                            "data-rich-button": !0,
                            role: "button",
                            className: (0, F.Z)(ly()["copy-button"], "hidden w-[59.5px] flex-row items-center justify-center gap-1.5 rounded-[4px] bg-[#3E8AE2] text-center font-semibold text-white/60 hover:bg-[#0d99ff] focus-visible:bg-[#0d99ff] active:bg-[#0d99ff] active:text-white/80 [@media(min-width:420px)]:flex"),
                            ...i,
                            children: [(0, c.jsx)(lN, {
                                size: 16,
                                className: "block text-white"
                            }), (null == t ? void 0 : t.copiedBy) ? (0, c.jsx)("span", {
                                className: "whitespace-nowrap",
                                children: (0, _.d)(null == t ? void 0 : t.copiedBy)
                            }) : null]
                        })]
                    })
                },
                lk = {
                    height: 217,
                    width: 342
                },
                lE = e => {
                    var t, i, l, n, a, r, o, d, u, x, h, m;
                    let {
                        data: p
                    } = e, v = (0, eL.$)(), g = (0, _.f6)(p.style, v), [{
                        editing: f
                    }] = (0, j.U)(), {
                        richdata: w,
                        loading: y
                    } = ed(p.href), b = null !== (x = null == w ? void 0 : null === (t = w.data) || void 0 === t ? void 0 : t.title) && void 0 !== x ? x : "Figma", N = (0, M.useMemo)(() => ix(b), [b]), C = (0, ih.J)(null === (i = p.overrides) || void 0 === i ? void 0 : i.title, N) ? b : null !== (h = null === (l = p.overrides) || void 0 === l ? void 0 : l.title) && void 0 !== h ? h : b, k = (0, _.ew)(null == w ? void 0 : null === (n = w.data) || void 0 === n ? void 0 : n.username, e => (0, _.bl)("@", e)), E = y || (null == w ? void 0 : w.status) === "FETCHING", S = im(p), L = lu(), I = (0, ih.J)(null === (a = p.overrides) || void 0 === a ? void 0 : a.figmaChat, L) ? "" : null !== (m = null === (r = p.overrides) || void 0 === r ? void 0 : r.figmaChat) && void 0 !== m ? m : "", D = ip(p), Z = (0, eM.H)(), z = (null == w ? void 0 : null === (o = w.data) || void 0 === o ? void 0 : o.thumbnail) ? {
                        "1x": (0, _.En)(null == w ? void 0 : null === (d = w.data) || void 0 === d ? void 0 : d.thumbnail, {
                            w: lk.width,
                            h: lk.height,
                            fit: "crop"
                        }),
                        "2x": (0, _.En)(null == w ? void 0 : null === (u = w.data) || void 0 === u ? void 0 : u.thumbnail, {
                            w: lk.width,
                            h: lk.height,
                            dpr: 2,
                            fit: "crop"
                        })
                    } : void 0, A = (0, M.useRef)(null), T = (0, M.useRef)(null), [O, R] = (0, M.useState)(!1), B = (0, eZ.A)(e => e.dragging), [H, U] = (0, M.useState)(!1), [V, G] = (0, M.useState)(!1), [W, Y] = (0, M.useState)(!1);
                    (0, M.useEffect)(() => (Y(!0), () => Y(!1)), []), (0, M.useEffect)(() => {
                        B && R(!1)
                    }, [B]), (0, M.useEffect)(() => {
                        H && R(!1)
                    }, [H]), (0, M.useEffect)(() => {
                        var e, t, i, l, s, n;
                        let a = e => {
                                B || H || "desktop" !== v || V || R(!0)
                            },
                            r = e => {
                                R(!1)
                            },
                            o = e => {
                                B || H || "desktop" !== v || V || R(!0)
                            };
                        return null === (e = T.current) || void 0 === e || null === (t = e.parentElement) || void 0 === t || t.addEventListener("mouseenter", a), null === (i = T.current) || void 0 === i || null === (l = i.parentElement) || void 0 === l || l.addEventListener("mouseleave", r), null === (s = T.current) || void 0 === s || null === (n = s.parentElement) || void 0 === n || n.addEventListener("mouseover", o), () => {
                            var e, t, i, l, s, n;
                            null === (e = T.current) || void 0 === e || null === (t = e.parentElement) || void 0 === t || t.removeEventListener("mouseenter", a), null === (i = T.current) || void 0 === i || null === (l = i.parentElement) || void 0 === l || l.removeEventListener("mouseleave", r), null === (s = T.current) || void 0 === s || null === (n = s.parentElement) || void 0 === n || n.removeEventListener("mouseover", o)
                        }
                    }, [B, v, H, W, R, O, V]), (0, M.useEffect)(() => {
                        let e = e => {
                                A.current && (A.current.style.transform = "translate(".concat(e.clientX + 5, "px, ").concat(e.clientY + 5, "px)"))
                            },
                            t = (0, eV.t)();
                        return t ? t.addEventListener("mousemove", e) : window.addEventListener("mousemove", e), () => {
                            t ? t.removeEventListener("mousemove", e) : window.removeEventListener("mousemove", e)
                        }
                    }, []), (0, M.useEffect)(() => {
                        let e = e => {
                                G(!0)
                            },
                            t = (0, eV.t)();
                        return t ? t.addEventListener("scroll", e) : document.addEventListener("scroll", e), () => {
                            t ? t.removeEventListener("scroll", e) : document.removeEventListener("scroll", e)
                        }
                    }, []), (0, M.useEffect)(() => {
                        V && (R(!1), window.setTimeout(() => {
                            setTimeout(() => {
                                G(!1)
                            })
                        }, 100))
                    }, [V]);
                    let q = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)("div", {
                            ref: T,
                            className: (0, F.Z)(ly()["link-widget"], ly()["link-widget--".concat(g)]),
                            children: [(0, c.jsxs)("div", {
                                className: ly().description,
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex items-start", "4x4" === g && "w-full"),
                                    children: [(0, c.jsx)(tW, {
                                        platform: ld.Ds,
                                        size: "1x4" === g ? "small" : "medium"
                                    }), "4x4" === g && (0, c.jsxs)(c.Fragment, {
                                        children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(lC, {
                                            data: null == w ? void 0 : w.data
                                        })]
                                    })]
                                }), (0, c.jsxs)("div", {
                                    className: ly()["link-meta__container"],
                                    children: [f && "mouse" === Z && (0, c.jsx)(ia, {
                                        onActiveChange: e => {
                                            U(e)
                                        },
                                        value: null != C ? C : b,
                                        extensions: N,
                                        className: (0, F.Z)(ly().title),
                                        containerClassName: ly()["title-editor"],
                                        clickToActivate: !0,
                                        floating: !0,
                                        onCommit: S
                                    }), (!f || "mouse" !== Z) && (0, c.jsx)(ii, {
                                        value: null != C ? C : b,
                                        extensions: N,
                                        className: ly().title
                                    }), "1x4" !== g && (0, c.jsx)("div", {
                                        className: ly().handle,
                                        children: k
                                    })]
                                }), !["4x2", "4x4", "1x4"].includes(g) && (0, c.jsx)(lC, {
                                    data: null == w ? void 0 : w.data
                                })]
                            }), "4x4" === g && (0, c.jsx)(J.L, {}), (z || f) && (0, c.jsxs)("div", {
                                className: (0, F.Z)(ly().cover, E && ly()["cover--fetching"]),
                                children: [!E && (0, c.jsx)(tV.J, {
                                    src: null == z ? void 0 : z["1x"],
                                    srcSet: "".concat(null == z ? void 0 : z["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    className: "h-full w-full rounded-[inherit] object-cover",
                                    fallback: q
                                }), E && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }), "4x2" === g && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(lC, {
                                    data: null == w ? void 0 : w.data
                                })]
                            })]
                        }), W && (f || I) ? (0, e8.createPortal)((0, c.jsx)("div", {
                            ref: A,
                            className: (0, F.Z)(ly()["figma-bubble-wrapper"]),
                            style: {
                                left: 10,
                                top: 14
                            },
                            onMouseEnter: () => {
                                B || H || "desktop" !== v || V || R(!0)
                            },
                            onMouseLeave: () => {
                                R(!1)
                            },
                            children: (0, c.jsx)(eX.M, {
                                children: O && (0, c.jsxs)(P.m.div, {
                                    initial: {
                                        opacity: 0
                                    },
                                    animate: {
                                        opacity: 1,
                                        transition: {
                                            ease: "easeInOut",
                                            duration: .14,
                                            delay: .3
                                        }
                                    },
                                    exit: {
                                        opacity: 0,
                                        transition: {
                                            ease: "easeInOut",
                                            duration: .14
                                        }
                                    },
                                    className: (0, F.Z)(ly()["figma-bubble"]),
                                    children: [f && "mouse" === Z && (0, c.jsx)(ia, {
                                        value: I,
                                        extensions: L,
                                        className: (0, F.Z)(ly()["figma-bubble-chat"]),
                                        clickToActivate: !0,
                                        focusInputOnMount: !0,
                                        onCommit: D,
                                        onChange: e => {
                                            clearTimeout(s), s = window.setTimeout(() => {
                                                D(e)
                                            }, 1e3)
                                        }
                                    }), (!f || "mouse" !== Z) && (0, c.jsx)(ii, {
                                        value: I,
                                        extensions: ix(),
                                        className: ly()["figma-bubble-chat"]
                                    })]
                                })
                            })
                        }), document.body) : null]
                    })
                };
            var lS = i(34018),
                lL = i.n(lS);
            let lI = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            d: "M3 13.1231V2.87688C3 1.42024 4.55203 0.520516 5.77196 1.26995L14.1114 6.39307C15.2962 7.12093 15.2962 8.87907 14.1114 9.60693L5.77196 14.73C4.55203 15.4795 3 14.5798 3 13.1231Z",
                            fill: "white"
                        })
                    })
                },
                lD = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        xmlns: "http://www.w3.org/2000/svg",
                        className: i,
                        fill: "none",
                        viewBox: "0 0 13 13",
                        children: [(0, c.jsxs)("g", {
                            fill: "currentColor",
                            clipPath: "url(#clip0_6138_16321)",
                            children: [(0, c.jsx)("rect", {
                                width: "3",
                                height: "12",
                                x: "1.5",
                                y: "0.5",
                                rx: "1"
                            }), (0, c.jsx)("rect", {
                                width: "3",
                                height: "12",
                                x: "8.5",
                                y: "0.5",
                                rx: "1"
                            })]
                        }), (0, c.jsx)("defs", {
                            children: (0, c.jsx)("clipPath", {
                                id: "clip0_6138_16321",
                                children: (0, c.jsx)("path", {
                                    fill: "currentColor",
                                    d: "M0 0H12V12H0z",
                                    transform: "translate(.5 .5)"
                                })
                            })
                        })]
                    })
                },
                lZ = e => {
                    let {
                        data: t,
                        className: i,
                        playing: l,
                        togglePlaying: s
                    } = e, n = iz();
                    return (0, c.jsx)("div", {
                        onClick: e => {
                            e.preventDefault(), e.stopPropagation(), s()
                        },
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(lL()["play-button"], "flex min-w-[86px] items-center justify-center gap-1  rounded-[18px] bg-[#1ED760] px-[10px] py-[7px] text-center text-xs font-bold text-white transition-transform will-change-transform hover:bg-[#1fdf64] active:scale-[0.95] active:bg-[#169c46] active:text-white/80 xs:px-[16px]", i),
                        ...n,
                        children: l ? (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lD, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Pause"
                            })]
                        }) : (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lI, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Play"
                            })]
                        })
                    })
                };
            var lz = i(132),
                lA = i(53416);
            let lF = (0, L.Ue)((e, t) => ({
                audios: {},
                activeId: void 0,
                playing: !1,
                ended: !1,
                addAudio(t, i) {
                    e(e => ({
                        audios: { ...e.audios,
                            [t]: i
                        }
                    }))
                },
                removeAudio(t) {
                    e(e => {
                        let {
                            [t]: i, ...l
                        } = e.audios;
                        if (e.activeId === t) {
                            var s;
                            null === (s = e.audios[t]) || void 0 === s || s.pause()
                        }
                        return i && i.remove(), {
                            audios: l
                        }
                    })
                },
                setActiveId(i, l) {
                    let s = t();
                    if (s.activeId === i) return;
                    let n = () => {
                            e({
                                playing: !0
                            })
                        },
                        a = () => {
                            e({
                                playing: !1
                            })
                        },
                        r = () => {
                            e({
                                playing: !1,
                                ended: !0
                            })
                        };
                    if (s.activeId) {
                        let e = s.audios[s.activeId];
                        if (e) {
                            var o;
                            null === (o = e.unregister) || void 0 === o || o.call(e), e.pause()
                        }
                    }
                    if (i) {
                        let t = s.audios[i];
                        t || ((t = new Audio(l)).src = l, e({
                            audios: { ...s.audios,
                                [i]: t
                            }
                        })), null == t || t.addEventListener("play", n), null == t || t.addEventListener("pause", a), null == t || t.addEventListener("ended", r), t && s.playing && (t.unregister = () => {
                            null == t || t.removeEventListener("play", n), null == t || t.removeEventListener("pause", a), null == t || t.removeEventListener("ended", r)
                        }, t.ended && (t.currentTime = 0), t.volume = .5, t.play().catch(t => {
                            console.error("Failed to play", t), e({
                                playing: !1
                            })
                        }))
                    }
                    e({
                        activeId: i
                    })
                },
                setPlaying(i) {
                    let l = t();
                    if (l.playing != i && l.activeId) {
                        let t = l.audios[l.activeId];
                        t && (i ? (t.volume = .5, t.play().catch(t => {
                            e({
                                playing: !1
                            })
                        })) : t.pause(), e({
                            playing: i,
                            ended: !1
                        }))
                    }
                }
            }));

            function lM(e) {
                let [t] = (0, M.useState)((0, lA.x0)()), {
                    activeId: i,
                    addAudio: l,
                    removeAudio: s,
                    setActiveId: n,
                    setPlaying: a,
                    playing: r,
                    ended: o
                } = lF(), d = () => {
                    i !== t && n(t, e), a(i !== t || !r)
                }, c = () => {
                    a(!1)
                }, u = () => {
                    n(t, e), a(!0)
                };
                return (0, M.useEffect)(() => () => {
                    s(t)
                }, [t]), {
                    playing: r && i === t,
                    toggle: d,
                    play: u,
                    pause: c,
                    hasEnded: o
                }
            }
            let lT = (e, t) => {
                    var i;
                    let [l, s] = (0, M.useState)(null !== (i = null == e ? void 0 : e.map(e => (0, lA.x0)())) && void 0 !== i ? i : []), {
                        audios: n,
                        activeId: a,
                        addAudio: r,
                        removeAudio: o,
                        setActiveId: d,
                        setPlaying: c,
                        playing: u,
                        ended: x
                    } = lF(), h = () => {
                        0 !== l.length && (a && l.includes(a) ? c(!u) : (d(l[0], e[0]), c(!0)))
                    }, m = () => {
                        c(!1)
                    }, p = () => {
                        c(!0)
                    };
                    (0, M.useEffect)(() => () => {
                        l.forEach(e => {
                            o(e)
                        })
                    }, [l]);
                    let v = () => {
                            for (let t = 1; t < l.length; t++) {
                                let i = (0, _.Rk)(l.indexOf(a) + t, e.length);
                                if (d(l[i], e[i]), c(!0), e[i]) break
                            }
                        },
                        g = () => {
                            for (let t = 1; t < l.length; t++) {
                                let i = (0, _.Rk)(l.indexOf(a) - t, e.length);
                                if (d(l[i], e[i]), c(!0), e[i]) break
                            }
                        },
                        f = t => {
                            (e[t] || u) && (u && a === l[t] ? c(!1) : l[t] !== a && (e[t] ? (d(l[t], e[t]), c(!0)) : u && c(!1)))
                        };
                    return (0, M.useEffect)(() => {
                        if (a && l.includes(a)) {
                            let e = n[a];
                            if (e) {
                                let t = () => {
                                    v()
                                };
                                return e.addEventListener("ended", t), () => {
                                    e.removeEventListener("ended", t)
                                }
                            }
                        }
                    }, [a]), (0, M.useEffect)(() => {
                        e.length !== l.length && s(e.map(e => (0, lA.x0)()))
                    }, [e.length]), {
                        playing: u && !!a && l.includes(a),
                        toggle: h,
                        play: p,
                        pause: m,
                        next: v,
                        prev: g,
                        hasEnded: x,
                        current: a ? l.indexOf(a) : 0,
                        setCurrent: f
                    }
                },
                lO = e => {
                    let {
                        size: t = 110,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: t,
                        height: t,
                        fill: "none",
                        viewBox: "0 0 110 110",
                        className: i,
                        children: [(0, c.jsx)("circle", {
                            cx: "55",
                            cy: "55",
                            r: "55",
                            fill: "#000"
                        }), (0, c.jsx)("mask", {
                            id: "mask0_6138_16576",
                            style: {
                                maskType: "alpha"
                            },
                            width: 110,
                            height: 110,
                            x: "0",
                            y: "0",
                            maskUnits: "userSpaceOnUse",
                            children: (0, c.jsx)("circle", {
                                cx: "55",
                                cy: "55",
                                r: "55",
                                fill: "#000"
                            })
                        }), (0, c.jsxs)("g", {
                            mask: "url(#mask0_6138_16576)",
                            children: [(0, c.jsx)("g", {
                                filter: "url(#filter0_f_6138_16576)",
                                children: (0, c.jsx)("circle", {
                                    cx: "55",
                                    cy: "55",
                                    r: "51.5",
                                    stroke: "#fff",
                                    strokeOpacity: "0.21"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter1_f_6138_16576)",
                                children: (0, c.jsx)("circle", {
                                    cx: "55",
                                    cy: "55",
                                    r: "47.5",
                                    stroke: "#fff",
                                    strokeOpacity: "0.21"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter2_f_6138_16576)",
                                children: (0, c.jsx)("circle", {
                                    cx: "55",
                                    cy: "55",
                                    r: "45.5",
                                    stroke: "#fff",
                                    strokeOpacity: "0.21"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter3_f_6138_16576)",
                                children: (0, c.jsx)("circle", {
                                    cx: "55",
                                    cy: "55",
                                    r: "43.5",
                                    stroke: "#fff",
                                    strokeOpacity: "0.21"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter4_f_6138_16576)",
                                children: (0, c.jsx)("circle", {
                                    cx: "55",
                                    cy: "55",
                                    r: "37.5",
                                    stroke: "#fff",
                                    strokeOpacity: "0.21"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter5_f_6138_16576)",
                                children: (0, c.jsx)("circle", {
                                    cx: "55",
                                    cy: "55",
                                    r: "34.5",
                                    stroke: "#fff",
                                    strokeOpacity: "0.21"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter6_f_6138_16576)",
                                opacity: "0.4",
                                children: (0, c.jsx)("path", {
                                    fill: "#fff",
                                    d: "M-14 38l68 19.579L-14 74V38z"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter7_f_6138_16576)",
                                opacity: "0.4",
                                children: (0, c.jsx)("path", {
                                    fill: "#fff",
                                    d: "M123 38L55 57.579 123 74V38z"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter8_f_6138_16576)",
                                opacity: "0.4",
                                children: (0, c.jsx)("path", {
                                    fill: "#fff",
                                    d: "M36.5 124.5l19.579-68 16.421 68h-36z"
                                })
                            }), (0, c.jsx)("g", {
                                filter: "url(#filter9_f_6138_16576)",
                                opacity: "0.4",
                                children: (0, c.jsx)("path", {
                                    fill: "#fff",
                                    d: "M36.5-12.5l19.579 68 16.421-68h-36z"
                                })
                            })]
                        }), (0, c.jsxs)("defs", {
                            children: [(0, c.jsxs)("filter", {
                                id: "filter0_f_6138_16576",
                                width: "108",
                                height: "108",
                                x: "1",
                                y: "1",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "1"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter1_f_6138_16576",
                                width: "100",
                                height: "100",
                                x: "5",
                                y: "5",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "1"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter2_f_6138_16576",
                                width: "96",
                                height: "96",
                                x: "7",
                                y: "7",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "1"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter3_f_6138_16576",
                                width: "92",
                                height: "92",
                                x: "9",
                                y: "9",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "1"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter4_f_6138_16576",
                                width: "80",
                                height: "80",
                                x: "15",
                                y: "15",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "1"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter5_f_6138_16576",
                                width: "74",
                                height: "74",
                                x: "18",
                                y: "18",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "1"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter6_f_6138_16576",
                                width: "100",
                                height: "68",
                                x: "-30",
                                y: "22",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "8"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter7_f_6138_16576",
                                width: "100",
                                height: "68",
                                x: "39",
                                y: "22",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "8"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter8_f_6138_16576",
                                width: "68",
                                height: "100",
                                x: "20.5",
                                y: "40.5",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "8"
                                })]
                            }), (0, c.jsxs)("filter", {
                                id: "filter9_f_6138_16576",
                                width: "68",
                                height: "100",
                                x: "20.5",
                                y: "-28.5",
                                colorInterpolationFilters: "sRGB",
                                filterUnits: "userSpaceOnUse",
                                children: [(0, c.jsx)("feFlood", {
                                    floodOpacity: "0",
                                    result: "BackgroundImageFix"
                                }), (0, c.jsx)("feBlend", { in: "SourceGraphic",
                                    in2: "BackgroundImageFix",
                                    result: "shape"
                                }), (0, c.jsx)("feGaussianBlur", {
                                    result: "effect1_foregroundBlur_6138_16576",
                                    stdDeviation: "8"
                                })]
                            })]
                        })]
                    })
                };
            var lR = i(32108),
                lB = i.n(lR),
                lH = i(63246);
            let lU = e => {
                    switch (e) {
                        case "left":
                            return "right";
                        case "right":
                            return "left";
                        case "top":
                            return "bottom";
                        case "bottom":
                            return "top"
                    }
                },
                lV = {
                    "cover-slide-left": {
                        initial: {
                            x: 0
                        },
                        animate: {
                            x: "-5%"
                        }
                    },
                    "cover-slide-right": {
                        initial: {
                            x: 0
                        },
                        animate: {
                            x: "5%"
                        }
                    },
                    "cover-slide-top": {
                        initial: {
                            y: 0
                        },
                        animate: {
                            y: "-5%"
                        }
                    },
                    "cover-slide-bottom": {
                        initial: {
                            y: 0
                        },
                        animate: {
                            y: "30%"
                        }
                    },
                    "vinyl-slide-out-left": {
                        initial: {
                            x: 0
                        },
                        animate: {
                            x: "-30%"
                        }
                    },
                    "vinyl-slide-out-right": {
                        initial: {
                            x: 0
                        },
                        animate: {
                            x: "30%"
                        }
                    },
                    "vinyl-slide-out-top": {
                        initial: {
                            y: 0
                        },
                        animate: {
                            y: "-5"
                        }
                    },
                    "vinyl-slide-out-bottom": {
                        initial: {
                            y: 0
                        },
                        animate: {
                            y: "30%"
                        }
                    }
                },
                lP = {
                    initial: {},
                    animate: {}
                },
                lG = e => {
                    let {
                        slideOutSide: t,
                        coverSize: i,
                        active: l,
                        children: s,
                        className: n
                    } = e, [a, r] = (0, M.useState)(!1), [o, d] = (0, M.useState)(!1), u = lV["vinyl-slide-out-".concat(t)], x = lV["cover-slide-".concat(lU(t))];
                    return (0, lH.Z)(() => {
                        d(l)
                    }, 200, [l]), (0, lH.Z)(() => {
                        r(l)
                    }, 20, [l]), (0, c.jsxs)(P.m.div, {
                        variants: lP,
                        initial: "initial",
                        animate: a ? "animate" : "inital",
                        className: (0, F.Z)(lB().container, a && lB()["is-active"], n),
                        style: {
                            maxWidth: i,
                            maxHeight: i,
                            width: "100%",
                            height: "100%"
                        },
                        children: [(0, c.jsx)(P.m.div, {
                            variants: u,
                            className: (0, F.Z)(lB().vinyl),
                            children: (0, c.jsx)(P.m.div, {
                                animate: {
                                    rotate: o ? 360 : void 0
                                },
                                transition: {
                                    ease: "linear",
                                    duration: 15,
                                    repeat: 1 / 0
                                },
                                children: (0, c.jsx)(lO, {
                                    size: .8 * i,
                                    className: "max-h-full max-w-full"
                                })
                            })
                        }), (0, c.jsx)(P.m.div, {
                            variants: x,
                            className: (0, F.Z)(lB().cover),
                            children: s
                        })]
                    })
                },
                lW = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: t,
                        height: t,
                        fill: "none",
                        viewBox: "0 0 12 12",
                        className: i,
                        children: [(0, c.jsx)("g", {
                            clipPath: "url(#clip0_6138_16346)",
                            children: (0, c.jsx)("path", {
                                fill: "currentColor",
                                fillRule: "evenodd",
                                d: "M11 1A1 1 0 009.757.03l-6 1.5A1 1 0 003 2.5V8a2 2 0 102 2V3.282l4-1v4.22a2 2 0 102 2V1z",
                                clipRule: "evenodd"
                            })
                        }), (0, c.jsx)("defs", {
                            children: (0, c.jsx)("clipPath", {
                                id: "clip0_6138_16346",
                                children: (0, c.jsx)("path", {
                                    fill: "#fff",
                                    d: "M0 0H12V12H0z"
                                })
                            })
                        })]
                    })
                },
                lJ = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: t,
                        height: t,
                        fill: "none",
                        viewBox: "0 0 12 13",
                        className: i,
                        children: [(0, c.jsx)("g", {
                            "clip-path": "url(#clip0_6348_16494)",
                            children: (0, c.jsx)("path", {
                                "fill-rule": "evenodd",
                                "clip-rule": "evenodd",
                                d: "M7.5 2.00195H4.5C3.11929 2.00195 2 3.12124 2 4.50195V8.92799C2.21691 8.76997 2.43861 8.6182 2.66262 8.4772C3.36331 8.03617 4.38893 7.50195 5.5 7.50195H7.5C8.74781 7.50195 10 6.53514 10 4.50195C10 3.12124 8.88071 2.00195 7.5 2.00195ZM4.5 0.00195312C2.01472 0.00195312 0 2.01667 0 4.50195V10.8421C0 11.7655 1.18892 12.2338 1.87408 11.6148C3.02097 10.5786 4.46237 9.50195 5.5 9.50195H7.5C9.98528 9.50195 12 7.50195 12 4.50195C12 2.01667 9.98528 0.00195312 7.5 0.00195312H4.5Z",
                                fill: "#1ED760"
                            })
                        }), (0, c.jsx)("defs", {
                            children: (0, c.jsx)("clipPath", {
                                id: "clip0_6348_16494",
                                children: (0, c.jsx)("rect", {
                                    width: "12",
                                    height: "12",
                                    fill: "white",
                                    transform: "translate(0 0.00195312)"
                                })
                            })
                        })]
                    })
                };
            var lY = i(62874),
                lq = i.n(lY);
            let lK = e => {
                    let {
                        children: t,
                        className: i,
                        playing: l,
                        variant: s = "music"
                    } = e, n = "music" === s ? lW : lJ;
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(i, "z-0", l && lq()["is-playing"]),
                        children: [t, (0, c.jsx)("span", {
                            className: (0, F.Z)(lq()["music-circle"], "absolute inset-0 z-30 h-full w-full rounded-full bg-[#1ED760]/[0.08] transition-transform")
                        }), (0, c.jsx)(n, {
                            size: 12,
                            className: (0, F.Z)(lq()["music-note"], l && lq()["music-note-1"])
                        }), (0, c.jsx)(n, {
                            size: 12,
                            className: (0, F.Z)(lq()["music-note"], l && lq()["music-note-2"])
                        }), (0, c.jsx)(n, {
                            size: 12,
                            className: (0, F.Z)(lq()["music-note"], l && lq()["music-note-3"])
                        })]
                    })
                },
                lX = {
                    height: 215,
                    width: 215
                },
                l$ = e => {
                    var t, i, l, s, n, a, r, o, d, u, x;
                    let {
                        data: h,
                        baseWidgetRef: m
                    } = e, p = (0, eL.$)(), v = (0, _.f6)(h.style, p), [{
                        editing: g
                    }] = (0, j.U)(), {
                        richdata: f,
                        loading: w
                    } = ed(h.href), y = null !== (u = null == f ? void 0 : null === (t = f.data) || void 0 === t ? void 0 : t.name) && void 0 !== u ? u : "Spotify", b = null == f ? void 0 : null === (i = f.data) || void 0 === i ? void 0 : i.artistName, N = (0, M.useMemo)(() => ix(y), [y]), C = (0, ih.J)(null === (l = h.overrides) || void 0 === l ? void 0 : l.title, N) ? y : null !== (x = null === (s = h.overrides) || void 0 === s ? void 0 : s.title) && void 0 !== x ? x : y, k = im(h), E = w || (null == f ? void 0 : f.status) === "FETCHING", S = (0, eM.H)(), {
                        playing: L,
                        toggle: I,
                        pause: D,
                        play: Z
                    } = lM(null == f ? void 0 : null === (n = f.data) || void 0 === n ? void 0 : n.audioSnippet), z = (0, M.useMemo)(() => {
                        switch (v) {
                            case "4x2":
                                return "bottom";
                            case "2x4":
                                return "left";
                            default:
                                return "right"
                        }
                    }, [v]);
                    (0, M.useEffect)(() => {
                        g && "1x4" === v && D()
                    }, [v, g]);
                    let A = (0, c.jsx)("div", {
                            className: "flex h-full w-full items-center justify-center text-black/50",
                            children: (0, c.jsx)(iv.X, {})
                        }),
                        T = (0, c.jsx)(lZ, {
                            togglePlaying: I,
                            playing: L,
                            data: null == f ? void 0 : f.data,
                            className: (0, F.Z)(["2x4", "2x2"].includes(v) && "max-[389px]:!hidden", ["4x2"].includes(v) && "max-[349px]:!hidden")
                        });
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)(lL()["link-widget"], lL()["link-widget--".concat(v)], L && lL()["is-playing"]),
                            children: [(0, c.jsxs)("div", {
                                className: lL().description,
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex items-start", ["4x4", "2x4"].includes(v) && "w-full"),
                                    children: [(0, c.jsxs)("div", {
                                        className: "relative",
                                        children: [(0, c.jsx)(lK, {
                                            playing: L,
                                            className: "absolute inset-0"
                                        }), (0, c.jsx)(tW, {
                                            className: "z-20",
                                            platform: lz.p$,
                                            size: "1x4" === v ? "small" : "medium"
                                        })]
                                    }), ["4x4"].includes(v) && (0, c.jsxs)(c.Fragment, {
                                        children: [(0, c.jsx)(J.L, {}), T]
                                    })]
                                }), (0, c.jsxs)("div", {
                                    className: lL()["link-meta__container"],
                                    children: [g && "mouse" === S && (0, c.jsx)(ia, {
                                        value: null != C ? C : y,
                                        extensions: N,
                                        className: (0, F.Z)(lL().title),
                                        containerClassName: lL()["title-editor"],
                                        clickToActivate: !0,
                                        floating: !0,
                                        onCommit: k
                                    }), (!g || "mouse" !== S) && (0, c.jsx)(ii, {
                                        value: null != C ? C : y,
                                        extensions: N,
                                        className: lL().title
                                    }), "1x4" !== v && (0, c.jsx)("div", {
                                        className: lL().handle,
                                        children: b
                                    })]
                                }), !["4x2", "4x4", "1x4"].includes(v) && T]
                            }), ["4x4", "2x4", "4x2"].includes(v) && (0, c.jsxs)(c.Fragment, {
                                children: ["4x4" === v && (0, c.jsx)(J.L, {}), ((null == f ? void 0 : null === (a = f.data) || void 0 === a ? void 0 : a.thumbnail) || E) && (0, c.jsxs)("div", {
                                    className: (0, F.Z)(lL().cover, "relative"),
                                    children: [(null == f ? void 0 : null === (r = f.data) || void 0 === r ? void 0 : r.thumbnail) && !E && (0, c.jsxs)(lG, {
                                        active: L,
                                        slideOutSide: z,
                                        coverSize: "4x4" === v ? 161 : 127,
                                        className: (0, F.Z)("4x4" !== v && "rounded-[10px]", "4x4" === v && "rounded-[6px]"),
                                        children: [(0, c.jsx)(tV.J, {
                                            src: (0, _.En)(null == f ? void 0 : null === (o = f.data) || void 0 === o ? void 0 : o.thumbnail, {
                                                h: lX.height
                                            }),
                                            srcSet: (0, _.En)(null == f ? void 0 : null === (d = f.data) || void 0 === d ? void 0 : d.thumbnail, {
                                                h: lX.height,
                                                dpr: 2
                                            }),
                                            alt: "",
                                            loading: "lazy",
                                            className: "relative inset-0 h-full w-full rounded-[inherit] border-black/[0.08] object-cover",
                                            fallback: A
                                        }), (0, c.jsx)(X.k, {
                                            className: lL()["phantom-border"]
                                        })]
                                    }, v), E && (0, c.jsx)($.O, {
                                        className: (0, F.Z)("aspect-[3] w-full rounded-[10px]", "2x4" === v && "h-full")
                                    })]
                                })]
                            }), ["4x2"].includes(v) && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), T]
                            })]
                        })
                    })
                };
            var lQ = i(75179),
                l0 = i.n(lQ);
            let l1 = e => {
                let {
                    data: t,
                    className: i
                } = e, l = iz();
                return (0, c.jsxs)("div", {
                    "data-prevent-widget": !0,
                    "data-rich-button": !0,
                    role: "button",
                    className: (0, F.Z)(l0()["follow-button"], "rounded-[5px] border border-black/10 text-center font-bold text-black hover:bg-[#D8F8E4] active:bg-[#ABF0C4]", i),
                    ...l,
                    children: ["Follow", (null == t ? void 0 : t.followers) != null && (0, c.jsxs)(c.Fragment, {
                        children: [" ", (0, c.jsx)("span", {
                            className: "ml-1 font-normal",
                            children: (0, _.d)(t.followers)
                        })]
                    })]
                })
            };
            var l2 = i(40546);
            let l4 = {
                    height: 135,
                    width: 135
                },
                l5 = e => {
                    var t, i, l, s;
                    let {
                        data: n
                    } = e, a = (0, eL.$)(), r = (0, _.f6)(n.style, a), [{
                        editing: o
                    }] = (0, j.U)(), {
                        richdata: d,
                        loading: u
                    } = ed(n.href), x = "Spotify";
                    (0, _.ew)((0, l2.Xv)(n.href), e => (0, _.bl)("@", e));
                    let h = (0, M.useMemo)(() => ix(x), [x]),
                        m = (0, ih.J)(null === (t = n.overrides) || void 0 === t ? void 0 : t.title, h) ? x : null !== (s = null === (i = n.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== s ? s : x,
                        p = u || (null == d ? void 0 : d.status) === "FETCHING",
                        v = im(n),
                        g = (0, eM.H)(),
                        f = (null == d ? void 0 : null === (l = d.data) || void 0 === l ? void 0 : l.playlists) ? (0, _.A1)(d.data.playlists.slice(0, 4), 4).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                            w: l4.width,
                            h: l4.height,
                            fit: "crop"
                        })) : (0, _.A1)([], 4),
                        w = (0, c.jsx)("div", {
                            className: "flex h-full w-full items-center justify-center text-black/50",
                            children: (0, c.jsx)(iv.X, {})
                        });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(l0()["link-widget"], l0()["link-widget--".concat(r)]),
                        children: [(0, c.jsxs)("div", {
                            className: l0().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === r && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: lz.p$,
                                    size: "1x4" === r ? "small" : "medium"
                                }), "4x4" === r && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(l1, {
                                        data: null == d ? void 0 : d.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: l0()["link-meta__container"],
                                children: [o && "mouse" === g && (0, c.jsx)(ia, {
                                    value: null != m ? m : x,
                                    extensions: h,
                                    className: (0, F.Z)(l0().title),
                                    containerClassName: l0()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: v
                                }), (!o || "mouse" !== g) && (0, c.jsx)(ii, {
                                    value: null != m ? m : x,
                                    extensions: h,
                                    className: l0().title
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(r) && (0, c.jsx)(l1, {
                                data: null == d ? void 0 : d.data,
                                className: (0, F.Z)(["2x4", "2x2"].includes(r) && "max-[389px]:!hidden")
                            })]
                        }), "4x4" === r && (0, c.jsx)(J.L, {}), (f.length > 0 || o) && (0, c.jsx)("div", {
                            className: (0, F.Z)(l0()["post-grid"], p && l0()["post-grid--fetching"]),
                            children: f.map(e => p || e ? (0, c.jsxs)("div", {
                                className: "relative",
                                children: [!p && e && (0, c.jsx)(tV.J, {
                                    src: e["1x"],
                                    srcSet: "".concat(e["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    fallback: w,
                                    className: "border-black/[0.08]"
                                }), p && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }) : null)
                        }), "4x2" === r && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(l1, {
                                data: null == d ? void 0 : d.data,
                                className: (0, F.Z)(["4x2"].includes(r) && "max-[349px]:!hidden")
                            })]
                        })]
                    })
                };
            var l9 = i(53406),
                l7 = i.n(l9);
            let l3 = e => {
                    let {
                        data: t,
                        className: i,
                        toggle: l,
                        playing: s
                    } = e, n = iz();
                    return (0, c.jsx)("div", {
                        onClick: e => {
                            e.preventDefault(), e.stopPropagation(), l()
                        },
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(l7()["play-button"], "flex min-w-[86px] items-center justify-center gap-1 rounded-[18px] bg-[#1ED760] px-[10px] py-[7px] text-center text-xs font-bold text-white transition-transform will-change-transform hover:bg-[#1fdf64] active:scale-[0.95] active:bg-[#169c46] active:text-white/80 xs:px-[16px]", i),
                        ...n,
                        children: s ? (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lD, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Pause"
                            })]
                        }) : (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lI, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Play"
                            })]
                        })
                    })
                },
                l6 = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M4 0C2.89543 0 2 0.89543 2 2V16C2 17.1046 2.89543 18 4 18C5.10457 18 6 17.1046 6 16V2C6 0.895431 5.10457 0 4 0ZM14 0C12.8954 0 12 0.89543 12 2V16C12 17.1046 12.8954 18 14 18C15.1046 18 16 17.1046 16 16V2C16 0.895431 15.1046 0 14 0Z",
                            fill: "currentColor"
                        })
                    })
                },
                l8 = {
                    height: 127,
                    width: 127
                },
                se = e => {
                    let t = Math.floor(e / 1e3 % 60).toString().padStart(2, "0");
                    return "".concat(Math.floor(e / 1e3 / 60), ":").concat(t)
                },
                st = e => {
                    var t, i, l, s, n, a, r, o, d, u, x, h, m, p;
                    let {
                        data: v
                    } = e, g = (0, eL.$)(), f = (0, _.f6)(v.style, g), [{
                        editing: w
                    }] = (0, j.U)(), {
                        richdata: y,
                        loading: b
                    } = ed(v.href), N = null !== (m = null == y ? void 0 : null === (t = y.data) || void 0 === t ? void 0 : t.name) && void 0 !== m ? m : "Spotify", C = (0, M.useMemo)(() => ix(N), [N]), k = (0, ih.J)(null === (i = v.overrides) || void 0 === i ? void 0 : i.title, C) ? N : null !== (p = null === (l = v.overrides) || void 0 === l ? void 0 : l.title) && void 0 !== p ? p : N, E = (null == y ? void 0 : null === (s = y.data) || void 0 === s ? void 0 : s.totalSongs) ? "".concat(null == y ? void 0 : null === (n = y.data) || void 0 === n ? void 0 : n.totalSongs, " songs") : null, S = b || (null == y ? void 0 : y.status) === "FETCHING", L = im(v), I = (0, eM.H)(), [D, Z] = (0, M.useState)(void 0), z = iz(), A = null == y ? void 0 : null === (a = y.data) || void 0 === a ? void 0 : null === (r = a.tracks) || void 0 === r ? void 0 : r.slice(0, 4), T = (0, M.useMemo)(() => {
                        var e, t;
                        return null == y ? void 0 : null === (e = y.data) || void 0 === e ? void 0 : null === (t = e.tracks) || void 0 === t ? void 0 : t.slice(0, 4).map(e => e.audioSnippet)
                    }, [null == y ? void 0 : null === (o = y.data) || void 0 === o ? void 0 : o.tracks]), {
                        toggle: O,
                        current: R,
                        play: B,
                        pause: H,
                        playing: U,
                        setCurrent: V
                    } = lT(null != T ? T : [], {
                        autoplay: !0
                    }), G = (0, M.useMemo)(() => {
                        switch (f) {
                            case "4x2":
                                return "bottom";
                            case "2x4":
                                return "left";
                            default:
                                return "right"
                        }
                    }, [f]);
                    (0, M.useEffect)(() => {
                        w && "1x4" === f && H()
                    }, [f, w]);
                    let W = (0, c.jsx)("div", {
                            className: "relative z-30 flex h-full w-full items-center justify-center text-black/50",
                            children: (0, c.jsx)(iv.X, {})
                        }),
                        Y = (0, c.jsx)(l3, {
                            toggle: O,
                            playing: U,
                            data: null == y ? void 0 : y.data,
                            className: (0, F.Z)(["2x4", "2x2"].includes(f) && "max-[389px]:!hidden", ["4x2"].includes(f) && "max-[349px]:!hidden")
                        });
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)(l7()["link-widget"], l7()["link-widget--".concat(f)], U && l7()["is-playing"]),
                            children: [(0, c.jsxs)("div", {
                                className: l7().description,
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex items-start", ["4x4", "2x4"].includes(f) && "w-full"),
                                    children: [(0, c.jsxs)("div", {
                                        className: "relative",
                                        children: [(0, c.jsx)(lK, {
                                            playing: U,
                                            className: "absolute inset-0"
                                        }), (0, c.jsx)(tW, {
                                            className: "z-20",
                                            platform: lz.p$,
                                            size: "1x4" === f ? "small" : "medium"
                                        })]
                                    }), ["4x4"].includes(f) && (0, c.jsxs)(c.Fragment, {
                                        children: [(0, c.jsx)(J.L, {}), Y]
                                    })]
                                }), (0, c.jsxs)("div", {
                                    className: l7()["link-meta__container"],
                                    children: [w && "mouse" === I && (0, c.jsx)(ia, {
                                        value: null != k ? k : N,
                                        extensions: C,
                                        className: (0, F.Z)(l7().title),
                                        containerClassName: l7()["title-editor"],
                                        clickToActivate: !0,
                                        floating: !0,
                                        onCommit: L
                                    }), (!w || "mouse" !== I) && (0, c.jsx)(ii, {
                                        value: null != k ? k : N,
                                        extensions: C,
                                        className: l7().title
                                    }), "1x4" !== f && (0, c.jsx)("div", {
                                        className: l7().handle,
                                        children: E
                                    })]
                                }), !["4x2", "4x4", "1x4"].includes(f) && Y]
                            }), ["2x4", "4x2"].includes(f) && (0, c.jsx)(c.Fragment, {
                                children: ((null == y ? void 0 : null === (d = y.data) || void 0 === d ? void 0 : d.thumbnail) || S) && (0, c.jsxs)("div", {
                                    className: l7().cover,
                                    children: [(null == y ? void 0 : null === (u = y.data) || void 0 === u ? void 0 : u.thumbnail) && !S && (0, c.jsxs)(lG, {
                                        active: U,
                                        slideOutSide: G,
                                        coverSize: "4x4" === f ? 161 : 127,
                                        className: "rounded-[10px]",
                                        children: [(0, c.jsx)(tV.J, {
                                            src: (0, _.En)(null == y ? void 0 : null === (x = y.data) || void 0 === x ? void 0 : x.thumbnail, {
                                                h: l8.height
                                            }),
                                            srcSet: (0, _.En)(null == y ? void 0 : null === (h = y.data) || void 0 === h ? void 0 : h.thumbnail, {
                                                h: l8.height,
                                                dpr: 2
                                            }),
                                            alt: "",
                                            loading: "lazy",
                                            className: "relative inset-0 h-full w-full rounded-[inherit] border-black/[0.08] object-cover",
                                            fallback: W
                                        }), (0, c.jsx)(X.k, {
                                            className: l7()["phantom-border"]
                                        })]
                                    }, f), S && (0, c.jsx)($.O, {
                                        className: (0, F.Z)("h-full w-full rounded-[inherit]")
                                    })]
                                })
                            }), ["4x2"].includes(f) && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), Y]
                            }), ["4x4"].includes(f) && (0, c.jsx)("ul", {
                                className: "flex w-full flex-col",
                                children: null == A ? void 0 : A.map((e, t) => {
                                    var i;
                                    return (0, c.jsx)("li", {
                                        className: (0, F.Z)("group", 2 === t && "hidden min-[340px]:flex", 3 === t && "hidden min-[405px]:flex"),
                                        children: (0, c.jsxs)(P.m.button, {
                                            initial: "initial",
                                            whileHover: "playing",
                                            animate: t === R && U ? "playing" : "initial",
                                            className: (0, F.Z)("group flex w-full flex-row items-center justify-between py-2 transition-transform duration-150 active:scale-[0.995] group-last:pb-0", 1 === t && "max-[339px]:pb-0", 2 === t && "max-[404px]:pb-0"),
                                            onClick: e => {
                                                e.preventDefault(), e.stopPropagation(), t === R ? O() : B(), V(t)
                                            },
                                            ...z,
                                            children: [(0, c.jsxs)("div", {
                                                className: "flex flex-row items-center",
                                                children: [(0, c.jsxs)(P.m.div, {
                                                    layout: !0,
                                                    className: (0, F.Z)("relative h-[40px] w-[40px] flex-none transition-all group-hover:rounded-full"),
                                                    children: [(0, c.jsx)("div", {
                                                        className: (0, F.Z)("absolute inset-0 z-20 flex h-full w-full appearance-none items-center justify-center rounded-full bg-[#1ED760] transition-all duration-150 ease-in hover:bg-[#12CE55] active:bg-[#07BB47] group-hover:flex group-hover:opacity-100", t === R && U ? "flex" : "hidden"),
                                                        children: t === R && U ? (0, c.jsx)(l6, {
                                                            size: 12,
                                                            className: "text-white"
                                                        }) : (0, c.jsx)(lI, {
                                                            size: 12,
                                                            className: "text-white"
                                                        })
                                                    }), (0, c.jsxs)("div", {
                                                        className: "relative rounded-[6px]",
                                                        children: [(0, c.jsx)(tV.J, {
                                                            src: (0, _.En)(e.thumbnail, {
                                                                h: 40,
                                                                w: 40
                                                            }),
                                                            srcSet: (0, _.En)(e.thumbnail, {
                                                                h: 40,
                                                                w: 40,
                                                                dpr: 2
                                                            }),
                                                            alt: "",
                                                            loading: "lazy",
                                                            className: (0, F.Z)("z-10 h-full w-full rounded-[inherit] border-black/[0.08] object-cover transition-all ease-in group-hover:hidden", t === R && U && "hidden"),
                                                            fallback: W
                                                        }), (0, c.jsx)(X.k, {})]
                                                    })]
                                                }), (0, c.jsxs)("div", {
                                                    className: "mx-3 flex flex-col text-left",
                                                    children: [(0, c.jsx)("div", {
                                                        className: "text-sm line-clamp-1",
                                                        children: e.title
                                                    }), (0, c.jsx)("div", {
                                                        className: "text-xs text-black/60 line-clamp-1",
                                                        children: null === (i = e.artists) || void 0 === i ? void 0 : i.join(", ")
                                                    })]
                                                })]
                                            }), (0, c.jsx)("div", {
                                                className: "w-fit flex-none text-sm tabular-nums text-black/40",
                                                children: e.duration ? se(e.duration) : ""
                                            })]
                                        })
                                    }, "track-".concat(t))
                                })
                            })]
                        })
                    })
                };
            var si = i(72431),
                sl = i.n(si);
            let ss = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: t,
                        height: t,
                        className: i,
                        fill: "none",
                        viewBox: "0 0 14 15",
                        children: [(0, c.jsx)("g", {
                            clipPath: "url(#clip0_6236_16116)",
                            children: (0, c.jsx)("path", {
                                fill: "#fff",
                                fillRule: "evenodd",
                                d: "M4.668 10.733V5.688a.5.5 0 01.181-.385l3.556-2.936a.5.5 0 00.144-.193L9.1.849A.5.5 0 019.84.625l.272.182a.5.5 0 01.222.416v1.475c0 .06-.01.12-.031.175l-.969 2.58h3.834a.5.5 0 01.3.1l.333.25a.5.5 0 01.2.4v3.534a.5.5 0 01-.156.364l-2.7 2.549a.5.5 0 01-.343.136h-3.94a.5.5 0 01-.338-.131L4.83 11.102a.5.5 0 01-.162-.369zm-4.64 1.565l-.055-6.333a.5.5 0 01.495-.504l1.834-.016a.5.5 0 01.504.495l.055 6.334a.5.5 0 01-.495.504l-1.834.016a.5.5 0 01-.504-.496z",
                                clipRule: "evenodd"
                            })
                        }), (0, c.jsx)("defs", {
                            children: (0, c.jsx)("clipPath", {
                                id: "clip0_6236_16116",
                                children: (0, c.jsx)("path", {
                                    fill: "#fff",
                                    d: "M0 0H14V14H0z",
                                    transform: "translate(0 .5)"
                                })
                            })
                        })]
                    })
                },
                sn = e => {
                    let {
                        data: t
                    } = e, i = iz();
                    return (0, c.jsxs)("div", {
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(sl()["follow-button"], "flex items-center rounded-[18px] bg-[#2F65EE] text-center font-bold text-white hover:bg-[#003ecb] focus-visible:bg-[#003ecb] active:bg-[#002f9a] active:text-white/80"),
                        ...i,
                        children: [(0, c.jsx)(ss, {
                            size: 14,
                            className: "inline-block"
                        }), (null == t ? void 0 : t.likes) != null && (0, c.jsxs)(c.Fragment, {
                            children: [" ", (0, c.jsx)("span", {
                                className: "ml-1 font-normal text-white/80",
                                children: (0, _.d)(null == t ? void 0 : t.likes)
                            })]
                        })]
                    })
                },
                sa = {
                    height: 217,
                    width: 342
                },
                sr = e => {
                    var t, i, l, s, n, a, r, o, d;
                    let {
                        data: u
                    } = e, x = (0, eL.$)(), h = (0, _.f6)(u.style, x), [{
                        editing: m
                    }] = (0, j.U)(), {
                        richdata: p,
                        loading: v
                    } = ed(u.href), g = null !== (o = null == p ? void 0 : null === (t = p.data) || void 0 === t ? void 0 : t.title) && void 0 !== o ? o : "Behance", f = (0, M.useMemo)(() => ix(g), [g]), w = (0, ih.J)(null === (i = u.overrides) || void 0 === i ? void 0 : i.title, f) ? g : null !== (d = null === (l = u.overrides) || void 0 === l ? void 0 : l.title) && void 0 !== d ? d : g, y = (0, _.ew)(null == p ? void 0 : null === (s = p.data) || void 0 === s ? void 0 : s.username, e => (0, _.bl)("@", e)), b = v || (null == p ? void 0 : p.status) === "FETCHING", N = im(u), C = (0, eM.H)(), k = (null == p ? void 0 : null === (n = p.data) || void 0 === n ? void 0 : n.thumbnail) ? {
                        "1x": (0, _.En)(null == p ? void 0 : null === (a = p.data) || void 0 === a ? void 0 : a.thumbnail, {
                            w: sa.width,
                            h: sa.height,
                            fit: "crop"
                        }),
                        "2x": (0, _.En)(null == p ? void 0 : null === (r = p.data) || void 0 === r ? void 0 : r.thumbnail, {
                            w: sa.width,
                            h: sa.height,
                            dpr: 2,
                            fit: "crop"
                        })
                    } : void 0, E = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(sl()["link-widget"], sl()["link-widget--".concat(h)]),
                        children: [(0, c.jsxs)("div", {
                            className: sl().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === h && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: ll.GF,
                                    size: "1x4" === h ? "small" : "medium"
                                }), "4x4" === h && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(sn, {
                                        data: null == p ? void 0 : p.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: sl()["link-meta__container"],
                                children: [m && "mouse" === C && (0, c.jsx)(ia, {
                                    value: null != w ? w : g,
                                    extensions: f,
                                    className: (0, F.Z)(sl().title),
                                    containerClassName: sl()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: N
                                }), (!m || "mouse" !== C) && (0, c.jsx)(ii, {
                                    value: null != w ? w : g,
                                    extensions: f,
                                    className: sl().title
                                }), "1x4" !== h && (0, c.jsx)("div", {
                                    className: sl().handle,
                                    children: y
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(h) && (0, c.jsx)(sn, {
                                data: null == p ? void 0 : p.data
                            })]
                        }), "4x4" === h && (0, c.jsx)(J.L, {}), (k || m) && (0, c.jsxs)("div", {
                            className: (0, F.Z)(sl().cover, b && sl()["cover--fetching"]),
                            children: [!b && (0, c.jsx)(tV.J, {
                                src: null == k ? void 0 : k["1x"],
                                srcSet: "".concat(null == k ? void 0 : k["2x"], " 2x"),
                                alt: "",
                                loading: "lazy",
                                className: "z-20 h-full w-full rounded-[inherit] object-cover",
                                fallback: E
                            }), b && (0, c.jsx)($.O, {
                                className: "h-full w-full rounded-[inherit]"
                            }), (0, c.jsx)(X.k, {})]
                        }), "4x2" === h && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(sn, {
                                data: null == p ? void 0 : p.data
                            })]
                        })]
                    })
                };
            var so = i(40674),
                sd = i.n(so);
            let sc = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        xmlns: "http://www.w3.org/2000/svg",
                        className: i,
                        fill: "none",
                        viewBox: "-2 0 16 13",
                        children: (0, c.jsx)("path", {
                            stroke: "currentColor",
                            strokeWidth: 1.5,
                            d: "M0 5.19C-.014 8.857 6.5 12 6.5 12S13 8.857 13 5.19C13 1.524 10.5 1 9.5 1c-1.776 0-3 1.571-3 1.571S5.381 1 3.5 1c-1 0-3.486.524-3.5 4.19z"
                        })
                    })
                },
                su = e => {
                    let {
                        data: t
                    } = e, i = iz();
                    return (0, c.jsxs)("div", {
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(sd()["follow-button"], "flex items-center justify-center gap-1.5 rounded-full border-[1px] border-[#e7e7e9] bg-white text-center font-bold text-black hover:bg-[#FFFAFE] focus-visible:bg-[#FFFAFE] active:bg-[#FFF4FC] active:text-black"),
                        ...i,
                        children: [(0, c.jsx)(sc, {
                            size: 12
                        }), (0, c.jsx)("span", {
                            children: "Like"
                        })]
                    })
                },
                sx = {
                    height: 217,
                    width: 342
                },
                sh = e => {
                    var t, i, l, s, n, a, r, o;
                    let {
                        data: d
                    } = e, u = (0, eL.$)(), x = (0, _.f6)(d.style, u), [{
                        editing: h
                    }] = (0, j.U)(), {
                        richdata: m,
                        loading: p
                    } = ed(d.href), v = null !== (r = null == m ? void 0 : null === (t = m.data) || void 0 === t ? void 0 : t.title) && void 0 !== r ? r : "Dribbble", g = (0, M.useMemo)(() => ix(v), [v]), f = (0, ih.J)(null === (i = d.overrides) || void 0 === i ? void 0 : i.title, g) ? v : null !== (o = null === (l = d.overrides) || void 0 === l ? void 0 : l.title) && void 0 !== o ? o : v, w = p || (null == m ? void 0 : m.status) === "FETCHING", y = im(d), b = (0, eM.H)(), N = (null == m ? void 0 : null === (s = m.data) || void 0 === s ? void 0 : s.thumbnail) ? {
                        "1x": (0, _.En)(null == m ? void 0 : null === (n = m.data) || void 0 === n ? void 0 : n.thumbnail, {
                            w: sx.width,
                            h: sx.height,
                            fit: "crop"
                        }),
                        "2x": (0, _.En)(null == m ? void 0 : null === (a = m.data) || void 0 === a ? void 0 : a.thumbnail, {
                            w: sx.width,
                            h: sx.height,
                            dpr: 2,
                            fit: "crop"
                        })
                    } : void 0, C = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(sd()["link-widget"], sd()["link-widget--".concat(x)]),
                        children: [(0, c.jsxs)("div", {
                            className: sd().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === x && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: i7.zK,
                                    size: "1x4" === x ? "small" : "medium"
                                }), "4x4" === x && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(su, {
                                        data: null == m ? void 0 : m.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: sd()["link-meta__container"],
                                children: [h && "mouse" === b && (0, c.jsx)(ia, {
                                    value: null != f ? f : v,
                                    extensions: g,
                                    className: (0, F.Z)(sd().title),
                                    containerClassName: sd()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: y
                                }), (!h || "mouse" !== b) && (0, c.jsx)(ii, {
                                    value: null != f ? f : v,
                                    extensions: g,
                                    className: sd().title
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(x) && (0, c.jsx)(su, {
                                data: null == m ? void 0 : m.data
                            })]
                        }), "4x4" === x && (0, c.jsx)(J.L, {}), (N || h) && (0, c.jsxs)("div", {
                            className: (0, F.Z)(sd().cover, w && sd()["cover--fetching"]),
                            children: [!w && (0, c.jsx)(tV.J, {
                                src: null == N ? void 0 : N["1x"],
                                srcSet: "".concat(null == N ? void 0 : N["2x"], " 2x"),
                                alt: "",
                                loading: "lazy",
                                className: "h-full w-full rounded-[inherit] object-cover",
                                fallback: C
                            }), w && (0, c.jsx)($.O, {
                                className: "h-full w-full rounded-[inherit]"
                            }), (0, c.jsx)(X.k, {})]
                        }), "4x2" === x && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(su, {
                                data: null == m ? void 0 : m.data
                            })]
                        })]
                    })
                };
            var sm = i(72625),
                sp = i.n(sm);
            let sv = e => {
                    let {
                        data: t,
                        className: i,
                        playing: l,
                        toggle: s
                    } = e, n = iz();
                    return (0, c.jsx)("div", {
                        onClick: e => {
                            e.preventDefault(), e.stopPropagation(), s()
                        },
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(sp()["play-button"], "flex min-w-[86px] items-center justify-center gap-1 rounded-[18px] bg-[#1ED760] px-[10px] py-[7px] text-center text-xs font-bold text-white transition-transform will-change-transform hover:bg-[#1fdf64] active:scale-[0.95] active:bg-[#169c46] active:text-white/80 xs:px-[16px]", i),
                        ...n,
                        children: l ? (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lD, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Pause"
                            })]
                        }) : (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lI, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Play"
                            })]
                        })
                    })
                },
                sg = {
                    height: 127,
                    width: 127
                },
                sf = e => {
                    let t = Math.floor(e / 1e3 / 60 / 60),
                        i = Math.floor(e / 1e3 / 60);
                    return (Math.floor(e / 1e3 % 60).toString().padStart(2, "0"), t > 0) ? "".concat(t, "h ").concat(i, "min") : "".concat(i, "min")
                },
                s_ = e => {
                    var t, i, l, s, n, a, r, o, d, u, x, h, m, p;
                    let {
                        data: v
                    } = e, g = (0, eL.$)(), f = (0, _.f6)(v.style, g), [{
                        editing: w
                    }] = (0, j.U)(), {
                        richdata: y,
                        loading: b
                    } = ed(v.href), N = null !== (m = null == y ? void 0 : y.data.name) && void 0 !== m ? m : "Spotify", C = (0, M.useMemo)(() => ix(N), [N]), k = (0, ih.J)(null === (t = v.overrides) || void 0 === t ? void 0 : t.title, C) ? N : null !== (p = null === (i = v.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== p ? p : N, E = null == y ? void 0 : null === (l = y.data) || void 0 === l ? void 0 : l.publisher, S = b || (null == y ? void 0 : y.status) === "FETCHING", L = im(v), I = (0, eM.H)(), D = iz(), Z = (0, M.useMemo)(() => {
                        var e, t;
                        return null == y ? void 0 : null === (e = y.data) || void 0 === e ? void 0 : null === (t = e.episodes) || void 0 === t ? void 0 : t.map(e => e.audioSnippet)
                    }, [null == y ? void 0 : null === (s = y.data) || void 0 === s ? void 0 : s.episodes]), {
                        toggle: z,
                        current: A,
                        play: T,
                        pause: O,
                        playing: R,
                        setCurrent: B
                    } = lT(null != Z ? Z : [], {
                        autoplay: !0
                    }), H = (0, M.useMemo)(() => {
                        switch (f) {
                            case "4x2":
                                return "bottom";
                            case "2x4":
                                return "left";
                            default:
                                return "right"
                        }
                    }, [f]);
                    (0, M.useEffect)(() => {
                        w && "1x4" === f && O()
                    }, [f, w]);
                    let U = (0, c.jsx)("div", {
                            className: "relative z-30 flex h-full w-full items-center justify-center text-black/50",
                            children: (0, c.jsx)(iv.X, {})
                        }),
                        V = (0, c.jsx)(sv, {
                            toggle: z,
                            playing: R,
                            data: null == y ? void 0 : y.data,
                            className: (0, F.Z)(["2x4", "2x2"].includes(f) && "max-[389px]:!hidden", ["4x2"].includes(f) && "max-[349px]:!hidden")
                        }),
                        G = (0, c.jsxs)("div", {
                            className: (0, F.Z)(sp()["link-meta__container"], "4x4" === f && "w-full"),
                            children: [w && "mouse" === I && (0, c.jsx)(ia, {
                                value: null != k ? k : N,
                                extensions: C,
                                className: (0, F.Z)(sp().title),
                                containerClassName: sp()["title-editor"],
                                clickToActivate: !0,
                                floating: !0,
                                onCommit: L
                            }), (!w || "mouse" !== I) && (0, c.jsx)(ii, {
                                value: null != k ? k : N,
                                extensions: C,
                                className: sp().title
                            }), "1x4" !== f && (0, c.jsx)("div", {
                                className: sp().handle,
                                children: E
                            })]
                        });
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)(sp()["link-widget"], sp()["link-widget--".concat(f)], R && sp()["is-playing"]),
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)(sp().description),
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex items-start", ["4x4", "2x4"].includes(f) && "w-full", "4x4" === f && "gap-3"),
                                    children: [(0, c.jsx)("div", {
                                        className: "relative",
                                        children: "4x4" === f ? (0, c.jsx)(c.Fragment, {
                                            children: (0, c.jsxs)("div", {
                                                className: "relative z-20 ml-2 mt-2 h-[88px] w-[88px] rounded-[10px]",
                                                children: [(0, c.jsx)(tV.J, {
                                                    src: (0, _.En)(null == y ? void 0 : null === (n = y.data) || void 0 === n ? void 0 : n.thumbnail, {
                                                        h: sg.height
                                                    }),
                                                    srcSet: (0, _.En)(null == y ? void 0 : null === (a = y.data) || void 0 === a ? void 0 : a.thumbnail, {
                                                        h: sg.height,
                                                        dpr: 2
                                                    }),
                                                    alt: "",
                                                    loading: "lazy",
                                                    className: "h-full w-full rounded-[inherit] border-black/[0.08] object-cover",
                                                    fallback: U
                                                }), (0, c.jsx)(X.k, {}), (0, c.jsx)(lK, {
                                                    playing: R,
                                                    className: sp()["favicon-wrapper"],
                                                    variant: "speech",
                                                    children: (0, c.jsx)(tW, {
                                                        className: "z-40",
                                                        platform: lz.p$,
                                                        size: "medium"
                                                    })
                                                })]
                                            })
                                        }) : (0, c.jsxs)(c.Fragment, {
                                            children: [(0, c.jsx)(lK, {
                                                playing: R,
                                                className: "absolute inset-0",
                                                variant: "speech"
                                            }), (0, c.jsx)(tW, {
                                                className: "z-40",
                                                platform: lz.p$,
                                                size: "1x4" === f ? "small" : "medium"
                                            })]
                                        })
                                    }), (0, c.jsxs)("div", {
                                        className: "flex h-full flex-grow flex-col items-end justify-between",
                                        children: [
                                            ["4x4"].includes(f) && (0, c.jsx)("div", {
                                                className: "w-fit",
                                                children: V
                                            }), "4x4" === f && G
                                        ]
                                    })]
                                }), "4x4" !== f && G, !["4x2", "4x4", "1x4"].includes(f) && V]
                            }), ["2x4", "4x2"].includes(f) && (0, c.jsx)(c.Fragment, {
                                children: ((null == y ? void 0 : null === (r = y.data) || void 0 === r ? void 0 : r.thumbnail) || S) && (0, c.jsxs)("div", {
                                    className: sp().cover,
                                    children: [(null == y ? void 0 : null === (o = y.data) || void 0 === o ? void 0 : o.thumbnail) && !S && (0, c.jsxs)(lG, {
                                        active: !1,
                                        slideOutSide: H,
                                        coverSize: "4x4" === f ? 161 : 127,
                                        className: "rounded-[10px]",
                                        children: [(0, c.jsx)(tV.J, {
                                            src: (0, _.En)(null == y ? void 0 : null === (d = y.data) || void 0 === d ? void 0 : d.thumbnail, {
                                                h: sg.height
                                            }),
                                            srcSet: (0, _.En)(null == y ? void 0 : null === (u = y.data) || void 0 === u ? void 0 : u.thumbnail, {
                                                h: sg.height,
                                                dpr: 2
                                            }),
                                            alt: "",
                                            loading: "lazy",
                                            className: "relative inset-0 h-full w-full rounded-[inherit] border-black/[0.08] object-cover",
                                            fallback: U
                                        }), (0, c.jsx)(X.k, {
                                            className: sp()["phantom-border"]
                                        })]
                                    }, f), S && (0, c.jsx)($.O, {
                                        className: (0, F.Z)("h-full w-full rounded-[inherit]")
                                    })]
                                })
                            }), ["4x2"].includes(f) && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), V]
                            }), ["4x4"].includes(f) && (0, c.jsx)("ul", {
                                className: "grid w-full grid-cols-2 gap-4 ",
                                children: null == y ? void 0 : null === (x = y.data) || void 0 === x ? void 0 : null === (h = x.episodes) || void 0 === h ? void 0 : h.slice(0, 2).map((e, t) => (0, c.jsx)("li", {
                                    children: (0, c.jsxs)("div", {
                                        className: "flex h-full w-full flex-col items-start justify-between rounded-xl border-[1px] border-black/[0.1] bg-white p-4 text-left shadow-[0px_2px_3px_rgba(0,0,0,0.03)] max-[360px]:py-3 max-[349px]:py-2",
                                        children: [(0, c.jsx)(P.m.button, {
                                            initial: "initial",
                                            whileHover: "playing",
                                            animate: t === A && R ? "playing" : "initial",
                                            onClick: e => {
                                                e.preventDefault(), e.stopPropagation(), t === A ? z() : (B(t), T())
                                            },
                                            className: (0, F.Z)("-ml-0.5 flex h-[32px] w-[32px] items-center justify-center rounded-full bg-[#1ED760] transition-all duration-150 ease-in hover:flex hover:bg-[#12CE55] hover:opacity-100 active:scale-[0.95] active:bg-[#07BB47] max-[369px]:hidden"),
                                            ...D,
                                            children: t === A && R ? (0, c.jsx)(l6, {
                                                size: 12,
                                                className: "text-white"
                                            }) : (0, c.jsx)(lI, {
                                                size: 12,
                                                className: "text-white"
                                            })
                                        }), (0, c.jsx)("div", {
                                            className: "mt-3 mb-5 flex-1 text-sm line-clamp-3 min-[410px]:line-clamp-4 min-[420px]:line-clamp-5",
                                            children: e.title
                                        }), (0, c.jsx)("div", {
                                            className: "flex flex-row gap-3 text-xs text-black/60",
                                            children: (0, c.jsxs)("span", {
                                                children: [eo()(e.date).format("MMM D"), (0, c.jsxs)("span", {
                                                    className: "max-[349px]:hidden",
                                                    children: [" ", "\xb7 ", e.duration ? sf(e.duration) : ""]
                                                })]
                                            })
                                        })]
                                    })
                                }, "episode-".concat(t)))
                            })]
                        })
                    })
                };
            var sj = i(69090),
                sw = i.n(sj);
            let sy = e => {
                    let {
                        data: t,
                        className: i,
                        playing: l,
                        togglePlaying: s
                    } = e, n = iz();
                    return (0, c.jsx)("div", {
                        onClick: e => {
                            e.preventDefault(), e.stopPropagation(), s()
                        },
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(sw()["play-button"], "flex min-w-[86px] items-center justify-center gap-1  rounded-[18px] bg-[#1ED760] px-[10px] py-[7px] text-center text-xs font-bold text-white transition-transform will-change-transform hover:bg-[#1fdf64] active:scale-[0.95] active:bg-[#169c46] active:text-white/80 xs:px-[16px]", i),
                        ...n,
                        children: l ? (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lD, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Pause"
                            })]
                        }) : (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lI, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Play"
                            })]
                        })
                    })
                },
                sb = {
                    height: 215,
                    width: 215
                },
                sN = e => {
                    var t, i, l, s, n, a, r, o, d, u, x;
                    let {
                        data: h
                    } = e, m = (0, eL.$)(), p = (0, _.f6)(h.style, m), [{
                        editing: v
                    }] = (0, j.U)(), {
                        richdata: g,
                        loading: f
                    } = ed(h.href), w = null !== (u = null == g ? void 0 : null === (t = g.data) || void 0 === t ? void 0 : t.title) && void 0 !== u ? u : "Spotify", y = null == g ? void 0 : null === (i = g.data) || void 0 === i ? void 0 : i.showName, b = (0, M.useMemo)(() => ix(w), [w]), N = (0, ih.J)(null === (l = h.overrides) || void 0 === l ? void 0 : l.title, b) ? w : null !== (x = null === (s = h.overrides) || void 0 === s ? void 0 : s.title) && void 0 !== x ? x : w, C = f || (null == g ? void 0 : g.status) === "FETCHING", k = im(h), E = (0, eM.H)(), {
                        playing: S,
                        toggle: L,
                        pause: I,
                        play: D
                    } = lM(null == g ? void 0 : null === (n = g.data) || void 0 === n ? void 0 : n.audioSnippet), Z = (0, M.useMemo)(() => {
                        switch (p) {
                            case "4x2":
                                return "bottom";
                            case "2x4":
                                return "left";
                            default:
                                return "right"
                        }
                    }, [p]);
                    (0, M.useEffect)(() => {
                        v && "1x4" === p && I()
                    }, [p, v]);
                    let z = (0, c.jsx)("div", {
                            className: "flex h-full w-full items-center justify-center text-black/50",
                            children: (0, c.jsx)(iv.X, {})
                        }),
                        A = (0, c.jsx)(sy, {
                            togglePlaying: L,
                            playing: S,
                            data: null == g ? void 0 : g.data,
                            className: (0, F.Z)(["2x4", "2x2"].includes(p) && "max-[389px]:!hidden", ["4x2"].includes(p) && "max-[349px]:!hidden")
                        });
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)(sw()["link-widget"], sw()["link-widget--".concat(p)], S && sw()["is-playing"]),
                            children: [(0, c.jsxs)("div", {
                                className: sw().description,
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex items-start", ["4x4", "2x4"].includes(p) && "w-full"),
                                    children: [(0, c.jsxs)("div", {
                                        className: "relative",
                                        children: [(0, c.jsx)(lK, {
                                            playing: S,
                                            className: "absolute inset-0",
                                            variant: "speech"
                                        }), (0, c.jsx)(tW, {
                                            className: "z-20",
                                            platform: lz.p$,
                                            size: "1x4" === p ? "small" : "medium"
                                        })]
                                    }), ["4x4"].includes(p) && (0, c.jsxs)(c.Fragment, {
                                        children: [(0, c.jsx)(J.L, {}), A]
                                    })]
                                }), (0, c.jsxs)("div", {
                                    className: sw()["link-meta__container"],
                                    children: [v && "mouse" === E && (0, c.jsx)(ia, {
                                        value: null != N ? N : w,
                                        extensions: b,
                                        className: (0, F.Z)(sw().title),
                                        containerClassName: sw()["title-editor"],
                                        clickToActivate: !0,
                                        floating: !0,
                                        onCommit: k
                                    }), (!v || "mouse" !== E) && (0, c.jsx)(ii, {
                                        value: null != N ? N : w,
                                        extensions: b,
                                        className: sw().title
                                    }), "1x4" !== p && (0, c.jsx)("div", {
                                        className: sw().handle,
                                        children: y
                                    })]
                                }), !["4x2", "4x4", "1x4"].includes(p) && A]
                            }), ["4x4", "2x4", "4x2"].includes(p) && (0, c.jsxs)(c.Fragment, {
                                children: ["4x4" === p && (0, c.jsx)(J.L, {}), ((null == g ? void 0 : null === (a = g.data) || void 0 === a ? void 0 : a.thumbnail) || C) && (0, c.jsxs)("div", {
                                    className: (0, F.Z)(sw().cover, "relative"),
                                    children: [(null == g ? void 0 : null === (r = g.data) || void 0 === r ? void 0 : r.thumbnail) && !C && (0, c.jsxs)(lG, {
                                        active: !1,
                                        slideOutSide: Z,
                                        coverSize: "4x4" === p ? 161 : 127,
                                        className: "rounded-[10px]",
                                        children: [(0, c.jsx)(tV.J, {
                                            src: (0, _.En)(null == g ? void 0 : null === (o = g.data) || void 0 === o ? void 0 : o.thumbnail, {
                                                h: sb.height
                                            }),
                                            srcSet: (0, _.En)(null == g ? void 0 : null === (d = g.data) || void 0 === d ? void 0 : d.thumbnail, {
                                                h: sb.height,
                                                dpr: 2
                                            }),
                                            alt: "",
                                            loading: "lazy",
                                            className: "relative inset-0 h-full w-full rounded-[inherit] border-black/[0.08] object-cover",
                                            fallback: z
                                        }), (0, c.jsx)(X.k, {
                                            className: sw()["phantom-border"]
                                        })]
                                    }, p), C && (0, c.jsx)($.O, {
                                        className: "aspect-[3] w-full rounded-[10px]"
                                    })]
                                })]
                            }), ["4x2"].includes(p) && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), A]
                            })]
                        })
                    })
                };
            var sC = i(26781),
                sk = i.n(sC);
            let sE = e => {
                    let {
                        data: t,
                        className: i,
                        playing: l,
                        toggle: s
                    } = e, n = iz();
                    return (0, c.jsx)("div", {
                        onClick: e => {
                            e.preventDefault(), e.stopPropagation(), s()
                        },
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(sk()["play-button"], "flex min-w-[86px] items-center justify-center gap-1 rounded-[18px] bg-[#1ED760] px-[10px] py-[7px] text-center text-xs font-bold text-white transition-transform will-change-transform hover:bg-[#1fdf64] active:scale-[0.95] active:bg-[#169c46] active:text-white/80 xs:px-[16px]", i),
                        ...n,
                        children: l ? (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lD, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Pause"
                            })]
                        }) : (0, c.jsxs)("span", {
                            className: "flex flex-row items-center gap-1.5",
                            children: [(0, c.jsx)(lI, {
                                size: 12,
                                className: "inline text-white"
                            }), (0, c.jsx)("span", {
                                children: "Play"
                            })]
                        })
                    })
                },
                sS = e => {
                    let {} = e;
                    return (0, c.jsx)("svg", {
                        width: "16",
                        height: "17",
                        viewBox: "0 0 16 17",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            d: "M1 12.7338V4.26619C1 3.4889 1.84797 3.00878 2.5145 3.4087L9.57084 7.64251C10.2182 8.03091 10.2182 8.96909 9.57084 9.35749L2.5145 13.5913C1.84797 13.9912 1 13.5111 1 12.7338Z",
                            fill: "#1ED760"
                        })
                    })
                },
                sL = e => {
                    let {} = e;
                    return (0, c.jsxs)("svg", {
                        width: "16",
                        height: "17",
                        viewBox: "0 0 16 17",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "1",
                            y: "3",
                            width: "3",
                            height: "12",
                            rx: "1",
                            fill: "#1ED760"
                        }), (0, c.jsx)("rect", {
                            x: "8",
                            y: "3",
                            width: "3",
                            height: "12",
                            rx: "1",
                            fill: "#1ED760"
                        })]
                    })
                },
                sI = {
                    height: 127,
                    width: 127
                },
                sD = e => {
                    let t = Math.floor(e / 1e3 % 60).toString().padStart(2, "0");
                    return "".concat(Math.floor(e / 1e3 / 60), ":").concat(t)
                },
                sZ = e => {
                    var t, i, l, s, n, a, r, o, d, u, x, h, m, p;
                    let {
                        data: v
                    } = e, g = (0, eL.$)(), f = (0, _.f6)(v.style, g), [w, y] = (0, M.useState)(-1), [{
                        editing: b
                    }] = (0, j.U)(), {
                        richdata: N,
                        loading: C
                    } = ed(v.href), k = null !== (m = null == N ? void 0 : N.data.name) && void 0 !== m ? m : "Spotify", E = (0, M.useMemo)(() => ix(k), [k]), S = (0, ih.J)(null === (t = v.overrides) || void 0 === t ? void 0 : t.title, E) ? k : null !== (p = null === (i = v.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== p ? p : k, L = null == N ? void 0 : null === (l = N.data) || void 0 === l ? void 0 : l.artistName, I = C || (null == N ? void 0 : N.status) === "FETCHING", D = im(v), Z = (0, eM.H)(), z = iz(), A = (0, M.useMemo)(() => {
                        var e, t;
                        return null == N ? void 0 : null === (e = N.data) || void 0 === e ? void 0 : null === (t = e.tracks) || void 0 === t ? void 0 : t.map(e => e.audioSnippet)
                    }, [null == N ? void 0 : null === (s = N.data) || void 0 === s ? void 0 : s.tracks]), {
                        toggle: T,
                        current: O,
                        play: R,
                        pause: B,
                        playing: H,
                        setCurrent: U
                    } = lT(null != A ? A : [], {
                        autoplay: !0
                    }), V = (0, M.useMemo)(() => {
                        switch (f) {
                            case "4x2":
                                return "bottom";
                            case "2x4":
                                return "left";
                            default:
                                return "right"
                        }
                    }, [f]);
                    (0, M.useEffect)(() => {
                        b && "1x4" === f && B()
                    }, [f, b]);
                    let G = (0, c.jsx)("div", {
                            className: "relative z-30 flex h-full w-full items-center justify-center text-black/50",
                            children: (0, c.jsx)(iv.X, {})
                        }),
                        W = (0, c.jsx)(sE, {
                            toggle: T,
                            playing: H,
                            data: null == N ? void 0 : N.data,
                            className: (0, F.Z)(["2x4", "2x2"].includes(f) && "max-[389px]:!hidden", ["4x2"].includes(f) && "max-[349px]:!hidden")
                        }),
                        Y = (0, c.jsxs)("div", {
                            className: (0, F.Z)(sk()["link-meta__container"], "4x4" === f && "w-full"),
                            children: [b && "mouse" === Z && (0, c.jsx)(ia, {
                                value: null != S ? S : k,
                                extensions: E,
                                className: (0, F.Z)(sk().title),
                                containerClassName: sk()["title-editor"],
                                clickToActivate: !0,
                                floating: !0,
                                onCommit: D
                            }), (!b || "mouse" !== Z) && (0, c.jsx)(ii, {
                                value: null != S ? S : k,
                                extensions: E,
                                className: sk().title
                            }), "1x4" !== f && (0, c.jsx)("div", {
                                className: sk().handle,
                                children: L
                            })]
                        });
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)(sk()["link-widget"], sk()["link-widget--".concat(f)], H && sk()["is-playing"]),
                            children: [(0, c.jsxs)("div", {
                                className: sk().description,
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex items-start", ["4x4", "2x4"].includes(f) && "w-full", "4x4" === f && "gap-3"),
                                    children: [(0, c.jsx)("div", {
                                        className: "relative",
                                        children: "4x4" === f ? (0, c.jsx)(c.Fragment, {
                                            children: (0, c.jsxs)("div", {
                                                className: "relative z-20 mt-2 ml-2 h-[88px] w-[88px] rounded-[10px]",
                                                children: [(0, c.jsx)(tV.J, {
                                                    src: (0, _.En)(null == N ? void 0 : null === (n = N.data) || void 0 === n ? void 0 : n.thumbnail, {
                                                        h: sI.height
                                                    }),
                                                    srcSet: (0, _.En)(null == N ? void 0 : null === (a = N.data) || void 0 === a ? void 0 : a.thumbnail, {
                                                        h: sI.height,
                                                        dpr: 2
                                                    }),
                                                    alt: "",
                                                    loading: "lazy",
                                                    className: "h-full w-full rounded-[inherit] border-black/[0.08] object-cover",
                                                    fallback: G
                                                }), (0, c.jsx)(X.k, {}), (0, c.jsx)(lK, {
                                                    playing: H,
                                                    className: (0, F.Z)(sk()["favicon-wrapper"]),
                                                    children: (0, c.jsx)(tW, {
                                                        className: "z-40",
                                                        platform: lz.p$,
                                                        size: "medium"
                                                    })
                                                })]
                                            })
                                        }) : (0, c.jsxs)(c.Fragment, {
                                            children: [(0, c.jsx)(lK, {
                                                playing: H,
                                                className: "absolute inset-0"
                                            }), (0, c.jsx)(tW, {
                                                className: "z-20",
                                                platform: lz.p$,
                                                size: "1x4" === f ? "small" : "medium"
                                            })]
                                        })
                                    }), (0, c.jsxs)("div", {
                                        className: "flex h-full flex-grow flex-col items-end justify-between",
                                        children: [
                                            ["4x4"].includes(f) && (0, c.jsx)("div", {
                                                className: "w-fit",
                                                children: W
                                            }), "4x4" === f && Y
                                        ]
                                    })]
                                }), "4x4" !== f && Y, !["4x2", "4x4", "1x4"].includes(f) && W]
                            }), ["2x4", "4x2"].includes(f) && (0, c.jsx)(c.Fragment, {
                                children: ((null == N ? void 0 : null === (r = N.data) || void 0 === r ? void 0 : r.thumbnail) || I) && (0, c.jsxs)("div", {
                                    className: sk().cover,
                                    children: [(null == N ? void 0 : null === (o = N.data) || void 0 === o ? void 0 : o.thumbnail) && !I && (0, c.jsxs)(lG, {
                                        active: H,
                                        slideOutSide: V,
                                        coverSize: "4x4" === f ? 161 : 127,
                                        className: "rounded-[10px]",
                                        children: [(0, c.jsx)(tV.J, {
                                            src: (0, _.En)(null == N ? void 0 : null === (d = N.data) || void 0 === d ? void 0 : d.thumbnail, {
                                                h: sI.height
                                            }),
                                            srcSet: (0, _.En)(null == N ? void 0 : null === (u = N.data) || void 0 === u ? void 0 : u.thumbnail, {
                                                h: sI.height,
                                                dpr: 2
                                            }),
                                            alt: "",
                                            loading: "lazy",
                                            className: "relative inset-0 h-full w-full rounded-[inherit] border-black/[0.08] object-cover",
                                            fallback: G
                                        }), (0, c.jsx)(X.k, {
                                            className: sk()["phantom-border"]
                                        })]
                                    }, f), I && (0, c.jsx)($.O, {
                                        className: (0, F.Z)("h-full w-full rounded-[inherit]")
                                    })]
                                })
                            }), ["4x2"].includes(f) && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(J.L, {}), W]
                            }), ["4x4"].includes(f) && (0, c.jsx)("ul", {
                                className: "flex w-full flex-col",
                                children: null == N ? void 0 : null === (x = N.data) || void 0 === x ? void 0 : null === (h = x.tracks) || void 0 === h ? void 0 : h.slice(0, 6).map((e, t) => (0, c.jsx)("li", {
                                    className: (0, F.Z)("group", 3 === t && "hidden min-[320px]:flex", 4 === t && "hidden min-[350px]:flex", 5 === t && "hidden min-[390px]:flex", 6 === t && "hidden min-[420px]:flex"),
                                    children: (0, c.jsxs)(P.m.button, {
                                        initial: "initial",
                                        whileHover: "playing",
                                        animate: t === O && H ? "playing" : "initial",
                                        className: (0, F.Z)("group flex w-full flex-row items-center justify-between py-1.5 transition-transform duration-150 active:scale-[0.993] group-first:pt-0 group-last:pb-0", 2 === t && "max-[319px]:pb-0", 3 === t && "max-[349px]:pb-0", 4 === t && "max-[389px]:pb-0", 5 === t && "max-[419px]:pb-0"),
                                        onClick: e => {
                                            e.preventDefault(), e.stopPropagation(), t === O ? T() : R(), U(t)
                                        },
                                        ...z,
                                        onMouseEnter: e => {
                                            y(t), z.onMouseEnter(e)
                                        },
                                        onMouseLeave: e => {
                                            y(-1), z.onMouseLeave(e)
                                        },
                                        children: [(0, c.jsxs)("div", {
                                            className: "flex flex-row items-center",
                                            children: [(0, c.jsx)("div", {
                                                className: "h-[17px] w-[20px] text-left text-sm tabular-nums text-black/40",
                                                children: (w === t || O === t && H) && e.audioSnippet ? (0, c.jsxs)(c.Fragment, {
                                                    children: [O === t && H && (0, c.jsx)(sL, {}), (O !== t || !H) && (0, c.jsx)(sS, {})]
                                                }) : "".concat(e.track_number, ".")
                                            }), (0, c.jsx)("div", {
                                                className: (0, F.Z)("mx-3 flex-1 text-left text-sm underline-offset-2 transition-opacity duration-100 line-clamp-1", !e.audioSnippet && "opacity-40", w !== t && H && O !== t && "opacity-40"),
                                                children: e.title
                                            })]
                                        }), (0, c.jsx)("div", {
                                            className: "w-fit flex-none text-sm tabular-nums text-black/40",
                                            children: e.duration ? sD(e.duration) : ""
                                        })]
                                    })
                                }, "track-".concat(t)))
                            })]
                        })
                    })
                };
            var sz = i(70254),
                sA = i.n(sz);
            let sF = e => {
                    let {
                        data: t,
                        className: i
                    } = e, l = iz();
                    return (0, c.jsxs)("div", {
                        "data-prevent-widget": !0,
                        "data-rich-button": !0,
                        role: "button",
                        className: (0, F.Z)(sA()["follow-button"], "rounded-[5px] border border-black/10 text-center font-bold text-black hover:bg-[#D8F8E4] active:bg-[#ABF0C4]", i),
                        ...l,
                        children: ["Follow", (null == t ? void 0 : t.followers) != null && (0, c.jsxs)(c.Fragment, {
                            children: [" ", (0, c.jsx)("span", {
                                className: "ml-1 font-normal",
                                children: (0, _.d)(t.followers)
                            })]
                        })]
                    })
                },
                sM = {
                    height: 135,
                    width: 135
                },
                sT = e => {
                    var t, i, l, s, n;
                    let {
                        data: a
                    } = e, r = (0, eL.$)(), o = (0, _.f6)(a.style, r), [{
                        editing: d
                    }] = (0, j.U)(), {
                        richdata: u,
                        loading: x
                    } = ed(a.href), h = null !== (s = null == u ? void 0 : u.data.name) && void 0 !== s ? s : "Spotify", m = (null == u ? void 0 : u.data.monthlyListeners) ? "".concat((0, _.d)(u.data.monthlyListeners), " monthly listeners") : "", p = (0, M.useMemo)(() => ix(h), [h]), v = (0, ih.J)(null === (t = a.overrides) || void 0 === t ? void 0 : t.title, p) ? h : null !== (n = null === (i = a.overrides) || void 0 === i ? void 0 : i.title) && void 0 !== n ? n : h, g = x || (null == u ? void 0 : u.status) === "FETCHING", f = im(a), w = (0, eM.H)(), y = (null == u ? void 0 : null === (l = u.data) || void 0 === l ? void 0 : l.albums) ? (0, _.A1)(u.data.albums.slice(0, 4), 4).map(e => (0, _.BA)(null == e ? void 0 : e.thumbnail, {
                        w: sM.width,
                        h: sM.height,
                        fit: "crop"
                    })) : (0, _.A1)([], 4), b = (0, c.jsx)("div", {
                        className: "flex h-full w-full items-center justify-center text-black/50",
                        children: (0, c.jsx)(iv.X, {})
                    });
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)(sA()["link-widget"], sA()["link-widget--".concat(o)]),
                        children: [(0, c.jsxs)("div", {
                            className: sA().description,
                            children: [(0, c.jsxs)("div", {
                                className: (0, F.Z)("flex items-start", "4x4" === o && "w-full"),
                                children: [(0, c.jsx)(tW, {
                                    platform: lz.p$,
                                    size: "1x4" === o ? "small" : "medium"
                                }), "4x4" === o && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(sF, {
                                        data: null == u ? void 0 : u.data
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: sA()["link-meta__container"],
                                children: [d && "mouse" === w && (0, c.jsx)(ia, {
                                    value: null != v ? v : h,
                                    extensions: p,
                                    className: (0, F.Z)(sA().title),
                                    containerClassName: sA()["title-editor"],
                                    clickToActivate: !0,
                                    floating: !0,
                                    onCommit: f
                                }), (!d || "mouse" !== w) && (0, c.jsx)(ii, {
                                    value: null != v ? v : h,
                                    extensions: p,
                                    className: sA().title
                                }), "1x4" !== o && (0, c.jsx)("div", {
                                    className: sA().handle,
                                    children: m
                                })]
                            }), !["4x2", "4x4", "1x4"].includes(o) && (0, c.jsx)(sF, {
                                data: null == u ? void 0 : u.data,
                                className: (0, F.Z)(["2x4", "2x2"].includes(o) && "max-[389px]:!hidden", ["4x2"].includes(o) && "max-[349px]:!hidden")
                            })]
                        }), "4x4" === o && (0, c.jsx)(J.L, {}), (y.length > 0 || d) && (0, c.jsx)("div", {
                            className: (0, F.Z)(sA()["post-grid"], g && sA()["post-grid--fetching"]),
                            children: y.map(e => g || e ? (0, c.jsxs)("div", {
                                className: "",
                                children: [!g && e && (0, c.jsx)(tV.J, {
                                    src: e["1x"],
                                    srcSet: "".concat(e["2x"], " 2x"),
                                    alt: "",
                                    loading: "lazy",
                                    fallback: b,
                                    className: "border-black/[0.08]"
                                }), g && (0, c.jsx)($.O, {
                                    className: "h-full w-full rounded-[inherit]"
                                }), (0, c.jsx)(X.k, {})]
                            }) : null)
                        }), "4x2" === o && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(J.L, {}), (0, c.jsx)(sF, {
                                data: null == u ? void 0 : u.data,
                                className: (0, F.Z)(["4x2"].includes(o) && "max-[349px]:!hidden")
                            })]
                        })]
                    })
                };
            var sO = i(25237),
                sR = i.n(sO),
                sB = i(59371),
                sH = i(88285),
                sU = i(19581),
                sV = i.n(sU);
            class sP {
                startMovement() {
                    var e;
                    this.active = !0;
                    let t = {
                            x: this.container.offsetWidth / 2 - this.el.clientWidth / 2,
                            y: this.container.offsetHeight / 2 - this.el.clientHeight / 2
                        },
                        i = Math.sqrt(Math.pow(this.container.clientWidth / 2 + this.el.clientWidth / 2, 2) + Math.pow(this.container.clientHeight / 2 + this.el.clientHeight / 2, 2));
                    this.position = {
                        x: t.x + Math.cos(this.direction * Math.PI / 180 + Math.PI) * i,
                        y: t.y + Math.sin(this.direction * Math.PI / 180 + Math.PI) * i
                    }, this.start = { ...this.position
                    }, this.end = {
                        x: this.start.x + Math.cos(this.direction * Math.PI / 180) * i * 2,
                        y: this.start.y + Math.sin(this.direction * Math.PI / 180) * i * 2
                    }, this.t = performance.now(), this.el.style.position = "absolute", this.el.style.left = "0", this.el.style.top = "0", this.el.style.transform = "translate(".concat(this.position.x, "px, ").concat(this.position.y, "px) rotate(").concat((null === (e = this.options) || void 0 === e ? void 0 : e.rotate) ? this.direction + 90 : 0, "deg)"), this.update()
                }
                isVisible() {
                    let e = {
                            x: this.end.x - this.start.x,
                            y: this.end.y - this.start.y
                        },
                        t = {
                            x: this.position.x - this.start.x,
                            y: this.position.y - this.start.y
                        },
                        i = e.x * t.x + e.y * t.y;
                    return !(i >= e.x * e.x + e.y * e.y)
                }
                update() {
                    var e, t, i, l, s, n, a, r;
                    let o = (performance.now() - this.t) / 1e3;
                    if (this.t = performance.now(), this.position.x += Math.cos(this.direction * Math.PI / 180) * this.speed * o, this.position.y += Math.sin(this.direction * Math.PI / 180) * this.speed * o, this.el.style.transform = "translate(".concat(this.position.x, "px, ").concat(this.position.y, "px) rotate(").concat((null === (e = this.options) || void 0 === e ? void 0 : e.rotate) ? this.direction + 90 : 0, "deg)"), this.shadow) {
                        let e = null !== (a = null === (t = this.options) || void 0 === t ? void 0 : null === (i = t.shadow) || void 0 === i ? void 0 : i.distance) && void 0 !== a ? a : 1;
                        this.shadow.style.transform = "translate(".concat(this.position.x - 5 * e, "px, ").concat(this.position.y + 40 * e, "px) scale(").concat(null !== (r = null === (l = this.options) || void 0 === l ? void 0 : null === (s = l.shadow) || void 0 === s ? void 0 : s.scale) && void 0 !== r ? r : 1, ") rotate(").concat((null === (n = this.options) || void 0 === n ? void 0 : n.rotate) ? this.direction + 90 : 0, "deg)")
                    }
                    this.isVisible() ? requestAnimationFrame(this.update.bind(this)) : this.active = !1
                }
                constructor(e, t, i, l, s) {
                    this.el = e, this.shadow = t, this.speed = i, this.wind = l, this.options = s, this.position = {
                        x: 0,
                        y: 0
                    }, this.start = {
                        x: 0,
                        y: 0
                    }, this.end = {
                        x: 0,
                        y: 0
                    }, this.active = !1, this.t = 0, this.container = e.parentElement, this.wind ? this.direction = 30 : this.direction = 360 * Math.random()
                }
            }

            function sG(e, t, i, l, s) {
                let n = () => new sP(e, t, i, l, s),
                    a = (0, M.useRef)(void 0);
                (0, M.useEffect)(() => {
                    e && (e.style.transform = "translate(-2000px, -2000px)")
                }, [e]), (0, M.useEffect)(() => {
                    t && (t.style.transform = "translate(-2000px, -2000px)")
                }, [t]);
                let r = () => {
                    e && (a.current && a.current.active || (a.current || (a.current = n()), a.current.startMovement()))
                };
                return {
                    startMovement: r
                }
            }
            let sW = e => {
                    let {
                        wind: t
                    } = e, [i, l] = (0, M.useState)(null), [s, n] = (0, M.useState)(null), {
                        startMovement: a
                    } = sG(i, s, t.speed, t);
                    return (0, M.useEffect)(() => {
                        if (i) {
                            let e;
                            let t = setTimeout(() => {
                                a(), e = setInterval(() => {
                                    a()
                                }, 7e4)
                            }, 1e4 * Math.random() + 2e4);
                            return () => {
                                clearTimeout(t), clearInterval(e)
                            }
                        }
                    }, [i]), (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("img", {
                            ref: l,
                            src: "/images/balloon.png",
                            alt: "",
                            className: "w-[16px]"
                        }), (0, c.jsx)("img", {
                            ref: n,
                            src: "/images/balloonshadow.png",
                            alt: "",
                            className: "w-[16px]"
                        })]
                    })
                },
                sJ = e => {
                    let {
                        wind: t
                    } = e, [i, l] = (0, M.useState)(null), [s, n] = (0, M.useState)(null), {
                        startMovement: a
                    } = sG(i, s, t.speed + 4, t, {
                        rotate: !0,
                        shadow: {
                            distance: 3
                        }
                    });
                    return (0, M.useEffect)(() => {
                        if (i) {
                            let e;
                            let t = setTimeout(() => {
                                a(), e = setInterval(() => {
                                    a()
                                }, 7e4)
                            }, 3e3 * Math.random() + 5e3);
                            return () => {
                                clearTimeout(t), clearInterval(e)
                            }
                        }
                    }, [i]), (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("img", {
                            ref: n,
                            src: "/images/cloud.png",
                            alt: "",
                            className: "absolute w-[1000px] opacity-[0.1] blur-[4px] brightness-[0.01]"
                        }), (0, c.jsx)("img", {
                            ref: l,
                            src: "/images/cloud.png",
                            alt: "",
                            className: "w-[1000px] opacity-80"
                        })]
                    })
                },
                sY = e => {
                    let {} = e, [t, i] = (0, M.useState)(null), [l, s] = (0, M.useState)(null), {
                        startMovement: n
                    } = sG(t, l, 15 * Math.random() + 10, void 0, {
                        rotate: !0,
                        shadow: {
                            distance: 2
                        }
                    });
                    return (0, M.useEffect)(() => {
                        if (t) {
                            let e;
                            let t = setTimeout(() => {
                                n(), e = setInterval(() => {
                                    n()
                                }, 7e4)
                            }, 6e3 * Math.random() + 1e4);
                            return () => {
                                clearTimeout(t), clearInterval(e)
                            }
                        }
                    }, [t]), (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("img", {
                            ref: i,
                            src: "/images/plane.png",
                            alt: "",
                            className: "w-[24px]"
                        }), (0, c.jsx)("img", {
                            ref: s,
                            src: "/images/planeshadow.png",
                            alt: "",
                            className: "w-[24px]"
                        })]
                    })
                },
                sq = e => {
                    let {} = e, [t, i] = (0, M.useState)(null), [l, s] = (0, M.useState)(null), {
                        startMovement: n
                    } = sG(t, l, 10 * Math.random() + 5, void 0, {
                        rotate: !0,
                        shadow: {
                            distance: 2
                        }
                    });
                    return (0, M.useEffect)(() => {
                        if (t) {
                            let e;
                            let t = setTimeout(() => {
                                n(), e = setInterval(() => {
                                    n()
                                }, 7e4)
                            }, 6e3 * Math.random() + 1e4);
                            return () => {
                                clearTimeout(t), clearInterval(e)
                            }
                        }
                    }, [t]), (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsx)("img", {
                            ref: i,
                            src: "/images/satellite.png",
                            alt: "",
                            className: "w-[18px]"
                        })
                    })
                },
                sK = e => {
                    let {} = e, [{
                        editing: t
                    }] = (0, j.U)(), [{
                        map: i
                    }] = (0, sH.w)(), [l, s] = (0, M.useState)(0), [n, a] = (0, M.useState)({
                        direction: 360 * Math.random(),
                        speed: 10 * Math.random() + 5
                    });
                    return ((0, M.useEffect)(() => {
                        i && (s(i.getZoom()), i.on("zoom", () => {
                            s(i.getZoom())
                        }))
                    }, [i]), t || !i) ? null : (0, c.jsxs)("div", {
                        className: "absolute inset-0 overflow-hidden rounded-[inherit]",
                        children: [l > 13 && (0, c.jsx)(sW, {
                            wind: n
                        }), l > 6 && (0, c.jsx)(sJ, {
                            wind: n
                        }), l > 5 && l <= 13 && (0, c.jsx)(sY, {}), l <= 5 && (0, c.jsx)(sq, {})]
                    })
                },
                sX = sR()(() => Promise.all([i.e(55), i.e(901)]).then(i.bind(i, 50901)).then(e => e.MapGl), {
                    loadableGenerated: {
                        webpack: () => [50901]
                    },
                    ssr: !1
                }),
                s$ = e => {
                    var t, i, l, s;
                    let {
                        data: n
                    } = e, [{
                        editing: a
                    }] = (0, j.U)(), r = (0, eL.$)(), o = (0, eM.H)(), d = (0, _.f6)(n.style, r), u = (0, M.useMemo)(() => (0, sB.j)(), []), x = function(e) {
                        let [, t] = (0, j.U)(), i = (0, M.useCallback)(i => {
                            t({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: e.id,
                                    overrides: { ...e.overrides,
                                        mapCaption: i
                                    }
                                }
                            }), ei.f.setCaption(e.id, (0, ih.V)(i, (0, sB.j)()))
                        }, [e, t]);
                        return i
                    }(n), [h, m] = (0, M.useState)(null === (t = n.overrides) || void 0 === t ? void 0 : t.mapCaption), p = (0, ih.J)(h, u), [v, g] = (0, M.useState)(void 0), {
                        lat: f,
                        long: w,
                        zoom: y
                    } = (0, el.Of)(n.href);
                    return (0, M.useEffect)(() => {
                        var e;
                        m(null === (e = n.overrides) || void 0 === e ? void 0 : e.mapCaption)
                    }, [null === (i = n.overrides) || void 0 === i ? void 0 : i.mapCaption]), (0, M.useEffect)(() => {
                        let e = document.createElement("canvas"),
                            t = e.getContext("webgl") || e.getContext("experimental-webgl");
                        g(!!t && t instanceof WebGLRenderingContext)
                    }, []), (0, c.jsx)(sH.t, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)(sV().widget, sV()["widget--".concat(d)]),
                            children: [v && (0, c.jsx)(sX, {
                                data: n,
                                style: d,
                                lat: f,
                                long: w,
                                zoom: y,
                                hasCaption: !p
                            }), !1 === v && (0, c.jsx)("div", {
                                className: "absolute inset-0 flex items-center justify-center bg-neutral-grey10",
                                children: (0, c.jsx)("div", {
                                    className: "text-[14px] font-medium text-[#959595]",
                                    children: "Your browser does not support WebGL"
                                })
                            }), (0, c.jsx)(sK, {}), (a || !p) && (0, c.jsx)("div", {
                                className: (0, F.Z)(sV()["caption-container"], p && sV()["caption-container--empty"], "mouse" === o && sV()["caption-container--mouse"]),
                                children: (0, c.jsxs)("div", {
                                    className: (0, F.Z)("bg-white/70 px-2 py-1.5 text-[14px] shadow-[0px_0px_0px_1px_rgba(0,0,0,0.06)] backdrop-blur-[20px]", "4x4" !== d && "rounded-[8px]", "4x4" === d && "rounded-[10px]"),
                                    children: [a && "mouse" === o && (0, c.jsx)(ia, {
                                        value: null === (l = n.overrides) || void 0 === l ? void 0 : l.mapCaption,
                                        extensions: u,
                                        clickToActivate: !0,
                                        fallback: "Caption...",
                                        onCommit: x,
                                        onChange: m,
                                        className: (0, F.Z)(!["2x2", "4x4"].includes(d) && "line-clamp-2", ["2x2", "4x4"].includes(d) && "line-clamp-1")
                                    }), (!a || "mouse" !== o) && (0, c.jsx)(ii, {
                                        value: null === (s = n.overrides) || void 0 === s ? void 0 : s.mapCaption,
                                        extensions: u,
                                        className: (0, F.Z)("2x2" !== d && "line-clamp-2", "2x2" === d && "line-clamp-1")
                                    })]
                                })
                            })]
                        })
                    })
                },
                sQ = {
                    "Github Profile": iR,
                    "Instagram Profile": iG,
                    "Twitter Profile": iX,
                    "Youtube Profile": i4,
                    "Dribbble Profile": i8,
                    "Dribbble Post": sh,
                    "Behance Profile": ln,
                    "Behance File": sr,
                    "Figma Profile": lh,
                    "Figma File": lE,
                    "Tiktok Profile": lj,
                    "Spotify Song": l$,
                    "Spotify Profile": l5,
                    "Spotify Playlist": st,
                    "Spotify Podcast": s_,
                    "Spotify Podcast Episode": sN,
                    "Spotify Album": sZ,
                    "Spotify Artist": sT,
                    "Google Maps": s$,
                    "Apple Maps": s$
                };
            var s0 = i(50921);
            let s1 = e => {
                var t;
                let {
                    className: i,
                    data: l,
                    pos: s,
                    onClick: n,
                    ...a
                } = e, [{
                    editable: r,
                    profile: o
                }] = (0, j.U)(), d = (0, eL.$)(), u = (0, _.f6)(l.style, d), x = (0, eB.X)(l.href), h = (0, _.f6)(s, d), m = (0, M.useRef)(), p = (0, M.useMemo)(() => {
                    if (x) {
                        var e, t, i, l;
                        return {
                            primary: null === (e = x.colors) || void 0 === e ? void 0 : e.primary,
                            bg: null === (t = x.colors) || void 0 === t ? void 0 : t.bg,
                            hover: null === (i = x.colors) || void 0 === i ? void 0 : i.hover,
                            active: null === (l = x.colors) || void 0 === l ? void 0 : l.active
                        }
                    }
                    return {}
                }, [x]), v = x && x.name ? sQ[x.name] : void 0, g = el.vT.includes(null == x ? void 0 : x.name);
                return (0, c.jsxs)(tB.$, {
                    as: "a",
                    href: l.href,
                    target: "_blank",
                    rel: "noopener noreferrer",
                    draggable: !1,
                    ...a,
                    className: (0, F.Z)(iI()["link-widget-base"], iI()["link-widget-base--".concat(u)], g && iI()["link-widget-base--maps"], (null == x ? void 0 : null === (t = x.name) || void 0 === t ? void 0 : t.includes("Figma")) && iI()["link-widget-base--figma"]),
                    rounding: "1x4" === u ? "sm" : "4x4" === u ? "lg" : "md",
                    clickable: !0,
                    colors: p,
                    snapContent: !g,
                    ref: m,
                    tabIndex: 5,
                    onClick: e => {
                        if (null == n || n(e), !r) {
                            var t;
                            let i = e.target;
                            (0, s0.U)().click(o.handle, l.id, d), (0, z.c)().track("BENTO_LINK_CLICKED", {
                                widgetType: "link",
                                href: l.href,
                                platformName: null !== (t = null == x ? void 0 : x.name) && void 0 !== t ? t : "Generic",
                                gridDevice: d,
                                widgetSize: u,
                                positionX: h.x,
                                positionY: h.y,
                                richButton: !!(null == i ? void 0 : i.closest("[data-rich-button]"))
                            })
                        }
                    },
                    children: [!x && (0, c.jsx)(iS, {
                        data: l
                    }), x && v && (0, M.createElement)(v, {
                        data: l,
                        baseWidgetRef: m
                    }), x && !v && (0, c.jsx)(iS, {
                        data: l
                    })]
                })
            };
            var s2 = i(28970),
                s4 = i(47312),
                s5 = i(37596),
                s9 = i(50106),
                s7 = i(10372),
                s3 = i(65753);
            let s6 = e => {
                let {
                    id: t,
                    src: i,
                    data: l
                } = e, s = (0, tR.A)(e => e.highlighting), [{
                    editing: n
                }] = (0, j.U)(), [a, r] = (0, M.useState)(void 0), o = (0, _.En)(i, {
                    w: 750,
                    h: 750
                }), d = (0, s9._e)(l), u = (0, eM.H)(), x = (0, s9.jj)(l);
                return (0, M.useEffect)(() => {
                    (0, s3.p)(o).then(e => {
                        r({
                            width: e.width,
                            height: e.height
                        })
                    }).catch(() => {})
                }, [o]), (0, c.jsx)(s7.T, {
                    dimensions: a,
                    editable: n && s === t && "mouse" === u,
                    id: t,
                    offsetX: d.offsetX,
                    offsetY: d.offsetY,
                    onChange: x,
                    withCanvas: n,
                    children: (0, c.jsx)("img", {
                        src: o,
                        alt: "",
                        loading: "lazy",
                        className: "rounded-[inherit]"
                    })
                })
            };
            var s8 = i(80588),
                ne = i.n(s8),
                nt = i(69289);
            let ni = sR()(() => Promise.all([i.e(915), i.e(574), i.e(75)]).then(i.bind(i, 1075)).then(e => e.Video), {
                    loadableGenerated: {
                        webpack: () => [1075]
                    },
                    ssr: !1
                }),
                nl = e => {
                    let {
                        id: t,
                        src: i,
                        data: l
                    } = e, s = (0, tR.A)(e => e.highlighting), [{
                        editing: n
                    }] = (0, j.U)(), [a, r] = (0, M.useState)(void 0), [o, d] = (0, M.useState)(!1), u = (0, s9._e)(l), x = (0, s9.jj)(l), h = (0, eM.H)();
                    return (0, M.useEffect)(() => {
                        (0, nt.j)(i).then(e => {
                            r({
                                width: e.width,
                                height: e.height
                            })
                        }).catch(e => {
                            d(!0), console.log("EEEE", e)
                        })
                    }, [i]), (0, c.jsxs)(c.Fragment, {
                        children: [o && (0, c.jsx)("div", {
                            className: "absolute inset-0 flex items-center justify-center rounded-[var(--widget-radius)] text-center text-xs font-medium text-neutral-grey20",
                            children: "Video failed to load"
                        }), !o && (0, c.jsx)(s7.T, {
                            dimensions: a,
                            editable: n && s === t && "mouse" === h,
                            id: t,
                            offsetX: u.offsetX,
                            offsetY: u.offsetY,
                            onChange: x,
                            withCanvas: n,
                            children: (0, c.jsx)(ni, {
                                src: i
                            })
                        })]
                    })
                },
                ns = {
                    primary: "#000"
                },
                nn = e => {
                    var t, i;
                    let {
                        className: l,
                        children: s,
                        data: n,
                        pos: a,
                        onClick: r,
                        ...o
                    } = e, d = (0, eL.$)(), [{
                        profile: u,
                        editing: x,
                        editable: h
                    }] = (0, j.U)(), m = (0, eM.H)(), p = (0, _.f6)(n.style, d), v = (0, M.useMemo)(() => (0, s4.K)(), []), {
                        getUpload: g,
                        addMediaUpload: f
                    } = (0, eS.r)(), w = g(n.id), y = (0, s9.oV)(n), {
                        urlPreCommit: b,
                        urlCommit: N
                    } = (0, s9.OF)(n), C = null !== (t = null == w ? void 0 : w.tmpUrl) && void 0 !== t ? t : n.url, k = (0, ih.J)(n.caption, v), E = (0, _.f6)(a, d), S = (0, eB.X)(n.href), L = (0, tR.A)(e => e.highlighting), I = (0, s2.c)(e => e.cropping);
                    return (0, c.jsx)("div", {
                        className: "h-full w-full rounded-[inherit]",
                        "data-media-container": !0,
                        children: (0, c.jsxs)(tB.$, { ...o,
                            as: n.href && !x ? "a" : "div",
                            href: x ? void 0 : n.href,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            rounding: "1x4" === p ? "sm" : "4x4" === p ? "lg" : "md",
                            className: (0, F.Z)(ne()["media-widget"], ne()["media-widget--".concat(p)], L === n.id && ne()["media-widget--highlighted"], I && ne()["media-widget--cropping"], l),
                            clipped: !x,
                            colors: ns,
                            clickable: !!n.href,
                            tabIndex: 5,
                            onClick: e => {
                                if (null == r || r(e), h && "mouse" === m) {
                                    let t = e.target,
                                        i = t.classList.contains("ProseMirror-trailingBreak") || null !== t.closest('[contenteditable="true"]') || null !== t.closest("[data-text-button]") || null !== t.closest("input");
                                    if (!i) {
                                        let e = document.createElement("input");
                                        e.type = "file", e.accept = "".concat(eI, ",").concat(eD), e.multiple = !1, e.onchange = e => {
                                            let t = e.target.files;
                                            if (t && t[0]) {
                                                let e = (0, ez.b)(t[0]);
                                                setTimeout(() => {
                                                    b()
                                                }, 50), f(t[0], n.id).then(t => {
                                                    N(t), (0, z.c)().track("MEDIA_SOURCE_REPLACED", {
                                                        variant: e
                                                    })
                                                }).catch(() => {})
                                            }
                                        }, e.click()
                                    }
                                }
                                if (n.href && !h) {
                                    var t;
                                    let i = e.target;
                                    (0, s0.U)().click(u.handle, n.id, d), (0, z.c)().track("BENTO_LINK_CLICKED", {
                                        widgetType: "media",
                                        href: n.href,
                                        platformName: null !== (t = null == S ? void 0 : S.name) && void 0 !== t ? t : "Generic",
                                        gridDevice: d,
                                        widgetSize: p,
                                        positionX: E.x,
                                        positionY: E.y,
                                        richButton: !!(null == i ? void 0 : i.closest("[data-rich-button]"))
                                    })
                                }
                            },
                            children: ["image" === n.variant && C && (0, c.jsx)(s6, {
                                id: n.id,
                                src: C,
                                data: n
                            }), "video" === n.variant && C && (0, c.jsx)(nl, {
                                id: n.id,
                                src: C,
                                data: n
                            }), w && (0, c.jsx)("div", {
                                className: "absolute left-6 top-6",
                                children: (0, c.jsx)(tq, {
                                    progress: null !== (i = w.progress) && void 0 !== i ? i : 0
                                })
                            }), (x || !k) && (0, c.jsx)("div", {
                                className: (0, F.Z)(ne()["caption-container"], k && ne()["caption-container--empty"], "mouse" === m && ne()["caption-container--mouse"]),
                                children: (0, c.jsxs)("div", {
                                    className: (0, F.Z)("bg-white px-2 py-1.5 text-[14px] shadow-[0px_0px_0px_1px_rgba(0,0,0,0.06)]", "4x4" !== p && "rounded-[8px]", "4x4" === p && "rounded-[10px]"),
                                    children: [x && "mouse" === m && (0, c.jsx)(ia, {
                                        value: n.caption,
                                        extensions: v,
                                        clickToActivate: !0,
                                        onCommit: y,
                                        className: "line-clamp-2"
                                    }), (!x || "mouse" !== m) && (0, c.jsx)(ii, {
                                        value: n.caption,
                                        extensions: v,
                                        className: "line-clamp-2"
                                    })]
                                })
                            }), n.href && (0, c.jsx)(s5.o, {
                                href: n.href
                            }, "link-indicator")]
                        })
                    })
                };
            var na = i(65213),
                nr = i(41435),
                no = i.n(nr);
            let nd = () => [iu.y, ic.Z, io.Z, ir.Z, id.Z.configure({
                    placeholder: "Add a title..."
                })],
                nc = e => {
                    var t;
                    let {
                        className: i,
                        children: l,
                        data: s,
                        ...a
                    } = e, [{
                        editing: r
                    }] = (0, j.U)(), o = (0, eM.H)(), d = function(e) {
                        var t;
                        let [{
                            profile: i
                        }, l] = (0, j.U)(), s = null === (t = i.bento.items.find(t => t.data.id === e.id)) || void 0 === t ? void 0 : t.data, a = (0, M.useCallback)(t => {
                            n && clearTimeout(n);
                            let i = (0, ih.V)(s.title, nd()),
                                a = (0, ih.V)(t, nd());
                            i !== a && (n = setTimeout(() => {
                                ei.f.renamedSection(e.id, (0, ih.V)(t, nd()))
                            }, 500)), l({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: e.id,
                                    title: t
                                }
                            })
                        }, [s, e, l]);
                        return a
                    }(s), u = (0, M.useMemo)(() => nd(), []), [x, h] = (0, M.useState)(null), m = null !== (t = s.title) && void 0 !== t ? t : "";
                    return ! function(e, t) {
                        let [i, l, s] = (0, eF.W)(e => [e.focused, e.setFocused, e.unsetFocused]), n = (0, eM.H)();
                        (0, M.useEffect)(() => {
                            if ("touch" !== n && t) {
                                let i = () => {
                                    s(e)
                                };
                                return t.on("blur", i), () => {
                                    t.off("blur", i)
                                }
                            }
                        }, [t, s, e, n]), (0, M.useEffect)(() => {
                            if ("touch" !== n && t && i !== e) {
                                let s = () => {
                                    i !== e && l(e)
                                };
                                return t.on("focus", s), () => {
                                    t.off("focus", s)
                                }
                            }
                        }, [t, i, l, e, n]), (0, M.useEffect)(() => {
                            if ("touch" !== n && t && i === e) {
                                let e = () => {
                                    t.view.dom.dispatchEvent(new CustomEvent("managed-focus"))
                                };
                                if (!t.view.dom) return t.on("create", e), () => {
                                    t.off("create", e)
                                };
                                e()
                            }
                        }, [t, i, l, e, n])
                    }(s.id, x), (0, c.jsxs)(tB.$, { ...a,
                        className: (0, F.Z)(no()["section-header-widget"]),
                        rounding: "xs",
                        bordered: !1,
                        elevated: !1,
                        clipped: !1,
                        children: [r && "mouse" === o && (0, c.jsx)(ia, {
                            value: m,
                            extensions: u,
                            clickToActivate: !0,
                            onChange: d,
                            onCommit: d,
                            containerClassName: (0, F.Z)(no()["title-editor"]),
                            onEditor: h
                        }), r && "touch" === o && (0, c.jsx)(ii, {
                            value: m,
                            extensions: u,
                            className: (0, F.Z)("!px-2 xl:!px-2")
                        }), !r && (0, c.jsx)(ii, {
                            value: m,
                            extensions: u,
                            showPlaceholder: !1,
                            className: "px-2"
                        })]
                    })
                };
            var nu = i(14673),
                nx = i.n(nu);
            let nh = (0, L.Ue)(e => ({
                    hoveringRemove: !1,
                    setHoveringRemove: t => {
                        e({
                            hoveringRemove: t
                        })
                    }
                })),
                nm = e => {
                    let {
                        data: t,
                        back: i,
                        children: l,
                        color: s = "#000",
                        selected: n,
                        flipped: a = !1,
                        onClick: r,
                        onOutsideClick: o
                    } = e, [d, u] = (0, M.useState)(null), [x, h] = (0, tR.A)(e => [e.highlighting, e.mode]), m = nh(e => e.hoveringRemove), p = x && x === t.id ? "highlight" : x ? "dim" : "none";
                    return (0, M.useEffect)(() => {
                        let e = (0, eV.$)(),
                            t = e => {
                                let t = e.target,
                                    i = !!(null == t ? void 0 : t.closest("[data-bento-menu]"));
                                for (; t && !i;) t === d && (i = !0), t = t.parentElement;
                                i || null == o || o()
                            };
                        return window.addEventListener("click", t), null == e || e.addEventListener("click", t), () => {
                            window.removeEventListener("click", t), null == e || e.removeEventListener("click", t)
                        }
                    }, [d, o]), (0, c.jsxs)("button", {
                        ref: u,
                        className: (0, F.Z)(nx().widget, nx()["widget--rounding-".concat("md")], nx()["widget--attention-".concat(p)], nx()["widget--highlight-".concat(h)], n && nx()["widget--selected"], m && nx()["widget--hovering"], a && nx()["widget--flipped"]),
                        onClick: r,
                        children: [(0, c.jsxs)("div", {
                            className: (0, F.Z)(nx().front),
                            children: [(0, c.jsx)("svg", {
                                className: "absolute top-[20px] right-[20px]",
                                width: "14",
                                height: "14",
                                viewBox: "0 0 14 14",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                "data-plus": !0,
                                children: (0, c.jsx)("path", {
                                    "fill-rule": "evenodd",
                                    "clip-rule": "evenodd",
                                    d: "M8 1C8 0.447715 7.55228 0 7 0C6.44772 0 6 0.447715 6 1V6H1C0.447715 6 0 6.44772 0 7C0 7.55228 0.447715 8 1 8H6V13C6 13.5523 6.44772 14 7 14C7.55228 14 8 13.5523 8 13V8H13C13.5523 8 14 7.55228 14 7C14 6.44772 13.5523 6 13 6H8V1Z",
                                    fill: n ? s : "#E9E9E9"
                                })
                            }), l]
                        }), (0, c.jsx)("div", {
                            className: (0, F.Z)(nx().back),
                            children: i
                        }), (0, c.jsx)("div", {
                            className: (0, F.Z)(nx().side)
                        }), (0, c.jsx)("div", {
                            className: nx().border,
                            style: {
                                "--color": s
                            }
                        })]
                    })
                },
                np = e => {
                    let {
                        data: t,
                        pos: i,
                        gridIndex: l
                    } = e, s = e9(e => e.selectedId), [n, a] = (0, tR.A)(e => [e.highlighting, e.setHighlighting]), [{
                        editing: r
                    }] = (0, j.U)(), o = (0, eM.H)(), d = {
                        selected: "touch" === o && s === t.id,
                        editing: r,
                        pos: i,
                        gridIndex: l,
                        attentionMode: n && n === t.id ? "highlight" : n ? "dim" : "none"
                    };
                    switch (t.type) {
                        case "link":
                            return (0, c.jsx)(s1, {
                                data: t,
                                ...d
                            });
                        case "media":
                            return (0, c.jsx)(nn, {
                                data: t,
                                ...d
                            });
                        case "section-header":
                            return (0, c.jsx)(nc, {
                                data: t,
                                ...d
                            });
                        case "rich-text":
                            return (0, c.jsx)(na.p8, {
                                data: t,
                                ...d
                            });
                        case "ghost":
                            return (0, c.jsx)(nm, {
                                data: t,
                                ...d
                            });
                        default:
                            throw Error("Unexpected bento type")
                    }
                };
            var nv = i(26892),
                ng = i.n(nv);
            let nf = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("path", {
                            d: "M9.99985 2.99985C9.99985 2.44756 9.55213 1.99985 8.99985 1.99985C8.44756 1.99985 7.99985 2.44756 7.99985 2.99985V7.99985H2.99985C2.44756 7.99985 1.99985 8.44756 1.99985 8.99985C1.99985 9.55213 2.44756 9.99985 2.99985 9.99985H7.99985V14.9998C7.99985 15.5521 8.44756 15.9998 8.99985 15.9998C9.55213 15.9998 9.99985 15.5521 9.99985 14.9998V9.99985H14.9998C15.5521 9.99985 15.9998 9.55213 15.9998 8.99985C15.9998 8.44756 15.5521 7.99985 14.9998 7.99985H9.99985V2.99985Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M4.70711 6.29274C5.09763 6.68327 5.09763 7.31643 4.70711 7.70696L3.41421 8.99985L4.70711 10.2927C5.09763 10.6833 5.09763 11.3164 4.70711 11.707C4.31658 12.0975 3.68342 12.0975 3.29289 11.707L1.29289 9.70696C0.902369 9.31643 0.902369 8.68327 1.29289 8.29274L3.29289 6.29274C3.68342 5.90222 4.31658 5.90222 4.70711 6.29274Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M3.99985 5.99985C4.55213 5.99985 4.99985 6.44756 4.99985 6.99985V10.9998C4.99985 11.5521 4.55213 11.9998 3.99985 11.9998C3.44756 11.9998 2.99985 11.5521 2.99985 10.9998V6.99985C2.99985 6.44756 3.44756 5.99985 3.99985 5.99985Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            d: "M9.70696 1.29289C9.31643 0.902369 8.68327 0.902369 8.29274 1.29289L6.30318 3.28246C6.25469 3.32955 6.21096 3.38153 6.17278 3.43758C6.06364 3.5978 5.99985 3.79137 5.99985 3.99985C5.99985 4.0071 5.99993 4.01435 6.00008 4.02161C6.00227 4.12329 6.01987 4.2247 6.05289 4.32204C6.10062 4.46275 6.18057 4.59494 6.29274 4.70711C6.49243 4.9068 6.75557 5.00438 7.01726 4.99985H10.9824C11.2441 5.00438 11.5073 4.9068 11.707 4.70711C11.8191 4.59498 11.899 4.46284 11.9468 4.32219C11.9812 4.22105 11.9998 4.11263 11.9998 3.99985C11.9998 3.82635 11.9557 3.66316 11.8779 3.52094C11.8624 3.49252 11.8454 3.4647 11.8269 3.43758C11.7887 3.38153 11.745 3.32955 11.6965 3.28245L9.70696 1.29289Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M13.2927 6.29274C13.6833 5.90222 14.3164 5.90222 14.707 6.29274L16.707 8.29274C17.0975 8.68327 17.0975 9.31643 16.707 9.70695L14.707 11.707C14.3164 12.0975 13.6833 12.0975 13.2927 11.707C12.9022 11.3164 12.9022 10.6833 13.2927 10.2927L14.5856 8.99985L13.2927 7.70696C12.9022 7.31643 12.9022 6.68327 13.2927 6.29274Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M13.9998 5.99985C14.5521 5.99985 14.9998 6.44756 14.9998 6.99985V10.9998C14.9998 11.5521 14.5521 11.9998 13.9998 11.9998C13.4476 11.9998 12.9998 11.5521 12.9998 10.9998V6.99985C12.9998 6.44756 13.4476 5.99985 13.9998 5.99985Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M6.29274 13.2927C6.68327 12.9022 7.31643 12.9022 7.70696 13.2927L8.99985 14.5856L10.2927 13.2927C10.6833 12.9022 11.3164 12.9022 11.707 13.2927C12.0975 13.6833 12.0975 14.3164 11.707 14.707L9.70696 16.707C9.31643 17.0975 8.68327 17.0975 8.29274 16.707L6.29274 14.707C5.90222 14.3164 5.90222 13.6833 6.29274 13.2927Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M5.99985 13.9998C5.99985 13.4476 6.44756 12.9998 6.99985 12.9998H10.9998C11.5521 12.9998 11.9998 13.4476 11.9998 13.9998C11.9998 14.5521 11.5521 14.9998 10.9998 14.9998H6.99985C6.44756 14.9998 5.99985 14.5521 5.99985 13.9998Z",
                            fill: "currentColor"
                        })]
                    })
                },
                n_ = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M13.2929 4.70741C12.5788 3.99336 11.4212 3.99336 10.7071 4.70741L4 11.4145V14.0003H6.58579L13.2929 7.2932C14.0069 6.57915 14.0069 5.42146 13.2929 4.70741ZM9.2929 3.29319C10.788 1.7981 13.212 1.7981 14.7071 3.2932C16.2022 4.78829 16.2022 7.21232 14.7071 8.70741L7.70711 15.7074C7.51957 15.8949 7.26522 16.0003 7 16.0003H3C2.44772 16.0003 2 15.5526 2 15.0003V11.0003C2 10.7351 2.10536 10.4807 2.29289 10.2932L9.2929 3.29319Z",
                            fill: "currentColor"
                        })
                    })
                },
                nj = (0, L.Ue)(e => ({
                    editingContentOfId: void 0,
                    setEditingContentOfId: t => e({
                        editingContentOfId: t
                    })
                })),
                nw = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 26 26",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M25.4142 4.58579C26.1953 5.36683 26.1953 6.63317 25.4142 7.41421L11.4142 21.4142C10.6332 22.1953 9.36684 22.1953 8.58579 21.4142L0.585786 13.4142C-0.195262 12.6332 -0.195262 11.3668 0.585786 10.5858C1.36683 9.80474 2.63317 9.80474 3.41421 10.5858L10 17.1716L22.5858 4.58579C23.3668 3.80474 24.6332 3.80474 25.4142 4.58579Z",
                            fill: "currentColor"
                        })
                    })
                },
                ny = e => {
                    let {
                        className: t,
                        selected: i,
                        data: l
                    } = e, [s, n, a] = (0, eF.W)(e => [e.focused, e.setFocused, e.unsetFocused]), r = nj(e => e.setEditingContentOfId), [, o] = (0, j.U)(), d = e9(e => e.selectedId), u = () => {
                        "rich-text" === l.type ? n(l.id) : r(l.id)
                    }, x = () => {
                        a(l.id)
                    }, h = () => {
                        (0, z.c)().track("WIDGET_REMOVED", {
                            type: l.type
                        }), ei.f.removedWidget(l.id), o({
                            type: "delete-bento-item",
                            id: l.id
                        })
                    }, m = (0, M.useMemo)(() => (0, c.jsx)("div", {
                        "data-drag-handle": !0,
                        className: (0, F.Z)("absolute left-1/2 bottom-0 -translate-x-1/2 translate-y-1/2 rounded-full bg-black p-3 text-xs font-semibold text-white", ng().button),
                        children: (0, c.jsx)(nf, {})
                    }), []);
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            "data-bento-menu": !0,
                            className: (0, F.Z)(ng().container, i && ng()["container--selected"], t),
                            children: [d === l.id && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)(eX.M, {
                                    initial: !1,
                                    children: s !== l.id && (0, c.jsx)(P.m.button, {
                                        initial: {
                                            opacity: 0
                                        },
                                        animate: {
                                            opacity: 1
                                        },
                                        exit: {
                                            opacity: 0
                                        },
                                        onClick: h,
                                        className: (0, F.Z)("translate-0 absolute left-1 top-1 -translate-x-1/2 -translate-y-1/2 rounded-full border-[1px] border-black/[0.06] bg-white p-3 text-xs font-semibold text-black", ng().button),
                                        children: (0, c.jsx)("svg", {
                                            width: "18",
                                            height: "18",
                                            viewBox: "0 0 18 18",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: (0, c.jsx)("path", {
                                                fillRule: "evenodd",
                                                clipRule: "evenodd",
                                                d: "M6 1C5.44772 1 5 1.44772 5 2C5 2.55228 5.44772 3 6 3H12C12.5523 3 13 2.55228 13 2C13 1.44772 12.5523 1 12 1H6ZM2 4C1.44772 4 1 4.44772 1 5C1 5.55228 1.44772 6 2 6H3V14C3 15.6569 4.34315 17 6 17H12C13.6569 17 15 15.6569 15 14V6H16C16.5523 6 17 5.55228 17 5C17 4.44772 16.5523 4 16 4H2ZM5 14V6H13V14C13 14.5523 12.5523 15 12 15H6C5.44772 15 5 14.5523 5 14Z",
                                                fill: "currentColor"
                                            })
                                        })
                                    }, "delete")
                                }), (0, c.jsx)(eX.M, {
                                    initial: !1,
                                    children: s !== l.id && (0, c.jsx)(P.m.button, {
                                        initial: {
                                            opacity: 0
                                        },
                                        animate: {
                                            opacity: 1
                                        },
                                        exit: {
                                            opacity: 0
                                        },
                                        className: (0, F.Z)("translate-0 absolute right-1 top-1 translate-x-1/2 -translate-y-1/2 rounded-full bg-black p-3 text-xs font-semibold text-white", ng().button),
                                        onClick: u,
                                        children: (0, c.jsx)(n_, {})
                                    }, "pencil")
                                }), (0, c.jsx)(eX.M, {
                                    initial: !1,
                                    children: s === l.id && (0, c.jsx)(P.m.button, {
                                        initial: {
                                            opacity: 0
                                        },
                                        animate: {
                                            opacity: 1
                                        },
                                        exit: {
                                            opacity: 0
                                        },
                                        className: (0, F.Z)("translate-0 absolute right-1 top-1 translate-x-1/2 -translate-y-1/2 rounded-full bg-action-green p-3 text-xs font-semibold text-white", ng().button),
                                        onClick: x,
                                        children: (0, c.jsx)(nw, {})
                                    }, "done")
                                })]
                            }), (0, c.jsx)("div", {
                                className: (0, F.Z)("transition-opacity duration-300", s === l.id && ng().hidden),
                                children: m
                            })]
                        }, "style-menu")
                    })
                };
            var nb = i(24441),
                nN = i.n(nb);
            let nC = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M17 9H3C2.50669 9 2.23688 9.00108 2.04183 9.01439C2.03276 9.01501 2.02424 9.01564 2.01626 9.01626C2.01564 9.02424 2.01501 9.03276 2.01439 9.04183C2.00108 9.23688 2 9.50669 2 10C2 10.4933 2.00108 10.7631 2.01439 10.9582C2.01501 10.9672 2.01564 10.9758 2.01626 10.9837C2.02424 10.9844 2.03276 10.985 2.04183 10.9856C2.23688 10.9989 2.50669 11 3 11H17C17.4933 11 17.7631 10.9989 17.9582 10.9856C17.9672 10.985 17.9758 10.9844 17.9837 10.9837C17.9844 10.9758 17.985 10.9672 17.9856 10.9582C17.9989 10.7631 18 10.4933 18 10C18 9.50669 17.9989 9.23688 17.9856 9.04183C17.985 9.03276 17.9844 9.02424 17.9837 9.01626C17.9758 9.01564 17.9672 9.01501 17.9582 9.01439C17.7631 9.00108 17.4933 9 17 9ZM0.152241 8.23463C0 8.60218 0 9.06812 0 10C0 10.9319 0 11.3978 0.152241 11.7654C0.355229 12.2554 0.744577 12.6448 1.23463 12.8478C1.60218 13 2.06812 13 3 13H17C17.9319 13 18.3978 13 18.7654 12.8478C19.2554 12.6448 19.6448 12.2554 19.8478 11.7654C20 11.3978 20 10.9319 20 10C20 9.06812 20 8.60218 19.8478 8.23463C19.6448 7.74458 19.2554 7.35523 18.7654 7.15224C18.3978 7 17.9319 7 17 7H3C2.06812 7 1.60218 7 1.23463 7.15224C0.744577 7.35523 0.355229 7.74458 0.152241 8.23463Z",
                            fill: "currentColor"
                        })
                    })
                },
                nk = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M13.6 2H6.4C5.24689 2 4.50235 2.00156 3.93567 2.04785C3.39235 2.09225 3.19091 2.1676 3.09202 2.21799C2.71569 2.40973 2.40973 2.71569 2.21799 3.09202C2.1676 3.19091 2.09225 3.39235 2.04785 3.93567C2.00156 4.50235 2 5.24689 2 6.4V13.6C2 14.7531 2.00156 15.4977 2.04785 16.0643C2.09225 16.6077 2.1676 16.8091 2.21799 16.908C2.40973 17.2843 2.71569 17.5903 3.09202 17.782C3.19091 17.8324 3.39235 17.9078 3.93567 17.9521C4.50235 17.9984 5.24689 18 6.4 18H13.6C14.7531 18 15.4977 17.9984 16.0643 17.9521C16.6077 17.9078 16.8091 17.8324 16.908 17.782C17.2843 17.5903 17.5903 17.2843 17.782 16.908C17.8324 16.8091 17.9078 16.6077 17.9521 16.0643C17.9984 15.4977 18 14.7531 18 13.6V6.4C18 5.24689 17.9984 4.50235 17.9521 3.93567C17.9078 3.39235 17.8324 3.19091 17.782 3.09202C17.5903 2.71569 17.2843 2.40973 16.908 2.21799C16.8091 2.1676 16.6077 2.09225 16.0643 2.04785C15.4977 2.00156 14.7531 2 13.6 2ZM0.435974 2.18404C0 3.03969 0 4.15979 0 6.4V13.6C0 15.8402 0 16.9603 0.435974 17.816C0.819467 18.5686 1.43139 19.1805 2.18404 19.564C3.03969 20 4.15979 20 6.4 20H13.6C15.8402 20 16.9603 20 17.816 19.564C18.5686 19.1805 19.1805 18.5686 19.564 17.816C20 16.9603 20 15.8402 20 13.6V6.4C20 4.15979 20 3.03969 19.564 2.18404C19.1805 1.43139 18.5686 0.819467 17.816 0.435974C16.9603 0 15.8402 0 13.6 0H6.4C4.15979 0 3.03969 0 2.18404 0.435974C1.43139 0.819467 0.819467 1.43139 0.435974 2.18404Z",
                            fill: "currentColor"
                        })
                    })
                },
                nE = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M11.8 7H8.2C7.60695 7 7.28244 7.00156 7.04927 7.02061C7.03998 7.02136 7.0312 7.02213 7.0229 7.0229C7.02213 7.0312 7.02136 7.03998 7.02061 7.04927C7.00156 7.28244 7 7.60695 7 8.2V11.8C7 12.3931 7.00156 12.7176 7.02061 12.9507C7.02136 12.96 7.02213 12.9688 7.0229 12.9771C7.0312 12.9779 7.03998 12.9786 7.04927 12.9794C7.28244 12.9984 7.60695 13 8.2 13H11.8C12.3931 13 12.7176 12.9984 12.9507 12.9794C12.96 12.9786 12.9688 12.9779 12.9771 12.9771C12.9779 12.9688 12.9786 12.96 12.9794 12.9507C12.9984 12.7176 13 12.3931 13 11.8V8.2C13 7.60695 12.9984 7.28244 12.9794 7.04927C12.9786 7.03998 12.9779 7.0312 12.9771 7.0229C12.9688 7.02213 12.96 7.02136 12.9507 7.02061C12.7176 7.00156 12.3931 7 11.8 7ZM5.21799 6.09202C5 6.51984 5 7.0799 5 8.2V11.8C5 12.9201 5 13.4802 5.21799 13.908C5.40973 14.2843 5.71569 14.5903 6.09202 14.782C6.51984 15 7.0799 15 8.2 15H11.8C12.9201 15 13.4802 15 13.908 14.782C14.2843 14.5903 14.5903 14.2843 14.782 13.908C15 13.4802 15 12.9201 15 11.8V8.2C15 7.0799 15 6.51984 14.782 6.09202C14.5903 5.71569 14.2843 5.40973 13.908 5.21799C13.4802 5 12.9201 5 11.8 5H8.2C7.0799 5 6.51984 5 6.09202 5.21799C5.71569 5.40973 5.40973 5.71569 5.21799 6.09202Z",
                            fill: "currentColor"
                        })
                    })
                },
                nS = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M15.2 7H4.8C3.92692 7 3.39239 7.00156 2.99247 7.03423C2.80617 7.04945 2.69345 7.06857 2.625 7.08469C2.59244 7.09236 2.57241 7.09879 2.56158 7.10265C2.55118 7.10636 2.54681 7.10858 2.54601 7.10899C2.35785 7.20487 2.20487 7.35785 2.10899 7.54601C2.10858 7.54681 2.10636 7.55118 2.10265 7.56158C2.09879 7.57241 2.09236 7.59244 2.08469 7.625C2.06857 7.69345 2.04945 7.80617 2.03423 7.99247C2.00156 8.39239 2 8.92692 2 9.8V10.2C2 11.0731 2.00156 11.6076 2.03423 12.0075C2.04945 12.1938 2.06857 12.3065 2.08469 12.375C2.09236 12.4076 2.09879 12.4276 2.10265 12.4384C2.10636 12.4488 2.10858 12.4532 2.10899 12.454C2.20487 12.6422 2.35785 12.7951 2.54601 12.891C2.54681 12.8914 2.55118 12.8936 2.56158 12.8973C2.57241 12.9012 2.59244 12.9076 2.625 12.9153C2.69345 12.9314 2.80617 12.9505 2.99247 12.9658C3.39239 12.9984 3.92692 13 4.8 13H15.2C16.0731 13 16.6076 12.9984 17.0075 12.9658C17.1938 12.9505 17.3065 12.9314 17.375 12.9153C17.4076 12.9076 17.4276 12.9012 17.4384 12.8973C17.4488 12.8936 17.4532 12.8914 17.454 12.891C17.6422 12.7951 17.7951 12.6422 17.891 12.454C17.8914 12.4532 17.8936 12.4488 17.8973 12.4384C17.9012 12.4276 17.9076 12.4076 17.9153 12.375C17.9314 12.3065 17.9505 12.1938 17.9658 12.0075C17.9984 11.6076 18 11.0731 18 10.2V9.8C18 8.92692 17.9984 8.39239 17.9658 7.99247C17.9505 7.80617 17.9314 7.69345 17.9153 7.625C17.9076 7.59244 17.9012 7.57241 17.8973 7.56158C17.8936 7.55118 17.8914 7.54681 17.891 7.54601C17.7951 7.35785 17.6422 7.20487 17.454 7.10899C17.4532 7.10858 17.4488 7.10636 17.4384 7.10265C17.4276 7.09879 17.4076 7.09236 17.375 7.08469C17.3065 7.06857 17.1938 7.04945 17.0075 7.03423C16.6076 7.00156 16.0731 7 15.2 7ZM0.32698 6.63803C0 7.27976 0 8.11984 0 9.8V10.2C0 11.8802 0 12.7202 0.32698 13.362C0.614601 13.9265 1.07354 14.3854 1.63803 14.673C2.27976 15 3.11984 15 4.8 15H15.2C16.8802 15 17.7202 15 18.362 14.673C18.9265 14.3854 19.3854 13.9265 19.673 13.362C20 12.7202 20 11.8802 20 10.2V9.8C20 8.11984 20 7.27976 19.673 6.63803C19.3854 6.07354 18.9265 5.6146 18.362 5.32698C17.7202 5 16.8802 5 15.2 5H4.8C3.11984 5 2.27976 5 1.63803 5.32698C1.07354 5.6146 0.614601 6.07354 0.32698 6.63803Z",
                            fill: "currentColor"
                        })
                    })
                },
                nL = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 20 20",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M10.2 2H9.8C8.92692 2 8.39239 2.00156 7.99247 2.03423C7.80617 2.04945 7.69345 2.06857 7.625 2.08469C7.59244 2.09236 7.57241 2.09879 7.56158 2.10265C7.55118 2.10636 7.54681 2.10858 7.54601 2.10899C7.35785 2.20487 7.20487 2.35785 7.10899 2.54601C7.10858 2.54681 7.10636 2.55118 7.10265 2.56158C7.09879 2.57241 7.09236 2.59244 7.08469 2.625C7.06857 2.69345 7.04945 2.80617 7.03423 2.99247C7.00156 3.39239 7 3.92692 7 4.8V15.2C7 16.0731 7.00156 16.6076 7.03423 17.0075C7.04945 17.1938 7.06857 17.3065 7.08469 17.375C7.09236 17.4076 7.09879 17.4276 7.10265 17.4384C7.10636 17.4488 7.10858 17.4532 7.10899 17.454C7.20487 17.6422 7.35785 17.7951 7.54601 17.891C7.54681 17.8914 7.55118 17.8936 7.56158 17.8973C7.57241 17.9012 7.59244 17.9076 7.625 17.9153C7.69345 17.9314 7.80617 17.9505 7.99247 17.9658C8.39239 17.9984 8.92692 18 9.8 18H10.2C11.0731 18 11.6076 17.9984 12.0075 17.9658C12.1938 17.9505 12.3065 17.9314 12.375 17.9153C12.4076 17.9076 12.4276 17.9012 12.4384 17.8973C12.4488 17.8936 12.4532 17.8914 12.454 17.891C12.6422 17.7951 12.7951 17.6422 12.891 17.454C12.8914 17.4532 12.8936 17.4488 12.8973 17.4384C12.9012 17.4276 12.9076 17.4076 12.9153 17.375C12.9314 17.3065 12.9505 17.1938 12.9658 17.0075C12.9984 16.6076 13 16.0731 13 15.2V4.8C13 3.92692 12.9984 3.39239 12.9658 2.99247C12.9505 2.80617 12.9314 2.69345 12.9153 2.625C12.9076 2.59244 12.9012 2.57241 12.8973 2.56158C12.8936 2.55118 12.8914 2.54681 12.891 2.54601C12.7951 2.35785 12.6422 2.20487 12.454 2.10899C12.4532 2.10858 12.4488 2.10636 12.4384 2.10265C12.4276 2.09879 12.4076 2.09236 12.375 2.08469C12.3065 2.06857 12.1938 2.04945 12.0075 2.03423C11.6076 2.00156 11.0731 2 10.2 2ZM5.32698 1.63803C5 2.27976 5 3.11984 5 4.8V15.2C5 16.8802 5 17.7202 5.32698 18.362C5.6146 18.9265 6.07354 19.3854 6.63803 19.673C7.27976 20 8.11984 20 9.8 20H10.2C11.8802 20 12.7202 20 13.362 19.673C13.9265 19.3854 14.3854 18.9265 14.673 18.362C15 17.7202 15 16.8802 15 15.2V4.8C15 3.11984 15 2.27976 14.673 1.63803C14.3854 1.07354 13.9265 0.614601 13.362 0.32698C12.7202 0 11.8802 0 10.2 0H9.8C8.11984 0 7.27976 0 6.63803 0.32698C6.07354 0.614601 5.6146 1.07354 5.32698 1.63803Z",
                            fill: "currentColor"
                        })
                    })
                },
                nI = (0, M.forwardRef)((e, t) => {
                    let {
                        className: i,
                        children: l
                    } = e;
                    return (0, c.jsx)("div", {
                        className: (0, F.Z)(nN().menu, i),
                        ref: t,
                        children: l
                    })
                });
            nI.displayName = "MenuWrapper";
            var nD = i(48813),
                nZ = i.n(nD);
            let nz = e => {
                let {
                    selected: t,
                    onClick: i,
                    disabled: l = !1,
                    children: s
                } = e;
                return (0, c.jsx)(b.z, {
                    className: nZ()["style-button"],
                    disabled: l,
                    variant: t ? "white" : "primary",
                    onClick: i,
                    children: s
                })
            };
            var nA = i(9697),
                nF = i.n(nA);
            let nM = e => {
                    let {
                        onClick: t,
                        children: i
                    } = e;
                    return (0, c.jsx)(b.z, {
                        className: nF()["done-button"],
                        variant: "success",
                        onClick: t,
                        children: i
                    })
                },
                nT = e => {
                    let {
                        className: t,
                        children: i,
                        scrollable: l = !1
                    } = e;
                    return (0, c.jsx)("div", {
                        className: (0, F.Z)("relative pb-4", !l && "left-1/2 w-[min(calc(100%-32px),400px)] -translate-x-1/2", l && "no-scrollbar flex w-full overflow-auto px-4 xl:overflow-visible", t),
                        children: i
                    })
                },
                nO = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), s = e9(e => e.setSelectedId), n = (0, eL.$)(), a = (0, _.f6)(i.style, n), r = e => () => {
                        (0, z.c)().track("LINK_STYLE_CHANGED", {
                            from: i.style[n],
                            to: e,
                            device: n
                        }), ei.f.resizedWidget(i.id), l({
                            type: "set-bento-item",
                            bento: { ...i,
                                style: (0, _.gN)(i.style, e, n)
                            }
                        })
                    }, o = () => s(void 0);
                    return (0, c.jsx)(nT, {
                        children: (0, c.jsxs)(nI, {
                            className: "flex flex-col gap-3 xxs:flex-row",
                            children: [(0, c.jsxs)("div", {
                                className: "flex flex-1 flex-row justify-between space-x-2 xxs:justify-start",
                                children: [(0, c.jsx)(nz, {
                                    selected: "2x2" === a,
                                    onClick: r("2x2"),
                                    children: (0, c.jsx)(nE, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "1x4" === a,
                                    onClick: r("1x4"),
                                    children: (0, c.jsx)(nC, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "2x4" === a,
                                    onClick: r("2x4"),
                                    children: (0, c.jsx)(nS, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x2" === a,
                                    onClick: r("4x2"),
                                    children: (0, c.jsx)(nL, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x4" === a,
                                    onClick: r("4x4"),
                                    children: (0, c.jsx)(nk, {
                                        size: 18
                                    })
                                })]
                            }), (0, c.jsx)("div", {
                                className: "w-full xxs:w-[100px]",
                                children: (0, c.jsx)(nM, {
                                    onClick: o,
                                    children: (0, c.jsx)("div", {
                                        className: "whitespace-nowrap",
                                        children: "Done"
                                    })
                                })
                            })]
                        })
                    })
                },
                nR = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), s = (0, eL.$)(), n = (0, _.f6)(i.style, s), a = e9(e => e.setSelectedId), r = e => () => {
                        (0, z.c)().track("MEDIA_STYLE_CHANGED", {
                            from: i.style[s],
                            to: e,
                            device: s
                        }), ei.f.resizedWidget(i.id), l({
                            type: "set-bento-item",
                            bento: { ...i,
                                style: (0, _.gN)(i.style, e, s)
                            }
                        })
                    }, o = () => a(void 0);
                    return (0, c.jsx)(nT, {
                        children: (0, c.jsxs)(nI, {
                            className: "flex flex-row gap-3",
                            children: [(0, c.jsxs)("div", {
                                className: "flex flex-1 flex-row justify-between space-x-2 xxs:justify-start",
                                children: [(0, c.jsx)(nz, {
                                    selected: "2x2" === n,
                                    onClick: r("2x2"),
                                    children: (0, c.jsx)(nE, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "2x4" === n,
                                    onClick: r("2x4"),
                                    children: (0, c.jsx)(nS, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x2" === n,
                                    onClick: r("4x2"),
                                    children: (0, c.jsx)(nL, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x4" === n,
                                    onClick: r("4x4"),
                                    children: (0, c.jsx)(nk, {
                                        size: 18
                                    })
                                })]
                            }), (0, c.jsx)("div", {
                                className: "w-full xxs:w-[100px]",
                                children: (0, c.jsx)(nM, {
                                    onClick: o,
                                    children: (0, c.jsx)("div", {
                                        className: "whitespace-nowrap",
                                        children: "Done"
                                    })
                                })
                            })]
                        })
                    })
                },
                nB = e => {
                    let {
                        className: t,
                        data: i
                    } = e, l = e9(e => e.setSelectedId), s = () => l(void 0), n = "section-header" === i.type ? "Section Title" : "Widget";
                    return (0, c.jsx)(nT, {
                        children: (0, c.jsxs)(nI, {
                            className: "flex flex-col gap-3 xxs:flex-row",
                            children: [(0, c.jsx)("div", {
                                className: "mr-3 flex flex-1 flex-row items-center whitespace-nowrap pl-2 text-sm text-white/60",
                                children: n
                            }), (0, c.jsx)("div", {
                                className: "w-full xxs:w-[100px]",
                                children: (0, c.jsx)(nM, {
                                    onClick: s,
                                    children: (0, c.jsx)("div", {
                                        className: "whitespace-nowrap",
                                        children: "Done"
                                    })
                                })
                            })]
                        })
                    })
                },
                nH = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "1",
                            y: "2",
                            width: "16",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "1",
                            y: "14",
                            width: "16",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "1",
                            y: "8",
                            width: "8",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        })]
                    })
                },
                nU = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "1",
                            y: "2",
                            width: "16",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "1",
                            y: "14",
                            width: "16",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "5",
                            y: "8",
                            width: "8",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        })]
                    })
                },
                nV = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "1",
                            y: "2",
                            width: "16",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "1",
                            y: "14",
                            width: "16",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "9",
                            y: "8",
                            width: "8",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        })]
                    })
                },
                nP = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "2",
                            y: "17",
                            width: "16",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 2 17)",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "14",
                            y: "17",
                            width: "16",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 14 17)",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "8",
                            y: "9",
                            width: "8",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 8 9)",
                            fill: "currentColor"
                        })]
                    })
                },
                nG = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "2",
                            y: "17",
                            width: "16",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 2 17)",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "14",
                            y: "17",
                            width: "16",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 14 17)",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "8",
                            y: "13",
                            width: "8",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 8 13)",
                            fill: "currentColor"
                        })]
                    })
                },
                nW = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "2",
                            y: "17",
                            width: "16",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 2 17)",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "14",
                            y: "17",
                            width: "16",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 14 17)",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            x: "8",
                            y: "17",
                            width: "8",
                            height: "2",
                            rx: "1",
                            transform: "rotate(-90 8 17)",
                            fill: "currentColor"
                        })]
                    })
                };
            var nJ = i(1547),
                nY = i(13361);
            let nq = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), [s, n] = (0, M.useState)(!1), [a, r] = (0, M.useState)(!0), o = (0, eL.$)(), d = (0, _.f6)(i.style, o), [u, x] = (0, M.useState)(null), h = (0, M.useMemo)(() => (0, nY.C)(), []), m = (0, na.iJ)((0, ih.V)(i.content, h)), [p, v] = (0, M.useState)(i.href), g = (0, _.f6)(i.halign, o), f = (0, _.f6)(i.valign, o);
                    "center" === g && "quote" === m && (g = "left"), "top" !== f && "quote" === m && (f = "top"), "middle" !== f && "1x4" === d && (f = "middle"), (0, M.useEffect)(() => {
                        if (u) {
                            let e = () => {
                                u.scrollLeft >= u.scrollWidth - u.clientWidth - 10 ? s || n(!0) : s && n(!1), u.scrollLeft < 10 ? a || r(!0) : a && r(!1)
                            };
                            return u.addEventListener("scroll", e), () => {
                                u.removeEventListener("scroll", e)
                            }
                        }
                    }, [u, s, a]);
                    let w = e => () => {
                            l({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: i.id,
                                    valign: (0, _.gN)(i.valign, e, o)
                                }
                            })
                        },
                        y = e => () => {
                            l({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: i.id,
                                    halign: (0, _.gN)(i.halign, e, o)
                                }
                            })
                        },
                        b = e => () => {
                            l({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: i.id,
                                    bg: e
                                }
                            })
                        },
                        N = () => {
                            let e = (0, _.QY)(null != p ? p : "");
                            e !== i.href && (e ? (0, z.c)().track("WIDGET_LINK_ADDED", {
                                type: "media",
                                hostname: (0, _.w6)(e).hostname,
                                protocol: (0, _.w6)(e).protocol
                            }) : (0, z.c)().track("WIDGET_LINK_REMOVED", {
                                type: "media"
                            }), l({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: i.id,
                                    href: e
                                }
                            }))
                        };
                    return (0, c.jsx)(nT, {
                        scrollable: !0,
                        children: (0, c.jsxs)("div", {
                            className: "relative",
                            children: [(0, c.jsx)(nI, {
                                className: "no-scrollbar relative mx-auto flex flex-col gap-3 xxs:flex-row xl:max-w-[320px] xl:overflow-auto",
                                ref: x,
                                children: (0, c.jsxs)("div", {
                                    className: "flex flex-1 flex-row items-center justify-between space-x-2 xxs:justify-start",
                                    children: [(0, c.jsx)(nz, {
                                        selected: "left" === g,
                                        onClick: y("left"),
                                        children: (0, c.jsx)(nH, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(nz, {
                                        selected: "center" === g,
                                        disabled: "quote" === m,
                                        onClick: y("center"),
                                        children: (0, c.jsx)(nU, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(nz, {
                                        selected: "right" === g,
                                        onClick: y("right"),
                                        children: (0, c.jsx)(nV, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                    }), (0, c.jsx)(nz, {
                                        selected: "top" === f,
                                        disabled: "1x4" === d,
                                        onClick: w("top"),
                                        children: (0, c.jsx)(nP, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(nz, {
                                        selected: "middle" === f,
                                        disabled: "quote" === m && "1x4" !== d,
                                        onClick: w("middle"),
                                        children: (0, c.jsx)(nG, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(nz, {
                                        selected: "bottom" === f,
                                        disabled: "1x4" === d || "quote" === m,
                                        onClick: w("bottom"),
                                        children: (0, c.jsx)(nW, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                    }), na.DM.map(e => (0, c.jsx)(nz, {
                                        onClick: b(e),
                                        selected: i.bg === e,
                                        children: (0, c.jsx)("div", {
                                            className: "rounded-full s-[18px]",
                                            style: {
                                                background: e,
                                                border: i.bg !== e ? "1px solid rgba(255,255,255,0.2)" : "1px solid rgba(0,0,0,0.12)"
                                            }
                                        })
                                    }, e)), (0, c.jsx)("input", {
                                        className: "h-[36px] w-[150px] rounded-[4px] bg-white/20 p-2 text-base text-white outline-none",
                                        placeholder: "#768CFF",
                                        onPaste: e => {
                                            let t = e.clipboardData.getData("text/plain");
                                            (0, nJ.Z)(t).isValid() && b(t)()
                                        },
                                        onChange: e => {
                                            let t = e.target.value;
                                            (0, nJ.Z)(t).isValid() && b(t)()
                                        }
                                    }), (0, c.jsx)("div", {
                                        className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                    }), (0, c.jsxs)("div", {
                                        className: "relative",
                                        children: [(0, c.jsx)("div", {
                                            className: "absolute left-2 top-0 bottom-0 flex items-center text-white",
                                            children: (0, c.jsx)(eb.x, {})
                                        }), (0, c.jsx)("input", {
                                            value: null != p ? p : "",
                                            className: "h-[36px] w-[190px] rounded-[4px] bg-white/20 py-2 pr-2 pl-8 text-base text-white outline-none",
                                            placeholder: "Enter a Link",
                                            onChange: e => {
                                                v(e.target.value)
                                            },
                                            onBlur: N
                                        })]
                                    })]
                                })
                            }), (0, c.jsx)("div", {
                                className: (0, F.Z)("pointer-events-none absolute right-0 top-0 z-10 hidden h-full w-[24px] rounded-r-[16px] bg-[linear-gradient(90deg,rgba(0,0,0,0)_0%,#000000_100%)] transition-all duration-1000 xl:block", s && "opacity-0")
                            }), (0, c.jsx)("div", {
                                className: (0, F.Z)("pointer-events-none absolute left-0 top-0 z-10 hidden h-full w-[24px] rounded-l-[16px] bg-[linear-gradient(270deg,rgba(0,0,0,0)_0%,#000000_100%)] transition-all duration-1000 xl:block", a && "opacity-0")
                            })]
                        })
                    })
                },
                nK = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), s = (0, eF.W)(e => e.focused), n = e9(e => e.setSelectedId), a = (0, eL.$)(), r = (0, _.f6)(i.style, a), o = e => () => {
                        (0, z.c)().track("RICH_TEXT_STYLE_CHANGED", {
                            from: i.style[a],
                            to: e,
                            device: a
                        }), ei.f.resizedWidget(i.id), l({
                            type: "set-bento-item-partial",
                            bento: {
                                id: i.id,
                                style: (0, _.gN)(i.style, e, a)
                            }
                        })
                    }, d = () => n(void 0);
                    return s === i.id ? (0, c.jsx)(nq, {
                        data: i
                    }) : (0, c.jsx)(nT, {
                        children: (0, c.jsxs)(nI, {
                            className: "flex flex-col gap-3 xxs:flex-row",
                            children: [(0, c.jsxs)("div", {
                                className: "flex flex-1 flex-row justify-between space-x-2 xxs:justify-start",
                                children: [(0, c.jsx)(nz, {
                                    selected: "2x2" === r,
                                    onClick: o("2x2"),
                                    children: (0, c.jsx)(nE, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "1x4" === r,
                                    onClick: o("1x4"),
                                    children: (0, c.jsx)(nC, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "2x4" === r,
                                    onClick: o("2x4"),
                                    children: (0, c.jsx)(nS, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x2" === r,
                                    onClick: o("4x2"),
                                    children: (0, c.jsx)(nL, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x4" === r,
                                    onClick: o("4x4"),
                                    children: (0, c.jsx)(nk, {
                                        size: 18
                                    })
                                })]
                            }), (0, c.jsx)("div", {
                                className: "w-full xxs:w-[100px]",
                                children: (0, c.jsx)(nM, {
                                    onClick: d,
                                    children: (0, c.jsx)("div", {
                                        className: "whitespace-nowrap",
                                        children: "Done"
                                    })
                                })
                            })]
                        })
                    })
                },
                nX = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), s = e9(e => e.setSelectedId), n = (0, eL.$)(), a = (0, _.f6)(i.style, n), r = e => () => {
                        (0, z.c)().track("LINK_STYLE_CHANGED", {
                            from: i.style[n],
                            to: e,
                            device: n
                        }), ei.f.resizedWidget(i.id), l({
                            type: "set-bento-item",
                            bento: { ...i,
                                style: (0, _.gN)(i.style, e, n)
                            }
                        })
                    }, o = () => s(void 0);
                    return (0, c.jsx)(nT, {
                        children: (0, c.jsxs)(nI, {
                            className: "flex flex-col gap-3 xxs:flex-row",
                            children: [(0, c.jsxs)("div", {
                                className: "flex flex-1 flex-row justify-between space-x-2 xxs:justify-start",
                                children: [(0, c.jsx)(nz, {
                                    selected: "2x2" === a,
                                    onClick: r("2x2"),
                                    children: (0, c.jsx)(nE, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "2x4" === a,
                                    onClick: r("2x4"),
                                    children: (0, c.jsx)(nS, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x2" === a,
                                    onClick: r("4x2"),
                                    children: (0, c.jsx)(nL, {
                                        size: 18
                                    })
                                }), (0, c.jsx)(nz, {
                                    selected: "4x4" === a,
                                    onClick: r("4x4"),
                                    children: (0, c.jsx)(nk, {
                                        size: 18
                                    })
                                })]
                            }), (0, c.jsx)("div", {
                                className: "w-full xxs:w-[100px]",
                                children: (0, c.jsx)(nM, {
                                    onClick: o,
                                    children: (0, c.jsx)("div", {
                                        className: "whitespace-nowrap",
                                        children: "Done"
                                    })
                                })
                            })]
                        })
                    })
                },
                n$ = e => {
                    let {
                        data: t
                    } = e, i = null;
                    if ("ghost" !== t.type) switch (t.type) {
                        case "link":
                            let l = (0, eB.X)(t.href);
                            i = l && el.vT.includes(l.name) ? (0, c.jsx)(nX, {
                                data: t
                            }) : (0, c.jsx)(nO, {
                                data: t
                            });
                            break;
                        case "media":
                            i = (0, c.jsx)(nR, {
                                data: t
                            });
                            break;
                        case "rich-text":
                            i = (0, c.jsx)(nK, {
                                data: t
                            });
                            break;
                        default:
                            i = (0, c.jsx)(nB, {
                                data: t
                            })
                    }
                    return i
                },
                nQ = e => {
                    let {
                        data: t,
                        ...i
                    } = e, l = e9(e => e.selectedId), s = (0, eM.H)(), n = (0, eL.$)();
                    return "touch" !== s ? null : (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)(ny, {
                            data: t,
                            selected: l === t.id
                        }, "generic"), "desktop" === n && (0, c.jsx)(eX.M, {
                            children: l === t.id && (0, c.jsx)(P.m.div, {
                                initial: {
                                    opacity: 0
                                },
                                animate: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                "data-bento-menu": !0,
                                children: (0, c.jsx)("div", {
                                    className: (0, F.Z)(nN()["attached-menu"]),
                                    children: (0, c.jsx)(n$, {
                                        data: t
                                    })
                                })
                            })
                        })]
                    })
                };
            var n0 = i(70873),
                n1 = i.n(n0);
            let n2 = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), s = e9(e => e.hoveredId), n = (0, eZ.A)(e => e.dragging), a = (0, s2.c)(e => e.cropping), r = () => {
                        (0, z.c)().track("WIDGET_REMOVED", {
                            type: i.type
                        }), ei.f.removedWidget(i.id), l({
                            type: "delete-bento-item",
                            id: i.id
                        })
                    };
                    return (0, c.jsx)(eX.M, {
                        children: s === i.id && !a && !n && (0, c.jsx)(P.m.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3,
                                ease: e$.V
                            },
                            className: t,
                            children: (0, c.jsx)("div", {
                                className: (0, F.Z)("absolute -left-2.5 -top-2.5 z-30"),
                                children: (0, c.jsx)(R, {
                                    size: 24,
                                    className: n1()["delete-button"],
                                    onClick: r,
                                    children: (0, c.jsx)(i_, {})
                                })
                            })
                        }, "generic-menu")
                    })
                },
                n4 = (0, M.forwardRef)((e, t) => {
                    let {
                        children: i,
                        selected: l,
                        onClick: s,
                        variant: n = "default",
                        disabled: a = !1,
                        ...r
                    } = e;
                    return (0, c.jsx)("button", {
                        ref: t,
                        ...r,
                        onClick: s,
                        disabled: a,
                        className: (0, F.Z)(n1()["style-button"], "rounded-[4px] outline-none disabled:text-white/40 not-disabled:active:scale-90", !l && " text-white not-disabled:active:!bg-white/30 not-disabled:active:!text-white", l && "default" === n && "bg-white text-black hover:bg-white/+2 active:bg-white/+8", l && "subtle" === n && "bg-white/30 text-white", l && "mode" === n && "bg-action-green text-white"),
                        children: i
                    })
                });
            n4.displayName = "StyleButton";
            var n5 = i(23839),
                n9 = i(77720),
                n7 = i.n(n9);
            let n3 = e => {
                    let {
                        className: t,
                        trigger: i,
                        children: l,
                        open: s,
                        setOpen: n,
                        layoutId: a,
                        asChildTrigger: r = !1,
                        asChildContent: o = !1,
                        side: d,
                        sideOffset: u = 12,
                        alignOffset: x = 0,
                        align: h = "center",
                        variant: m = "default",
                        portal: p = !0,
                        modal: v = !0,
                        animation: g = "default",
                        ...f
                    } = e, [_, j] = (0, M.useState)(null), [w, y] = (0, M.useState)(null);
                    (0, M.useEffect)(() => {
                        var e;
                        j(null !== (e = null == w ? void 0 : w.ownerDocument.body) && void 0 !== e ? e : null)
                    }, [w]);
                    let b = (0, c.jsx)(n5.VY, {
                        className: (0, F.Z)(n7().content, n7()["content--".concat(m)], n7()["content--animation-".concat(g)], t),
                        side: d,
                        asChild: o,
                        sideOffset: u,
                        alignOffset: x,
                        align: h,
                        ...f,
                        children: (0, c.jsx)(c.Fragment, {
                            children: l
                        })
                    });
                    return (0, c.jsxs)(n5.fC, {
                        modal: v,
                        open: s,
                        onOpenChange: n,
                        children: [(0, c.jsx)(n5.xz, {
                            ref: y,
                            asChild: r,
                            children: i
                        }), p ? (0, c.jsx)(n5.h_, {
                            container: _,
                            children: b
                        }) : b]
                    })
                },
                n6 = n5.x8,
                n8 = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("path", {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M1 2C1 1.44772 1.44772 1 2 1H7C7.55228 1 8 1.44772 8 2C8 2.55228 7.55228 3 7 3H3V7C3 7.55228 2.55228 8 2 8C1.44772 8 1 7.55228 1 7V2Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M10 2C10 1.44772 10.4477 1 11 1H16C16.5523 1 17 1.44772 17 2V7C17 7.55228 16.5523 8 16 8C15.4477 8 15 7.55228 15 7V3H11C10.4477 3 10 2.55228 10 2Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M16 10C16.5523 10 17 10.4477 17 11V16C17 16.5523 16.5523 17 16 17H11C10.4477 17 10 16.5523 10 16C10 15.4477 10.4477 15 11 15H15V11C15 10.4477 15.4477 10 16 10Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M2 10C2.55228 10 3 10.4477 3 11V15H7C7.55228 15 8 15.4477 8 16C8 16.5523 7.55228 17 7 17H2C1.44772 17 1 16.5523 1 16V11C1 10.4477 1.44772 10 2 10Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            d: "M2 2L6.5 6.5",
                            stroke: "currentColor",
                            "stroke-width": "2",
                            "stroke-linecap": "round"
                        }), (0, c.jsx)("path", {
                            d: "M16 2L11.5 6.5",
                            stroke: "currentColor",
                            "stroke-width": "2",
                            "stroke-linecap": "round"
                        }), (0, c.jsx)("path", {
                            d: "M16 16L11.5 11.5",
                            stroke: "currentColor",
                            "stroke-width": "2",
                            "stroke-linecap": "round"
                        }), (0, c.jsx)("path", {
                            d: "M2 16L6.5 11.5",
                            stroke: "currentColor",
                            "stroke-width": "2",
                            "stroke-linecap": "round"
                        })]
                    })
                },
                ae = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("circle", {
                            cx: "8",
                            cy: "8",
                            r: "6",
                            stroke: "currentColor",
                            "stroke-width": "2"
                        }), (0, c.jsx)("path", {
                            d: "M16 16L12.5 12.5",
                            stroke: "currentColor",
                            "stroke-width": "2",
                            "stroke-linecap": "round"
                        })]
                    })
                },
                at = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M3 9C3 8.44772 3.44772 8 4 8H14C14.5523 8 15 8.44772 15 9C15 9.55228 14.5523 10 14 10H4C3.44772 10 3 9.55228 3 9Z",
                            fill: "currentColor"
                        })
                    })
                },
                ai = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("path", {
                            d: "M9 4V14",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            strokeLinecap: "round"
                        }), (0, c.jsx)("path", {
                            d: "M4 9H14",
                            stroke: "currentColor",
                            strokeWidth: "2",
                            strokeLinecap: "round"
                        })]
                    })
                },
                al = sR()(() => i.e(215).then(i.bind(i, 91215)).then(e => e.SearchBox), {
                    loadableGenerated: {
                        webpack: () => [91215]
                    },
                    ssr: !1
                }),
                as = e => {
                    var t, i;
                    let {
                        className: l,
                        data: s
                    } = e, [, n] = (0, j.U)(), a = (0, eL.$)(), [r, o] = (0, M.useState)(!1), [d, u] = (0, M.useState)(!1), [x, h] = e9(e => [e.hoveredId, e.setLocked]), m = (0, eZ.A)(e => e.dragging), p = (0, _.OX)(s.style, a), [v, g] = (0, tR.A)(e => [e.highlighting, e.setHighlighting]);
                    (0, M.useEffect)(() => {
                        x !== s.id && o(!1)
                    }, [x, s.id]), (0, M.useEffect)(() => {
                        v || h(!1)
                    }, [v]);
                    let f = e => () => {
                            (0, z.c)().track("LINK_STYLE_CHANGED", {
                                from: s.style[a],
                                to: e,
                                device: a
                            }), ei.f.resizedWidget(s.id), n({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: s.id,
                                    style: (0, _.gN)(s.style, e, a)
                                }
                            })
                        },
                        w = (e, t, i, l) => {
                            window.dispatchEvent(new CustomEvent("bento:map:locate", {
                                detail: {
                                    lat: e,
                                    lng: t,
                                    description: i,
                                    id: s.id,
                                    type: l
                                }
                            }))
                        },
                        y = null !== (i = null === (t = (0, eV.t)()) || void 0 === t ? void 0 : t.querySelector("[data-bento-container]")) && void 0 !== i ? i : document.querySelector("[data-bento-container]");
                    return (0, c.jsx)(eX.M, {
                        children: x === s.id && !m && (0, c.jsx)(P.m.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3,
                                ease: e$.V
                            },
                            className: l,
                            children: (0, c.jsxs)("div", {
                                className: (0, F.Z)(n1().menu),
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)(n1()["bottom-menu"], n1()["style-menu"]),
                                    children: [(0, c.jsx)(n4, {
                                        selected: "2x2" === p,
                                        onClick: f("2x2"),
                                        children: (0, c.jsx)(nE, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "2x4" === p,
                                        onClick: f("2x4"),
                                        children: (0, c.jsx)(nS, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x2" === p,
                                        onClick: f("4x2"),
                                        children: (0, c.jsx)(nL, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x4" === p,
                                        onClick: f("4x4"),
                                        children: (0, c.jsx)(nk, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                    }), (0, c.jsx)(n3, {
                                        asChildTrigger: !0,
                                        open: v === s.id,
                                        trigger: (0, c.jsx)(n4, {
                                            variant: "mode",
                                            selected: v === s.id,
                                            onClick: () => {
                                                g(e => e === s.id ? void 0 : s.id), h(v !== s.id)
                                            },
                                            children: (0, c.jsx)(n8, {
                                                size: 18
                                            })
                                        }),
                                        modal: !1,
                                        portal: !1,
                                        variant: "none",
                                        collisionPadding: 16,
                                        className: (0, F.Z)(n1().submenu),
                                        children: (0, c.jsxs)("div", {
                                            className: n1()["submenu-row"],
                                            children: [(0, c.jsx)(n4, {
                                                onClick: () => {
                                                    window.dispatchEvent(new CustomEvent("bento:map:zoomOut", {
                                                        detail: {
                                                            id: s.id
                                                        }
                                                    }))
                                                },
                                                children: (0, c.jsx)(at, {
                                                    size: 18
                                                })
                                            }), (0, c.jsx)(n4, {
                                                onClick: () => {
                                                    window.dispatchEvent(new CustomEvent("bento:map:zoomIn", {
                                                        detail: {
                                                            id: s.id
                                                        }
                                                    }))
                                                },
                                                children: (0, c.jsx)(ai, {
                                                    size: 18
                                                })
                                            })]
                                        })
                                    }), (0, c.jsx)(n3, {
                                        asChildTrigger: !0,
                                        open: r,
                                        setOpen: e => {
                                            e && g(void 0), o(e), setTimeout(() => {
                                                h(e)
                                            }, 0)
                                        },
                                        trigger: (0, c.jsxs)(n4, {
                                            selected: r,
                                            variant: "default",
                                            children: [(0, c.jsx)(ae, {
                                                size: 18
                                            }), " "]
                                        }),
                                        modal: !1,
                                        portal: !1,
                                        variant: "none",
                                        collisionPadding: 16,
                                        collisionBoundary: y,
                                        className: (0, F.Z)(n1().submenu),
                                        onOpenAutoFocus: e => {
                                            e.preventDefault()
                                        },
                                        children: (0, c.jsx)("div", {
                                            className: n1()["submenu-row"],
                                            children: (0, c.jsx)(al, {
                                                onLocate: w
                                            })
                                        })
                                    })]
                                }), (0, c.jsx)("div", {
                                    className: "hidden",
                                    children: (0, c.jsx)(al, {
                                        onLocate: w
                                    })
                                })]
                            })
                        }, x)
                    })
                },
                an = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), s = (0, eL.$)(), n = (0, _.OX)(i.style, s), a = (0, eZ.A)(e => e.dragging), r = e9(e => e.hoveredId), o = (0, el._N)(i.href), d = e => () => {
                        (0, z.c)().track("LINK_STYLE_CHANGED", {
                            from: i.style[s],
                            to: e,
                            device: s
                        }), ei.f.resizedWidget(i.id), l({
                            type: "set-bento-item-partial",
                            bento: {
                                id: i.id,
                                style: (0, _.gN)(i.style, e, s)
                            }
                        })
                    };
                    return o ? (0, c.jsx)(as, {
                        data: i,
                        className: t
                    }) : (0, c.jsx)(eX.M, {
                        children: r === i.id && !a && (0, c.jsx)(P.m.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3,
                                ease: e$.V
                            },
                            className: t,
                            children: (0, c.jsx)("div", {
                                className: (0, F.Z)(n1().menu),
                                children: (0, c.jsxs)("div", {
                                    className: (0, F.Z)(n1()["bottom-menu"], n1()["style-menu"]),
                                    children: [(0, c.jsx)(n4, {
                                        selected: "2x2" === n,
                                        onClick: d("2x2"),
                                        children: (0, c.jsx)(nE, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "1x4" === n,
                                        onClick: d("1x4"),
                                        children: (0, c.jsx)(nC, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "2x4" === n,
                                        onClick: d("2x4"),
                                        children: (0, c.jsx)(nS, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x2" === n,
                                        onClick: d("4x2"),
                                        children: (0, c.jsx)(nL, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x4" === n,
                                        onClick: d("4x4"),
                                        children: (0, c.jsx)(nk, {
                                            size: 18
                                        })
                                    })]
                                })
                            })
                        }, "style-menu")
                    })
                },
                aa = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M8.12132 13.7782L8.3434 13.5561C8.26452 14.283 8.5037 15.0379 9.06096 15.5951L9.06993 15.6041C7.10828 17.1337 4.26855 16.9965 2.46447 15.1924C0.511845 13.2398 0.511845 10.0739 2.46447 8.12132L3.87921 6.70658L3.87943 6.70635C4.26996 6.31583 4.90312 6.31583 5.29365 6.70635C5.68417 7.09688 5.68417 7.73004 5.29365 8.12056L5.29342 8.12079L3.87868 9.53553C2.70711 10.7071 2.70711 12.6066 3.87868 13.7782C5.05025 14.9497 6.94975 14.9497 8.12132 13.7782ZM13.7787 10.9492L13.7781 10.9486L13.778 10.9487C13.3875 11.3392 12.7543 11.3392 12.3638 10.9487C11.9733 10.5582 11.9733 9.925 12.3638 9.53448C12.3737 9.52459 12.3837 9.51496 12.3939 9.50558L13.7782 8.12132C14.9497 6.94975 14.9497 5.05025 13.7782 3.87868C12.6066 2.70711 10.7071 2.70711 9.53553 3.87868L8.12185 5.29236L8.12177 5.29244C7.73125 5.68296 7.09808 5.68296 6.70756 5.29244C6.31704 4.90192 6.31704 4.26875 6.70756 3.87823L6.70763 3.87815L8.12132 2.46447C10.0739 0.511845 13.2398 0.511845 15.1924 2.46447C17.145 4.41709 17.145 7.58291 15.1924 9.53553L13.7787 10.9492ZM11.6569 7.41353C12.0475 7.02301 12.0475 6.38984 11.6569 5.99932C11.2664 5.6088 10.6332 5.6088 10.2427 5.99932L6.00007 10.242C5.60955 10.6325 5.60955 11.2656 6.00007 11.6562C6.3906 12.0467 7.02376 12.0467 7.41429 11.6562L11.6569 7.41353ZM17.5352 12.5352C17.9258 12.1447 17.9258 11.5115 17.5352 11.121C17.1447 10.7305 16.5115 10.7305 16.121 11.121L12.8281 14.4139L11.5352 13.121C11.1447 12.7305 10.5115 12.7305 10.121 13.121C9.73049 13.5115 9.73049 14.1447 10.121 14.5352L12.121 16.5352C12.5115 16.9258 13.1447 16.9258 13.5352 16.5352L17.5352 12.5352Z",
                            fill: "currentColor"
                        })
                    })
                },
                ar = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("path", {
                            d: "M15 1C15 0.447715 14.5523 0 14 0C13.4477 0 13 0.447715 13 1V13H7V15H14C14.5523 15 15 14.5523 15 14V5H17C17.5523 5 18 4.55228 18 4C18 3.44772 17.5523 3 17 3H15V1Z",
                            fill: "currentColor"
                        }), (0, c.jsx)("path", {
                            d: "M3 15V17C3 17.5523 3.44772 18 4 18C4.55228 18 5 17.5523 5 17V5H11V3H4C3.44772 3 3 3.44772 3 4V13H1C0.447715 13 0 13.4477 0 14C0 14.5523 0.447715 15 1 15H3Z",
                            fill: "currentColor"
                        })]
                    })
                },
                ao = {
                    "1x4": 4,
                    "2x2": 1,
                    "2x4": 2.22,
                    "4x2": .45,
                    "4x4": 1
                },
                ad = e => {
                    let {
                        className: t,
                        data: i
                    } = e, [, l] = (0, j.U)(), s = (0, eL.$)(), n = (0, _.OX)(i.style, s), {
                        addMediaUpload: a
                    } = (0, eS.r)(), r = (0, eZ.A)(e => e.dragging), [o, d] = (0, M.useState)(i.href), [u, x] = (0, M.useState)(!1), h = (0, s2.c)(e => e.cropping), [m, p] = e9(e => [e.hoveredId, e.setLocked]), [v, g] = (0, tR.A)(e => [e.highlighting, e.setHighlighting]), [f, w] = (0, M.useState)(void 0), y = !f || Math.abs(f.width / f.height - ao[null != n ? n : "2x2"]) > .05;
                    (0, M.useEffect)(() => {
                        if (i.url) {
                            let e = "image" === i.variant ? s3.p : nt.j;
                            e(i.url).then(e => {
                                w(e)
                            }).catch(() => {})
                        }
                    }, [i.url, i.variant]), (0, M.useEffect)(() => {
                        if (!y && v === i.id) {
                            let e = setTimeout(() => {
                                g(void 0)
                            }, 800);
                            return () => {
                                clearTimeout(e)
                            }
                        }
                    }, [y, v]);
                    let b = e => () => {
                            (0, z.c)().track("MEDIA_STYLE_CHANGED", {
                                from: i.style[s],
                                to: e,
                                device: s
                            }), ei.f.resizedWidget(i.id), l({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: i.id,
                                    style: (0, _.gN)(i.style, e, s)
                                }
                            })
                        },
                        N = () => {
                            let e = (0, _.QY)(null != o ? o : "");
                            e !== i.href && (e ? (0, z.c)().track("WIDGET_LINK_ADDED", {
                                type: "media",
                                hostname: (0, _.w6)(e).hostname,
                                protocol: (0, _.w6)(e).protocol
                            }) : (0, z.c)().track("WIDGET_LINK_REMOVED", {
                                type: "media"
                            }), l({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: i.id,
                                    href: e
                                }
                            }))
                        };
                    return (0, M.useEffect)(() => {
                        u || o === i.href || N()
                    }, [u]), (0, c.jsx)(eX.M, {
                        children: m === i.id && !h && !r && (0, c.jsx)(P.m.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3,
                                ease: e$.V
                            },
                            className: t,
                            children: (0, c.jsx)("div", {
                                className: (0, F.Z)(n1().menu),
                                children: (0, c.jsxs)("div", {
                                    className: (0, F.Z)(n1()["bottom-menu"], n1()["style-menu"]),
                                    children: [(0, c.jsx)(n4, {
                                        selected: "2x2" === n,
                                        onClick: b("2x2"),
                                        children: (0, c.jsx)(nE, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "2x4" === n,
                                        onClick: b("2x4"),
                                        children: (0, c.jsx)(nS, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x2" === n,
                                        onClick: b("4x2"),
                                        children: (0, c.jsx)(nL, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x4" === n,
                                        onClick: b("4x4"),
                                        children: (0, c.jsx)(nk, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                    }), (0, c.jsx)(S.pn, {
                                        children: (0, c.jsx)(E.u, {
                                            disableHoverableContent: !0,
                                            sideOffset: 12,
                                            side: "bottom",
                                            asChild: !0,
                                            tooltip: y ? void 0 : (0, c.jsx)(e_, {
                                                content: "Fits perfectly already"
                                            }),
                                            children: (0, c.jsx)(n4, {
                                                variant: "mode",
                                                selected: v === i.id,
                                                disabled: !y,
                                                onClick: () => {
                                                    g(e => e === i.id ? void 0 : i.id, "full"), p(v !== i.id)
                                                },
                                                children: (0, c.jsx)(ar, {
                                                    size: 18
                                                })
                                            })
                                        })
                                    }), (0, c.jsx)(n3, {
                                        asChildTrigger: !0,
                                        open: u,
                                        setOpen: e => {
                                            x(e), p(e)
                                        },
                                        trigger: (0, c.jsxs)(n4, {
                                            selected: u,
                                            variant: "default",
                                            children: [!i.href && (0, c.jsx)(eb.x, {
                                                size: 18
                                            }), i.href && (0, c.jsx)(aa, {
                                                size: 18
                                            })]
                                        }),
                                        onOpenAutoFocus: e => {
                                            e.preventDefault()
                                        },
                                        modal: !1,
                                        portal: !1,
                                        variant: "none",
                                        collisionPadding: 16,
                                        className: (0, F.Z)(n1().submenu, "p-1.5"),
                                        children: (0, c.jsxs)("div", {
                                            className: "relative",
                                            children: [(0, c.jsx)("form", {
                                                className: "inline",
                                                onSubmit: e => {
                                                    e.preventDefault(), N(), x(!1), p(!1)
                                                },
                                                children: (0, c.jsx)("input", {
                                                    value: null != o ? o : "",
                                                    onChange: e => d(e.target.value),
                                                    autoFocus: !0,
                                                    className: "rounded-[4px] bg-white/20 px-1.5 py-[3px] pr-7 text-sm text-white outline-none",
                                                    placeholder: "Enter link here"
                                                })
                                            }), o && (0, c.jsx)("div", {
                                                className: "absolute right-0.5 top-0 flex h-full items-center",
                                                children: (0, c.jsx)(R, {
                                                    variant: "transparent",
                                                    size: 24,
                                                    onClick: () => {
                                                        d("")
                                                    },
                                                    children: (0, c.jsx)("svg", {
                                                        width: "8",
                                                        height: "9",
                                                        viewBox: "0 0 8 9",
                                                        fill: "none",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: (0, c.jsx)("path", {
                                                            "fill-rule": "evenodd",
                                                            "clip-rule": "evenodd",
                                                            d: "M1.70711 0.792893C1.31658 0.402369 0.683417 0.402369 0.292893 0.792893C-0.0976311 1.18342 -0.0976311 1.81658 0.292893 2.20711L2.58579 4.5L0.292893 6.79289C-0.0976311 7.18342 -0.0976311 7.81658 0.292893 8.20711C0.683417 8.59763 1.31658 8.59763 1.70711 8.20711L4 5.91421L6.29289 8.20711C6.68342 8.59763 7.31658 8.59763 7.70711 8.20711C8.09763 7.81658 8.09763 7.18342 7.70711 6.79289L5.41421 4.5L7.70711 2.20711C8.09763 1.81658 8.09763 1.18342 7.70711 0.792893C7.31658 0.402369 6.68342 0.402369 6.29289 0.792893L4 3.08579L1.70711 0.792893Z",
                                                            fill: "white"
                                                        })
                                                    })
                                                })
                                            })]
                                        })
                                    })]
                                })
                            })
                        }, "media-menu")
                    })
                },
                ac = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M5 9.5C5 10.3284 4.32843 11 3.5 11C2.67157 11 2 10.3284 2 9.5C2 8.67157 2.67157 8 3.5 8C4.32843 8 5 8.67157 5 9.5ZM10.5 9.5C10.5 10.3284 9.82843 11 9 11C8.17157 11 7.5 10.3284 7.5 9.5C7.5 8.67157 8.17157 8 9 8C9.82843 8 10.5 8.67157 10.5 9.5ZM14.5 11C15.3284 11 16 10.3284 16 9.5C16 8.67157 15.3284 8 14.5 8C13.6716 8 13 8.67157 13 9.5C13 10.3284 13.6716 11 14.5 11Z",
                            fill: "currentColor"
                        })
                    })
                },
                au = e => {
                    var t, i, l;
                    let {
                        className: s,
                        data: n
                    } = e, [, a] = (0, j.U)(), r = (0, eL.$)(), o = (0, M.useMemo)(() => (0, nY.C)(), []), [d, u] = (0, M.useState)(!1), [x, h] = (0, M.useState)(void 0), [m, p] = e9(e => [e.hoveredId, e.setLocked]), v = (0, eZ.A)(e => e.dragging), g = (0, _.OX)(n.style, r), f = (0, na.iJ)((0, ih.V)(n.content, o)), [w, y] = (0, M.useState)(n.href), b = null !== (i = null === (t = (0, eV.t)()) || void 0 === t ? void 0 : t.querySelector("[data-bento-container]")) && void 0 !== i ? i : document.querySelector("[data-bento-container]"), N = (0, _.f6)(n.halign, r), C = (0, _.f6)(n.valign, r);
                    "center" === N && "quote" === f && (N = "left"), "top" !== C && "quote" === f && (C = "top"), "middle" !== C && "1x4" === g && (C = "middle"), (0, M.useEffect)(() => {
                        d || m === n.id || u(!1)
                    }, [m, n.id]);
                    let k = e => () => {
                            (0, z.c)().track("RICH_TEXT_STYLE_CHANGED", {
                                from: n.style[r],
                                to: e,
                                device: r
                            }), ei.f.resizedWidget(n.id), a({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: n.id,
                                    style: (0, _.gN)(n.style, e, r)
                                }
                            })
                        },
                        E = e => () => {
                            a({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: n.id,
                                    valign: (0, _.gN)(n.valign, e, r)
                                }
                            })
                        },
                        S = e => () => {
                            a({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: n.id,
                                    halign: (0, _.gN)(n.halign, e, r)
                                }
                            })
                        },
                        L = e => () => {
                            a({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: n.id,
                                    bg: e
                                }
                            })
                        },
                        I = () => {
                            let e = (0, _.QY)(null != w ? w : "");
                            e !== n.href && (e ? (0, z.c)().track("WIDGET_LINK_ADDED", {
                                type: "media",
                                hostname: (0, _.w6)(e).hostname,
                                protocol: (0, _.w6)(e).protocol
                            }) : (0, z.c)().track("WIDGET_LINK_REMOVED", {
                                type: "media"
                            }), a({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: n.id,
                                    href: e
                                }
                            }))
                        };
                    return (0, M.useEffect)(() => {
                        d || w === n.href || I(), h(void 0)
                    }, [d]), (0, c.jsx)(eX.M, {
                        children: m === n.id && !v && (0, c.jsx)(P.m.div, {
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3,
                                ease: e$.V
                            },
                            className: s,
                            children: (0, c.jsx)("div", {
                                className: (0, F.Z)(n1().menu),
                                children: (0, c.jsxs)("div", {
                                    className: (0, F.Z)(n1()["bottom-menu"], n1()["style-menu"]),
                                    children: [(0, c.jsx)(n4, {
                                        selected: "2x2" === g,
                                        onClick: k("2x2"),
                                        children: (0, c.jsx)(nE, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "1x4" === g,
                                        onClick: k("1x4"),
                                        children: (0, c.jsx)(nC, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "2x4" === g,
                                        onClick: k("2x4"),
                                        children: (0, c.jsx)(nS, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x2" === g,
                                        onClick: k("4x2"),
                                        children: (0, c.jsx)(nL, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)(n4, {
                                        selected: "4x4" === g,
                                        onClick: k("4x4"),
                                        children: (0, c.jsx)(nk, {
                                            size: 18
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                    }), (0, c.jsxs)(n3, {
                                        asChildTrigger: !0,
                                        open: d,
                                        setOpen: e => {
                                            u(e), p(e)
                                        },
                                        trigger: (0, c.jsxs)(n4, {
                                            selected: d,
                                            variant: "default",
                                            children: [(0, c.jsx)(ac, {}), " "]
                                        }),
                                        modal: !1,
                                        portal: !1,
                                        variant: "none",
                                        collisionBoundary: b,
                                        collisionPadding: 16,
                                        className: (0, F.Z)(n1().submenu),
                                        children: [(0, c.jsxs)("div", {
                                            className: n1()["submenu-row"],
                                            children: [(0, c.jsx)(n4, {
                                                selected: "left" === N,
                                                onClick: S("left"),
                                                children: (0, c.jsx)(nH, {
                                                    size: 18
                                                })
                                            }), (0, c.jsx)(n4, {
                                                selected: "center" === N,
                                                disabled: "quote" === f,
                                                onClick: S("center"),
                                                children: (0, c.jsx)(nU, {
                                                    size: 18
                                                })
                                            }), (0, c.jsx)(n4, {
                                                selected: "right" === N,
                                                onClick: S("right"),
                                                children: (0, c.jsx)(nV, {
                                                    size: 18
                                                })
                                            }), (0, c.jsx)("div", {
                                                className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                            }), (0, c.jsx)(n4, {
                                                selected: "top" === C,
                                                disabled: "1x4" === g,
                                                onClick: E("top"),
                                                children: (0, c.jsx)(nP, {
                                                    size: 18
                                                })
                                            }), (0, c.jsx)(n4, {
                                                selected: "middle" === C,
                                                disabled: "quote" === f && "1x4" !== g,
                                                onClick: E("middle"),
                                                children: (0, c.jsx)(nG, {
                                                    size: 18
                                                })
                                            }), (0, c.jsx)(n4, {
                                                selected: "bottom" === C,
                                                disabled: "1x4" === g || "quote" === f,
                                                onClick: E("bottom"),
                                                children: (0, c.jsx)(nW, {
                                                    size: 18
                                                })
                                            }), (0, c.jsx)("div", {
                                                className: "h-[12px] w-[2px] rounded-full bg-white/[0.18]"
                                            }), (0, c.jsx)(n4, {
                                                selected: "color" === x,
                                                variant: "default",
                                                onClick: () => h(e => "color" !== e ? "color" : void 0),
                                                children: (0, c.jsx)("div", {
                                                    className: "rounded-full s-[18px]",
                                                    style: {
                                                        background: null !== (l = n.bg) && void 0 !== l ? l : "#fff",
                                                        border: "color" !== x ? "1px solid rgba(255,255,255,0.2)" : "1px solid rgba(0,0,0,0.12)"
                                                    }
                                                })
                                            }), (0, c.jsxs)(n4, {
                                                selected: "link" === x,
                                                variant: "default",
                                                onClick: () => h(e => "link" !== e ? "link" : void 0),
                                                children: [!n.href && (0, c.jsx)(eb.x, {
                                                    size: 18
                                                }), n.href && (0, c.jsx)(aa, {
                                                    size: 18
                                                })]
                                            })]
                                        }), "color" === x && (0, c.jsxs)(c.Fragment, {
                                            children: [(0, c.jsx)("div", {
                                                className: n1()["submenu-colors"],
                                                children: na.DM.map(e => (0, c.jsx)(n4, {
                                                    onClick: L(e),
                                                    selected: n.bg === e,
                                                    children: (0, c.jsx)("div", {
                                                        className: "rounded-full s-[18px]",
                                                        style: {
                                                            background: e,
                                                            border: n.bg !== e ? "1px solid rgba(255,255,255,0.2)" : "1px solid rgba(0,0,0,0.12)"
                                                        }
                                                    })
                                                }, e))
                                            }), (0, c.jsx)("div", {
                                                className: "px-2.5 pb-2",
                                                children: (0, c.jsx)("input", {
                                                    className: "w-full rounded-[4px] bg-white/20 p-1 text-sm text-white outline-none",
                                                    placeholder: "#768CFF",
                                                    onPaste: e => {
                                                        let t = e.clipboardData.getData("text/plain");
                                                        (0, nJ.Z)(t).isValid() && L(t)()
                                                    },
                                                    onChange: e => {
                                                        let t = e.target.value;
                                                        (0, nJ.Z)(t).isValid() && L(t)()
                                                    }
                                                })
                                            })]
                                        }), "link" === x && (0, c.jsx)("div", {
                                            className: "mb-1.5 mt-2 w-full px-1.5",
                                            children: (0, c.jsxs)("div", {
                                                className: "relative w-full",
                                                children: [(0, c.jsx)("form", {
                                                    className: "inline w-full",
                                                    onSubmit: e => {
                                                        e.preventDefault(), I(), u(!1), p(!1)
                                                    },
                                                    children: (0, c.jsx)("input", {
                                                        value: null != w ? w : "",
                                                        onChange: e => y(e.target.value),
                                                        autoFocus: !0,
                                                        className: "w-full rounded-[4px] bg-white/20 px-1.5 py-[3px] pr-7 text-sm text-white outline-none",
                                                        placeholder: "Enter link here"
                                                    })
                                                }), w && (0, c.jsx)("div", {
                                                    className: "absolute right-0.5 top-0 flex h-full items-center",
                                                    children: (0, c.jsx)(R, {
                                                        variant: "transparent",
                                                        size: 24,
                                                        onClick: () => {
                                                            y("")
                                                        },
                                                        children: (0, c.jsx)("svg", {
                                                            width: "8",
                                                            height: "9",
                                                            viewBox: "0 0 8 9",
                                                            fill: "none",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: (0, c.jsx)("path", {
                                                                "fill-rule": "evenodd",
                                                                "clip-rule": "evenodd",
                                                                d: "M1.70711 0.792893C1.31658 0.402369 0.683417 0.402369 0.292893 0.792893C-0.0976311 1.18342 -0.0976311 1.81658 0.292893 2.20711L2.58579 4.5L0.292893 6.79289C-0.0976311 7.18342 -0.0976311 7.81658 0.292893 8.20711C0.683417 8.59763 1.31658 8.59763 1.70711 8.20711L4 5.91421L6.29289 8.20711C6.68342 8.59763 7.31658 8.59763 7.70711 8.20711C8.09763 7.81658 8.09763 7.18342 7.70711 6.79289L5.41421 4.5L7.70711 2.20711C8.09763 1.81658 8.09763 1.18342 7.70711 0.792893C7.31658 0.402369 6.68342 0.402369 6.29289 0.792893L4 3.08579L1.70711 0.792893Z",
                                                                fill: "white"
                                                            })
                                                        })
                                                    })
                                                })]
                                            })
                                        })]
                                    })]
                                })
                            })
                        }, m)
                    })
                },
                ax = e => {
                    let {
                        data: t,
                        ...i
                    } = e, l = (0, eM.H)();
                    if ("mouse" !== l) return null;
                    let s = null;
                    switch (t.type) {
                        case "link":
                            s = (0, c.jsxs)(M.Fragment, {
                                children: [(0, c.jsx)(n2, {
                                    data: t
                                }), (0, c.jsx)(an, {
                                    data: t
                                })]
                            }, t.id);
                            break;
                        case "media":
                            s = (0, c.jsxs)(M.Fragment, {
                                children: [(0, c.jsx)(n2, {
                                    data: t
                                }), (0, c.jsx)(ad, {
                                    data: t
                                })]
                            }, t.id);
                            break;
                        case "rich-text":
                            s = (0, c.jsxs)(M.Fragment, {
                                children: [(0, c.jsx)(n2, {
                                    data: t
                                }), (0, c.jsx)(au, {
                                    data: t
                                })]
                            }, t.id);
                            break;
                        default:
                            s = (0, c.jsx)(M.Fragment, {
                                children: (0, c.jsx)(n2, {
                                    data: t
                                })
                            }, t.id)
                    }
                    return (0, c.jsx)(eX.M, {
                        mode: "wait",
                        children: s
                    })
                },
                ah = e => {
                    let {} = e, [{
                        profile: t
                    }] = (0, j.U)(), i = e9(e => e.selectedId), l = (0, eZ.A)(e => e.dragging), s = (0, eL.$)(), n = (0, eM.H)(), a = function() {
                        let e = t0(e => e.editing);
                        return e
                    }(), r = t.bento.items.find(e => e.data.id === i), o = null == r ? void 0 : r.data;
                    if ("touch" !== n || "mobile" !== s) return null;
                    let d = !l && i && o && !a && "ghost" !== o.type && "ghost-materialized" !== o.type;
                    return (0, c.jsx)("div", {
                        className: "fixed bottom-0 left-0 z-40 w-full",
                        "data-bento-menu": !0,
                        children: (0, c.jsx)(eX.M, {
                            children: d && (0, c.jsx)(P.m.div, {
                                animate: {
                                    y: 0
                                },
                                initial: {
                                    y: 200
                                },
                                exit: {
                                    y: 200
                                },
                                children: (0, c.jsx)(n$, {
                                    data: o
                                })
                            })
                        })
                    })
                };
            var am = i(4048),
                ap = i(40820),
                av = i.n(ap);
            let ag = {
                    "2x4": 1.34,
                    "4x2": 1.91,
                    "4x4": 1.91
                },
                af = e => {
                    var t, i, l;
                    let {
                        data: s,
                        onClose: n
                    } = e, {
                        metadata: a,
                        loading: r
                    } = (0, tH.N)(s.href), [{
                        editing: o
                    }, d] = (0, j.U)(), [u, x] = (0, M.useState)(s.overrides), [h, m] = (0, M.useState)([]), p = (0, eL.$)(), v = (0, _.f6)(s.style, p), {
                        addMediaUpload: g,
                        getUpload: f
                    } = (0, eS.r)(), w = f(s.id), y = null == w ? void 0 : w.tmpUrl, N = (null == u ? void 0 : u.ogImage) || y ? null != y ? y : null == u ? void 0 : u.ogImage : void 0, C = null !== (l = null !== (i = null !== (t = null == w ? void 0 : w.tmpUrl) && void 0 !== t ? t : N) && void 0 !== i ? i : null == a ? void 0 : a.imageUrl) && void 0 !== l ? l : null == a ? void 0 : a.screenshotUrl, k = JSON.stringify(s.overrides) !== JSON.stringify(u), E = (0, eB.X)(s.href), S = E ? E.getDisplayName(s.href, a) : null == a ? void 0 : a.title, L = e => {
                        e && g(e, s.id).then(e => {
                            m([...h.filter(e => "LINK_PREVIEW_OVERRIDE_REMOVED" !== e), "LINK_PREVIEW_OVERRIDE"]), x({ ...u,
                                ogImage: e
                            })
                        })
                    }, I = () => {
                        m([...h.filter(e => "LINK_PREVIEW_OVERRIDE" !== e), "LINK_PREVIEW_OVERRIDE_REMOVED"]), x({ ...u,
                            ogImage: void 0
                        })
                    }, D = e => {
                        m([...h.filter(e => "LINK_TEXT_OVERRIDE" !== e), "LINK_TEXT_OVERRIDE"]), x({ ...u,
                            title: e
                        })
                    }, Z = () => {
                        k && (h.filter((e, t, i) => i.indexOf(e) === t).forEach(e => {
                            (0, z.c)().track(e)
                        }), d({
                            type: "set-bento-item-partial",
                            bento: {
                                id: s.id,
                                overrides: u
                            }
                        })), n()
                    };
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)("div", {
                            className: "order-2 mt-10 flex flex-col",
                            children: [(0, c.jsx)(tW, {
                                platform: E,
                                metadata: a,
                                loading: r,
                                size: "large",
                                className: "mb-6"
                            }), ["2x4", "4x2", "4x4"].includes(v) && !["Twitter Profile", "Instagram Profile", "Github Profile", "Youtube Profile"].includes(null == E ? void 0 : E.name) && (0, c.jsxs)("div", {
                                className: "mb-6 flex flex-col",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Preview Image"
                                }), (0, c.jsxs)("div", {
                                    className: (0, F.Z)(av().og, !C && av()["og--empty"], "2x4" === v && av()["og--fix-aspect"]),
                                    style: {
                                        aspectRatio: ag[v]
                                    },
                                    children: [C && (0, c.jsx)(tK, {
                                        url: (0, _.En)(C),
                                        loading: r,
                                        upload: w
                                    }), !C && (0, c.jsx)(tQ, {
                                        className: "h-full w-full"
                                    })]
                                }), (0, c.jsx)(ij, {
                                    onPick: L,
                                    className: "flex",
                                    buttonClassName: (0, F.Z)(av()["upload-button"]),
                                    accept: eI,
                                    children: (0, c.jsxs)("div", {
                                        className: "flex flex-col",
                                        children: [(0, c.jsx)("div", {
                                            className: "text-sm font-bold",
                                            children: "Upload Image or Video"
                                        }), (0, c.jsx)("div", {
                                            className: "text-[10px] font-medium leading-[1.2]",
                                            children: "Best 1200x630"
                                        })]
                                    })
                                }), (null == u ? void 0 : u.ogImage) && (0, c.jsx)(b.z, {
                                    variant: "danger",
                                    className: "h-[51px] !rounded-[12px]",
                                    onClick: I,
                                    children: (0, c.jsx)("div", {
                                        className: "text-sm font-bold",
                                        children: "Delete"
                                    })
                                })]
                            }), (0, c.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Title"
                                }), (0, c.jsx)(am.I, {
                                    value: (0, ih.V)(null == u ? void 0 : u.title, ix()),
                                    onChange: e => D(e.target.value),
                                    placeholder: null != S ? S : void 0
                                })]
                            })]
                        }), (0, c.jsxs)("div", {
                            className: "order-1 flex",
                            children: [k && (0, c.jsx)(b.z, {
                                variant: "secondary",
                                className: "h-[52px] w-[100px] !rounded-[12px]",
                                onClick: n,
                                children: (0, c.jsx)("span", {
                                    className: "text-title-3",
                                    children: "Cancel"
                                })
                            }), (0, c.jsx)(J.L, {}), (0, c.jsx)(b.z, {
                                disabled: !!w && !w.finished,
                                variant: "success",
                                className: "h-[52px] w-[100px] !rounded-[12px]",
                                onClick: Z,
                                children: (0, c.jsxs)("span", {
                                    className: "text-title-3",
                                    children: [!k && "Done", k && "Save"]
                                })
                            })]
                        })]
                    })
                };
            var a_ = i(66996),
                aj = i.n(a_);
            let aw = sR()(() => Promise.all([i.e(915), i.e(574), i.e(75)]).then(i.bind(i, 1075)).then(e => e.Video), {
                    loadableGenerated: {
                        webpack: () => [1075]
                    },
                    ssr: !1
                }),
                ay = e => {
                    var t;
                    let {
                        id: i,
                        aspect: l,
                        url: s,
                        caption: n,
                        enabled: a,
                        upload: r,
                        variant: o,
                        style: d,
                        crop: u,
                        setCrop: x
                    } = e, [h, m] = (0, M.useState)(void 0);
                    return (0, M.useEffect)(() => {
                        if (s) {
                            let e = "image" === o ? s3.p : nt.j;
                            e(s).then(e => {
                                m({
                                    width: e.width,
                                    height: e.height
                                })
                            }).catch(() => {})
                        } else m(void 0)
                    }, [s]), (0, c.jsxs)("div", {
                        className: (0, F.Z)("relative", l > 1 && "w-full", l <= 1 && "h-full"),
                        style: {
                            aspectRatio: l
                        },
                        children: [(0, c.jsxs)("div", {
                            className: (0, F.Z)("relative h-full w-full rounded-[20px] bg-white transition-transform duration-[240ms] ease-[cubic-bezier(0.43,0.01,0.29,1)]", a && "-translate-y-1"),
                            children: ["image" === o && (0, c.jsx)(s7.T, {
                                id: i,
                                dimensions: h,
                                editable: a,
                                offsetX: u.offsetX,
                                offsetY: u.offsetY,
                                onChange: x,
                                withCanvas: !0,
                                children: (0, c.jsx)("img", {
                                    src: s,
                                    alt: "",
                                    loading: "lazy",
                                    className: "rounded-[inherit]"
                                })
                            }), "video" === o && (0, c.jsx)(s7.T, {
                                id: i,
                                dimensions: h,
                                editable: a,
                                offsetX: u.offsetX,
                                offsetY: u.offsetY,
                                onChange: x,
                                withCanvas: !0,
                                children: (0, c.jsx)(aw, {
                                    src: s
                                })
                            }), (0, c.jsx)("div", {
                                className: (0, F.Z)("pointer-events-none absolute inset-0 z-10 rounded-[inherit] border-[2px] border-black transition-opacity duration-[240ms] ease-in-out", !a && "opacity-0", a && "opacity-100")
                            })]
                        }), n && (0, c.jsx)("div", {
                            className: "absolute left-0 bottom-0 max-w-full p-4",
                            children: (0, c.jsx)("div", {
                                className: (0, F.Z)("rounded-[8px] bg-white px-2 py-1.5 shadow-[0px_0px_0px_1px_rgba(0,0,0,0.06)] line-clamp-2", "4x2" === d && "text-[10px]", "4x4" === d && "text-[11px]", "2x2" === d && "text-[12px]", "2x4" === d && "text-[12px]"),
                                children: n
                            })
                        }), r && (0, c.jsx)(tq, {
                            progress: null !== (t = null == r ? void 0 : r.progress) && void 0 !== t ? t : 0,
                            className: "absolute left-6 top-6"
                        })]
                    })
                },
                ab = {
                    "2x4": 2.15,
                    "4x2": .46
                },
                aN = {
                    "1x4": 4,
                    "2x2": 1,
                    "2x4": 2.22,
                    "4x2": .45,
                    "4x4": 1
                },
                aC = e => {
                    var t, i;
                    let {
                        data: l,
                        onClose: s
                    } = e, [{
                        editing: n
                    }, a] = (0, j.U)(), [r, o] = (0, M.useState)(l), [d, u] = (0, M.useState)([]), x = (0, eL.$)(), h = (0, _.f6)(l.style, x), {
                        addMediaUpload: m,
                        getUpload: p
                    } = (0, eS.r)(), v = l.id + "touch-editor", g = p(v), f = null == g ? void 0 : g.tmpUrl, w = null != f ? f : r.url, y = JSON.stringify(l) !== JSON.stringify(r), N = (0, M.useMemo)(() => (0, s4.K)(), []), [C, k] = (0, M.useState)(!1), E = (0, eL.$)(), S = (0, s9._e)(l), [L, I] = (0, M.useState)(void 0), D = !L || Math.abs(L.width / L.height - aN[null != h ? h : "2x2"]) > .05;
                    (0, M.useEffect)(() => {
                        if (l.url) {
                            let e = "image" === l.variant ? s3.p : nt.j;
                            e(l.url).then(e => {
                                I(e)
                            }).catch(() => {})
                        }
                    }, [l.url, l.variant]);
                    let Z = (e, t) => {
                            o({ ...r,
                                crop: { ...l.crop,
                                    [E]: {
                                        offsetX: e,
                                        offsetY: t
                                    }
                                }
                            })
                        },
                        A = e => {
                            e && m(e, v).then(e => {
                                u([...d, "MEDIA_SOURCE_REPLACED"]), o({ ...r,
                                    url: e
                                })
                            })
                        },
                        T = () => {
                            y && (d.filter((e, t, i) => i.indexOf(e) === t).forEach(e => {
                                (0, z.c)().track(e)
                            }), r.href = (0, _.QY)(r.href), r.href !== l.href && (r.href ? (0, z.c)().track("WIDGET_LINK_ADDED", {
                                type: "media",
                                hostname: (0, _.w6)(r.href).hostname,
                                protocol: (0, _.w6)(r.href).protocol
                            }) : (0, z.c)().track("WIDGET_LINK_REMOVED", {
                                type: "media"
                            })), a({
                                type: "set-bento-item",
                                bento: { ...l,
                                    ...r
                                }
                            })), s()
                        };
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)("div", {
                            className: "order-2 mt-10 flex flex-col",
                            children: [(0, c.jsxs)("div", {
                                className: "mb-6 flex flex-col",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Preview Image"
                                }), (0, c.jsx)("div", {
                                    className: (0, F.Z)("mb-3 flex  items-center justify-center overflow-hidden rounded-[24px] bg-neutral-grey10 p-6", ["4x2", "4x4"].includes(h) && "h-[350px]", !["4x2", "4x4"].includes(h) && "h-[208px]"),
                                    children: (0, c.jsx)(ay, {
                                        id: l.id,
                                        style: h,
                                        aspect: null !== (t = ab[h]) && void 0 !== t ? t : 1,
                                        url: w,
                                        variant: l.variant,
                                        caption: (0, ih.V)(r.caption, N),
                                        upload: g,
                                        enabled: C,
                                        crop: S,
                                        setCrop: Z
                                    })
                                }), (0, c.jsxs)("div", {
                                    className: "mb-3 flex space-x-3",
                                    children: [(0, c.jsx)(ij, {
                                        onPick: A,
                                        className: (0, F.Z)("flex flex-1", "transition-opacity duration-300", C && "pointer-events-none opacity-0"),
                                        buttonClassName: (0, F.Z)(aj()["upload-button"]),
                                        accept: eI,
                                        children: (0, c.jsxs)("div", {
                                            className: "flex flex-col",
                                            children: [(0, c.jsx)("div", {
                                                className: "text-sm font-bold",
                                                children: "Upload Image or Video"
                                            }), (0, c.jsx)("div", {
                                                className: "text-[10px] font-medium leading-[1.2]",
                                                children: "Best 1200x630"
                                            })]
                                        })
                                    }), D && (0, c.jsx)(b.z, {
                                        variant: C ? "success" : "white",
                                        className: (0, F.Z)("w-[50px]", !C && "shadow-[0px_1px_2px_rgba(0,0,0,0.08)]"),
                                        onClick: () => {
                                            k(!C)
                                        },
                                        children: (0, c.jsx)(ar, {})
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Caption"
                                }), (0, c.jsx)(am.I, {
                                    value: (0, ih.V)(null == r ? void 0 : r.caption, N),
                                    onChange: e => o({ ...r,
                                        caption: e.target.value
                                    }),
                                    clearable: !0,
                                    onClear: () => o({ ...r,
                                        caption: ""
                                    })
                                })]
                            }), (0, c.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Link"
                                }), (0, c.jsx)(am.I, {
                                    value: null !== (i = r.href) && void 0 !== i ? i : "",
                                    onChange: e => o({ ...r,
                                        href: e.target.value
                                    }),
                                    clearable: !0,
                                    onClear: () => o({ ...r,
                                        href: ""
                                    })
                                })]
                            })]
                        }), (0, c.jsxs)("div", {
                            className: "order-1 flex",
                            children: [y && (0, c.jsx)(b.z, {
                                variant: "secondary",
                                className: "w-[100px] !rounded-[12px]",
                                onClick: s,
                                children: "Cancel"
                            }), (0, c.jsx)(J.L, {}), (0, c.jsxs)(b.z, {
                                disabled: !!g && !g.finished,
                                variant: "success",
                                className: "w-[100px] !rounded-[12px]",
                                onClick: T,
                                children: [!y && "Done", y && "Save"]
                            })]
                        })]
                    })
                },
                ak = e => {
                    let {
                        data: t,
                        onClose: i
                    } = e, [{
                        editing: l
                    }, s] = (0, j.U)(), [n, a] = (0, M.useState)(t), [r, o] = (0, M.useState)([]), d = (0, M.useMemo)(() => nd(), []), u = JSON.stringify(t) !== JSON.stringify(n), x = e => {
                        a({ ...n,
                            title: e
                        })
                    }, h = () => {
                        u && (r.filter((e, t, i) => i.indexOf(e) === t).forEach(e => {
                            (0, z.c)().track(e)
                        }), s({
                            type: "set-bento-item",
                            bento: { ...t,
                                ...n
                            }
                        })), i()
                    };
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("div", {
                            className: "order-2 mt-10 flex flex-col",
                            children: (0, c.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Title"
                                }), (0, c.jsx)(am.I, {
                                    value: (0, ih.V)(null == n ? void 0 : n.title, d),
                                    onChange: e => x(e.target.value)
                                })]
                            })
                        }), (0, c.jsxs)("div", {
                            className: "order-1 flex",
                            children: [u && (0, c.jsx)(b.z, {
                                variant: "secondary",
                                className: "w-[100px] !rounded-[12px]",
                                onClick: i,
                                children: "Cancel"
                            }), (0, c.jsx)(J.L, {}), (0, c.jsxs)(b.z, {
                                variant: "success",
                                className: "w-[100px] !rounded-[12px]",
                                onClick: h,
                                children: [!u && "Done", u && "Save"]
                            })]
                        })]
                    })
                };
            var aE = i(22447),
                aS = i(28223);
            let aL = new aS.aN({
                    apiKey: "AIzaSyA3ghvpzoWf1jNdCaCgL26is_YGG9e6enM",
                    version: "weekly",
                    libraries: ["places"]
                }),
                aI = [{
                    name: "Berlin, Germany"
                }, {
                    name: "New York, United States"
                }, {
                    name: "Tokyo, Japan"
                }],
                aD = sR()(() => Promise.all([i.e(55), i.e(580)]).then(i.bind(i, 54407)).then(e => e.MapGl), {
                    loadableGenerated: {
                        webpack: () => [54407]
                    },
                    ssr: !1
                }),
                aZ = {
                    "2x2": 1,
                    "2x4": 2.15,
                    "4x2": .46,
                    "4x4": 1
                },
                az = e => {
                    var t;
                    let {
                        data: i,
                        onClose: l
                    } = e, [{
                        editing: s
                    }, n] = (0, j.U)(), [a, r] = (0, M.useState)(i.overrides), [o, d] = (0, M.useState)([]), u = (0, eL.$)(), x = (0, _.f6)(i.style, u), {
                        addMediaUpload: h,
                        getUpload: m
                    } = (0, eS.r)(), p = m(i.id);
                    null == p || p.tmpUrl;
                    let [v, g] = (0, M.useState)(!1), f = v || JSON.stringify(i.overrides) !== JSON.stringify(a), w = (0, M.useMemo)(() => (0, sB.j)(), []), [y, N] = (0, M.useState)(!1), [C, k] = (0, M.useState)(void 0), [E, S] = (0, M.useState)(void 0), [L, I] = (0, M.useState)(!1), [D, Z] = (0, M.useState)(""), [A, T] = (0, M.useState)(void 0), [R, B] = (0, M.useState)(!1), {
                        suggestions: H,
                        selectAddress: U
                    } = function(e) {
                        let t = (0, M.useRef)(),
                            i = (0, M.useRef)(),
                            [l, s] = (0, M.useState)(aI);
                        (0, M.useEffect)(() => {
                            aL.load().then(async () => {
                                t.current = new google.maps.places.AutocompleteService, i.current = new google.maps.Geocoder
                            })
                        }, []);
                        let n = e => new Promise((t, l) => {
                            i.current && e ? i.current.geocode({
                                address: e
                            }, (i, s) => {
                                if (s === google.maps.GeocoderStatus.OK) {
                                    if (i && i[0]) {
                                        let l;
                                        let {
                                            lat: s,
                                            lng: n
                                        } = i[0].geometry.location;
                                        ["premise", "route", "street_address"].some(e => {
                                            var t;
                                            return !!(null === (t = i[0]) || void 0 === t ? void 0 : t.types.includes(e))
                                        }) ? l = "street" : i[0].types.includes("locality") ? l = "city" : i[0].types.includes("country") && (l = "country"), t({
                                            lat: s(),
                                            lng: n(),
                                            address: e,
                                            type: l
                                        })
                                    } else l("No results found")
                                } else l("No results found")
                            }) : l("No results found")
                        });
                        return (0, lH.Z)(() => {
                            t.current && e ? t.current.getQueryPredictions({
                                input: e
                            }, (e, t) => {
                                if (t === google.maps.places.PlacesServiceStatus.OK) {
                                    var i;
                                    s(null !== (i = null == e ? void 0 : e.map(e => ({
                                        name: e.description
                                    })).slice(0, 3)) && void 0 !== i ? i : [])
                                } else s(aI)
                            }) : e || s(aI)
                        }, 200, [e]), {
                            suggestions: l,
                            selectAddress: n
                        }
                    }(D), V = e => {
                        r({ ...a,
                            mapCaption: e
                        })
                    }, P = (0, M.useCallback)(() => {
                        C && C.zoomTo(C.getZoom() + 1)
                    }, [C]), G = (0, M.useCallback)(() => {
                        C && C.zoomTo(C.getZoom() - 1)
                    }, [C]);
                    (0, M.useEffect)(() => {
                        if (C) {
                            let e = () => {
                                g(!0)
                            };
                            return C.on("move", e), () => {
                                C.off("move", e)
                            }
                        }
                    }, [C]);
                    let W = () => {
                        if (f) {
                            o.filter((e, t, i) => i.indexOf(e) === t).forEach(e => {
                                (0, z.c)().track(e)
                            });
                            let e = i.href;
                            if (C) {
                                let t = C.getZoom(),
                                    l = C.getCenter();
                                e = "https://www.google.com/maps/@".concat(l.lat, ",").concat(l.lng, ",").concat(t + el.by, "z"), window.dispatchEvent(new CustomEvent("bento:map:refresh", {
                                    detail: {
                                        id: i.id,
                                        lat: l.lat,
                                        lng: l.lng,
                                        zoom: t
                                    }
                                }))
                            }
                            n({
                                type: "set-bento-item-partial",
                                bento: {
                                    id: i.id,
                                    href: e,
                                    overrides: a
                                }
                            })
                        }
                        l()
                    };
                    (0, M.useEffect)(() => {
                        if (R) {
                            let e = e => {
                                let t = e.target;
                                t.closest("[data-search-menu]") || B(!1)
                            };
                            return document.addEventListener("click", e), () => {
                                document.removeEventListener("click", e)
                            }
                        }
                    }, [R]);
                    let Y = (e, t, i) => {
                            null == C || C.flyTo({
                                center: [t, e],
                                zoom: null != i ? i : C.getZoom(),
                                speed: 2,
                                curve: .8
                            }), null == E || E.setLngLat([t, e])
                        },
                        q = () => {
                            I(!0), navigator.geolocation.getCurrentPosition(e => {
                                I(!1), Y(e.coords.latitude, e.coords.longitude)
                            }, () => {
                                I(!1)
                            })
                        };
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)("div", {
                            className: "order-2 mt-10 flex min-h-[80vh] flex-col",
                            children: [(0, c.jsxs)("div", {
                                className: "mb-6 flex flex-col",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Location"
                                }), (0, c.jsxs)("div", {
                                    className: "flex",
                                    children: [(0, c.jsx)("div", {
                                        className: (0, F.Z)("transition-all duration-200 ease-in-out", !R && "w-full", R && "w-[calc(100%-64px)]"),
                                        "data-search-menu": !0,
                                        children: (0, c.jsx)(am.I, {
                                            ref: T,
                                            className: "border-[1px] border-black/[0.04]",
                                            value: D,
                                            onChange: e => Z(e.target.value),
                                            placeholder: "Search...",
                                            onFocus: () => B(!0),
                                            addonRight: (0, c.jsx)(b.z, {
                                                variant: "white",
                                                className: "!rounded-[6px] !p-0 shadow-[0px_1px_2px_rgba(0,0,0,0.08)] s-[32px]",
                                                loading: L,
                                                onClick: e => {
                                                    e.preventDefault(), e.stopPropagation(), q()
                                                },
                                                children: (0, c.jsx)(aE.l, {
                                                    size: 18
                                                })
                                            })
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: (0, F.Z)("flex justify-end overflow-hidden transition-all duration-200 ease-in-out", R && "w-[64px] opacity-100", !R && "w-[0px] opacity-0"),
                                        children: (0, c.jsx)(b.z, {
                                            variant: "secondary",
                                            className: "!rounded-[12px] !p-0 s-[52px]",
                                            onClick: e => {
                                                B(!1), e.preventDefault(), e.stopPropagation()
                                            },
                                            children: (0, c.jsx)(O.b, {
                                                size: 14
                                            })
                                        })
                                    })]
                                })]
                            }), (0, c.jsx)("div", {
                                className: (0, F.Z)("absolute left-0 top-[200px] right-0 bottom-0 z-30 bg-white px-4 py-2 transition-opacity duration-200", R && "opacity-100", !R && "pointer-events-none opacity-0"),
                                "data-search-menu": !0,
                                children: (0, c.jsx)("div", {
                                    className: "flex flex-col",
                                    children: H.map(e => (0, c.jsx)("button", {
                                        className: "px-4 py-[10px] text-left",
                                        onClick: () => {
                                            let t = null == E ? void 0 : E.getLngLat();
                                            null == E || E.setLngLat([0, 0]), U(e.name).then(e => {
                                                var t;
                                                let i = null !== (t = ({
                                                    street: 15.5,
                                                    city: 11,
                                                    country: 4
                                                })[e.type]) && void 0 !== t ? t : 13;
                                                "city" === e.type && (e.lat = e.lat - .008), Y(e.lat, e.lng, i)
                                            }).catch(() => {
                                                null == E || E.setLngLat(t)
                                            }), Z(""), B(!1)
                                        },
                                        children: e.name
                                    }))
                                })
                            }), (0, c.jsxs)("div", {
                                className: "mb-6 flex flex-col",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Map"
                                }), (0, c.jsxs)("div", {
                                    className: "flex flex-col items-center justify-start rounded-[24px] bg-[#F9F7F7] p-[22px]",
                                    children: [(0, c.jsxs)("div", {
                                        className: (0, F.Z)("relative overflow-hidden rounded-[20px] shadow-[0px_2px_4px_rgba(0,0,0,0.1)]", ["4x2"].includes(x) && "h-[350px]", ["4x4", "2x4"].includes(x) && "w-full", ["2x2"].includes(x) && "w-[140px]"),
                                        style: {
                                            aspectRatio: aZ[x]
                                        },
                                        children: [(0, c.jsx)(sH.t, {
                                            children: (0, c.jsx)(aD, {
                                                setMap: k,
                                                setMarker: S,
                                                data: i,
                                                style: x,
                                                hasCaption: !(0, ih.J)(null == a ? void 0 : a.mapCaption, w),
                                                movable: y
                                            })
                                        }), (0, c.jsx)(X.k, {}), (null == a ? void 0 : a.mapCaption) && (0, c.jsx)("div", {
                                            className: "pointer-events-none absolute inset-4 flex items-end justify-start",
                                            children: (0, c.jsx)("div", {
                                                className: (0, F.Z)("bg-white/70 px-2 py-1.5 shadow-[0px_0px_0px_1px_rgba(0,0,0,0.06)] backdrop-blur-[20px]", "4x4" !== x && "rounded-[8px]", "4x4" === x && "rounded-[10px]", "2x4" === x && "max-w-[155px]", !["2x2", "4x4"].includes(x) && "line-clamp-2", ["2x2", "4x4"].includes(x) && "line-clamp-1", "2x2" === x && "text-[14px]", "2x2" !== x && "text-[13px]"),
                                                children: (0, c.jsx)(ii, {
                                                    extensions: w,
                                                    value: a.mapCaption
                                                })
                                            })
                                        })]
                                    }), (0, c.jsxs)("div", {
                                        className: "mt-[24px] flex w-full",
                                        children: [(0, c.jsx)(b.z, {
                                            variant: "white",
                                            className: "mr-4 shadow-[0px_1px_2px_rgba(0,0,0,0.08)] s-[44px]",
                                            onClick: () => G(),
                                            children: (0, c.jsx)(at, {})
                                        }), (0, c.jsx)(b.z, {
                                            variant: "white",
                                            className: "shadow-[0px_1px_2px_rgba(0,0,0,0.08)] s-[44px]",
                                            onClick: () => P(),
                                            children: (0, c.jsx)(ai, {})
                                        }), (0, c.jsx)(J.L, {}), (0, c.jsx)(b.z, {
                                            variant: y ? "success" : "white",
                                            className: "shadow-[0px_1px_2px_rgba(0,0,0,0.08)] s-[44px]",
                                            onClick: () => N(!y),
                                            children: (0, c.jsx)(n8, {})
                                        })]
                                    })]
                                })]
                            }), (0, c.jsxs)("div", {
                                className: "mb-6",
                                children: [(0, c.jsx)("label", {
                                    className: "ml-2 mb-2 text-title-6 text-neutral-grey30",
                                    children: "Caption"
                                }), (0, c.jsx)(am.I, {
                                    className: "border-[1px] border-black/[0.04]",
                                    value: (0, ih.V)(null == a ? void 0 : a.mapCaption, w),
                                    onChange: e => V(e.target.value),
                                    placeholder: null === (t = i.overrides) || void 0 === t ? void 0 : t.mapPlace
                                })]
                            })]
                        }), (0, c.jsxs)("div", {
                            className: "order-1 flex",
                            children: [f && (0, c.jsx)(b.z, {
                                variant: "secondary",
                                className: "h-[52px] w-[100px] !rounded-[12px]",
                                onClick: l,
                                children: (0, c.jsx)("span", {
                                    className: "text-title-3",
                                    children: "Cancel"
                                })
                            }), (0, c.jsx)(J.L, {}), (0, c.jsx)(b.z, {
                                variant: "success",
                                className: "h-[52px] w-[100px] !rounded-[12px]",
                                onClick: W,
                                children: (0, c.jsxs)("span", {
                                    className: "text-title-3",
                                    children: [!f && "Done", f && "Save"]
                                })
                            })]
                        })]
                    })
                },
                aA = e => {
                    let {
                        data: t
                    } = e, [i, l] = nj(e => [e.editingContentOfId, e.setEditingContentOfId]), s = null, n = (0, M.useCallback)(() => {
                        l(void 0)
                    }, [l]);
                    switch (t.type) {
                        case "link":
                            let a = (0, eB.X)(t.href);
                            s = a && el.vT.includes(a.name) ? (0, c.jsx)(az, {
                                data: t,
                                onClose: n
                            }) : (0, c.jsx)(af, {
                                data: t,
                                onClose: n
                            });
                            break;
                        case "media":
                            s = (0, c.jsx)(aC, {
                                data: t,
                                onClose: n
                            });
                            break;
                        case "section-header":
                            s = (0, c.jsx)(ak, {
                                data: t,
                                onClose: n
                            });
                            break;
                        default:
                            s = (0, c.jsx)(c.Fragment, {})
                    }
                    return s
                },
                aF = e => {
                    let {} = e, [{
                        profile: t
                    }] = (0, j.U)(), [i, l] = nj(e => [e.editingContentOfId, e.setEditingContentOfId]), [s, n] = (0, M.useState)(void 0), a = (0, eM.H)(), r = t.bento.items.find(e => e.data.id === i), o = null == r ? void 0 : r.data;
                    (0, M.useEffect)(() => {
                        o && n(o)
                    }, [o]);
                    let d = (0, M.useCallback)(e => {
                        e || l(void 0)
                    }, [l]);
                    if ("touch" !== a) return null;
                    let u = null != o ? o : s;
                    return (0, c.jsx)(q, {
                        open: !!i,
                        setOpen: d,
                        "data-bento-menu": !0,
                        children: (0, c.jsx)("div", {
                            className: "flex flex-col",
                            children: u && (0, c.jsx)(aA, {
                                data: u
                            })
                        })
                    })
                },
                aM = {
                    "data-grid-dropzone": !0
                },
                aT = e => {
                    if (!e.target) return !1;
                    let t = e.target;
                    return !!t.closest("[data-grid-dropzone]")
                },
                aO = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsx)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 18 18",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: (0, c.jsx)("path", {
                            fillRule: "evenodd",
                            clipRule: "evenodd",
                            d: "M9 16C5.13401 16 2 12.866 2 9C2 5.13401 5.13401 2 9 2C12.866 2 16 5.13401 16 9C16 12.866 12.866 16 9 16ZM0 9C0 4.02944 4.02944 0 9 0C13.9706 0 18 4.02944 18 9C18 13.9706 13.9706 18 9 18C4.02944 18 0 13.9706 0 9ZM9 5C9.28141 5 9.53568 5.11624 9.7174 5.30333L12.7071 8.29304C13.0976 8.68357 13.0976 9.31673 12.7071 9.70726C12.3166 10.0978 11.6834 10.0978 11.2929 9.70726L10 8.41436V12C10 12.5523 9.55228 13 9 13C8.44772 13 8 12.5523 8 12V8.41436L6.70711 9.70726C6.31658 10.0978 5.68342 10.0978 5.29289 9.70726C4.90237 9.31673 4.90237 8.68357 5.29289 8.29304L8.2826 5.30333C8.46432 5.11624 8.71859 5 9 5Z",
                            fill: "currentColor"
                        })
                    })
                };
            var aR = i(10075),
                aB = i(74424),
                aH = i(8058),
                aU = i.n(aH);
            let aV = e => {
                var t;
                let {
                    src: i,
                    className: l
                } = e, [, s] = (0, j.U)(), {
                    addMediaUpload: n,
                    getUpload: a
                } = (0, eS.r)(), r = (0, eM.H)(), o = a("avatar-image-file"), d = null !== (t = null == o ? void 0 : o.tmpUrl) && void 0 !== t ? t : null === o ? void 0 : i, {
                    getRootProps: u,
                    getInputProps: x,
                    isDragActive: h,
                    isDragReject: m,
                    isDragAccept: p,
                    acceptedFiles: v,
                    inputRef: g
                } = (0, aB.uI)({
                    accept: {
                        "image/png": [],
                        "image/jpeg": [],
                        "image/heic": [],
                        "image/gif": [],
                        "image/webp": []
                    },
                    multiple: !1,
                    onDrop: e => {
                        e.length <= 0 || ((0, z.c)().track("AVATAR_SET"), ei.f.avatarChanged(), n(e[0], "avatar-image-file").then(e => {
                            s({
                                type: "set-profile-field",
                                field: "image",
                                value: e
                            })
                        }).catch(() => {}))
                    },
                    onDragOver: e => {
                        e.dataTransfer.dropEffect = "move"
                    }
                }), f = () => {
                    (0, z.c)().track("AVATAR_REMOVED"), s({
                        type: "set-profile-field",
                        field: "image",
                        value: null
                    })
                };
                return (0, c.jsxs)("div", {
                    "data-avatar-editor": !0,
                    className: (0, F.Z)("relative", aU()["avatar-editor-wrapper"], aU()["input-mode--".concat(r)], l),
                    children: [(0, c.jsxs)("div", {
                        className: (0, F.Z)(aU()["avatar-editor"], !!d && aU()["avatar-editor--has-avatar"], "group/avatar"),
                        ...u(),
                        children: [(0, c.jsx)("div", {
                            className: (0, F.Z)("absolute inset-0 rounded-[inherit]", !d && "border-2 border-dashed border-black/[0.08] bg-[#FAFAFA] transition-colors duration-200 ease-in-out group-hover/avatar:bg-[#F6F6F6] group-active/avatar:bg-[#F1F1F1]", d && "border-transparent", h && "border-2 border-dashed", h && p && "border-action-green bg-action-green/20", h && m && "border-action-red bg-action-red/20"),
                            children: !d && (0, c.jsx)(c.Fragment, {
                                children: (0, c.jsxs)("div", {
                                    className: "typography-title-5 pointer-events-none flex h-full w-full flex-col items-center justify-center rounded-[inherit] text-center text-black/60",
                                    children: [(0, c.jsx)("svg", {
                                        className: "mb-3",
                                        width: "34",
                                        height: "34",
                                        viewBox: "0 0 34 34",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, c.jsx)("path", {
                                            "fill-rule": "evenodd",
                                            "clip-rule": "evenodd",
                                            d: "M17 30.2222C9.69757 30.2222 3.77778 24.3024 3.77778 17C3.77778 9.69757 9.69757 3.77778 17 3.77778C24.3024 3.77778 30.2222 9.69757 30.2222 17C30.2222 24.3024 24.3024 30.2222 17 30.2222ZM0 17C0 7.61116 7.61116 0 17 0C26.3888 0 34 7.61116 34 17C34 26.3888 26.3888 34 17 34C7.61116 34 0 26.3888 0 17ZM17 9.44444C17.5316 9.44444 18.0119 9.66402 18.3551 10.0174L24.0023 15.6646C24.74 16.4023 24.74 17.5983 24.0023 18.3359C23.2647 19.0736 22.0687 19.0736 21.331 18.3359L18.8889 15.8938V22.6667C18.8889 23.7099 18.0432 24.5556 17 24.5556C15.9568 24.5556 15.1111 23.7099 15.1111 22.6667V15.8938L12.669 18.3359C11.9313 19.0736 10.7353 19.0736 9.99769 18.3359C9.26003 17.5983 9.26003 16.4023 9.99769 15.6646L15.6449 10.0174C15.9882 9.66402 16.4684 9.44444 17 9.44444Z",
                                            fill: "black",
                                            "fill-opacity": "0.1"
                                        })
                                    }), "Add Avatar"]
                                })
                            })
                        }), d && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)("img", {
                                src: (0, aR.E)(d),
                                className: (0, F.Z)("h-full w-full rounded-[inherit] object-cover transition-all duration-200 ease-in-out", h && "scale-[0.8] opacity-[0.4]"),
                                alt: ""
                            }), (0, c.jsx)("div", {
                                className: (0, F.Z)("pointer-events-none absolute inset-0 rounded-[inherit]"),
                                style: {
                                    boxShadow: "inset 0px 0px 0px 1px rgba(0, 0, 0, 0.1)"
                                }
                            })]
                        }), (0, c.jsx)("input", { ...x()
                        })]
                    }), d && (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("div", {
                            className: (0, F.Z)("absolute left-3 bottom-3 hidden xl:block", aU()["delete-wrapper"], h && aU()["delete-wrapper--dragging"]),
                            children: (0, c.jsx)(R, {
                                variant: "white",
                                className: aU()["action-button"],
                                size: 34,
                                onClick: () => {
                                    var e;
                                    null === (e = g.current) || void 0 === e || e.click()
                                },
                                children: (0, c.jsx)(aO, {
                                    size: 18
                                })
                            })
                        }), (0, c.jsx)("div", {
                            className: (0, F.Z)("absolute right-3 bottom-3 hidden xl:block", aU()["delete-wrapper"], h && aU()["delete-wrapper--dragging"]),
                            children: (0, c.jsx)(R, {
                                variant: "white",
                                className: aU()["action-button"],
                                size: 34,
                                onClick: f,
                                children: (0, c.jsx)(i_, {
                                    size: 18
                                })
                            })
                        }), (0, c.jsx)("div", {
                            className: (0, F.Z)("absolute -right-1 -bottom-1 xl:hidden", aU()["delete-wrapper"], h && aU()["delete-wrapper--dragging"]),
                            children: (0, c.jsx)(R, {
                                variant: "white",
                                className: aU()["action-button"],
                                size: 42,
                                onClick: f,
                                children: (0, c.jsx)(i_, {
                                    size: 18
                                })
                            })
                        })]
                    })]
                })
            };
            var aP = i(35328),
                aG = i.n(aP),
                aW = i(2665),
                aJ = i(96458),
                aY = i(49692),
                aq = i(82918),
                aK = i(42701),
                aX = i(64652);
            let a$ = () => [aJ.Z, ic.Z, io.Z, aY.Z, aW.ZP, aq.ZP, aK.ZP, aX.ZP, ir.Z, lc.Z.configure({
                    limit: 280,
                    mode: "textSize"
                }), id.Z.configure({
                    placeholder(e) {
                        let {
                            node: t,
                            pos: i
                        } = e;
                        return "paragraph" === t.type.name && 0 === i ? "Your bio..." : ""
                    }
                })],
                aQ = e => {
                    let {
                        className: t
                    } = e, [{
                        profile: i,
                        editing: l
                    }, s] = (0, j.U)(), n = (0, M.useMemo)(() => a$(), []), r = (0, M.useCallback)(e => {
                        let {
                            editor: t
                        } = e;
                        s({
                            type: "set-profile-field",
                            field: "bio",
                            value: t.getJSON()
                        }), a && clearTimeout(a), a = setTimeout(() => {
                            (0, z.c)().track("BIO_EDITED")
                        }, 2e3), ei.f.bioEdited()
                    }, [s]), o = (0, t1.jE)({
                        extensions: n,
                        content: i.bio
                    }, [t]);
                    return (0, M.useEffect)(() => {
                        o && o.setEditable(l)
                    }, [l, o]), (0, t4.F)(o, r), (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)("div", {
                            className: aG().bio,
                            children: [o && l && (0, c.jsx)(t2, {
                                editor: o
                            }), (!o || !l) && (0, c.jsx)(ii, {
                                extensions: n,
                                value: i.bio
                            })]
                        }), o && l && o.storage.characterCount.characters() > 224 && (0, c.jsxs)("div", {
                            className: "mt-4 text-xs font-semibold text-neutral-grey20",
                            style: {
                                opacity: (o.storage.characterCount.characters() - 210) / 70
                            },
                            children: [o.storage.characterCount.characters(), "/", 280, " characters"]
                        })]
                    })
                },
                a0 = e => {
                    var t;
                    let {
                        className: i
                    } = e, [{
                        profile: l,
                        editing: s
                    }, n] = (0, j.U)(), a = (0, M.useCallback)(e => {
                        let {
                            editor: t
                        } = e;
                        n({
                            type: "set-profile-field",
                            field: "name",
                            value: t.getText()
                        }), r && clearTimeout(r), r = setTimeout(() => {
                            (0, z.c)().track("NAME_EDITED")
                        }, 2e3)
                    }, [n]), o = (0, t1.jE)({
                        extensions: [aJ.B, ic.x, io.n, ir.Z, id.V.configure({
                            placeholder: "Your name"
                        })],
                        content: "<p>".concat(null !== (t = l.name) && void 0 !== t ? t : "", "</p>"),
                        editorProps: {
                            attributes: {
                                class: (0, F.Z)(i, "rt-editor")
                            }
                        }
                    }, [i]);
                    return (0, M.useEffect)(() => {
                        o && o.setEditable(s)
                    }, [s, o]), (0, t4.F)(o, a), (0, c.jsxs)(c.Fragment, {
                        children: [(!o || !s) && (0, c.jsx)("div", {
                            className: (0, F.Z)(i, "rt-editor"),
                            children: l.name
                        }), o && s && (0, c.jsx)(t2, {
                            editor: o
                        }, s ? "editable" : "non-editable")]
                    })
                };

            function a1(e) {
                let t = (0, M.useRef)(),
                    l = (0, M.useRef)(120);
                return s => {
                    (0, z.c)().track("SHARE_LINK_COPIED"), navigator.clipboard.writeText(window.location.href).catch(() => {});
                    let n = s.target,
                        a = n.closest("button");
                    if (!a) return;
                    let r = a.getBoundingClientRect();
                    i.e(636).then(i.bind(i, 59636)).then(t => {
                        t.default({
                            origin: "up" === e ? {
                                x: (r.left + r.width / 2) / window.innerWidth,
                                y: (r.top + 0) / window.innerHeight
                            } : {
                                x: .5,
                                y: -.01
                            },
                            spread: "up" === e ? 120 : 180,
                            particleCount: "up" === e ? l.current : 2 * l.current,
                            angle: 90,
                            gravity: "up" === e ? 1 : 3,
                            scalar: "up" === e ? 1.3 : 1.4,
                            startVelocity: "up" === e ? 40 : 30
                        })
                    }).catch(e => {
                        console.error("EEE", e)
                    }), l.current = Math.max(1, Math.floor(.9 * l.current)), a.style.filter = "grayscale(".concat(1 - l.current / 120, ")"), t && clearTimeout(t.current), t.current = setTimeout(() => {
                        l.current = 120, a && (a.style.transition = "filter 0.5s ease-in-out, transform 1s ease-in-out", a.style.filter = "grayscale(0)", setTimeout(() => {
                            a.style.removeProperty("transition")
                        }, 1e3))
                    }, 1400)
                }
            }
            var a2 = i(94915),
                a4 = i.n(a2);
            let a5 = e => {
                    let {} = e, [{
                        previewing: t,
                        publishing: i
                    }, l] = (0, j.U)(), [s, n] = (0, M.useState)(!1);
                    return a1("down"), (0, c.jsxs)(k, {
                        device: "mobile",
                        children: [(0, c.jsx)("div", {
                            className: (0, F.Z)(a4().container),
                            children: (0, c.jsx)("div", {
                                className: "mt-2 flex flex-row",
                                children: (0, c.jsx)(b.z, {
                                    shine: !0,
                                    variant: "none",
                                    className: a4().button,
                                    disabled: i,
                                    onClick: () => {
                                        (0, z.c)().track("SHARE_BENTO_CLICKED"), n(!0)
                                    },
                                    children: (0, c.jsxs)("div", {
                                        className: "flex items-center text-sm",
                                        children: [!i && "Share my Bento", i && (0, c.jsxs)(c.Fragment, {
                                            children: [(0, c.jsx)(A.T, {
                                                size: 16,
                                                className: "mr-2"
                                            }), (0, c.jsx)("div", {
                                                className: "text-sm",
                                                children: "Saving..."
                                            })]
                                        })]
                                    })
                                })
                            })
                        }), (0, c.jsx)(ev, {
                            open: s,
                            setOpen: n
                        })]
                    })
                },
                a9 = e => {
                    let {} = e, [{
                        editing: t,
                        editable: i,
                        profile: l
                    }] = (0, j.U)(), s = l.image || t, n = (0, eZ.A)(e => e.engine), a = (0, eL.$)(), [r, o] = (0, M.useState)(null);
                    return (0, M.useEffect)(() => {
                        if (n && r) {
                            window.screen.width >= 1260 && (r.style.transform = "translate(0, 40px)");
                            let e = r.querySelector("[data-avatar]");
                            e && ("desktop" === a ? e.style.transform = "rotateZ(-8deg)" : e.style.transform = "rotateZ(0deg)"), setTimeout(() => {
                                r.style.transition = "opacity 1s cubic-bezier(0.42, 0, 0.25, 1), transform 1s cubic-bezier(0.2, 1.18, 0.47, 1)", r.style.opacity = "1", r.style.transform = "translate(0, 0px)", e && (e.style.transition = "transform 1s cubic-bezier(0.2, 1.18, 0.47, 1)", e.style.transform = "rotateZ(0deg)")
                            }, 0)
                        }
                    }, [n, a, r]), (0, c.jsxs)(P.m.div, {
                        ref: o,
                        animate: "enter",
                        initial: "initial",
                        exit: "exit",
                        transition: {
                            y: {
                                duration: 1,
                                ease: [0, .66, .25, 1]
                            },
                            opacity: {
                                duration: 1,
                                ease: e$.S
                            }
                        },
                        style: {
                            opacity: 0
                        },
                        className: "relative xl:sticky xl:top-16",
                        children: [s && (0, c.jsxs)("div", {
                            "data-avatar": !0,
                            className: "s-[120px] xl:s-[184px]",
                            children: [!t && l.image && (0, c.jsx)(K.q, {
                                src: (0, _.En)(l.image, {
                                    w: 300,
                                    h: 300
                                }),
                                className: "s-full"
                            }), t && (0, c.jsx)(aV, {
                                src: (0, _.En)(l.image, {
                                    w: 300,
                                    h: 300
                                }),
                                className: "s-full"
                            })]
                        }), (0, c.jsxs)("div", {
                            className: (0, F.Z)("ml-2 w-[calc(100%-8px)] max-w-[min(500px,100%-8px)] xl:max-w-[min(500px,calc(100vw_-_1000px))]", s && "mt-8"),
                            children: [(0, c.jsx)("div", {
                                className: "text-[32px] font-bold leading-[120%] tracking-[-1px] xl:text-[44px] xl:tracking-[-2px]",
                                children: (0, c.jsx)(a0, {})
                            }), (0, c.jsx)("div", {
                                className: (0, F.Z)("mt-3 text-[#565656] xl:mt-3 xl:text-xl"),
                                children: (0, c.jsx)(aQ, {})
                            })]
                        }), i && (0, c.jsx)(a5, {})]
                    })
                };
            var a7 = i(4637),
                a3 = i(3207),
                a6 = i(88403),
                a8 = i.n(a6),
                re = i(51101);
            let rt = e => "bento-link-input-".concat((0, re.l)(e)),
                ri = (0, M.forwardRef)((e, t) => {
                    var i, l, s, n, a, r, o, d, u, x, h;
                    let {
                        className: m,
                        platform: p,
                        href: v,
                        onAdd: g,
                        onRemove: f,
                        ..._
                    } = e, j = !1, [w, y, N] = function(e) {
                        let [t, i] = (0, M.useState)(""), l = e => {
                            i(e.target.value)
                        };
                        return [t, l, i]
                    }(0);
                    if (!p) throw Error("Unknown Platform ".concat(v));
                    let C = e => p.match(e),
                        k = e => {
                            let t = e.startsWith("https://") || e.startsWith("http://") ? e : "https://".concat(e);
                            j || (j = !0, setTimeout(() => {
                                j = !1
                            }, 50), N(""), g(t))
                        },
                        S = async () => {
                            try {
                                if (navigator.clipboard) {
                                    let e = (await navigator.clipboard.readText()).trim();
                                    C(e) || !p.makeProfileUrl ? k(e) : k(p.makeProfileUrl(e))
                                }
                            } catch (e) {}
                        },
                        L = () => {
                            let e = w.trim();
                            e && (C(e) || !p.makeProfileUrl ? k(e) : k(p.makeProfileUrl(e)))
                        },
                        I = e => {
                            let t = e.clipboardData.getData("text").trim();
                            e.preventDefault(), e.stopPropagation(), C(t) || !p.makeProfileUrl ? k(t) : k(p.makeProfileUrl(t))
                        };
                    return (0, c.jsxs)("div", {
                        ref: t,
                        className: (0, F.Z)(a8().container, m),
                        "data-link-input-href": v,
                        ..._,
                        children: [(0, c.jsx)(E.u, {
                            delayDuration: 200,
                            tooltip: p.name,
                            disableHoverableContent: !0,
                            children: (0, c.jsxs)("div", {
                                className: (0, F.Z)(a8()["icon-container"]),
                                style: {
                                    backgroundColor: null !== (o = null === (i = p.colors) || void 0 === i ? void 0 : i.primary) && void 0 !== o ? o : "#000"
                                },
                                children: [(0, M.createElement)(p.icon, {
                                    size: 44
                                }), (0, c.jsx)(X.k, {})]
                            })
                        }), (0, c.jsxs)("div", {
                            className: (0, F.Z)(a8()["input-container"], !1),
                            style: {
                                backgroundColor: v ? null !== (d = null === (l = p.colors) || void 0 === l ? void 0 : l.primary) && void 0 !== d ? d : "#fff" : void 0,
                                color: v ? null !== (u = null === (s = p.colors) || void 0 === s ? void 0 : s.text) && void 0 !== u ? u : "#000" : void 0
                            },
                            children: [!v && (0, c.jsxs)(c.Fragment, {
                                children: [p.makeProfileUrl && (0, c.jsx)("div", {
                                    className: "ml-3 -mt-[2px] -mr-2.5 text-sm",
                                    children: "@"
                                }), (0, c.jsx)("input", {
                                    id: rt(null !== (x = p.name) && void 0 !== x ? x : "any"),
                                    placeholder: p.name ? "username" : "Any link...",
                                    className: (0, F.Z)(a8().input),
                                    onChange: y,
                                    onPaste: I,
                                    value: w,
                                    onBlur: () => L(),
                                    tabIndex: 8,
                                    onKeyDown: e => {
                                        "Enter" === e.key && L()
                                    }
                                })]
                            }), v && (0, c.jsxs)("div", {
                                className: "flex max-w-full flex-1 items-center pl-3",
                                children: [(0, c.jsx)("div", {
                                    className: "mr-1 -mb-[3px] flex items-center",
                                    children: (0, c.jsx)(a3.r, {
                                        size: 14
                                    })
                                }), (0, c.jsx)("div", {
                                    className: "flex-1 truncate font-medium",
                                    children: p.getDisplayName(v)
                                }), (0, c.jsx)(R, {
                                    variant: "transparent",
                                    size: 32,
                                    onClick: f,
                                    tabIndex: 8,
                                    children: (0, c.jsx)("div", {
                                        style: {
                                            color: null === (n = p.colors) || void 0 === n ? void 0 : n.text
                                        },
                                        children: (0, c.jsx)(O.b, {
                                            size: 14
                                        })
                                    })
                                })]
                            }), (0, c.jsxs)("div", {
                                className: (0, F.Z)(a8()["action-container"]),
                                children: [!w && !v && (0, c.jsx)("div", {
                                    className: (0, F.Z)(a8()["paste-button-container"], "hidden lg:block"),
                                    children: (0, c.jsx)(b.z, {
                                        variant: "white",
                                        className: (0, F.Z)("h-[32px] !py-0", a8()["button--shadow"]),
                                        onClick: S,
                                        children: (0, c.jsx)("div", {
                                            className: "text-sm",
                                            children: "Paste"
                                        })
                                    })
                                }), w && !v && (0, c.jsx)(b.z, {
                                    variant: "success",
                                    className: (0, F.Z)("h-[32px] !py-0", a8()["button--shadow"]),
                                    onClick: L,
                                    tabIndex: -1,
                                    children: (0, c.jsx)("div", {
                                        className: "text-sm",
                                        children: "Add"
                                    })
                                }), !1]
                            }), v && ["#fff", "#ffffff"].includes(null !== (h = null === (a = p.colors) || void 0 === a ? void 0 : null === (r = a.primary) || void 0 === r ? void 0 : r.toLocaleLowerCase()) && void 0 !== h ? h : "") && (0, c.jsx)(X.k, {})]
                        })]
                    })
                });
            ri.displayName = "BentoLinkInput";
            var rl = i(36878),
                rs = i.n(rl);
            let rn = e => {
                let {
                    children: t,
                    className: i,
                    containerClassName: l
                } = e, [s, n] = (0, M.useState)(null);
                return (0, M.useEffect)(() => {
                    if (s) {
                        let e = () => {
                            var e, t;
                            let i = s.scrollHeight - s.clientHeight,
                                l = s.scrollTop / (i + .01),
                                n = null === (e = s.parentElement) || void 0 === e ? void 0 : e.querySelector("[data-overlay-top]"),
                                a = null === (t = s.parentElement) || void 0 === t ? void 0 : t.querySelector("[data-overlay-bottom]");
                            n && (0 === i ? n.style.height = "0px" : n.style.height = "".concat(Math.round(72 * l), "px")), a && (0 === i ? a.style.height = "0px" : a.style.height = "".concat(Math.round((1 - l) * 72), "px"))
                        };
                        return s.addEventListener("scroll", e), e(), () => {
                            s.removeEventListener("scroll", e)
                        }
                    }
                }, [s]), (0, c.jsxs)("div", {
                    className: (0, F.Z)("relative", i),
                    children: [(0, c.jsx)("div", {
                        className: (0, F.Z)(l),
                        ref: n,
                        children: t
                    }), (0, c.jsx)("div", {
                        className: rs()["overlay-top"],
                        "data-overlay-top": !0
                    }), (0, c.jsx)("div", {
                        className: rs()["overlay-bottom"],
                        "data-overlay-bottom": !0
                    })]
                })
            };
            var ra = i(49254),
                rr = i(33126),
                ro = i(95375);
            let rd = () => window.dispatchEvent(new Event("pulse-bento-phantom")),
                rc = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
                ru = (0, lA.kP)(rc, 16);
            (0, lA.kP)("0123456789abcdefghijklmnopqrstuvwxyz", 6), (0, lA.kP)(rc, 24);
            var rx = i(54381);
            let rh = e => {
                    let {
                        className: t
                    } = e, {
                        step: i,
                        goToNextStep: l
                    } = (0, rx.a)(), s = () => {
                        (0, z.c)().track("PROFILE_ONBOARDING_STEP_COMPLETED", {
                            step: i,
                            skipped: !1
                        }), l()
                    }, n = () => {
                        (0, z.c)().track("PROFILE_ONBOARDING_STEP_COMPLETED", {
                            step: i,
                            skipped: !0
                        }), l()
                    };
                    return (0, c.jsxs)("div", {
                        className: (0, F.Z)("grid grid-cols-1 justify-start gap-3 xs:grid-cols-[auto_auto]", t),
                        children: [(0, c.jsx)(b.z, {
                            onClick: s,
                            className: "h-[52px] w-[190px] lg:h-[41px]",
                            children: "Next"
                        }), (0, c.jsx)(b.z, {
                            variant: "transparent",
                            onClick: n,
                            className: "h-[52px] w-[100px] lg:h-[41px]",
                            children: "Skip"
                        })]
                    })
                },
                rm = () => {
                    var e;
                    let t = (0, M.useRef)(0),
                        [{
                            profile: i
                        }, l] = (0, j.U)(),
                        s = rr.I.filter(e => e.showInOnboarding),
                        n = (0, eZ.A)(e => e.engine),
                        a = (0, eL.$)();
                    (0, M.useEffect)(() => {
                        let e = i.bento.items.filter(ti.mz);
                        if (e.length > 0) {
                            let t = Math.min(150 * e.length, 300),
                                s = t / e.length,
                                n = e.sort((e, t) => t.data.pos[a].y - e.data.pos[a].y || t.data.pos[a].x - e.data.pos[a].x).map((e, t) => setTimeout(() => {
                                    l({
                                        type: "remove-ghost",
                                        ghost: e.data
                                    })
                                }, s * t));
                            return n.push(setTimeout(() => {
                                i.bento.items.length > 0 && rd()
                            }, t)), () => {
                                n.forEach(e => clearTimeout(e))
                            }
                        }
                    }, []);
                    let r = e => {
                            var t;
                            if (e && e.name) return null === (t = i.bento.items.find(t => "link" === t.data.type && e.match(t.data.href))) || void 0 === t ? void 0 : t.data
                        },
                        o = (e, i) => {
                            var s, r;
                            let o = Array.from(document.querySelectorAll('[id^="bento-link-input-"')),
                                d = o.findIndex(t => t.id === rt(null !== (s = e.name) && void 0 !== s ? s : "any"));
                            d >= 0 && d + 1 < o.length && (null === (r = o[d + 1]) || void 0 === r || r.focus()), e.name && (0, z.c)().track("PROFILE_ONBOARDING_SOCIAL_MEDIA_ADDED", {
                                name: e.name
                            }), l({
                                type: "add-bento-item",
                                bento: {
                                    href: i,
                                    id: ru(),
                                    style: (0, _.um)("2x2", a),
                                    type: "link"
                                },
                                device: a,
                                viewSlice: null == n ? void 0 : n.view.getViewSlice()
                            }), Date.now() - t.current > 2e3 && (t.current = Date.now(), rd())
                        },
                        d = e => {
                            let t = r(e);
                            t && l({
                                type: "delete-bento-item",
                                id: t.id
                            })
                        };
                    return (0, c.jsxs)(ra.I, {
                        className: "max-w-[376px]",
                        children: [(0, c.jsx)("h1", {
                            className: "mb-10 text-2xl font-bold",
                            children: "Now, let’s add your social media accounts to your page."
                        }), (0, c.jsx)(rn, {
                            containerClassName: "no-scrollbar max-h-[calc(100vh-340px)] overflow-auto pr-4",
                            children: s.map(t => {
                                var i;
                                return (0, c.jsx)(ri, {
                                    onAdd: e => o(t, e),
                                    onRemove: () => d(t),
                                    href: null === (i = r(t)) || void 0 === i ? void 0 : i.href,
                                    platform: t,
                                    className: "mb-4 lg:mb-3"
                                }, null !== (e = t.name) && void 0 !== e ? e : ru())
                            })
                        }), (0, c.jsx)(rh, {
                            className: "mt-10"
                        })]
                    })
                };
            var rp = i(68278),
                rv = i(36330),
                rg = i(10952),
                rf = i.n(rg);
            let r_ = e => {
                    let {
                        className: t
                    } = e;
                    return (0, c.jsx)("div", {
                        className: (0, F.Z)(rf().highlight, t)
                    })
                },
                rj = e => {
                    let {
                        title: t,
                        icon: i,
                        variant: l = "default"
                    } = e;
                    return (0, c.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [(0, c.jsxs)("div", {
                            className: (0, F.Z)("relative mb-2 rounded-[7px] s-[24px]", "default" === l && "shadow-[0px_0.6px_2px_rgba(0,0,0,0.16)]", "white" === l && "shadow-[0px_0.6px_2px_rgba(0,0,0,0.06)]"),
                            children: [i, (0, c.jsx)("div", {
                                className: "absolute inset-0 rounded-[inherit] border-[1px] border-black/[0.08]"
                            }), (0, c.jsx)(r_, {
                                className: (0, F.Z)("absolute inset-[1px] rounded-[6px] border-[1px]", "default" === l && "border-white/[0.16]", "white" === l && "border-white/[0.9]")
                            })]
                        }), (0, c.jsx)("div", {
                            className: "text-sm font-semibold",
                            children: t
                        })]
                    })
                },
                rw = e => {
                    let {
                        data: t
                    } = e, [, i] = (0, j.U)(), [l, s] = (0, M.useState)(null), n = (0, eL.$)(), {
                        getUpload: a,
                        addMediaUpload: r
                    } = (0, eS.r)(), [o] = e9(e => [e.setSelectedId]), [d, u] = (0, M.useState)(!1), [x, h] = (0, M.useState)("image"), [m, p] = (0, M.useState)(void 0), v = a(t.id), g = null != m ? m : null == v ? void 0 : v.tmpUrl, f = e => ({
                        type: "media",
                        id: t.id,
                        variant: x,
                        url: e,
                        style: {
                            desktop: (0, ti.kQ)(t.dim.desktop),
                            mobile: (0, ti.kQ)(t.dim.mobile)
                        }
                    }), _ = g ? f(g) : void 0, w = e => {
                        var l;
                        let s = null === (l = e.target.files) || void 0 === l ? void 0 : l[0];
                        s && (i({
                            type: "materialize-bento-ghost",
                            bento: t,
                            device: n
                        }), setTimeout(() => {
                            o(t.id), u(!0)
                        }, 50), r(s, t.id).then(e => {
                            p(e), h((0, ez.b)(s)), i({
                                type: "replace-bento-ghost",
                                bento: f(e),
                                device: n
                            })
                        }))
                    };
                    return (0, c.jsxs)(nm, {
                        data: t,
                        flipped: d && !!g,
                        onClick: () => {
                            !d && l && l.click()
                        },
                        back: _ ? (0, c.jsx)(np, {
                            data: _,
                            pos: {
                                desktop: {
                                    x: 0,
                                    y: 0
                                }
                            }
                        }) : void 0,
                        children: [(0, c.jsx)("input", {
                            ref: s,
                            accept: "".concat(eI, ",").concat(eD),
                            type: "file",
                            multiple: !1,
                            onChange: w,
                            className: "pointer-events-none invisible h-0 w-0 opacity-0"
                        }), (0, c.jsx)(rj, {
                            title: "Add Photo",
                            icon: (0, c.jsx)("img", {
                                src: "/images/illustrations/image.png",
                                alt: "",
                                className: "rounded-[inherit]"
                            })
                        })]
                    })
                },
                ry = e => {
                    let {
                        data: t
                    } = e, [, i] = (0, j.U)(), [l, s] = (0, M.useState)(null), n = (0, eL.$)(), {
                        getUpload: a,
                        addMediaUpload: r
                    } = (0, eS.r)(), [o] = e9(e => [e.setSelectedId]), [d, u] = (0, M.useState)(!1), [x, h] = (0, M.useState)("image"), [m, p] = (0, M.useState)(void 0), v = a(t.id), g = null != m ? m : null == v ? void 0 : v.tmpUrl, f = e => ({
                        type: "media",
                        id: t.id,
                        variant: x,
                        url: e,
                        style: {
                            desktop: (0, ti.kQ)(t.dim.desktop),
                            mobile: (0, ti.kQ)(t.dim.mobile)
                        }
                    }), _ = g ? f(g) : void 0, w = e => {
                        var l;
                        let s = null === (l = e.target.files) || void 0 === l ? void 0 : l[0];
                        s && (i({
                            type: "materialize-bento-ghost",
                            bento: t,
                            device: n
                        }), setTimeout(() => {
                            o(t.id), u(!0)
                        }, 50), r(s, t.id).then(e => {
                            p(e), h((0, ez.b)(s)), i({
                                type: "replace-bento-ghost",
                                bento: f(e),
                                device: n
                            })
                        }))
                    };
                    return (0, c.jsxs)(nm, {
                        data: t,
                        flipped: d && !!g,
                        onClick: () => {
                            !d && l && l.click()
                        },
                        back: _ ? (0, c.jsx)(np, {
                            data: _,
                            pos: {
                                desktop: {
                                    x: 0,
                                    y: 0
                                }
                            }
                        }) : void 0,
                        children: [(0, c.jsx)("input", {
                            ref: s,
                            accept: "".concat(eI, ",").concat(eD),
                            type: "file",
                            multiple: !1,
                            onChange: w,
                            className: "pointer-events-none invisible h-0 w-0 opacity-0"
                        }), (0, c.jsx)(rj, {
                            title: "Add Video",
                            icon: (0, c.jsx)("img", {
                                src: "/images/illustrations/image.png",
                                alt: "",
                                className: "rounded-[inherit]"
                            })
                        })]
                    })
                },
                rb = e => {
                    let {
                        data: t
                    } = e, [, i] = (0, j.U)(), l = (0, eL.$)(), [s, n] = (0, M.useState)(void 0), [a, r] = (0, M.useState)(!1), o = () => ({
                        type: "rich-text",
                        id: t.id,
                        halign: (0, _.um)("left", l),
                        valign: (0, _.um)("top", l),
                        style: {
                            desktop: (0, ti.kQ)(t.dim.desktop),
                            mobile: (0, ti.kQ)(t.dim.mobile)
                        }
                    });
                    return (0, M.useEffect)(() => {
                        setTimeout(() => {
                            n(o())
                        }, 1e3)
                    }, []), (0, c.jsx)(nm, {
                        data: t,
                        flipped: a,
                        onClick: () => {
                            if (a) return;
                            let e = o();
                            n(e), setTimeout(() => {
                                r(!0)
                            }, 50), i({
                                type: "materialize-bento-ghost",
                                bento: t,
                                device: l
                            }), setTimeout(() => {
                                i({
                                    type: "replace-bento-ghost",
                                    bento: e,
                                    device: l
                                })
                            }, 1e3)
                        },
                        back: s ? (0, c.jsx)(np, {
                            data: s,
                            pos: {
                                desktop: {
                                    x: 0,
                                    y: 0
                                }
                            }
                        }) : void 0,
                        children: (0, c.jsx)(rj, {
                            title: "Add Note",
                            icon: (0, c.jsx)("img", {
                                src: "/images/illustrations/text.png",
                                alt: "",
                                className: "rounded-[inherit]"
                            })
                        })
                    })
                },
                rN = e => {
                    let {
                        data: t
                    } = e, [i, l] = (0, M.useState)(!1), [, s] = (0, j.U)(), n = (0, eL.$)(), [a, r] = (0, M.useState)(void 0);
                    return (0, c.jsx)(nm, {
                        data: t,
                        flipped: i,
                        onClick: () => {
                            if (i) return;
                            let e = {
                                type: "link",
                                href: "https://www.google.com/maps/@52.5141272,13.406142,13.86z",
                                id: t.id,
                                style: {
                                    desktop: (0, ti.kQ)(t.dim.desktop),
                                    mobile: (0, ti.kQ)(t.dim.mobile)
                                },
                                overrides: {
                                    mapCaption: "Berlin, Germany",
                                    mapPlace: "Berlin, Germany"
                                }
                            };
                            r(e), setTimeout(() => {
                                l(!0)
                            }, 0), s({
                                type: "materialize-bento-ghost",
                                bento: t,
                                device: n
                            }), setTimeout(() => {
                                s({
                                    type: "replace-bento-ghost",
                                    bento: e,
                                    device: n
                                })
                            }, 1e3)
                        },
                        back: a ? (0, c.jsx)(np, {
                            data: a,
                            pos: {
                                desktop: {
                                    x: 0,
                                    y: 0
                                }
                            }
                        }) : void 0,
                        children: (0, c.jsx)(rj, {
                            title: "Add Map",
                            icon: (0, c.jsx)("img", {
                                src: "/images/illustrations/map.png",
                                alt: "",
                                className: "rounded-[inherit]"
                            })
                        })
                    })
                };
            var rC = i(75126),
                rk = i.n(rC);
            let rE = !1,
                rS = (0, M.forwardRef)((e, t) => {
                    let {
                        className: i,
                        onAdd: l,
                        value: s,
                        onChange: n,
                        autoFocus: a,
                        error: r = !1,
                        id: o,
                        placeholder: d,
                        addOnPaste: u = !1,
                        addOnBlur: x = !1
                    } = e, [h, m] = (0, M.useState)(), p = () => {
                        setTimeout(() => {
                            if (h) {
                                let e = h.querySelector("input");
                                null == e || e.select()
                            }
                        }, 0)
                    };
                    (0, M.useEffect)(() => {
                        h && r && p()
                    }, [r, h]);
                    let v = e => {
                            rE || (rE = !0, setTimeout(() => {
                                rE = !1
                            }, 200), l(e))
                        },
                        g = async () => {
                            try {
                                if (navigator.clipboard) {
                                    let e = await navigator.clipboard.readText();
                                    u && v(e), n(e)
                                }
                            } catch (e) {}
                        },
                        f = () => {
                            v(s)
                        },
                        _ = e => {
                            let t = e.clipboardData.getData("text");
                            e.preventDefault(), e.stopPropagation(), u && v(t), n(t)
                        };
                    return (0, c.jsxs)("div", {
                        ref: m,
                        className: (0, F.Z)(rk()["input-container"], r && rk()["input-container--error"], i),
                        children: [(0, c.jsx)("input", {
                            ref: t,
                            id: o,
                            placeholder: d,
                            className: (0, F.Z)(rk().input),
                            onChange: e => n(e.target.value),
                            onPaste: _,
                            autoFocus: a,
                            value: s,
                            onBlur: () => x ? f() : void 0,
                            onKeyDown: e => {
                                "Enter" === e.key && f()
                            }
                        }), (0, c.jsxs)("div", {
                            className: (0, F.Z)(rk()["action-container"]),
                            children: [!s && !r && (0, c.jsx)("div", {
                                className: (0, F.Z)(rk()["paste-button-container"], "hidden lg:block"),
                                children: (0, c.jsx)(b.z, {
                                    variant: "white",
                                    className: (0, F.Z)("h-[28px] w-[53px] !rounded-[6px] !py-0", rk()["button--shadow"]),
                                    onClick: g,
                                    children: (0, c.jsx)("div", {
                                        className: "text-xs",
                                        children: "Paste"
                                    })
                                })
                            }), s && !r && (0, c.jsx)(b.z, {
                                variant: "success",
                                className: (0, F.Z)("h-[28px] w-[53px] !rounded-[6px] !py-0", rk()["button--shadow"]),
                                onClick: f,
                                tabIndex: -1,
                                children: (0, c.jsx)("div", {
                                    className: "text-xs",
                                    children: "Add"
                                })
                            }), r && (0, c.jsx)("div", {
                                className: "mr-2 text-sm font-semibold text-action-red",
                                children: "Invalid"
                            })]
                        })]
                    })
                });
            rS.displayName = "PasteInput";
            let rL = e => {
                let {
                    onChange: t
                } = e, [i, l] = (0, M.useState)("");
                return (0, c.jsxs)("div", {
                    className: "relative z-[600] w-full items-center xl:w-[300px]",
                    "data-bento-menu": !0,
                    children: [(0, c.jsxs)("div", {
                        className: "absolute left-0 top-1/2 flex h-full w-full -translate-y-1/2 items-center justify-center rounded-[7px] border-[1px] border-black/[0.08] bg-[#1ED760] shadow-[0px_1px_2px_rgba(0,0,0,0.1)] s-[28px]",
                        children: [(0, c.jsx)("svg", {
                            width: "16",
                            height: "15",
                            viewBox: "0 0 16 15",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: (0, c.jsx)("path", {
                                d: "M7.99996 0C3.85793 0 0.5 3.35792 0.5 7.50004C0.5 11.6423 3.85793 15 7.99996 15C12.1424 15 15.5 11.6423 15.5 7.50004C15.5 3.35819 12.1424 0.000358243 7.99987 0.000358243L7.99996 0ZM11.4394 10.8172C11.305 11.0375 11.0167 11.1074 10.7964 10.9722C9.03544 9.89653 6.81867 9.65292 4.20802 10.2494C3.95645 10.3067 3.70568 10.1491 3.64836 9.89742C3.59078 9.64575 3.74777 9.39498 3.99997 9.33766C6.85691 8.68494 9.30752 8.96598 11.2844 10.1742C11.5048 10.3094 11.5746 10.5969 11.4394 10.8172ZM12.3574 8.77504C12.1881 9.05017 11.8281 9.13705 11.5531 8.96778C9.53715 7.7286 6.4641 7.36973 4.07959 8.09357C3.77034 8.18698 3.44372 8.01269 3.34986 7.70398C3.25672 7.39472 3.43109 7.06872 3.7398 6.97468C6.46357 6.14821 9.84971 6.54854 12.1648 7.97123C12.4398 8.1405 12.5266 8.50044 12.3574 8.77504ZM12.4362 6.6485C10.019 5.21274 6.03091 5.08072 3.72306 5.78118C3.35246 5.89358 2.96055 5.68437 2.84824 5.31376C2.73593 4.94298 2.94497 4.55133 3.31583 4.43866C5.96508 3.6344 10.3692 3.78979 13.1521 5.44193C13.4862 5.63977 13.5954 6.07029 13.3975 6.40319C13.2005 6.73653 12.7688 6.84643 12.4365 6.6485H12.4362Z",
                                fill: "white"
                            })
                        }), (0, c.jsx)(r_, {
                            className: "absolute inset-[0px] rounded-[6px] border-white/[0.2]"
                        })]
                    }), (0, c.jsx)(rS, {
                        value: i,
                        addOnPaste: !1,
                        autoFocus: !0,
                        onAdd: t,
                        onChange: l,
                        className: "h-[28px] w-full bg-transparent pl-[36px] text-sm outline-none placeholder:text-neutral-grey20",
                        placeholder: "Link to Playlist, Podcast,..."
                    })]
                })
            };
            var rI = i(58322),
                rD = i.n(rI);
            let rZ = e => {
                let {
                    children: t,
                    data: i
                } = e, [l, s] = (0, M.useState)(null), [n] = e9(e => [e.selectedId]), a = n === i.id && "ghost" === i.type;
                return (0, M.useEffect)(() => {
                    if (a && l) {
                        let e = l.querySelector("input");
                        e && e.focus()
                    }
                }, [a]), (0, e8.createPortal)((0, c.jsx)(e1, {
                    children: (0, c.jsx)("div", {
                        ref: s,
                        className: (0, F.Z)(rD().container, a && rD()["container--visible"]),
                        "data-bento-menu": !0,
                        children: t
                    })
                }), document.body)
            };

            function rz(e) {
                let [t, i] = e9(e => [e.selectedId, e.setSelectedId]), [l, s] = (0, M.useState)(!1);
                (0, eL.$)();
                let n = (0, eM.H)();
                return {
                    selected: "touch" === n ? t === e : l,
                    setSelected: "touch" === n ? e => {} : e => s(e)
                }
            }
            let rA = e => {
                    let {
                        data: t
                    } = e, [, i] = (0, j.U)(), l = (0, eL.$)(), {
                        selected: s,
                        setSelected: n
                    } = rz(t.id), [a, r] = (0, M.useState)(!1), [o, d] = (0, M.useState)(!1), [u, x] = (0, M.useState)(void 0), h = (0, eM.H)(), m = e => {
                        let {
                            href: i
                        } = eH(e);
                        return {
                            type: "link",
                            id: t.id,
                            href: i,
                            style: {
                                desktop: (0, ti.kQ)(t.dim.desktop),
                                mobile: (0, ti.kQ)(t.dim.mobile)
                            }
                        }
                    }, p = e => {
                        !a && (o || (d(!0), setTimeout(() => {
                            let s = m(e);
                            x(s), setTimeout(() => {
                                r(!0)
                            }, 50), i({
                                type: "materialize-bento-ghost",
                                bento: t,
                                device: l
                            }), setTimeout(() => {
                                i({
                                    type: "replace-bento-ghost",
                                    bento: s,
                                    device: l
                                })
                            }, 900)
                        }, 100)))
                    };
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)(n3, {
                            open: s && !o && ("desktop" === l || "mouse" === h),
                            setOpen: n,
                            asChildTrigger: !0,
                            modal: !1,
                            portal: !0,
                            collisionPadding: 12,
                            side: "bottom",
                            animation: "flipper",
                            className: "!rounded-[12px] p-2",
                            onOpenAutoFocus: e => {
                                e.preventDefault()
                            },
                            trigger: (0, c.jsx)("div", {
                                className: "h-full w-full",
                                children: (0, c.jsx)(nm, {
                                    data: t,
                                    flipped: a,
                                    selected: s && !a,
                                    onClick: () => {
                                        n(!s)
                                    },
                                    onOutsideClick: () => {
                                        s && n(!1)
                                    },
                                    color: "#1ED760",
                                    back: u ? (0, c.jsx)(np, {
                                        data: u,
                                        pos: {
                                            desktop: {
                                                x: 0,
                                                y: 0
                                            }
                                        }
                                    }) : void 0,
                                    children: (0, c.jsx)(rj, {
                                        title: "Add Music",
                                        icon: (0, c.jsx)("div", {
                                            className: "flex h-full w-full items-center justify-center rounded-[inherit] bg-[#1ED760]",
                                            children: (0, c.jsx)("svg", {
                                                width: "16",
                                                height: "15",
                                                viewBox: "0 0 16 15",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: (0, c.jsx)("path", {
                                                    d: "M7.99996 0C3.85793 0 0.5 3.35792 0.5 7.50004C0.5 11.6423 3.85793 15 7.99996 15C12.1424 15 15.5 11.6423 15.5 7.50004C15.5 3.35819 12.1424 0.000358243 7.99987 0.000358243L7.99996 0ZM11.4394 10.8172C11.305 11.0375 11.0167 11.1074 10.7964 10.9722C9.03544 9.89653 6.81867 9.65292 4.20802 10.2494C3.95645 10.3067 3.70568 10.1491 3.64836 9.89742C3.59078 9.64575 3.74777 9.39498 3.99997 9.33766C6.85691 8.68494 9.30752 8.96598 11.2844 10.1742C11.5048 10.3094 11.5746 10.5969 11.4394 10.8172ZM12.3574 8.77504C12.1881 9.05017 11.8281 9.13705 11.5531 8.96778C9.53715 7.7286 6.4641 7.36973 4.07959 8.09357C3.77034 8.18698 3.44372 8.01269 3.34986 7.70398C3.25672 7.39472 3.43109 7.06872 3.7398 6.97468C6.46357 6.14821 9.84971 6.54854 12.1648 7.97123C12.4398 8.1405 12.5266 8.50044 12.3574 8.77504ZM12.4362 6.6485C10.019 5.21274 6.03091 5.08072 3.72306 5.78118C3.35246 5.89358 2.96055 5.68437 2.84824 5.31376C2.73593 4.94298 2.94497 4.55133 3.31583 4.43866C5.96508 3.6344 10.3692 3.78979 13.1521 5.44193C13.4862 5.63977 13.5954 6.07029 13.3975 6.40319C13.2005 6.73653 12.7688 6.84643 12.4365 6.6485H12.4362Z",
                                                    fill: "white"
                                                })
                                            })
                                        })
                                    })
                                })
                            }),
                            children: ("desktop" === l || "mouse" === h) && (0, c.jsx)(rL, {
                                onChange: p
                            })
                        }), "mobile" === l && (0, c.jsx)(rZ, {
                            data: t,
                            children: (0, c.jsx)(rL, {
                                onChange: p
                            })
                        })]
                    })
                },
                rF = e => {
                    let {
                        onChange: t
                    } = e, [i, l] = (0, M.useState)("");
                    return (0, c.jsxs)("div", {
                        className: "relative z-[600] w-full xl:w-[300px]",
                        "data-bento-menu": !0,
                        children: [(0, c.jsxs)("div", {
                            className: "absolute left-0 top-1/2 flex h-full w-full -translate-y-1/2 items-center justify-center rounded-[7px] bg-[linear-gradient(180deg,#EEEEEE_0%,rgba(255,255,255,0)_100%)] shadow-[0px_0.6px_2px_rgba(0,0,0,0.06)] s-[28px]",
                            children: [(0, c.jsx)(eb.x, {
                                size: 16
                            }), (0, c.jsx)("div", {
                                className: "absolute inset-0 rounded-[7px] border-[1px] border-black/[0.08]"
                            }), (0, c.jsx)(r_, {
                                className: "absolute inset-[1px] rounded-[6px] border-[1px] border-white/[0.9]"
                            })]
                        }), (0, c.jsx)(rS, {
                            value: i,
                            addOnPaste: !1,
                            autoFocus: !0,
                            onAdd: t,
                            onChange: l,
                            className: "h-[28px] w-full bg-transparent pl-[36px] text-sm outline-none placeholder:text-neutral-grey20",
                            placeholder: "Enter Link..."
                        })]
                    })
                },
                rM = e => {
                    let {
                        data: t
                    } = e, [, i] = (0, j.U)(), l = (0, eL.$)(), {
                        selected: s,
                        setSelected: n
                    } = rz(t.id), [a, r] = (0, M.useState)(!1), [o, d] = (0, M.useState)(!1), [u, x] = (0, M.useState)(void 0), h = (0, eM.H)(), m = e => {
                        let {
                            href: i
                        } = eH(e);
                        return {
                            type: "link",
                            id: t.id,
                            href: i,
                            style: {
                                desktop: (0, ti.kQ)(t.dim.desktop),
                                mobile: (0, ti.kQ)(t.dim.mobile)
                            }
                        }
                    }, p = e => {
                        !a && (o || (d(!0), setTimeout(() => {
                            let s = m(e);
                            x(s), setTimeout(() => {
                                r(!0)
                            }, 50), i({
                                type: "materialize-bento-ghost",
                                bento: t,
                                device: l
                            }), setTimeout(() => {
                                i({
                                    type: "replace-bento-ghost",
                                    bento: s,
                                    device: l
                                })
                            }, 900)
                        }, 100)))
                    };
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)(n3, {
                            open: s && !o && ("desktop" === l || "mouse" === h),
                            setOpen: n,
                            asChildTrigger: !0,
                            modal: !1,
                            portal: !0,
                            collisionPadding: 12,
                            side: "bottom",
                            animation: "flipper",
                            className: "!rounded-[12px] p-2",
                            onOpenAutoFocus: e => {
                                e.preventDefault()
                            },
                            trigger: (0, c.jsx)("div", {
                                className: "h-full w-full",
                                children: (0, c.jsx)(nm, {
                                    data: t,
                                    flipped: a,
                                    selected: s && !a,
                                    onOutsideClick: () => {
                                        s && n(!s)
                                    },
                                    onClick: () => {
                                        n(!s)
                                    },
                                    back: u ? (0, c.jsx)(np, {
                                        data: u,
                                        pos: {
                                            desktop: {
                                                x: 0,
                                                y: 0
                                            }
                                        }
                                    }) : void 0,
                                    children: (0, c.jsx)(rj, {
                                        title: "Add Link",
                                        icon: (0, c.jsx)("div", {
                                            className: "flex h-full w-full items-center justify-center rounded-[inherit] bg-[linear-gradient(180deg,#EEEEEE_0%,rgba(255,255,255,0)_100%)]",
                                            children: (0, c.jsx)(eb.x, {
                                                size: 16
                                            })
                                        }),
                                        variant: "white"
                                    })
                                })
                            }),
                            children: ("desktop" === l || "mouse" === h) && (0, c.jsx)(rF, {
                                onChange: p
                            })
                        }), "mobile" === l && (0, c.jsx)(rZ, {
                            data: t,
                            children: (0, c.jsx)(rF, {
                                onChange: p
                            })
                        })]
                    })
                },
                rT = e => {
                    let {
                        data: t
                    } = e;
                    switch (t.variant) {
                        case "image":
                            return (0, c.jsx)(rw, {
                                data: t
                            });
                        case "video":
                            return (0, c.jsx)(ry, {
                                data: t
                            });
                        case "note":
                            return (0, c.jsx)(rb, {
                                data: t
                            });
                        case "map":
                            return (0, c.jsx)(rN, {
                                data: t
                            });
                        case "spotify":
                            return (0, c.jsx)(rA, {
                                data: t
                            });
                        case "link":
                            return (0, c.jsx)(rM, {
                                data: t
                            })
                    }
                    throw Error("Unknown ghost variant")
                },
                rO = e => {
                    let {} = e, [{
                        editing: t,
                        editable: i,
                        profile: l
                    }] = (0, j.U)(), {
                        breakpoints: s,
                        settings: n,
                        data: a,
                        onChange: r
                    } = tO(), o = l.bento.items.filter(ti.mz), d = l.bento.items.filter(ti.zF), [u] = (0, tR.A)(e => [e.highlighting]), x = (0, eM.H)();
                    return (0, c.jsxs)(tz, {
                        breakpoints: s,
                        settings: n,
                        data: a,
                        editable: t && !u,
                        dragHandle: "touch" === x ? "[data-drag-handle]" : void 0,
                        onChange: r,
                        className: "-ml-[12px] !w-[calc(100%_+_24px)] !max-w-[calc(100%_+_24px)]",
                        children: [d.map(e => (0, c.jsxs)(tA, {
                            id: e.data.id,
                            children: [t && (0, c.jsx)("div", {
                                className: (0, F.Z)("absolute bottom-2 left-1/2 block h-[36px] w-[220px] translate-y-full -translate-x-1/2", "touch" === x && "hidden")
                            }), (0, c.jsx)(np, {
                                data: e.data,
                                pos: e.position
                            }), t && (0, c.jsx)(ax, {
                                data: e.data
                            }), t && (0, c.jsx)(nQ, {
                                data: e.data
                            })]
                        }, e.data.id)), o.map(e => (0, c.jsx)(tA, {
                            id: e.data.id,
                            "data-ghost": !0,
                            children: (0, c.jsx)(rT, {
                                data: e.data
                            })
                        }, e.data.id))]
                    })
                },
                rR = !1,
                rB = () => {
                    (0, M.useRef)(0);
                    let {
                        goToPreviousStep: e
                    } = (0, rx.a)(), [{
                        profile: t
                    }, i] = (0, j.U)(), l = t.bento, s = (0, eL.$)();
                    (0, eZ.A)(e => e.engine);
                    let [{
                        anyLinks: n
                    }, a] = v();
                    return (0, M.useEffect)(() => {
                        let e = t.bento.items.some(ti.mz);
                        if (!e && !rR) {
                            rR = !0;
                            let e = (0, rv.L)(t.bento, 6),
                                l = Math.min(500 * e.length, 1e3),
                                n = l / e.length,
                                a = e.sort((e, t) => e.data.pos[s].y - t.data.pos[s].y || e.data.pos[s].x - t.data.pos[s].x).map((e, t) => setTimeout(() => {
                                    i({
                                        type: "add-ghost",
                                        ghost: e.data
                                    })
                                }, n * t));
                            return () => {
                                rR = !1, a.forEach(e => clearTimeout(e))
                            }
                        }
                    }, []), (0, M.useEffect)(() => {
                        let e = n.reduce((e, t) => e && null != l.items.find(e => "link" === e.data.type && e.data.href === t), !0);
                        e || a(e => ({ ...e,
                            anyLinks: e.anyLinks.filter(e => null != l.items.find(t => "link" === t.data.type && t.data.href === e))
                        }))
                    }, [l, n, a]), (0, c.jsxs)(ra.I, {
                        className: "flex max-w-[376px] flex-col",
                        children: [(0, c.jsx)("div", {
                            className: "mb-10",
                            children: (0, c.jsx)("button", {
                                onClick: e,
                                className: "-m2 p-2 active:scale-90",
                                children: (0, c.jsx)(rp.Y, {
                                    size: 20
                                })
                            })
                        }), (0, c.jsx)("h1", {
                            className: "mb-10 text-2xl font-bold",
                            children: "You can also add photos, video, maps, and notes."
                        }), (0, c.jsx)("div", {
                            className: "mb-10",
                            children: (0, c.jsx)("img", {
                                src: "/images/illustrations/onboarding-step2.svg",
                                alt: ""
                            })
                        }), (0, c.jsx)(k, {
                            device: "mobile",
                            children: (0, c.jsx)(rO, {})
                        }), (0, c.jsx)(rh, {})]
                    })
                },
                rH = () => {
                    let {
                        user: e
                    } = (0, f.aC)(), {
                        step: t
                    } = (0, rx.a)(), [, l] = v(), [s, n] = (0, M.useState)(), [a, r] = (0, M.useState)(void 0), {
                        trigger: o,
                        isMutating: d
                    } = (0, tl.O$)(null == e ? void 0 : e.id), u = async () => {
                        e && (r(void 0), (0, z.c)().track("PROFILE_ONBOARDING_STEP_COMPLETED", {
                            step: t,
                            skipped: !1
                        }), l(e => ({ ...e,
                            onboarding: !1
                        })))
                    };
                    return (0, M.useEffect)(() => {
                        e && o().catch(() => {})
                    }, [null == e ? void 0 : e.id]), (0, M.useEffect)(() => {
                        s && i.e(636).then(i.bind(i, 59636)).then(e => {
                            e.default({
                                origin: {
                                    x: 0,
                                    y: 1
                                },
                                startVelocity: 90,
                                particleCount: 110,
                                spread: 70,
                                angle: 60
                            })
                        }).catch(e => {})
                    }, [s]), (0, c.jsxs)(ra.I, {
                        className: "max-w-[376px]",
                        children: [(0, c.jsxs)("svg", {
                            width: "48",
                            height: "48",
                            viewBox: "0 0 48 48",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: [(0, c.jsx)("circle", {
                                cx: "24",
                                cy: "24",
                                r: "24",
                                fill: "#4EDD76"
                            }), (0, c.jsx)("path", {
                                fillRule: "evenodd",
                                clipRule: "evenodd",
                                d: "M36.4142 15.5858C37.1953 16.3668 37.1953 17.6332 36.4142 18.4142L22.4142 32.4142C21.6332 33.1953 20.3668 33.1953 19.5858 32.4142L11.5858 24.4142C10.8047 23.6332 10.8047 22.3668 11.5858 21.5858C12.3668 20.8047 13.6332 20.8047 14.4142 21.5858L21 28.1716L33.5858 15.5858C34.3668 14.8047 35.6332 14.8047 36.4142 15.5858Z",
                                fill: "white"
                            })]
                        }), (0, c.jsx)("div", {
                            className: "flex",
                            children: (0, c.jsx)("h1", {
                                ref: n,
                                className: "typography-title-1 mb-10 mt-6",
                                children: "Looks great!"
                            })
                        }), (0, c.jsx)("div", {
                            className: "text-2xl",
                            children: "You can keep customising your profile and then share it with the world!"
                        }), (0, c.jsx)(b.z, {
                            onClick: u,
                            className: "confetti-button mt-10 h-[52px] w-[190px] lg:h-[41px]",
                            children: "Go to Profile"
                        }), (0, c.jsx)(eX.M, {
                            children: a && (0, c.jsxs)(P.m.div, {
                                initial: {
                                    opacity: 0
                                },
                                animate: {
                                    opacity: 1
                                },
                                exit: {
                                    opacity: 0
                                },
                                className: "mt-10 text-sm font-medium text-action-red",
                                children: ["Oh no, something went wrong! Reach our developers directly at", " ", (0, c.jsx)("a", {
                                    href: "mailto:support@creatorspace.dev",
                                    className: "font-semibold text-action-blue",
                                    children: "engineering@creatorpsace.dev"
                                })]
                            })
                        })]
                    })
                },
                rU = () => {
                    let [{
                        onboarding: e
                    }] = v();
                    return (0, c.jsx)(P.m.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        exit: {
                            opacity: 0
                        },
                        transition: {
                            duration: e ? 1.7 : .7,
                            ease: e$.V
                        },
                        children: (0, c.jsxs)(a7.e, {
                            children: [(0, c.jsx)(rm, {}), (0, c.jsx)(rB, {}), (0, c.jsx)(rH, {})]
                        })
                    })
                },
                rV = e => {
                    let {} = e;
                    return (0, c.jsx)(rU, {})
                };
            var rP = i(1753);
            let rG = () => {
                let {
                    ref: e,
                    setRef: t
                } = function() {
                    let [e, t] = (0, M.useState)(null), i = (0, M.useCallback)(() => {
                        if (e) {
                            let t = e.querySelectorAll("[data-phantom-content]");
                            Array.from(t).map(e => {
                                var t, i;
                                let l = e.parentElement,
                                    s = Number.parseFloat(null !== (t = l.getAttribute("data-x")) && void 0 !== t ? t : "0"),
                                    n = Number.parseFloat(null !== (i = l.getAttribute("data-y")) && void 0 !== i ? i : "0");
                                (0, tI.j)([e], {
                                    background: ["#fff", "#f6f6f6", "#fff"],
                                    transform: ["scale(0.95)", "scale(1)", "scale(0.95)"],
                                    filter: ["blur(5px)", "blur(0px)", "blur(5px)"]
                                }, {
                                    easing: [.5, 1, .89, 1],
                                    duration: 1,
                                    delay: .5 * (.2 * s + .2 * n)
                                })
                            });
                            let i = Array.from((0, eV.t)().querySelectorAll(".bento-item__content")),
                                l = [
                                    [i, {
                                        transform: ["rotate(0deg)", "rotate(".concat(.4, "deg)")]
                                    }, {
                                        easing: "ease-in-out",
                                        duration: .2
                                    }], ...[, , , ].fill(0).flatMap(() => [
                                        [i, {
                                            transform: ["rotate(".concat(.4, "deg)"), "rotate(".concat(-.4, "deg)")]
                                        }, {
                                            easing: "ease-in-out",
                                            duration: .2
                                        }],
                                        [i, {
                                            transform: ["rotate(".concat(-.4, "deg)"), "rotate(".concat(.4, "deg)")]
                                        }, {
                                            easing: "ease-in-out",
                                            duration: .2
                                        }]
                                    ]), [i, {
                                        transform: ["rotate(".concat(.4, "deg)"), "rotate(0deg)"]
                                    }, {
                                        easing: "ease-in-out",
                                        duration: .2
                                    }]
                                ];
                            (0, ro.Z)(l, {
                                delay: .2
                            })
                        }
                    }, [e]);
                    return (0, M.useEffect)(() => {
                        window.addEventListener("pulse-bento-phantom", i)
                    }, [i]), {
                        ref: e,
                        setRef: t
                    }
                }(), [i, l] = (0, eZ.A)(e => [e.engine, e.device]), [{
                    profile: s
                }] = (0, j.U)(), n = (0, N.AS)(), a = (0, M.useMemo)(() => {
                    if (!i) return (0, c.jsx)(c.Fragment, {});
                    let e = (0, tf.D)(l),
                        t = (0, _.uZ)(Math.round(n / 150), 2, 20) + 1,
                        a = (0, tF.EM)(s.bento),
                        r = (0, th.ru)((0, tm.f)(a, l), l),
                        o = (0, rP.tJ)(r, l),
                        d = (t, i) => {
                            for (let l = 0; l < 2; l++)
                                for (let s = 0; s < 2; s++)
                                    if (t + l >= e || !(i + s >= o.length) && o[i + s][t + l]) return !1;
                            return !0
                        };
                    Array(t).fill(Array(e).fill(0));
                    let u = 0,
                        x = 0,
                        h = [];
                    for (; x < t;) {
                        if (d(u, x)) {
                            h.push({
                                x: u,
                                y: x
                            });
                            for (let t = 0; t < 2; t++)
                                for (let i = 0; i < 2; i++) u + t >= e || (o[x + i] || (o[x + i] = Array(e).fill(!1)), o[x + i][u + t] = !0);
                            u += 2
                        } else u += 1;
                        u > e && (x++, u = 0)
                    }
                    let m = null == i ? void 0 : i.view.getHeights(),
                        p = (e, t) => {
                            var l, s, n, a, r, o;
                            let d = i.settings.spacing,
                                c = i.view.getCellSize(),
                                u = t * (c + d);
                            m && m.length > 0 && (u = null !== (a = null === (n = m[t]) || void 0 === n ? void 0 : n.start) && void 0 !== a ? a : m[m.length - 1].end + d + (t - m.length) * (c + d));
                            let x = (null !== (r = null === (l = m[t]) || void 0 === l ? void 0 : l.end) && void 0 !== r ? r : 0) - (null !== (o = null === (s = m[t]) || void 0 === s ? void 0 : s.start) && void 0 !== o ? o : 0) || c;
                            return {
                                position: "absolute",
                                transform: "translate(".concat((c + d) * e, "px, ").concat(u, "px)"),
                                width: 2 * c + 1 * d,
                                height: (x + d) * 2 - d
                            }
                        };
                    return h.map(e => (0, c.jsx)("div", {
                        style: p(e.x, e.y),
                        "data-phantom-item": !0,
                        "data-x": e.x,
                        "data-y": e.y,
                        children: (0, c.jsx)("div", {
                            "data-phantom-content": !0,
                            className: "h-full w-full rounded-[24px]"
                        })
                    }, "".concat(e.x, "-").concat(e.y)))
                }, [i, l, s.bento, n]);
                return i ? (0, c.jsx)("div", {
                    ref: t,
                    className: "relative w-full",
                    children: a
                }) : null
            };
            var rW = i(9181);
            let rJ = e => {
                    let {
                        size: t = 16,
                        className: i
                    } = e;
                    return (0, c.jsxs)("svg", {
                        width: t,
                        height: t,
                        className: i,
                        viewBox: "0 0 16 16",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, c.jsx)("rect", {
                            x: "1",
                            y: "3",
                            width: "15",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("rect", {
                            y: "11",
                            width: "15",
                            height: "2",
                            rx: "1",
                            fill: "currentColor"
                        }), (0, c.jsx)("circle", {
                            cx: "10",
                            cy: "4",
                            r: "2",
                            fill: "white",
                            stroke: "currentColor",
                            strokeWidth: "2"
                        }), (0, c.jsx)("circle", {
                            cx: "6",
                            cy: "12",
                            r: "2",
                            fill: "white",
                            stroke: "currentColor",
                            strokeWidth: "2"
                        })]
                    })
                },
                rY = (0, M.forwardRef)((e, t) => {
                    let i = (0, c.jsx)("button", { ...e,
                        ref: t,
                        type: "button",
                        "aria-label": "Open Settings",
                        style: {
                            transition: "transform 100ms cubic-bezier(0.427, 0.073, 0.105, 0.997),color 100ms cubic-bezier(0.427, 0.073, 0.105, 0.997)"
                        },
                        className: (0, F.Z)("!mr-0 rounded-full  p-2  text-[#8E8E8E] outline-none transition-all hover:bg-[#F6F6F6] focus-visible:bg-[#F6F6F6] active:scale-[0.86] data-[state=open]:bg-[#F6F6F6] data-[state=open]:text-black"),
                        children: (0, c.jsx)(rJ, {
                            size: 16
                        })
                    });
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)(k, {
                            device: "desktop",
                            children: (0, c.jsx)(S.pn, {
                                children: (0, c.jsx)(E.u, {
                                    delayDuration: 300,
                                    disableHoverableContent: !0,
                                    closeOnClick: !0,
                                    tooltip: (0, c.jsx)(e_, {
                                        content: "Settings"
                                    }),
                                    children: i
                                })
                            })
                        }), (0, c.jsx)(k, {
                            device: "mobile",
                            children: i
                        })]
                    })
                });
            rY.displayName = "SettingsButton";
            var rq = i(33418),
                rK = i(56886),
                rX = i(6401);
            let r$ = e => {
                let {
                    setMode: t
                } = e, {
                    user: i
                } = (0, f.aC)(), [l, s] = (0, M.useState)(""), [n, a] = (0, M.useState)(!1), [r, o] = (0, M.useState)(!1), {
                    trigger: d,
                    isMutating: u,
                    error: x
                } = (0, rq.y)(null == i ? void 0 : i.id), h = "" === l, m = !n && x;
                return (0, M.useEffect)(() => {
                    t && t("password")
                }, [r]), (0, c.jsx)("div", {
                    className: "flex flex-grow flex-col",
                    children: !n && r ? (0, c.jsxs)("div", {
                        className: "flex flex-grow flex-col items-center justify-center gap-3 py-4",
                        children: [(0, c.jsx)("span", {
                            className: "rounded-full shadow-[0px_1px_2px_rgba(0,0,0,0.12)]",
                            children: (0, c.jsx)(rX.M, {
                                size: 48,
                                className: " text-action-green "
                            })
                        }), (0, c.jsx)("p", {
                            className: "text-sm font-semibold",
                            children: "Your password was updated"
                        })]
                    }) : (0, c.jsxs)("form", {
                        onSubmit: e => {
                            e.preventDefault(), d({
                                password: l
                            }).then(() => {
                                o(!0)
                            }).catch(e => {
                                o(!1)
                            }), a(!1)
                        },
                        className: "flex flex-col gap-3",
                        children: [(0, c.jsxs)("div", {
                            children: [(0, c.jsx)("h3", {
                                className: "text-2xl font-semibold xl:text-sm",
                                children: "Change Password"
                            }), (0, c.jsx)("p", {
                                className: "text-xs text-neutral-grey30",
                                children: "Change the password you use to log in to Bento."
                            })]
                        }), (0, c.jsx)(rK.W, {
                            className: "rounded-[12px] xl:rounded-[6px]",
                            autoComplete: "new-password",
                            placeholder: "New Password",
                            value: l,
                            autoFocus: !0,
                            onChange: e => {
                                s(e.target.value), a(!0)
                            }
                        }, "password-input"), (0, c.jsxs)("div", {
                            className: "relative flex flex-col",
                            children: [(0, c.jsx)(eX.M, {
                                children: m && (0, c.jsx)("p", {
                                    className: "absolute z-20 text-xs text-action-red",
                                    children: x.message
                                })
                            }), (0, c.jsx)(b.z, {
                                type: "submit",
                                disabled: h,
                                variant: "primary-blue",
                                className: (0, F.Z)("!py-3", h && "opacity-40", m && "invisible relative z-10 opacity-0"),
                                loading: u,
                                children: "Save Password"
                            })]
                        })]
                    })
                })
            };
            var rQ = i(11896),
                r0 = i(5632),
                r1 = i(30474);
            let r2 = {
                    hidden: {
                        opacity: 0,
                        transition: {
                            duration: .3
                        }
                    },
                    visible: {
                        opacity: 1,
                        transition: {
                            duration: .3
                        }
                    }
                },
                r4 = e => {
                    var t;
                    let {
                        setMode: i
                    } = e, {
                        user: l
                    } = (0, f.aC)(), s = (0, r0.useRouter)(), {
                        trigger: n,
                        isMutating: a,
                        error: r
                    } = (0, tl.wp)(null == l ? void 0 : l.id), [o, d] = (0, M.useState)(null !== (t = null == l ? void 0 : l.handle) && void 0 !== t ? t : ""), {
                        handle: u,
                        loading: x
                    } = (0, r1.t)(o), h = a1("up"), [m, p] = (0, M.useState)(!1), [v, g] = (0, M.useState)(!1), _ = !x && !!(null == u ? void 0 : u.isBlocked) && o !== (null == l ? void 0 : l.handle), j = !x && !(null == u ? void 0 : u.isFree) && o !== (null == l ? void 0 : l.handle), w = "" !== o && (j || !m && void 0 !== r);
                    (0, M.useEffect)(() => {
                        i && i(v ? "username-success" : "username")
                    }, [v]);
                    let y = x || "" === o || (null == l ? void 0 : l.handle) === o || j || _;
                    return l ? (0, c.jsx)("div", {
                        className: "flex flex-grow flex-col",
                        children: (0, c.jsx)(eX.M, {
                            mode: "wait",
                            children: !m && v ? (0, c.jsxs)(P.m.div, {
                                variants: r2,
                                initial: "hidden",
                                animate: "visible",
                                exit: "hidden",
                                className: "flex flex-grow flex-col justify-center gap-3 py-[30px] xl:py-[25px]",
                                children: [(0, c.jsxs)("div", {
                                    className: "mb-4 flex flex-col items-center gap-3 xl:mb-0",
                                    children: [(0, c.jsx)("span", {
                                        className: "rounded-full shadow-[0px_1px_2px_rgba(0,0,0,0.12)]",
                                        children: (0, c.jsx)(rX.M, {
                                            size: 48,
                                            className: " text-action-green "
                                        })
                                    }), (0, c.jsx)("p", {
                                        className: "text-lg font-semibold xl:text-sm",
                                        children: "Your new username is"
                                    })]
                                }), (0, c.jsxs)("div", {
                                    className: "rounded-[12px] bg-neutral-grey10 py-3 text-center text-sm xl:rounded-[6px]",
                                    children: [(0, c.jsx)("span", {
                                        className: "text-neutral-grey30",
                                        children: "bento.me/"
                                    }), (0, c.jsx)("span", {
                                        children: l.handle
                                    })]
                                }), (0, c.jsx)(b.z, {
                                    onClick: h,
                                    className: "mt-2 !py-3 !text-sm xl:mt-0",
                                    type: "button",
                                    variant: "success",
                                    children: "Copy my Link"
                                }), (0, c.jsx)("p", {
                                    className: "mx-auto mt-3 max-w-[290px] text-center text-xs text-neutral-grey30 xl:mt-2",
                                    children: "The link is ready for your bio!"
                                })]
                            }) : (0, c.jsxs)(P.m.form, {
                                onSubmit: async e => {
                                    e.preventDefault(), await n({
                                        handle: o
                                    }).then(() => {
                                        g(!0), s.replace("/".concat(o))
                                    }).catch(() => {
                                        g(!1)
                                    }), p(!1)
                                },
                                variants: r2,
                                initial: "hidden",
                                animate: "visible",
                                exit: "hidden",
                                className: "flex flex-col gap-3",
                                children: [(0, c.jsxs)("div", {
                                    className: "mb-[2px] ",
                                    children: [(0, c.jsx)("h3", {
                                        className: "text-2xl font-semibold xl:text-sm",
                                        children: "Change Username"
                                    }), (0, c.jsx)("p", {
                                        className: "text-xs text-neutral-grey30",
                                        children: "Choose a new username for your Bento."
                                    })]
                                }), (0, c.jsx)("div", {
                                    className: "relative",
                                    children: (0, c.jsx)(am.I, {
                                        name: "handle",
                                        variant: "plain",
                                        autoFocus: !0,
                                        className: "rounded-[12px] bg-neutral-grey10 py-3 px-3 xl:rounded-[6px]",
                                        addonLeft: (0, c.jsx)("div", {
                                            className: "whitespace-nowrap text-neutral-grey30",
                                            children: "bento.me/"
                                        }),
                                        addonRight: o ? (0, c.jsx)("div", {
                                            className: "flex w-[18px] items-center justify-center",
                                            children: (0, c.jsxs)(eX.M, {
                                                mode: "wait",
                                                children: [x && o !== (null == l ? void 0 : l.handle) && (0, c.jsx)(P.m.span, {
                                                    variants: r2,
                                                    initial: "hidden",
                                                    animate: "visible",
                                                    exit: "hidden",
                                                    children: (0, c.jsx)(A.T, {
                                                        size: 12
                                                    })
                                                }), !x && (null == u ? void 0 : u.isFree) && (null == l ? void 0 : l.handle) !== o && (0, c.jsx)(P.m.span, {
                                                    variants: r2,
                                                    initial: "hidden",
                                                    animate: "visible",
                                                    exit: "hidden",
                                                    children: (0, c.jsx)(rX.M, {
                                                        className: "text-action-green",
                                                        size: 16,
                                                        checkmarkDelay: "0s"
                                                    })
                                                }), j && (0, c.jsx)(P.m.button, {
                                                    variants: r2,
                                                    initial: "hidden",
                                                    animate: "visible",
                                                    exit: "hidden",
                                                    onClick: () => d(""),
                                                    children: (0, c.jsx)(O.b, {
                                                        size: 14
                                                    })
                                                })]
                                            })
                                        }) : void 0,
                                        value: o,
                                        onChange: e => {
                                            d((0, re.l)(e.target.value)), p(!0)
                                        }
                                    })
                                }), (0, c.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, c.jsx)(eX.M, {
                                        children: w && (0, c.jsx)("p", {
                                            className: "absolute z-20 text-xs text-action-red",
                                            children: j || (null == r ? void 0 : r.code) === rQ.Q.HANDLE_NOT_FREE ? (0, c.jsxs)(c.Fragment, {
                                                children: ["This username seems to be taken.", (0, c.jsx)("br", {}), "Maybe you have some other ideas?"]
                                            }) : null == r ? void 0 : r.message
                                        })
                                    }), (0, c.jsx)("div", {
                                        className: (0, F.Z)("flex flex-col gap-3", w && "invisible relative z-10"),
                                        children: (0, c.jsx)(b.z, {
                                            disabled: y,
                                            loading: a,
                                            type: "submit",
                                            variant: "primary-blue",
                                            className: (0, F.Z)("!py-3", y && "opacity-40"),
                                            children: "Update My Username"
                                        })
                                    })]
                                })]
                            })
                        })
                    }) : null
                },
                r5 = (0, M.forwardRef)((e, t) => {
                    let {
                        title: i,
                        subtitle: l,
                        ...s
                    } = e;
                    return (0, c.jsx)(b.z, {
                        variant: "setting",
                        type: "button",
                        ref: t,
                        className: "!cursor-pointer !rounded-[10px] !p-3 group-[:has(button:hover)]:bg-transparent group-[:has(button:focus-visible)]:bg-transparent",
                        textAlignment: "left",
                        ...s,
                        children: (0, c.jsxs)("div", {
                            className: "flex flex-col font-normal",
                            children: [(0, c.jsx)("div", {
                                className: "text-sm xl:text-xs",
                                children: i
                            }), (0, c.jsx)("div", {
                                className: "text-sm text-neutral-grey30 xl:text-xs",
                                children: l
                            })]
                        })
                    })
                });
            r5.displayName = "SettingsListItem";
            var r9 = i(9962);
            let r7 = e => {
                    let {
                        setMode: t
                    } = e, {
                        user: i
                    } = (0, f.aC)(), {
                        trigger: l,
                        isMutating: s,
                        error: n
                    } = (0, tl.wp)(null == i ? void 0 : i.id), [a, r] = (0, M.useState)(""), [o, d] = (0, M.useState)(!1), [u, x] = (0, M.useState)(!1), h = !o && void 0 !== n;
                    (0, M.useEffect)(() => {
                        t && t(u ? "email-success" : "email")
                    }, [u]);
                    let m = !(0, r9.J)(a);
                    return (0, c.jsx)("div", {
                        className: "flex flex-grow flex-col",
                        children: !o && u ? (0, c.jsxs)("div", {
                            className: "flex flex-grow flex-col items-center justify-center gap-3 py-7",
                            children: [(0, c.jsx)("span", {
                                className: "rounded-full shadow-[0px_1px_2px_rgba(0,0,0,0.12)]",
                                children: (0, c.jsx)(rX.M, {
                                    size: 48,
                                    className: " text-action-green "
                                })
                            }), (0, c.jsx)("p", {
                                className: "text-lg font-semibold xl:text-sm",
                                children: "Your email was changed!"
                            }), (0, c.jsxs)("p", {
                                className: "text-center text-xs text-neutral-grey30",
                                children: ["Your email address was changed to ", (0, c.jsx)("br", {}), " ", (0, c.jsx)("span", {
                                    className: "text-neutral-foreground",
                                    children: null == i ? void 0 : i.email
                                }), "."]
                            })]
                        }) : (0, c.jsxs)("form", {
                            onSubmit: async e => {
                                e.preventDefault(), await l({
                                    email: a
                                }).then(() => {
                                    x(!0)
                                }).catch(() => {
                                    x(!1)
                                }), d(!1)
                            },
                            className: "flex flex-col gap-3",
                            children: [(0, c.jsxs)("div", {
                                className: "",
                                children: [(0, c.jsx)("h3", {
                                    className: "text-2xl font-semibold xl:text-sm",
                                    children: "Change Email"
                                }), (0, c.jsx)("p", {
                                    className: "text-xs text-neutral-grey30",
                                    children: "Change the email you use to log in to Bento."
                                })]
                            }), (0, c.jsx)(am.I, {
                                required: !0,
                                name: "email",
                                type: "email",
                                className: "rounded-[12px] xl:rounded-[6px]",
                                placeholder: "New Email",
                                value: a,
                                autoFocus: !0,
                                onChange: e => {
                                    r(e.target.value), d(!0)
                                }
                            }), (0, c.jsxs)("div", {
                                className: "relative flex flex-col",
                                children: [(0, c.jsx)(eX.M, {
                                    children: h && (0, c.jsx)("p", {
                                        className: "absolute z-20 text-xs text-action-red",
                                        children: n.message
                                    })
                                }), (0, c.jsx)(b.z, {
                                    loading: s,
                                    disabled: m,
                                    type: "submit",
                                    variant: "primary-blue",
                                    className: (0, F.Z)("rounded-[12px] !py-3 opacity-100 transition-opacity xl:rounded-[6px]", m && "opacity-40", h && "invisible relative z-10 opacity-0"),
                                    children: "Update My Email"
                                })]
                            })]
                        })
                    })
                },
                r3 = {
                    hidden: {
                        opacity: 0,
                        transition: {
                            duration: .2
                        }
                    },
                    visible: {
                        opacity: 1,
                        transition: {
                            duration: .2
                        }
                    }
                },
                r6 = e => {
                    var t;
                    let {
                        isActive: i,
                        setIsActive: l
                    } = e, {
                        user: s
                    } = (0, f.aC)(), {
                        signOut: n
                    } = (0, f.UQ)(), [a, r] = (0, M.useState)(null), [o, d] = (0, M.useState)(!1);
                    return (0, M.useEffect)(() => {
                        var e;
                        d(!(null == s ? void 0 : null === (e = s.credentials) || void 0 === e ? void 0 : e.includes("credentials")))
                    }, [s, d]), (0, c.jsx)(q, {
                        open: i,
                        setOpen: () => l(!1),
                        "aria-label": "Account Settings",
                        children: (0, c.jsx)("div", {
                            className: "h-[calc(90vh-50px)]",
                            children: (0, c.jsxs)("div", {
                                className: "mx-auto flex h-full max-w-[360px] flex-col gap-12",
                                children: [(0, c.jsxs)("div", {
                                    className: (0, F.Z)("flex w-full items-center pt-2", !a && "justify-end", a && "justify-between"),
                                    children: [(0, c.jsx)(eX.M, {
                                        children: (0, c.jsx)(P.m.span, {
                                            variants: r3,
                                            initial: "hidden",
                                            animate: "visible",
                                            exit: "hidden",
                                            children: a && (0, c.jsx)(b.z, {
                                                className: (0, F.Z)("!p-4", !a && "invisible"),
                                                onClick: e => {
                                                    r(null)
                                                },
                                                variant: "secondary",
                                                "aria-label": "Back to all settings",
                                                icon: (0, c.jsx)(rp.Y, {
                                                    size: 20
                                                })
                                            })
                                        })
                                    }), (0, c.jsx)(b.z, {
                                        variant: "success",
                                        className: "!px-6 !py-3 !text-xl",
                                        onClick: e => {
                                            l(!1), r(null)
                                        },
                                        children: "Done"
                                    })]
                                }), (0, c.jsx)(eX.M, {
                                    mode: "wait",
                                    children: a ? (0, c.jsxs)("div", {
                                        className: "flex-grow",
                                        children: ["username" === a && (0, c.jsx)(P.m.div, {
                                            className: "flex h-full flex-col",
                                            variants: r3,
                                            initial: "hidden",
                                            animate: "visible",
                                            exit: "hidden",
                                            children: (0, c.jsx)(r4, {})
                                        }), "email" === a && (0, c.jsx)(P.m.div, {
                                            className: "flex h-full flex-col",
                                            variants: r3,
                                            initial: "hidden",
                                            animate: "visible",
                                            exit: "hidden",
                                            children: (0, c.jsx)(r7, {})
                                        }), "password" === a && (0, c.jsx)(P.m.div, {
                                            className: "flex h-full flex-col",
                                            variants: r3,
                                            initial: "hidden",
                                            animate: "visible",
                                            exit: "hidden",
                                            children: (0, c.jsx)(r$, {})
                                        })]
                                    }) : (0, c.jsxs)(P.m.div, {
                                        variants: r3,
                                        initial: "hidden",
                                        animate: "visible",
                                        exit: "hidden",
                                        className: "flex flex-grow flex-col justify-between",
                                        children: [(0, c.jsxs)("ul", {
                                            className: "flex flex-col overflow-auto",
                                            role: "tablist",
                                            children: [(0, c.jsx)("li", {
                                                children: (0, c.jsx)(r5, {
                                                    onClick: e => {
                                                        r("username")
                                                    },
                                                    title: "Change Username",
                                                    subtitle: "/".concat(null == s ? void 0 : s.handle)
                                                })
                                            }), (0, c.jsx)("li", {
                                                children: (0, c.jsx)(r5, {
                                                    onClick: e => {
                                                        r("email")
                                                    },
                                                    disabled: o,
                                                    title: "Change Email",
                                                    subtitle: o ? "Signed in with Google" : null !== (t = null == s ? void 0 : s.email) && void 0 !== t ? t : ""
                                                })
                                            }), (0, c.jsx)("li", {
                                                children: (0, c.jsx)(r5, {
                                                    onClick: e => {
                                                        r("password")
                                                    },
                                                    disabled: o,
                                                    subtitle: o ? "Signed in with Google" : (0, c.jsx)("span", {
                                                        className: "font-black",
                                                        children: "\xb7 \xb7 \xb7 \xb7 \xb7 \xb7 \xb7"
                                                    }),
                                                    title: "Change password"
                                                })
                                            })]
                                        }), (0, c.jsx)("button", {
                                            onClick: () => {
                                                (0, z.c)().track("LOGOUT_CLICKED"), n().catch(() => {})
                                            },
                                            className: "mb-20 text-sm text-action-red",
                                            children: "Log out"
                                        })]
                                    })
                                })]
                            })
                        })
                    })
                },
                r8 = () => {
                    var e;
                    let {
                        user: t
                    } = (0, f.aC)(), {
                        signOut: i
                    } = (0, f.UQ)(), [l, s] = (0, M.useState)(!1), [n, a] = (0, M.useState)(null);
                    return (0, M.useEffect)(() => {
                        var e;
                        s(!(null == t ? void 0 : null === (e = t.credentials) || void 0 === e ? void 0 : e.includes("credentials")))
                    }, [t, s]), (0, c.jsxs)(n3, {
                        asChildTrigger: !0,
                        modal: !0,
                        align: "start",
                        alignOffset: -10,
                        animation: "flipper",
                        sideOffset: 20,
                        className: "min-w-[210px] p-2",
                        trigger: (0, c.jsx)(rY, {}),
                        children: [(0, c.jsxs)("ul", {
                            className: "group flex flex-col",
                            role: "tablist",
                            children: [(0, c.jsx)(n3, {
                                asChildTrigger: !0,
                                layoutId: "setting-popover",
                                side: "right",
                                trigger: (0, c.jsx)(r5, {
                                    title: "Change Username",
                                    subtitle: "/".concat(null == t ? void 0 : t.handle)
                                }),
                                align: "center",
                                sideOffset: 0,
                                modal: !1,
                                children: (0, c.jsx)("div", {
                                    style: {
                                        transitionTimingFunction: "cubic-bezier(.33,.01,.19,1)"
                                    },
                                    className: (0, F.Z)("flex w-[330px] p-5 transition-all duration-300 ", "username" === n && "!h-[190px]", "username-success" === n && "!h-[318px]"),
                                    children: (0, c.jsx)(r4, {
                                        setMode: a
                                    })
                                })
                            }), (0, c.jsx)(n3, {
                                asChildTrigger: !0,
                                layoutId: "setting-popover",
                                side: "right",
                                trigger: (0, c.jsx)(r5, {
                                    disabled: l,
                                    title: "Change Email",
                                    subtitle: l ? "Signed in with Google" : null !== (e = null == t ? void 0 : t.email) && void 0 !== e ? e : ""
                                }),
                                align: "center",
                                sideOffset: 0,
                                modal: !1,
                                children: (0, c.jsx)("div", {
                                    style: {
                                        transitionTimingFunction: "cubic-bezier(.33,.01,.19,1)"
                                    },
                                    className: (0, F.Z)("flex w-[330px] p-5 transition-all duration-100", "email" === n && "!h-[188px]", "email-success" === n && "!h-[220px]"),
                                    children: (0, c.jsx)(r7, {
                                        setMode: a
                                    })
                                })
                            }), (0, c.jsx)(n3, {
                                asChildTrigger: !0,
                                layoutId: "setting-popover",
                                side: "right",
                                trigger: (0, c.jsx)(r5, {
                                    disabled: l,
                                    title: "Change Password",
                                    subtitle: l ? "Signed in with Google" : (0, c.jsx)("span", {
                                        className: "font-black",
                                        children: "\xb7 \xb7 \xb7 \xb7 \xb7 \xb7 \xb7"
                                    })
                                }),
                                align: "center",
                                sideOffset: 0,
                                modal: !1,
                                children: (0, c.jsx)("div", {
                                    style: {
                                        transitionTimingFunction: "cubic-bezier(.33,.01,.19,1)"
                                    },
                                    className: (0, F.Z)("flex w-[330px] p-5 transition-all duration-300 ", "password" === n && "!h-[188px]", "password-success" === n && "!h-[152px]"),
                                    children: (0, c.jsx)(r$, {
                                        setMode: a
                                    })
                                })
                            })]
                        }), (0, c.jsx)("div", {
                            className: "px-3 py-2",
                            children: (0, c.jsx)("hr", {
                                className: "h-[1px] w-full rounded-sm border-0 bg-[#EFEFEF]"
                            })
                        }), (0, c.jsx)(b.z, {
                            variant: "setting",
                            type: "button",
                            className: "!cursor-pointer !rounded-[10px] !p-3",
                            textAlignment: "left",
                            onClick: () => {
                                (0, z.c)().track("LOGOUT_CLICKED"), i().catch(() => {})
                            },
                            children: (0, c.jsx)("span", {
                                className: "text-xs font-normal",
                                children: "Log Out"
                            })
                        })]
                    })
                },
                oe = () => {
                    let [e, t] = (0, M.useState)(!1), i = C();
                    return (0, c.jsx)("div", {
                        className: "relative",
                        children: "desktop" === i ? (0, c.jsx)(r8, {}) : (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(rY, {
                                onClick: e => {
                                    t(e => !e)
                                }
                            }), (0, c.jsx)(r6, {
                                isActive: e,
                                setIsActive: t
                            })]
                        })
                    })
                };
            var ot = i(92478),
                oi = i.n(ot),
                ol = i(54207),
                os = i(30299);
            let on = e => {
                let {
                    value: t,
                    className: i,
                    setActive: l
                } = e, s = t.toString().split(""), n = (0, M.useRef)(performance.now()), {
                    ref: a,
                    inView: r
                } = (0, os.YD)({
                    delay: 250,
                    triggerOnce: !0,
                    trackVisibility: !0
                }), o = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [d, u] = (0, M.useState)(s.map(e => 0));
                return (0, M.useEffect)(() => {
                    if (r) {
                        let e = setTimeout(() => {
                            null == l || l(!0), setTimeout(() => {
                                u(s.map((e, t) => {
                                    let i = parseInt(e);
                                    return i + 10 * t * 1 * (0 === i ? 0 : 1)
                                }))
                            }, 600)
                        }, Math.min(Math.max(n.current - performance.now() + 100, 0), 100) + 400);
                        return () => {
                            clearTimeout(e)
                        }
                    }
                }, [r]), (0, c.jsx)(c.Fragment, {
                    children: (0, c.jsx)("div", {
                        ref: a,
                        className: (0, F.Z)("first-letter relative inline overflow-hidden py-[3px] ordinal slashed-zero lining-nums tabular-nums", i),
                        style: {
                            fontFeatureSettings: '"ss01"',
                            WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 7px, black calc(100% - 7px), transparent 100%)"
                        },
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)("relative", i),
                            children: [(0, c.jsx)("span", {
                                className: "invisible",
                                children: t
                            }), (0, c.jsx)("div", {
                                className: "absolute left-0 top-0 flex",
                                children: d.map((e, t) => (0, c.jsx)("div", {
                                    className: "flex flex-col",
                                    style: {
                                        transition: "transform 3s cubic-bezier(0.5, 0, 0, 1)",
                                        transform: "translateY(-".concat(10 / (1 * d.length) * e, "%)")
                                    },
                                    children: (0, _.rx)(o, (t + 1) * 1).map((e, t) => (0, c.jsx)("span", {
                                        children: e
                                    }, t))
                                }, t))
                            })]
                        })
                    })
                })
            };
            var oa = i(70082),
                or = i.n(oa);
            let oo = (0, M.forwardRef)((e, t) => {
                let [{
                    profile: i
                }] = (0, j.U)(), {
                    traffic: l
                } = (0, ol.zF)(i.handle), [s, n] = (0, M.useState)(!1);
                return (0, M.useEffect)(() => {
                    if (l && 0 === l.views) {
                        let e = setTimeout(() => {
                            n(!0)
                        }, 100);
                        return () => {
                            clearTimeout(e)
                        }
                    }
                }, [l]), (0, c.jsx)("button", { ...e,
                    ref: t,
                    type: "button",
                    "aria-label": "Open Foot Traffic",
                    style: {
                        transition: "transform 100ms cubic-bezier(0.427, 0.073, 0.105, 0.997), color 100ms cubic-bezier(0.427, 0.073, 0.105, 0.997)"
                    },
                    className: (0, F.Z)("min-h-[32px] rounded-[8px] px-[10px] py-[4px] text-[14px] text-neutral-grey30 outline-none transition-all hover:bg-[#F8F8F8] focus-visible:bg-[#F6F6F6] active:scale-[0.96] data-[state=open]:bg-[#F6F6F6] data-[state=open]:text-black sm:typography-text", or()["foot-traffic-button"], s && or()["foot-traffic-button--active"]),
                    children: l && (0, c.jsxs)("div", {
                        className: "flex items-center",
                        children: [l.views > 0 && (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(on, {
                                setActive: n,
                                value: l.views,
                                className: "mr-0.5"
                            }, l.views), " ", "View", l.views > 1 ? "s" : "", " Yesterday"]
                        }), 0 === l.views && (0, c.jsx)(c.Fragment, {
                            children: "No Views Yesterday"
                        })]
                    })
                })
            });
            oo.displayName = "FootTrafficButton";
            let od = {
                    hidden: {
                        opacity: 0,
                        transition: {
                            duration: .2
                        }
                    },
                    visible: {
                        opacity: 1,
                        transition: {
                            duration: .2
                        }
                    }
                },
                oc = e => {
                    var t;
                    let {
                        isActive: i,
                        setIsActive: l
                    } = e, [{
                        profile: s
                    }] = (0, j.U)(), {
                        traffic: n
                    } = (0, ol.zF)(s.handle), [a, r] = (0, M.useState)(!1);
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)(q, {
                            open: i,
                            setOpen: () => l(!1),
                            "aria-label": "Account Settings",
                            children: (0, c.jsx)("div", {
                                className: "h-[calc(90vh-50px)]",
                                children: (0, c.jsxs)("div", {
                                    className: "mx-auto flex h-full max-w-[360px] flex-col gap-12",
                                    children: [(0, c.jsxs)("div", {
                                        className: (0, F.Z)("flex w-full items-center justify-end pt-2"),
                                        children: [n && 0 === n.views && (0, c.jsxs)(b.z, {
                                            variant: "success",
                                            className: "!px-6 !py-3 !text-xl",
                                            onClick: e => {
                                                (0, z.c)().track("SHARE_BENTO_CLICKED"), r(!0), l(!1)
                                            },
                                            children: [(0, c.jsx)("div", {
                                                className: "xxs:hidden",
                                                children: "Share"
                                            }), (0, c.jsx)("div", {
                                                className: "hidden xxs:block",
                                                children: "Share my Bento"
                                            })]
                                        }), (0, c.jsx)("div", {
                                            className: "flex-1"
                                        }), (0, c.jsx)(b.z, {
                                            variant: "success",
                                            className: "!px-6 !py-3 !text-xl",
                                            onClick: e => {
                                                l(!1)
                                            },
                                            children: "Done"
                                        })]
                                    }), (0, c.jsx)(eX.M, {
                                        mode: "wait",
                                        children: n && (0, c.jsxs)(P.m.div, {
                                            variants: od,
                                            initial: "hidden",
                                            animate: "visible",
                                            exit: "hidden",
                                            className: "flex flex-grow flex-col justify-start",
                                            children: [n.viewers.map(e => (0, c.jsx)(b.z, {
                                                as: "a",
                                                href: _.L1.profile(e.viewer.handle),
                                                rel: "noreferrer noopener",
                                                target: "_blank",
                                                variant: "transparent",
                                                children: (0, c.jsxs)("div", {
                                                    className: "flex w-full items-center",
                                                    children: [(0, c.jsxs)("div", {
                                                        className: "mr-3",
                                                        children: [e.viewer.image && (0, c.jsx)(K.q, {
                                                            src: null !== (t = e.viewer.image) && void 0 !== t ? t : void 0,
                                                            size: 32
                                                        }), !e.viewer.image && (0, c.jsx)("div", {
                                                            className: "flex items-center justify-center rounded-full border-[1px] border-black/[0.06] text-xs s-[32px]",
                                                            children: "?"
                                                        })]
                                                    }), (0, c.jsx)("div", {
                                                        className: "flex-1 text-left text-sm font-normal line-clamp-1",
                                                        children: e.viewer.handle
                                                    })]
                                                })
                                            })), n.views - n.viewers.length > 0 && (0, c.jsxs)("div", {
                                                className: "flex w-full items-center px-2.5 py-2 text-sm",
                                                children: [(0, c.jsx)("div", {
                                                    className: "mr-3",
                                                    children: (0, c.jsx)("div", {
                                                        className: "flex items-center justify-center rounded-full text-xs s-[32px]",
                                                        children: (0, c.jsx)("img", {
                                                            src: "/images/moon.png",
                                                            alt: ""
                                                        })
                                                    })
                                                }), (0, c.jsxs)("div", {
                                                    className: "flex-1 text-left font-normal text-black/40",
                                                    children: [(0, c.jsx)("span", {
                                                        className: "ordinal slashed-zero tabular-nums",
                                                        style: {
                                                            fontFeatureSettings: '"ss01"'
                                                        },
                                                        children: n.views - n.viewers.length
                                                    }), " ", n.viewers.length > 0 && "other" + (n.views - n.viewers.length > 1 ? "s" : ""), 0 === n.viewers.length && n.views - n.viewers.length > 1 && "viewers", 0 === n.viewers.length && n.views - n.viewers.length == 1 && "viewer"]
                                                })]
                                            }), n && 0 === n.views && (0, c.jsx)("div", {
                                                className: "flex w-full flex-col items-center px-3 py-3 text-base",
                                                children: (0, c.jsx)("div", {
                                                    className: "mb-4 w-full pt-1 text-center",
                                                    children: "Share your Bento so people can find it"
                                                })
                                            })]
                                        })
                                    })]
                                })
                            })
                        }), (0, c.jsx)(ev, {
                            open: a,
                            setOpen: r
                        })]
                    })
                },
                ou = () => {
                    var e;
                    let [{
                        profile: t
                    }] = (0, j.U)(), {
                        traffic: i
                    } = (0, ol.zF)(t.handle), [l, s] = (0, M.useState)(!1);
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsxs)(n3, {
                            asChildTrigger: !0,
                            modal: !0,
                            align: "center",
                            alignOffset: -10,
                            sideOffset: 20,
                            animation: "flipper",
                            className: "min-w-[182px] max-w-[230px] !rounded-[16px]",
                            trigger: (0, c.jsx)(oo, {}),
                            children: [i && i.views > 0 && (0, c.jsxs)("div", {
                                className: "flex flex-col p-2",
                                children: [i.viewers.map(t => (0, c.jsx)(b.z, {
                                    as: "a",
                                    href: _.L1.profile(t.viewer.handle),
                                    rel: "noreferrer noopener",
                                    target: "_blank",
                                    variant: "transparent",
                                    className: "!rounded-[8px] active:!scale-[0.97]",
                                    children: (0, c.jsxs)("div", {
                                        className: "flex w-full items-center",
                                        children: [(0, c.jsxs)("div", {
                                            className: "mr-3",
                                            children: [t.viewer.image && (0, c.jsx)(K.q, {
                                                src: null !== (e = t.viewer.image) && void 0 !== e ? e : void 0,
                                                size: 20
                                            }), !t.viewer.image && (0, c.jsx)("div", {
                                                className: "flex items-center justify-center rounded-full border-[1px] border-black/[0.06] text-xs s-[20px]",
                                                children: "?"
                                            })]
                                        }), (0, c.jsx)("div", {
                                            className: "flex-1 text-left text-xs font-normal line-clamp-1",
                                            children: t.viewer.handle
                                        })]
                                    })
                                })), i.views - i.viewers.length > 0 && (0, c.jsxs)("div", {
                                    className: "flex w-full items-center px-2.5 py-2 text-xs",
                                    children: [(0, c.jsx)("div", {
                                        className: "mr-3",
                                        children: (0, c.jsx)("div", {
                                            className: "flex items-center justify-center rounded-full text-xs s-[20px]",
                                            children: (0, c.jsx)("img", {
                                                src: "/images/moon.png",
                                                alt: ""
                                            })
                                        })
                                    }), (0, c.jsxs)("div", {
                                        className: "flex-1 text-left text-xs font-normal text-black/40",
                                        children: [(0, c.jsx)("span", {
                                            className: "ordinal slashed-zero tabular-nums",
                                            style: {
                                                fontFeatureSettings: '"ss01"'
                                            },
                                            children: i.views - i.viewers.length
                                        }), " ", i.viewers.length > 0 && "other" + (i.views - i.viewers.length > 1 ? "s" : ""), 0 === i.viewers.length && i.views - i.viewers.length > 1 && "viewers", 0 === i.viewers.length && i.views - i.viewers.length == 1 && "viewer"]
                                    })]
                                })]
                            }), i && 0 === i.views && (0, c.jsxs)("div", {
                                className: "flex max-w-[182px] flex-col items-center px-3 py-3 text-xs",
                                children: [(0, c.jsx)("div", {
                                    className: "mb-4 max-w-[130px] pt-1 text-center",
                                    children: "Share your Bento so people can find it"
                                }), (0, c.jsx)(n6, {
                                    asChild: !0,
                                    children: (0, c.jsx)(b.z, {
                                        variant: "success",
                                        shine: !0,
                                        className: (0, F.Z)("h-[33px] w-full !rounded-[6px] !p-0 !shadow-[0px_2px_3px_rgba(0,0,0,0.06)]"),
                                        onClick: () => {
                                            (0, z.c)().track("SHARE_BENTO_CLICKED"), s(!0)
                                        },
                                        children: "Share my Bento"
                                    })
                                })]
                            })]
                        }), (0, c.jsx)(ev, {
                            open: l,
                            setOpen: s
                        })]
                    })
                },
                ox = () => {
                    let [e, t] = (0, M.useState)(!1), i = C();
                    return (0, c.jsx)("div", {
                        className: "relative",
                        children: "desktop" === i ? (0, c.jsx)(ou, {}) : (0, c.jsxs)(c.Fragment, {
                            children: [(0, c.jsx)(oo, {
                                onClick: e => {
                                    t(e => !e)
                                }
                            }), (0, c.jsx)(oc, {
                                isActive: e,
                                setIsActive: t
                            })]
                        })
                    })
                },
                oh = e => {
                    var t;
                    let {} = e, {
                        user: i
                    } = (0, f.aC)(), [{
                        id: l
                    }] = (0, j.U)(), [{
                        onboarding: s
                    }] = v(), n = C(), a = l === (null == i ? void 0 : i.id) && !!i;
                    return "mobile" !== n || s ? null : (0, c.jsxs)("div", {
                        className: "flex w-full flex-col items-center bg-[#FBFBFB] py-10 xl:hidden",
                        children: [!a && i && (0, c.jsx)(c.Fragment, {
                            children: (0, c.jsxs)("a", {
                                href: _.L1.profile(i.handle),
                                className: (0, F.Z)(oi().button, oi()["button--white"]),
                                children: [(0, c.jsx)(K.q, {
                                    src: null !== (t = (0, aR.E)(i.image)) && void 0 !== t ? t : (0, aR.l)(i.handle),
                                    size: 20,
                                    className: "mr-2"
                                }), (0, c.jsx)("div", {
                                    children: "My Bento"
                                })]
                            })
                        }), !a && !i && (0, c.jsx)(c.Fragment, {
                            children: (0, c.jsxs)(b.z, {
                                variant: "primary-blue",
                                shine: !0,
                                as: "a",
                                href: _.L1.signup(),
                                onClick: () => (0, z.c)().track("CREATE_BENTO_CLICKED"),
                                className: (0, F.Z)(oi()["shiny-button"]),
                                children: [(0, c.jsx)(rW.F, {
                                    className: "mr-2 s-[20px]"
                                }), (0, c.jsx)("div", {
                                    children: "Create Your Bento"
                                })]
                            })
                        }), (0, c.jsxs)("div", {
                            className: (0, F.Z)("flex w-[428px] max-w-full items-center px-6", !a && "mt-6", a && "justify-between", !a && "justify-center"),
                            children: [(0, c.jsxs)("div", {
                                className: "flex items-center space-x-2",
                                children: [a && (0, c.jsx)(oe, {}), (0, c.jsx)(R, {
                                    as: "a",
                                    size: 32,
                                    variant: "transparent",
                                    target: "_blank",
                                    href: "https://bento.me/explore",
                                    onClick: () => {
                                        (0, z.c)().track("EXPLORE_CLICKED")
                                    },
                                    className: "flex items-center justify-center",
                                    children: (0, c.jsxs)("svg", {
                                        width: "16",
                                        height: "16",
                                        viewBox: "0 0 16 16",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: [(0, c.jsx)("circle", {
                                            cx: "8",
                                            cy: "8",
                                            r: "6",
                                            stroke: "#8E8E8E",
                                            "stroke-width": "2"
                                        }), (0, c.jsx)("path", {
                                            d: "M6.22695 6.84827L5.68089 9.57858C5.59287 10.0187 5.98088 10.4067 6.42096 10.3187L9.15128 9.7726C9.4625 9.71035 9.70577 9.46708 9.76801 9.15587L10.3141 6.42555C10.4021 5.98546 10.0141 5.59746 9.574 5.68547L6.84368 6.23154C6.53246 6.29378 6.28919 6.53705 6.22695 6.84827Z",
                                            fill: "#8E8E8E"
                                        })]
                                    })
                                }), i && (0, c.jsx)(R, {
                                    as: "a",
                                    size: 32,
                                    variant: "transparent",
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    href: "https://discord.gg/8rJvDWaSz7",
                                    className: "flex items-center justify-center",
                                    children: (0, c.jsx)("svg", {
                                        width: "16",
                                        height: "16",
                                        viewBox: "0 0 16 16",
                                        fill: "none",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, c.jsx)("path", {
                                            d: "M13.5535 3.03729C12.5178 2.55271 11.4104 2.20053 10.2526 2C10.1104 2.25707 9.94428 2.60284 9.82974 2.8779C8.599 2.69281 7.37956 2.69281 6.17144 2.8779C6.05693 2.60284 5.88704 2.25707 5.74358 2C4.58454 2.20053 3.47584 2.554 2.44013 3.03985C0.351096 6.19666 -0.215208 9.27505 0.0679444 12.3098C1.45351 13.3444 2.79627 13.973 4.11639 14.3843C4.44232 13.9357 4.73303 13.4588 4.98345 12.9563C4.5065 12.7751 4.04969 12.5514 3.61805 12.2918C3.73256 12.2069 3.84457 12.1182 3.95279 12.0269C6.58546 13.2583 9.44593 13.2583 12.0472 12.0269C12.1566 12.1182 12.2686 12.2069 12.3819 12.2918C11.949 12.5527 11.4909 12.7763 11.0139 12.9576C11.2644 13.4588 11.5539 13.937 11.881 14.3855C13.2024 13.9742 14.5464 13.3457 15.932 12.3098C16.2642 8.79176 15.3644 5.74164 13.5535 3.03729ZM5.34212 10.4434C4.55181 10.4434 3.9037 9.70562 3.9037 8.80718C3.9037 7.90872 4.53798 7.16966 5.34212 7.16966C6.14628 7.16966 6.79437 7.90743 6.78054 8.80718C6.78178 9.70562 6.14628 10.4434 5.34212 10.4434ZM10.6578 10.4434C9.86748 10.4434 9.21941 9.70562 9.21941 8.80718C9.21941 7.90872 9.85365 7.16966 10.6578 7.16966C11.4619 7.16966 12.1101 7.90743 12.0963 8.80718C12.0963 9.70562 11.4619 10.4434 10.6578 10.4434Z",
                                            fill: "#969696"
                                        })
                                    })
                                }), !a && !i && (0, c.jsx)(b.z, {
                                    variant: "transparent",
                                    as: "a",
                                    href: _.L1.login(),
                                    onClick: () => {
                                        (0, z.c)().track("LOGIN_CLICKED")
                                    },
                                    children: (0, c.jsx)("div", {
                                        className: "text-text font-normal text-neutral-grey30",
                                        children: "Log In"
                                    })
                                })]
                            }), (0, c.jsx)("div", {
                                className: "flex items-center",
                                children: a && (0, c.jsx)(ox, {})
                            })]
                        })]
                    })
                },
                om = () => (0, c.jsxs)(P.m.div, {
                    className: "flex items-center",
                    initial: {
                        opacity: 0,
                        height: 0,
                        marginBottom: 0
                    },
                    animate: {
                        opacity: 1,
                        height: 44,
                        marginBottom: 32
                    },
                    exit: {
                        opacity: 0,
                        height: 0,
                        marginBottom: 0
                    },
                    transition: {
                        ease: e$.V,
                        duration: .7
                    },
                    children: [(0, c.jsx)("div", {
                        className: "h-[2px] flex-1 bg-[#F8F8F8]"
                    }), (0, c.jsx)("div", {
                        className: "typography-title-3 mx-4",
                        children: "Your page"
                    }), (0, c.jsx)("div", {
                        className: "h-[2px] flex-1 bg-[#F8F8F8]"
                    })]
                });
            var op = i(73906),
                ov = i.n(op);
            let og = () => {
                    let [e, t] = (0, eZ.A)(e => [e.engine, e.device]), [{
                        profile: i
                    }] = (0, j.U)(), l = (0, N.AS)(), s = (0, M.useMemo)(() => {
                        if (!e) return (0, c.jsx)(c.Fragment, {});
                        let s = (0, tf.D)(t),
                            n = (0, _.uZ)(Math.round(l / 150), 2, 20) + 1,
                            a = (0, tF.EM)(i.bento),
                            r = (0, tm.f)(a, t),
                            o = (0, rP.tJ)(r, t),
                            d = (e, t) => {
                                for (let i = 0; i < 2; i++)
                                    for (let l = 0; l < 2; l++)
                                        if (e + i >= s || !(t + l >= o.length) && o[t + l][e + i]) return !1;
                                return !0
                            };
                        Array(n).fill(Array(s).fill(0));
                        let u = 0,
                            x = 0,
                            h = [];
                        for (; x < n;) {
                            if (d(u, x)) {
                                h.push({
                                    x: u,
                                    y: x
                                });
                                for (let e = 0; e < 2; e++)
                                    for (let t = 0; t < 2; t++) u + e >= s || (o[x + t] || (o[x + t] = Array(s).fill(!1)), o[x + t][u + e] = !0);
                                u += 2
                            } else u += 1;
                            u > s && (x++, u = 0)
                        }
                        let m = null == e ? void 0 : e.view.getHeights(),
                            p = (t, i) => {
                                var l, s, n, a, r, o;
                                let d = e.settings.spacing,
                                    c = e.view.getCellSize(),
                                    u = i * (c + d);
                                m && m.length > 0 && (u = null !== (a = null === (n = m[i]) || void 0 === n ? void 0 : n.start) && void 0 !== a ? a : m[m.length - 1].end + d + (i - m.length) * (c + d));
                                let x = (null !== (r = null === (l = m[i]) || void 0 === l ? void 0 : l.end) && void 0 !== r ? r : 0) - (null !== (o = null === (s = m[i]) || void 0 === s ? void 0 : s.start) && void 0 !== o ? o : 0) || c;
                                return {
                                    position: "absolute",
                                    transform: "translate(".concat((c + d) * t, "px, ").concat(u, "px)"),
                                    width: 2 * c + 1 * d,
                                    height: (x + d) * 2 - d
                                }
                            };
                        return h.map(e => (0, c.jsx)("div", {
                            style: p(e.x, e.y),
                            "data-phantom-item": !0,
                            "data-x": e.x,
                            "data-y": e.y,
                            children: (0, c.jsx)("div", {
                                "data-phantom-content": !0,
                                className: "h-full w-full rounded-[24px] bg-[#f6f6f6]"
                            })
                        }, "".concat(e.x, "-").concat(e.y)))
                    }, [e, t, i.bento, l]);
                    return e ? (0, c.jsx)("div", {
                        className: "relative w-full",
                        children: s
                    }) : null
                },
                of = rr.I.filter(e => e.showInOnboarding),
                o_ = e => {
                    var t;
                    let {} = e;
                    (0, M.useRef)(0);
                    let [{
                        profile: i
                    }, l] = (0, j.U)(), s = (0, eZ.A)(e => e.engine), n = (0, eL.$)(), [a, r] = (0, M.useState)([]);
                    (0, M.useEffect)(() => {
                        i.bento.items.length > 0 && rd()
                    }, []);
                    let o = (e, t) => {
                            var i, l;
                            let s = Array.from(document.querySelectorAll('[id^="bento-link-input-"')),
                                n = s.findIndex(t => t.id === rt(null !== (i = e.name) && void 0 !== i ? i : "any"));
                            n >= 0 && n + 1 < s.length && (null === (l = s[n + 1]) || void 0 === l || l.focus()), r(e => [...e, t]), rd()
                        },
                        d = e => {
                            r(t => t.filter(t => {
                                var i;
                                return (null === (i = (0, eB.X)(t)) || void 0 === i ? void 0 : i.name) !== e.name
                            })), rd()
                        },
                        u = () => {
                            a.forEach((e, t) => {
                                let i = (0, eB.X)(e);
                                (null == i ? void 0 : i.name) && (0, z.c)().track("PROFILE_ONBOARDING_FALLBACK_SOCIAL_MEDIA_ADDED", {
                                    name: i.name
                                }), setTimeout(() => {
                                    l({
                                        type: "add-bento-item",
                                        bento: {
                                            href: e,
                                            id: (0, _.x0)(),
                                            style: (0, _.um)("2x2", n),
                                            type: "link"
                                        },
                                        device: n,
                                        viewSlice: null == s ? void 0 : s.view.getViewSlice()
                                    })
                                }, Math.min(1e3 / a.length, 200) * t)
                            })
                        };
                    return (0, c.jsx)(k, {
                        device: "desktop",
                        children: (0, c.jsxs)(P.m.div, {
                            animate: "enter",
                            initial: "initial",
                            exit: "exit",
                            variants: {
                                initial: {
                                    opacity: 0,
                                    y: 40
                                },
                                enter: {
                                    opacity: 1,
                                    y: 0
                                },
                                exit: {
                                    opacity: 0,
                                    y: 40,
                                    transition: {
                                        duration: 0
                                    }
                                }
                            },
                            transition: {
                                y: {
                                    duration: 1,
                                    ease: [0, .66, .25, 1]
                                },
                                opacity: {
                                    duration: 1,
                                    ease: e$.S
                                }
                            },
                            className: "pointer-events-none absolute inset-0 flex min-h-[700px] items-center justify-center",
                            children: [(0, c.jsx)("div", {
                                className: (0, F.Z)("absolute inset-0", ov()["onboarding-fade"]),
                                children: (0, c.jsx)(og, {})
                            }), (0, c.jsxs)("div", {
                                className: (0, F.Z)(ov()["onboarding-popup"]),
                                children: [(0, c.jsx)("h1", {
                                    className: "mb-10 px-2.5 pt-2.5 text-xl font-semibold",
                                    children: "Add your social media accounts to your Bento"
                                }), (0, c.jsx)(rn, {
                                    className: "flex max-h-[400px] flex-1 flex-col xl:max-h-[min(60vh-150px,600px)]",
                                    containerClassName: "no-scrollbar overflow-auto",
                                    children: of .map(e => (0, c.jsx)(ri, {
                                        onAdd: t => o(e, t),
                                        onRemove: () => d(e),
                                        href: a.find(t => {
                                            var i;
                                            return (null === (i = (0, eB.X)(t)) || void 0 === i ? void 0 : i.name) === e.name
                                        }),
                                        platform: e,
                                        className: "mb-4 lg:mb-3"
                                    }, null !== (t = e.name) && void 0 !== t ? t : (0, _.x0)()))
                                }), (0, c.jsx)("button", {
                                    onClick: u,
                                    className: "mt-7 flex h-[56px] w-full items-center justify-center space-x-2 rounded-[36px] border-[1px] border-black/[0.06] bg-[#55ACEE] text-xl font-semibold text-white shadow-[0px_2px_4px_rgba(0,0,0,0.08)] transition-all duration-100 ease-in-out hover:bg-[#49A0E2] active:scale-[0.99] active:bg-[#4198DA]",
                                    children: "Add Selected Platforms"
                                })]
                            })]
                        }, "onboarding-fallback")
                    })
                };
            var oj = i(60266);
            let ow = !1;
            var oy = i(92716),
                ob = i.n(oy);
            let oN = e => {
                    let {} = e, [t, i] = (0, M.useState)(!1), [{
                        id: l,
                        profile: s,
                        editing: n
                    }, a] = (0, j.U)(), [r, o, d] = (0, oj.Z)("bento.ghosts-blocked"), u = (0, eL.$)();
                    return (0, c.jsxs)(P.m.button, {
                        animate: {
                            opacity: 1
                        },
                        exit: {
                            opacity: 0
                        },
                        initial: {
                            opacity: 0
                        },
                        transition: {
                            duration: .5,
                            ease: e$.V
                        },
                        className: (0, F.Z)(ob()["flat-button"]),
                        onClick: () => {
                            if (!n || !l || t) return;
                            r ? o(r + "," + l) : o(l);
                            let e = s.bento.items.filter(ti.mz);
                            if (e.length > 0) {
                                let t = Math.min(150 * e.length, 300),
                                    l = t / e.length;
                                i(!0), e.sort((e, t) => t.data.pos[u].y - e.data.pos[u].y || t.data.pos[u].x - e.data.pos[u].x).map((e, t) => setTimeout(() => {
                                    a({
                                        type: "remove-ghost",
                                        ghost: e.data
                                    })
                                }, l * t))
                            }
                        },
                        children: [(0, c.jsx)(i_, {}), (0, c.jsx)("div", {
                            children: "Remove Suggestions"
                        })]
                    })
                },
                oC = e => {
                    var t;
                    let {} = e, [{
                        editing: i,
                        editable: l,
                        profile: s
                    }] = (0, j.U)(), {
                        breakpoints: n,
                        settings: a,
                        data: r,
                        onChange: o
                    } = tO(), d = (0, eM.H)(), {
                        dropping: u,
                        attrs: x
                    } = function() {
                        let [e, t] = (0, M.useState)(!1), [{
                            editing: i
                        }, l] = (0, j.U)(), {
                            createMedia: s
                        } = eA(), n = (0, eZ.A)(e => e.engine), a = (0, eL.$)(), r = (0, M.useCallback)(e => {
                            if (i && (e.preventDefault(), e.dataTransfer && aT(e))) {
                                for (let i of (t(!1), e.dataTransfer.files))(eI.includes(i.type) || eD.includes(i.type)) && s(i, "drop");
                                if (0 === e.dataTransfer.files.length) {
                                    let t = e.dataTransfer.getData("text");
                                    if ((0, _.u$)(t)) {
                                        var r;
                                        let e = (0, eB.X)((0, _.Ac)(t)),
                                            i = (0, _.x0)(),
                                            s = (null == e ? void 0 : e.transformLink) ? e.transformLink((0, _.Ac)(t)) : (0, _.Ac)(t);
                                        (0, z.c)().track("WIDGET_ADDED", {
                                            addMode: "drop",
                                            type: "link",
                                            hostname: (0, _.w6)(s).hostname
                                        }), ei.f.addedLink(i, s), l({
                                            type: "add-bento-item",
                                            bento: {
                                                id: i,
                                                type: "link",
                                                href: s,
                                                style: {
                                                    [a]: null !== (r = null == e ? void 0 : e.defaultSize) && void 0 !== r ? r : "2x2"
                                                }
                                            },
                                            device: a,
                                            viewSlice: null == n ? void 0 : n.view.getViewSlice()
                                        })
                                    }
                                }
                            }
                        }, [a, i, s]);
                        return (0, M.useEffect)(() => {
                            let e = (0, eV.t)();
                            if (e) {
                                let l = e => {
                                        i && aT(e) && t(!0)
                                    },
                                    s = e => {
                                        i && !aT(e) && t(!1)
                                    },
                                    n = e => {
                                        i && aT(e) && (t(!0), e.preventDefault())
                                    };
                                return e.addEventListener("dragenter", l), e.addEventListener("dragleave", s), e.addEventListener("dragover", n), e.addEventListener("drop", r), () => {
                                    e.removeEventListener("dragenter", l), e.removeEventListener("dragleave", s), e.removeEventListener("dragover", n), e.removeEventListener("drop", r)
                                }
                            }
                        }, [r, i, s]), {
                            dropping: e,
                            attrs: aM
                        }
                    }(), [{
                        onboarding: h
                    }] = v(), m = (0, eZ.A)(e => e.engine), [p, g] = (0, M.useState)(!h), f = (0, eL.$)(), [w] = (0, tR.A)(e => [e.highlighting]);
                    td(),
                        function() {
                            let e = (0, eM.H)(),
                                [t, i] = e9(e => [e.hoveredId, e.selectedId]),
                                l = (0, eZ.A)(e => e.dragging),
                                s = (0, M.useRef)({});
                            (0, M.useEffect)(() => {
                                if ("touch" === e && i) {
                                    let e = document.querySelector("iframe[data-editor-iframe]"),
                                        t = null == e ? void 0 : e.contentDocument;
                                    if (!t) return;
                                    let l = t.querySelector('.bento-grid .bento-grid__item[data-id="'.concat(i, '"]'));
                                    if (l) return s.current[i] && clearTimeout(s.current[i]), l.style.zIndex = "35", () => {
                                        l.style.zIndex = "34", s.current[i] = setTimeout(() => {
                                            l.style.removeProperty("z-index")
                                        }, 500)
                                    }
                                }
                            }, [i, e]), (0, M.useEffect)(() => {
                                if (!l && t && t !== i) {
                                    let e = document.querySelector("iframe[data-editor-iframe]"),
                                        i = null == e ? void 0 : e.contentDocument;
                                    if (!i) return;
                                    let l = i.querySelector('.bento-grid .bento-grid__item[data-id="'.concat(t, '"]'));
                                    if (l) return s.current[t] && clearTimeout(s.current[t]), l.style.zIndex = "28", () => {
                                        l.style.zIndex = "27", s.current[t] = setTimeout(() => {
                                            l.style.removeProperty("z-index")
                                        }, 500)
                                    }
                                }
                            }, [t, i, e, l])
                        }(),
                        function() {
                            let e = (0, eM.H)(),
                                [{
                                    profile: t
                                }] = (0, j.U)(),
                                [i, l] = e9(e => [e.selectedId, e.setSelectedId]),
                                [s, n] = (0, tR.A)(e => [e.highlighting, e.setHighlighting]);
                            (0, M.useEffect)(() => {
                                if ("touch" !== e || !i) return;
                                let s = t.bento.items.find(e => e.data.id === i);
                                s || l(void 0)
                            }, [i, t, e]), (0, M.useEffect)(() => {
                                s && !t.bento.items.find(e => e.data.id === s) && n(void 0)
                            }, [s, t])
                        }(),
                        function() {
                            let [{
                                editing: e
                            }, t] = (0, j.U)();
                            (0, eZ.A)(e => e.engine);
                            let {
                                createMedia: i
                            } = eA(), {
                                createLink: l
                            } = eU(), s = (0, eL.$)();
                            (0, M.useEffect)(() => {
                                var t;
                                let s = t => {
                                        if (!e) return;
                                        let s = t.target,
                                            n = s.classList.contains("ProseMirror-trailingBreak") || null !== s.closest('[contenteditable="true"]') || null !== s.closest("input");
                                        if (!n && (t.preventDefault(), t.clipboardData)) {
                                            for (let e of t.clipboardData.files) i(e, "paste");
                                            if (0 === t.clipboardData.files.length) {
                                                let e = t.clipboardData.getData("text").trim();
                                                (0, _.u$)(e) && l(e, "paste")
                                            }
                                        }
                                    },
                                    n = null === (t = document.querySelector("iframe[data-editor-iframe]")) || void 0 === t ? void 0 : t.contentDocument;
                                return document.addEventListener("paste", s), null == n || n.addEventListener("paste", s), () => {
                                    document.removeEventListener("paste", s), null == n || n.removeEventListener("paste", s)
                                }
                            }, [s, e, l, i])
                        }(),
                        function() {
                            let [{
                                editing: e
                            }, t] = (0, j.U)();
                            (0, M.useEffect)(() => {
                                let i = i => {
                                        e && ("z" === i.key && i.metaKey && i.shiftKey ? (t({
                                            type: "redo"
                                        }), i.preventDefault()) : "z" === i.key && i.metaKey ? (t({
                                            type: "undo"
                                        }), i.preventDefault()) : "y" === i.key && i.metaKey && (t({
                                            type: "redo"
                                        }), i.preventDefault()))
                                    },
                                    l = (0, eV.t)();
                                return document.addEventListener("keydown", i), null == l || l.addEventListener("keydown", i), () => {
                                    document.removeEventListener("keydown", i), null == l || l.removeEventListener("keydown", i)
                                }
                            }, [e])
                        }(),
                        function() {
                            let [{
                                profile: e
                            }] = (0, j.U)(), [t, i] = e9(e => [e.locked, e.setHoveredId]), l = (0, tR.A)(e => e.highlighting);
                            (0, M.useEffect)(() => {
                                let e = (0, eV.t)();
                                if (!e) return;
                                let t = e.querySelectorAll("[data-id]"),
                                    s = e => {
                                        let t = e.target,
                                            s = t.closest("[data-id]");
                                        if (!s) return;
                                        let n = s.getAttribute("data-id");
                                        n && (l && l !== n || i(n))
                                    },
                                    n = () => {
                                        i(void 0)
                                    };
                                return t.forEach(e => {
                                    e.addEventListener("mouseenter", s), e.addEventListener("mouseleave", n)
                                }), () => {
                                    t.forEach(e => {
                                        e.removeEventListener("mouseenter", s), e.removeEventListener("mouseleave", n)
                                    })
                                }
                            }, [i, l, e.bento.items, t])
                        }(),
                        function() {
                            let e = (0, eM.H)(),
                                [t, i] = e9(e => [e.toggleSelectedId, e.setSelectedId]),
                                [l, s] = (0, eF.W)(e => [e.focused, e.unsetFocused]),
                                [n] = (0, tR.A)(e => [e.setHighlighting]);
                            (0, M.useEffect)(() => {
                                let n = (0, eV.t)();
                                if (!n) return;
                                let a = n => {
                                    if ("touch" === e) {
                                        let e = n.target,
                                            a = !!e.closest("[data-bento-menu]");
                                        if (a) return;
                                        let r = e.closest("[data-id]"),
                                            o = (null == r ? void 0 : r.getAttribute("data-ghost")) === "true",
                                            d = null == r ? void 0 : r.getAttribute("data-id");
                                        l ? d && d === l || (s(l), o || n.preventDefault()) : d ? (d !== l && t(d), o || n.preventDefault()) : i(void 0)
                                    }
                                };
                                return n.addEventListener("click", a), () => {
                                    n.removeEventListener("click", a)
                                }
                            }, [t, i, s, e, l]), (0, M.useEffect)(() => {
                                "touch" !== e && i(void 0)
                            }, [i, e])
                        }(),
                        function() {
                            let [e] = e9(e => [e.setLocked]), [t, i] = (0, tR.A)(e => [e.highlighting, e.setHighlighting]);
                            (0, M.useEffect)(() => {
                                let l = (0, eV.t)();
                                if (!l) return;
                                let s = {
                                        x: 0,
                                        y: 0
                                    },
                                    n = e => {
                                        s = {
                                            x: e.clientX,
                                            y: e.clientY
                                        }
                                    },
                                    a = n => {
                                        let a = Math.sqrt(Math.pow(n.clientX - s.x, 2) + Math.pow(n.clientY - s.y, 2));
                                        if (a > 10) return;
                                        let r = n.target,
                                            o = !!r.closest("[data-bento-menu]");
                                        if (o) return;
                                        let d = r.closest("[data-id]"),
                                            c = null == d ? void 0 : d.getAttribute("data-id"),
                                            u = !r || r.getRootNode() === l;
                                        (!c || c !== t) && u && (i(void 0), e(!1))
                                    };
                                return l.addEventListener("mousedown", n), l.addEventListener("click", a), () => {
                                    l.removeEventListener("mousedown", n), l.removeEventListener("click", a)
                                }
                            }, [t, i, e])
                        }(),
                        function() {
                            let [{
                                profile: e,
                                editing: t,
                                id: i
                            }, l] = (0, j.U)(), [{
                                onboarding: s
                            }] = v(), n = (0, eZ.A)(e => e.engine), a = (0, eL.$)(), [r, o, d] = (0, oj.Z)("bento.ghosts-blocked");
                            (0, M.useEffect)(() => {
                                let o = e.bento.items.some(ti.mz),
                                    d = e.bento.items.filter(ti.zF).length < 6,
                                    c = e.bento.items.filter(ti.zF).length > 0;
                                if (n && t && !s && i && !(null == r ? void 0 : r.includes(i))) {
                                    if (!o && d && c && !ow) {
                                        let t = (0, rv.L)(e.bento, 6),
                                            i = Math.min(500 * t.length, 1e3),
                                            s = i / t.length;
                                        ow = !0, t.sort((e, t) => e.data.pos[a].y - t.data.pos[a].y || e.data.pos[a].x - t.data.pos[a].x).map((e, t) => setTimeout(() => {
                                            l({
                                                type: "add-ghost",
                                                ghost: e.data
                                            })
                                        }, s * t + 1700))
                                    } else o && !c && (ow = !1, l({
                                        type: "remove-ghosts"
                                    }))
                                } else !t && o && l({
                                    type: "remove-ghosts"
                                })
                            }, [i, n, t, r, s, l])
                        }(), (0, M.useEffect)(() => {
                            if (!h) {
                                let e = setTimeout(() => {
                                        g(!0)
                                    }, 500),
                                    t = setTimeout(() => {
                                        null == m || m.render()
                                    }, 520);
                                return () => {
                                    clearTimeout(e), clearTimeout(t)
                                }
                            }
                        }, [h]);
                    let y = (0, M.useMemo)(() => {
                        let e = s.bento.items.filter(ti.mz),
                            t = s.bento.items.filter(ti.zF),
                            l = (e, t) => {
                                let i = r[f].find(t => t.id === e.data.id),
                                    l = r[f].find(e => e.id === t.data.id);
                                return i && l && i.pos && l.pos ? i.pos.y - l.pos.y || i.pos.x - l.pos.x : 0
                            },
                            u = new Map;
                        return [...s.bento.items].sort(l).forEach((e, t) => {
                            u.set(e.data.id, t)
                        }), (0, c.jsxs)(tz, {
                            breakpoints: n,
                            settings: a,
                            data: r,
                            editable: i && !w,
                            dragHandle: "touch" === d ? "[data-drag-handle]" : void 0,
                            onChange: o,
                            isMainEngine: !0,
                            children: [t.map(e => (0, c.jsxs)(tA, {
                                id: e.data.id,
                                children: [i && (0, c.jsx)("div", {
                                    className: (0, F.Z)("absolute bottom-2 left-1/2 block h-[36px] w-[220px] translate-y-full -translate-x-1/2", "touch" === d && "hidden")
                                }), (0, c.jsx)(np, {
                                    data: e.data,
                                    pos: e.position,
                                    gridIndex: u.get(e.data.id)
                                }), i && (0, c.jsx)(ax, {
                                    data: e.data
                                }), i && (0, c.jsx)(nQ, {
                                    data: e.data
                                })]
                            }, e.data.id)), e.map(e => (0, c.jsx)(tA, {
                                id: e.data.id,
                                "data-ghost": !0,
                                children: (0, c.jsx)(rT, {
                                    data: e.data
                                })
                            }, e.data.id))]
                        })
                    }, [s.bento.items, n, a, r, i, d, o, w]);
                    return (0, c.jsx)(c.Fragment, {
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)("relative flex min-h-screen w-full flex-1 flex-col items-center", "mobile" === f && i && "overflow-hidden"),
                            children: [(0, c.jsx)("div", {
                                className: (0, F.Z)("flex h-full w-full max-w-[428px] items-center justify-center p-6 pt-12 pb-0 xl:absolute xl:top-0 xl:max-w-[min(100vw,1728px)] xl:items-stretch xl:justify-start xl:p-16"),
                                children: (0, c.jsx)("div", {
                                    className: "flex w-full flex-col px-4 xl:mr-20 xl:flex-1 xl:px-0",
                                    children: (0, c.jsxs)(eX.M, {
                                        mode: "wait",
                                        children: [!h && (0, c.jsx)(a9, {}, "profile"), h && (0, c.jsx)(rV, {}, "onboard")]
                                    })
                                })
                            }), (0, c.jsxs)("div", {
                                className: (0, F.Z)("flex h-full w-full max-w-[428px] flex-1 flex-col p-6 pt-0 xl:max-w-[1728px] xl:flex-row xl:p-16", i && "xl:overflow-hidden"),
                                "data-bento-container": !0,
                                children: [(0, c.jsx)("div", {
                                    className: "mb-10 flex flex-col px-4 xl:mb-0 xl:mr-20 xl:flex-1 xl:px-0"
                                }), (0, c.jsxs)("div", {
                                    className: (0, F.Z)("relative flex-1 xl:w-[820px] xl:flex-none", u && "bg-action-green", !p && "hidden xl:block"),
                                    ...x,
                                    children: [(0, c.jsx)(eX.M, {
                                        initial: h,
                                        children: h && (0, c.jsx)(om, {})
                                    }), h && (0, c.jsx)(rG, {}), (0, c.jsx)(eX.M, {
                                        children: !h && s.bento && 0 === s.bento.items.length && i && (0, c.jsx)(o_, {})
                                    }), y, i && !h && (null === (t = s.bento) || void 0 === t ? void 0 : t.items.some(e => (0, ti.mz)(e))) && (0, c.jsx)(k, {
                                        device: "mobile",
                                        children: (0, c.jsxs)("div", {
                                            className: "relative z-10 mb-[80px] -mt-[49px]",
                                            children: [(0, c.jsx)("div", {
                                                className: "mb-[24px] h-[2px] w-full rounded-[1px] bg-[#F8F8F8]"
                                            }), (0, c.jsx)(oN, {})]
                                        })
                                    }), u && (0, c.jsx)("div", {
                                        className: "absolute -inset-6 rounded-[48px] border-4 border-dashed border-neutral-grey20/40 bg-[#F9F9F9]"
                                    })]
                                }), i && (0, c.jsx)(ah, {}), i && (0, c.jsx)(aF, {})]
                            }), (0, c.jsx)(oh, {})]
                        })
                    })
                },
                ok = e => {
                    var t;
                    let {} = e, {
                        user: i
                    } = (0, f.aC)(), [{
                        id: l
                    }] = (0, j.U)(), [{
                        onboarding: s
                    }] = v(), [n, a] = (0, M.useState)(!1), r = l === (null == i ? void 0 : i.id), o = C(), d = I(e => e.device), u = "desktop" === o && "desktop" === d;
                    return (0, M.useEffect)(() => {
                        setTimeout(() => {
                            a(!0)
                        }, 500)
                    }), (0, c.jsx)(eX.M, {
                        children: !s && (0, c.jsxs)(P.m.div, {
                            animate: {
                                opacity: 1
                            },
                            initial: {
                                opacity: 0
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: 2,
                                ease: e$.S,
                                delay: .4
                            },
                            className: (0, F.Z)("fixed left-16 bottom-[52px] -m-1 hidden items-center space-x-1 rounded-[12px] p-1 transition-colors xl:flex 2xl:space-x-2", u && "duration-400 bg-white delay-500", !u && "bg-transparent duration-[0]"),
                            children: [!r && i && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsxs)(b.z, {
                                    variant: "transparent",
                                    as: "a",
                                    href: _.L1.profile(i.handle),
                                    children: [(0, c.jsx)(K.q, {
                                        src: null !== (t = (0, aR.E)(i.image)) && void 0 !== t ? t : (0, aR.l)(i.handle),
                                        size: 20,
                                        className: "mr-2"
                                    }), (0, c.jsx)("div", {
                                        className: "text-text font-normal text-neutral-grey30",
                                        children: "My Bento"
                                    })]
                                }), (0, c.jsx)("div", {
                                    className: "px-2",
                                    children: (0, c.jsx)("div", {
                                        className: " h-[14px] w-[2px] rounded-[2px] bg-[#EBEBEB]"
                                    })
                                })]
                            }), n && !r && !i && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsxs)(b.z, {
                                    variant: "primary-blue",
                                    shine: !0,
                                    as: "a",
                                    href: _.L1.signup(),
                                    onClick: () => (0, z.c)().track("CREATE_BENTO_CLICKED"),
                                    className: "mr-3",
                                    children: [(0, c.jsx)(rW.F, {
                                        className: "mr-2 s-[20px]"
                                    }), (0, c.jsx)("div", {
                                        className: "text-text font-semibold text-white",
                                        children: "Create Your Bento"
                                    })]
                                }), (0, c.jsx)(b.z, {
                                    variant: "transparent",
                                    as: "a",
                                    href: _.L1.login(),
                                    onClick: () => {
                                        (0, z.c)().track("LOGIN_CLICKED")
                                    },
                                    children: (0, c.jsx)("div", {
                                        className: "text-text font-normal text-neutral-grey30",
                                        children: "Log In"
                                    })
                                })]
                            }), r && (0, c.jsx)(oe, {}, "settings"), (0, c.jsx)(S.pn, {
                                children: (0, c.jsx)(E.u, {
                                    delayDuration: 300,
                                    disableHoverableContent: !0,
                                    tooltip: (0, c.jsx)(e_, {
                                        content: "Explore"
                                    }),
                                    children: (0, c.jsx)(R, {
                                        as: "a",
                                        size: 32,
                                        variant: "transparent",
                                        target: "_blank",
                                        href: "https://bento.me/explore",
                                        onClick: () => {
                                            (0, z.c)().track("EXPLORE_CLICKED")
                                        },
                                        className: "flex items-center justify-center",
                                        children: (0, c.jsxs)("svg", {
                                            width: "16",
                                            height: "16",
                                            viewBox: "0 0 16 16",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: [(0, c.jsx)("circle", {
                                                cx: "8",
                                                cy: "8",
                                                r: "6",
                                                stroke: "#8E8E8E",
                                                "stroke-width": "2"
                                            }), (0, c.jsx)("path", {
                                                d: "M6.22695 6.84827L5.68089 9.57858C5.59287 10.0187 5.98088 10.4067 6.42096 10.3187L9.15128 9.7726C9.4625 9.71035 9.70577 9.46708 9.76801 9.15587L10.3141 6.42555C10.4021 5.98546 10.0141 5.59746 9.574 5.68547L6.84368 6.23154C6.53246 6.29378 6.28919 6.53705 6.22695 6.84827Z",
                                                fill: "#8E8E8E"
                                            })]
                                        })
                                    })
                                })
                            }), i && (0, c.jsx)(S.pn, {
                                children: (0, c.jsx)(E.u, {
                                    delayDuration: 300,
                                    disableHoverableContent: !0,
                                    tooltip: (0, c.jsx)(e_, {
                                        content: "Community"
                                    }),
                                    children: (0, c.jsx)(R, {
                                        as: "a",
                                        size: 32,
                                        variant: "transparent",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        href: "https://discord.gg/8rJvDWaSz7",
                                        className: "flex items-center justify-center",
                                        children: (0, c.jsx)("svg", {
                                            width: "16",
                                            height: "16",
                                            viewBox: "0 0 16 16",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: (0, c.jsx)("path", {
                                                d: "M13.5535 3.03729C12.5178 2.55271 11.4104 2.20053 10.2526 2C10.1104 2.25707 9.94428 2.60284 9.82974 2.8779C8.599 2.69281 7.37956 2.69281 6.17144 2.8779C6.05693 2.60284 5.88704 2.25707 5.74358 2C4.58454 2.20053 3.47584 2.554 2.44013 3.03985C0.351096 6.19666 -0.215208 9.27505 0.0679444 12.3098C1.45351 13.3444 2.79627 13.973 4.11639 14.3843C4.44232 13.9357 4.73303 13.4588 4.98345 12.9563C4.5065 12.7751 4.04969 12.5514 3.61805 12.2918C3.73256 12.2069 3.84457 12.1182 3.95279 12.0269C6.58546 13.2583 9.44593 13.2583 12.0472 12.0269C12.1566 12.1182 12.2686 12.2069 12.3819 12.2918C11.949 12.5527 11.4909 12.7763 11.0139 12.9576C11.2644 13.4588 11.5539 13.937 11.881 14.3855C13.2024 13.9742 14.5464 13.3457 15.932 12.3098C16.2642 8.79176 15.3644 5.74164 13.5535 3.03729ZM5.34212 10.4434C4.55181 10.4434 3.9037 9.70562 3.9037 8.80718C3.9037 7.90872 4.53798 7.16966 5.34212 7.16966C6.14628 7.16966 6.79437 7.90743 6.78054 8.80718C6.78178 9.70562 6.14628 10.4434 5.34212 10.4434ZM10.6578 10.4434C9.86748 10.4434 9.21941 9.70562 9.21941 8.80718C9.21941 7.90872 9.85365 7.16966 10.6578 7.16966C11.4619 7.16966 12.1101 7.90743 12.0963 8.80718C12.0963 9.70562 11.4619 10.4434 10.6578 10.4434Z",
                                                fill: "#969696"
                                            })
                                        })
                                    })
                                })
                            }), r && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)("div", {
                                    className: (0, F.Z)("px-2", oi()["foot-traffic-divider"]),
                                    children: (0, c.jsx)("div", {
                                        className: " h-[14px] w-[2px] rounded-[2px] bg-[#EBEBEB]"
                                    })
                                }), (0, c.jsx)(ox, {}, "foottraffic")]
                            })]
                        })
                    })
                },
                oE = e => {
                    let {} = e, [t, i] = (0, M.useState)(!1), [{
                        id: l,
                        profile: s,
                        editing: n
                    }, a] = (0, j.U)(), [r, o, d] = (0, oj.Z)("bento.ghosts-blocked"), [u, x] = nh(e => [e.hoveringRemove, e.setHoveringRemove]), h = (0, eL.$)();
                    return (0, c.jsx)(P.m.button, {
                        animate: {
                            opacity: 1
                        },
                        exit: {
                            opacity: 0
                        },
                        initial: {
                            opacity: 0
                        },
                        transition: {
                            duration: .5,
                            ease: e$.V
                        },
                        className: (0, F.Z)(ob()["floating-button"]),
                        onMouseEnter: () => {
                            x(!0)
                        },
                        onMouseLeave: () => {
                            x(!1)
                        },
                        onClick: () => {
                            if (!n || !l || t) return;
                            r ? o(r + "," + l) : o(l);
                            let e = s.bento.items.filter(ti.mz);
                            if (e.length > 0) {
                                let t = Math.min(150 * e.length, 300),
                                    l = t / e.length;
                                i(!0), e.sort((e, t) => t.data.pos[h].y - e.data.pos[h].y || t.data.pos[h].x - e.data.pos[h].x).map((e, t) => setTimeout(() => {
                                    a({
                                        type: "remove-ghost",
                                        ghost: e.data
                                    })
                                }, l * t))
                            }
                        },
                        children: (0, c.jsxs)("div", {
                            className: (0, F.Z)("flex items-center space-x-1.5 rounded-[6px] p-1.5 transition-colors duration-150", u && "bg-[#F6F6F6]"),
                            children: [(0, c.jsx)(i_, {}), (0, c.jsx)("div", {
                                children: "Remove Suggestions"
                            })]
                        })
                    })
                },
                oS = () => {
                    var e, t;
                    let [{
                        profile: i,
                        editable: l,
                        editing: s
                    }] = (0, j.U)(), {
                        user: n
                    } = (0, f.aC)(), a = !!(null == n ? void 0 : n.onboarded), r = !a && l;
                    return (0, M.useEffect)(() => {
                        if (l) return document.body.classList.add("no-scrollbar"), () => {
                            document.body.classList.remove("no-scrollbar")
                        }
                    }, [l]), (0, c.jsx)("main", {
                        className: (0, F.Z)("min-full-screen flex flex-col items-center justify-center", l && "bg-[#F8F8F8]"),
                        children: (0, c.jsxs)(g, {
                            initialValue: {
                                anyLinks: [],
                                onboarding: r
                            },
                            children: [(0, c.jsxs)(rx.A, {
                                children: [l && (0, c.jsxs)(c.Fragment, {
                                    children: [(0, c.jsx)(tt, {
                                        className: "flex h-full w-full",
                                        children: (0, c.jsx)(oC, {})
                                    }), (0, c.jsx)(eJ, {}), (0, c.jsx)(e7, {}), (0, c.jsx)(k, {
                                        device: "desktop",
                                        children: (0, c.jsx)(eX.M, {
                                            children: s && !r && (null === (e = i.bento) || void 0 === e ? void 0 : e.items.some(e => (0, ti.mz)(e))) && (0, c.jsx)(oE, {})
                                        })
                                    })]
                                }), !l && (0, c.jsx)("div", {
                                    className: "min-full-screen flex w-full max-w-[1728px] flex-col",
                                    children: (0, c.jsx)(oC, {})
                                })]
                            }), (0, c.jsx)(ok, {})]
                        }, null !== (t = null == n ? void 0 : n.id) && void 0 !== t ? t : "nokey")
                    })
                },
                oL = () => {
                    let e = new Date;
                    return Math.floor(e.getTime() / 1e3 / 60 / 60)
                },
                oI = () => {
                    var e, t;
                    let [{
                        profile: i,
                        editable: l
                    }] = (0, j.U)(), s = (0, eZ.A)(e => e.engine);
                    (0, M.useEffect)(() => {
                        !l && (null == s ? void 0 : s.device) && (0, s0.U)().visit(i.handle, s.device)
                    }, [l, null == s ? void 0 : s.device, i.handle]);
                    let n = !i.name && !i.image && !(null === (e = i.bento) || void 0 === e ? void 0 : e.items.length);
                    return (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)(m.PB, {
                            title: i.name ? "".concat(null !== (t = i.name) && void 0 !== t ? t : "Bento") : void 0,
                            twitter: {
                                cardType: "summary_large_image"
                            },
                            openGraph: {
                                description: n ? "This Bento is still under construction" : (0, ih.V)(i.bio, a$()),
                                images: [{
                                    url: "".concat("https://api.bento.me", "/v1/og/").concat(i.handle, "?v=").concat(oL()),
                                    height: 630,
                                    width: 1200
                                }]
                            }
                        }), (0, c.jsxs)(h(), {
                            children: [i.image && (0, c.jsxs)(c.Fragment, {
                                children: [(0, c.jsx)("link", {
                                    rel: "apple-touch-icon",
                                    sizes: "180x180",
                                    href: "/apple-touch-icon.png"
                                }), (0, c.jsx)("link", {
                                    rel: "shortcut icon",
                                    href: (0, _.En)(i.image, {
                                        w: 200,
                                        h: 200,
                                        fit: "crop"
                                    })
                                })]
                            }), !i.image && (0, c.jsx)(c.Fragment, {
                                children: (0, c.jsx)("link", {
                                    rel: "apple-touch-icon",
                                    sizes: "180x180",
                                    href: "/apple-touch-icon.png"
                                })
                            })]
                        }), (0, c.jsx)(oS, {})]
                    })
                };

            function oD(e) {
                let {
                    times: t,
                    children: i
                } = e;
                return "function" == typeof i ? (0, c.jsx)(c.Fragment, {
                    children: [...Array(t)].map((e, t) => i(t))
                }) : (0, c.jsx)(c.Fragment, {
                    children: [...Array(t)].map(() => i)
                })
            }
            var oZ = i(86269),
                oz = i.n(oZ);
            let oA = e => {
                let {
                    children: t,
                    className: i
                } = e, [l, s] = (0, M.useState)(null), [n, a] = (0, M.useState)(null), [r, o] = (0, M.useState)(!1), [d, u] = (0, M.useState)(!1);
                return (0, M.useEffect)(() => {
                    l && n && u(n.clientWidth > l.clientWidth)
                }, [l, n]), (0, M.useEffect)(() => {
                    if (!d) return;
                    let e = setTimeout(() => {
                        o(!0)
                    }, 3e3);
                    return () => clearTimeout(e)
                }, [d]), (0, c.jsxs)("div", {
                    className: (0, F.Z)("relative", i),
                    ref: s,
                    children: [(0, c.jsx)("div", {
                        className: "no-scrollbar",
                        children: (0, c.jsx)("div", {
                            className: (0, F.Z)("flex items-center space-x-[50px]", r && oz().moving),
                            style: {
                                "--distance": n ? "".concat(n.clientWidth, "px") : void 0,
                                "--spacing": "50px"
                            },
                            children: (0, c.jsx)(oD, {
                                times: d ? 2 : 1,
                                children: (0, c.jsx)("div", {
                                    ref: a,
                                    className: "flex items-center",
                                    children: t
                                })
                            })
                        })
                    }), d && (0, c.jsxs)(c.Fragment, {
                        children: [(0, c.jsx)("div", {
                            className: oz()["overlay-left"]
                        }), (0, c.jsx)("div", {
                            className: (0, F.Z)(oz()["overlay-right"], "rounded-[20px]")
                        })]
                    })]
                })
            };
            var oF = i(11395),
                oM = i.n(oF);
            let oT = e => {
                    let {
                        info: t
                    } = e, i = (0, r0.useRouter)(), l = i.query.handle;
                    return (0, c.jsxs)("div", {
                        className: "flex h-screen w-screen flex-col items-center overflow-hidden",
                        children: [(0, c.jsx)(J.L, {}), (0, c.jsxs)("div", {
                            className: "flex flex-col items-center pt-[100px]",
                            children: [(0, c.jsx)("div", {
                                className: (0, F.Z)(oM().logo, oM().peripheral),
                                children: (0, c.jsx)(rW.F, {
                                    className: "s-[42px]"
                                })
                            }), (0, c.jsxs)("div", {
                                className: (0, F.Z)("relative mt-10 rounded-[16px] border-[1px] border-black/[0.02] bg-[#FAFAFA]", oM()["url-animation"]),
                                children: [(0, c.jsx)(oA, {
                                    className: " max-w-[min(85vw,500px)] overflow-hidden whitespace-nowrap",
                                    children: (0, c.jsxs)("div", {
                                        className: "relative flex items-center px-[28px] py-[16px] text-[24px] font-semibold sm:text-[40px] sm:leading-[52px]",
                                        children: [(0, c.jsx)("span", {
                                            className: "text-[#7D7878]",
                                            children: "bento.me/"
                                        }), (0, c.jsxs)("div", {
                                            className: (0, F.Z)("relative overflow-hidden"),
                                            children: [l, (0, c.jsx)("div", {
                                                className: (0, F.Z)("absolute -left-[200px] top-0 bottom-0 w-10  rotate-12 bg-white blur-[14px]", oM().glare)
                                            })]
                                        })]
                                    })
                                }), !(null == t ? void 0 : t.isSpecial) && !(null == t ? void 0 : t.isBlocked) && (0, c.jsx)("div", {
                                    className: (0, F.Z)("absolute right-0 top-0 z-20 translate-x-[24px] -translate-y-1/2 rotate-[2deg] rounded-[6px] border-[1px] border-black/[0.08] bg-[#4EDD76] px-[12px] py-[7px] text-[16px] font-semibold leading-[1.2] text-white", oM()["badge-shadow"], oM()["badge-animation"]),
                                    children: "Available!"
                                }), (null == t ? void 0 : t.isSpecial) && (0, c.jsx)("div", {
                                    className: (0, F.Z)("absolute right-0 top-0 z-20 translate-x-[24px] -translate-y-1/2 rotate-[2deg] rounded-[6px] border-[1px] border-black/[0.08] bg-action-red px-[12px] py-[7px] text-[16px] font-semibold leading-[1.2] text-white", oM()["badge-shadow"], oM()["badge-animation"]),
                                    children: "Unavailable"
                                }), (null == t ? void 0 : t.isBlocked) && (0, c.jsx)("div", {
                                    className: (0, F.Z)("absolute right-0 top-0 z-20 translate-x-[24px] -translate-y-1/2 rotate-[2deg] rounded-[6px] border-[1px] border-black/[0.08] bg-action-red px-[12px] py-[7px] text-[16px] font-semibold leading-[1.2] text-white", oM()["badge-shadow"], oM()["badge-animation"]),
                                    children: "Blocked"
                                })]
                            }), (0, c.jsxs)("div", {
                                className: (0, F.Z)("mt-4 max-w-[288px] text-center text-[16px] leading-[24px] text-[#7D7878]", oM().peripheral),
                                children: ["Bento is the most beautiful link in bio. And it’s all free.", " ", (0, c.jsx)("a", {
                                    href: "https://bento.me/",
                                    target: "_blank",
                                    className: "text-[#768CFF] underline underline-offset-[3px]",
                                    rel: "noreferrer",
                                    children: "Learn more"
                                })]
                            }), !(null == t ? void 0 : t.isSpecial) && !(null == t ? void 0 : t.isBlocked) && (0, c.jsx)(b.z, {
                                as: "a",
                                href: _.L1.signup() + "?handle=".concat(l),
                                variant: "primary-blue",
                                className: (0, F.Z)("mt-8 flex h-[54px] !rounded-[10px]", oM().peripheral),
                                children: (0, c.jsx)("span", {
                                    className: "px-2 text-[18px]",
                                    children: "Claim Handle Now"
                                })
                            })]
                        }), (0, c.jsx)(J.L, {}), (0, c.jsx)("img", {
                            src: "/images/claimillustration.png",
                            alt: "",
                            className: (0, F.Z)("mt-20 -mb-3 hidden max-w-[75%] -rotate-1 lg:block", oM().illustration)
                        }), (0, c.jsx)("img", {
                            src: "/images/claimillustration-mobile.png",
                            alt: "",
                            className: (0, F.Z)("mt-20 -mb-3 max-w-[min(95%,400px)] -rotate-1 lg:hidden", oM().illustration)
                        })]
                    })
                },
                oO = e => {
                    var t, i, l;
                    let {
                        profile: s,
                        info: n
                    } = e;
                    if ((0, M.useEffect)(() => {
                            ei.f.reset()
                        }, [null == s ? void 0 : s.id]), !s) return (0, c.jsx)(oT, {
                        info: n
                    });
                    let a = {
                        handle: null !== (i = s.handle) && void 0 !== i ? i : "",
                        name: s.name,
                        bio: s.bio,
                        bento: null !== (l = s.bento) && void 0 !== l ? l : {
                            version: "v2",
                            items: []
                        },
                        ogImage: s.ogImage,
                        image: s.image
                    };
                    return (0, c.jsx)(j.A, {
                        initialState: {
                            id: s.id,
                            profile: a,
                            original: a,
                            history: [a],
                            historyPointer: 0,
                            previewing: !1,
                            publishing: !1,
                            stage: (null === (t = s.bento) || void 0 === t ? void 0 : t.items) && s.bento.items.length > 0 ? "updated" : "created"
                        },
                        children: (0, c.jsx)(oI, {})
                    }, s.id)
                };
            var oR = !0,
                oB = (0, u.withSuperJSONPage)(oO)
        },
        10075: function(e, t, i) {
            "use strict";
            i.d(t, {
                E: function() {
                    return l
                },
                l: function() {
                    return s
                }
            });
            let l = e => e ? e.startsWith("https://lh3.googleusercontent.com/a") ? e.replace("=s96-c", "=s256-c") : e : null != e ? e : void 0,
                s = e => {
                    let t = "-seed4zgd";
                    return e ? "https://avatars.dicebear.com/api/big-smile/".concat(encodeURIComponent(e + t), ".svg?scale=90&size=200") : "https://avatars.dicebear.com/api/big-smile/".concat(encodeURIComponent(t), ".svg?scale=90&size=200")
                }
        },
        9962: function(e, t, i) {
            "use strict";
            i.d(t, {
                J: function() {
                    return s
                }
            });
            let l = RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i),
                s = e => l.test(null != e ? e : "")
        },
        54207: function(e, t, i) {
            "use strict";
            i.d(t, {
                q1: function() {
                    return o
                },
                zF: function() {
                    return r
                },
                xU: function() {
                    return n
                },
                UP: function() {
                    return a
                }
            });
            var l = i(93143),
                s = i(37523);

            function n(e) {
                let {
                    data: t,
                    ...i
                } = (0, s.$)((0, l.tF)(e));
                return {
                    viewers: t,
                    ...i
                }
            }

            function a(e, t, i) {
                let {
                    data: n,
                    ...a
                } = (0, s.$)((0, l.g5)(e, t, i));
                return {
                    views: n,
                    ...a
                }
            }

            function r(e) {
                let {
                    data: t,
                    ...i
                } = (0, s.$)((0, l.nh)(e));
                return {
                    traffic: t,
                    ...i
                }
            }

            function o(e) {
                let {
                    data: t,
                    ...i
                } = (0, s.$)((0, l.de)(e));
                return {
                    ctrs: t,
                    ...i
                }
            }
        },
        30474: function(e, t, i) {
            "use strict";
            i.d(t, {
                t: function() {
                    return n
                }
            });
            var l = i(93143),
                s = i(37523);

            function n(e) {
                let {
                    data: t,
                    ...i
                } = (0, s.$)((0, l.hc)(e));
                return {
                    handle: t,
                    ...i
                }
            }
        },
        33418: function(e, t, i) {
            "use strict";
            i.d(t, {
                y: function() {
                    return r
                }
            });
            var l = i(24920),
                s = i(93143),
                n = i(36715),
                a = i(4618);

            function r(e) {
                let {
                    data: t,
                    trigger: i,
                    error: r,
                    ...o
                } = (0, n.h)((0, s.p5)(e), "PUT"), {
                    mutate: d
                } = (0, a.K)(), c = e => i(e).then(d);
                return {
                    me: t,
                    trigger: c,
                    error: r ? (0, l.ds)(r) : void 0,
                    ...o
                }
            }
        },
        11896: function(e, t, i) {
            "use strict";
            var l, s;
            i.d(t, {
                Q: function() {
                    return l
                }
            }), (s = l || (l = {})).UNIMPLEMENTED = "UNIMPLEMENTED", s.UNAUTHORIZED = "UNAUTHORIZED", s.FORBIDDEN = "FORBIDDEN", s.INSUFFICIENT_PERMISSION = "INSUFFICIENT_PERMISSION", s.PARAMETER_MISSING = "PARAMETER_MISSING", s.PARAMETER_NOT_ALLOWED = "PARAMETER_NOT_ALLOWED", s.PASSWORD_ERROR = "PASSWORD_ERROR", s.UNKNOWN_ERROR = "UNKNOWN_ERROR", s.KNOWN_ERROR = "KNOWN_ERROR", s.KNOWN_DATABASE_ERROR = "KNOWN_DATABASE_ERROR", s.DATABASE_UNKNOWN_ERROR = "DATABASE_UNKNOWN_ERROR", s.DATABASE_KNOWN_ERROR = "DATABASE_KNOWN_ERROR", s.DATABASE_VALIDATION_ERROR = "DATABASE_VALIDATION_ERROR", s.DATABASE_CONSTRAINT_ERROR = "DATABASE_CONSTRAINT_ERROR", s.WRONG_CREDENTIALS = "WRONG_CREDENTIALS", s.WRONG_PROVIDER = "WRONG_PROVIDER", s.OAUTH_STATE_MISSING = "OAUTH_STATE_MISSING", s.BAD_OAUTH_STATE = "BAD_OAUTH_STATE", s.NOT_SIGNED_UP = "NOT_SIGNED_UP", s.ALREADY_SIGNED_UP = "ALREADY_SIGNED_UP", s.USER_COULD_NOT_BE_CREATED = "USER_COULD_NOT_BE_CREATED", s.NOT_FOUND_ERROR = "NOT_FOUND", s.HANDLE_NOT_FREE = "HANDLE_NOT_FREE", s.HANDLE_BLOCKED = "HANDLE_BLOCKED", s.INVITE_INVALID = "INVITE_INVALID", s.INVITE_NOT_PROVIDED = "INVITE_NOT_PROVIDED", s.INVITE_NOT_FOUND = "INVITE_NOT_FOUND", s.INVITE_NOT_REDEEMABLE = "INVITE_NOT_REDEEMABLE", s.HANDLE_INVALID = "HANDLE_INVALID", s.HANDLE_IS_SPECIAL = "HANDLE_IS_SPECIAL", s.BAD_REQUEST = "BAD_REQUEST", s.EMAIL_TAKEN = "EMAIL_TAKEN", s.ALREADY_ONBOARDED = "ALREADY_ONBOARDED", s.INCOMPATIBLE_BENTO_SCHEMA = "INCOMPATIBLE_BENTO_SCHEMA", s.INCOMPATIBLE_BENTO_VERSION = "INCOMPATIBLE_BENTO_VERSION", s.INVALID_LINK_TYPE = "INVALID_LINK_TYPE", s.REACHED_MAX_HANDLE_CHANGES = "REACHED_MAX_HANDLE_CHANGES", s.PASSWORD_RESET_TOKEN_EXPIRED = "PASSWORD_RESET_TOKEN_EXPIRED"
        },
        51101: function(e, t, i) {
            "use strict";
            i.d(t, {
                l: function() {
                    return l
                }
            });
            let l = e => e.toString().normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-")
        },
        82746: function(e) {
            e.exports = {
                frame: "styles_frame__ymcZM",
                menu: "styles_menu___Mz8b"
            }
        },
        19716: function(e) {
            e.exports = {
                "image-edit-bar": "styles_image-edit-bar__QWte4",
                button: "styles_button__txv8q",
                "button--disabled": "styles_button--disabled__1xdmz"
            }
        },
        62874: function(e) {
            e.exports = {
                "music-circle": "styles_music-circle__J5i6N",
                "is-playing": "styles_is-playing__ryufb",
                circle: "styles_circle__PJsmu",
                "music-note": "styles_music-note__PwtLj",
                "music-note-1": "styles_music-note-1__APCeJ",
                "music-note-2": "styles_music-note-2___DmCS",
                "music-note-3": "styles_music-note-3__9Meev"
            }
        },
        88403: function(e) {
            e.exports = {
                container: "styles_container__l3kld",
                "icon-container": "styles_icon-container__EbbTG",
                "input-container": "styles_input-container__0PmFD",
                "input-container--error": "styles_input-container--error__TVk_X",
                input: "styles_input__TdTQr",
                "action-container": "styles_action-container__Rcqpr",
                "button--shadow": "styles_button--shadow__kI4Je",
                "paste-button-container": "styles_paste-button-container___jbi9"
            }
        },
        1520: function(e) {
            e.exports = {
                "link-widget-base": "styles_link-widget-base__zEwMR",
                "link-widget-base--figma": "styles_link-widget-base--figma__rI1hV",
                "link-widget-base--1x4": "styles_link-widget-base--1x4__KmQGD",
                "link-widget-base--maps": "styles_link-widget-base--maps__371fZ"
            }
        },
        80588: function(e) {
            e.exports = {
                "media-widget": "styles_media-widget__lX7ez",
                "caption-container": "styles_caption-container__X5mzw",
                "caption-container--empty": "styles_caption-container--empty__EgEfr",
                "media-widget--cropping": "styles_media-widget--cropping__DMzUA",
                "media-widget--highlighted": "styles_media-widget--highlighted__uxUFf",
                "caption-container--mouse": "styles_caption-container--mouse__7oY0_"
            }
        },
        41435: function(e) {
            e.exports = {
                "section-header-widget": "styles_section-header-widget__4wtox",
                "title-editor": "styles_title-editor__mOQna"
            }
        },
        47146: function(e) {
            e.exports = {
                icon: "styles_icon__5o5__",
                favicon: "styles_favicon__bJMP4",
                "icon--small": "styles_icon--small__GAmBu",
                "icon--large": "styles_icon--large__cYPfM"
            }
        },
        14673: function(e) {
            e.exports = {
                widget: "styles_widget__pu6FE",
                "widget--flipped": "styles_widget--flipped___4CBt",
                "widget--selected": "styles_widget--selected__wUSZh",
                "widget--attention-dim": "styles_widget--attention-dim__fCOdP",
                "widget--highlight-partial": "styles_widget--highlight-partial__79Moa",
                "widget--highlight-full": "styles_widget--highlight-full__3YB7p",
                "widget--rounding-xs": "styles_widget--rounding-xs__qORjh",
                "widget--rounding-sm": "styles_widget--rounding-sm__yYF_e",
                "widget--rounding-md": "styles_widget--rounding-md__Vff55",
                "widget--rounding-lg": "styles_widget--rounding-lg__lDdnh",
                front: "styles_front___BcIU",
                back: "styles_back__pu_7a",
                border: "styles_border__j_OpU",
                "widget--hovering": "styles_widget--hovering__1bbRF"
            }
        },
        58322: function(e) {
            e.exports = {
                container: "styles_container__Yyi_C",
                "container--visible": "styles_container--visible__cTdAy"
            }
        },
        72431: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__K0yWV",
                "link-widget--4x2": "styles_link-widget--4x2__laIvO",
                "link-widget--4x4": "styles_link-widget--4x4__lOBjL",
                "link-widget--1x4": "styles_link-widget--1x4__10P67",
                description: "styles_description__7Y3xU",
                "link-meta__container": "styles_link-meta__container__RB2Q2",
                "link-widget--2x2": "styles_link-widget--2x2__bk1Xo",
                "link-widget--2x4": "styles_link-widget--2x4__gr2m_",
                cover: "styles_cover__ulhTd",
                title: "styles_title__O1qi7",
                host: "styles_host__TQi12",
                "title-editor": "styles_title-editor__Dwsvf",
                "cover-grid-fetching": "styles_cover-grid-fetching__d4uKe",
                "follow-button": "styles_follow-button__xUV1Q"
            }
        },
        44821: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__s1j4b",
                "link-widget--4x2": "styles_link-widget--4x2__DhpfK",
                "link-widget--4x4": "styles_link-widget--4x4__PuwM9",
                "link-widget--1x4": "styles_link-widget--1x4__mCKLe",
                description: "styles_description__xhYIb",
                "link-meta__container": "styles_link-meta__container__9hU4O",
                "link-widget--2x2": "styles_link-widget--2x2__fEjZU",
                "link-widget--2x4": "styles_link-widget--2x4__zmBbo",
                title: "styles_title__faoIC",
                host: "styles_host__29IPQ",
                "title-editor": "styles_title-editor__qpLMu",
                "post-grid": "styles_post-grid__VvM_w",
                "post-grid-fetching": "styles_post-grid-fetching__eFsDO",
                "follow-button": "styles_follow-button__l1_od"
            }
        },
        40674: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__isuPC",
                "link-widget--4x2": "styles_link-widget--4x2__Z8qJZ",
                "link-widget--4x4": "styles_link-widget--4x4__p6mX_",
                "link-widget--1x4": "styles_link-widget--1x4__XbNpk",
                description: "styles_description__Ml58E",
                "link-meta__container": "styles_link-meta__container__YYgU_",
                "link-widget--2x2": "styles_link-widget--2x2__6GdJd",
                "link-widget--2x4": "styles_link-widget--2x4__gzbuO",
                cover: "styles_cover__HZJDR",
                title: "styles_title__ilw5Z",
                host: "styles_host__vl7px",
                "title-editor": "styles_title-editor__OMxND",
                "cover-grid-fetching": "styles_cover-grid-fetching__47ZJO",
                "follow-button": "styles_follow-button__7aINI"
            }
        },
        29021: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__6kyRV",
                "link-widget--4x2": "styles_link-widget--4x2__BYO0r",
                "link-widget--4x4": "styles_link-widget--4x4__7b5b4",
                "link-widget--1x4": "styles_link-widget--1x4__WPgEQ",
                description: "styles_description__a_vrb",
                "link-meta__container": "styles_link-meta__container__WfE_0",
                "link-widget--2x2": "styles_link-widget--2x2__Z2V5z",
                "link-widget--2x4": "styles_link-widget--2x4__WqBQf",
                title: "styles_title__sZ6b2",
                host: "styles_host__46C8o",
                "title-editor": "styles_title-editor___HFyf",
                "post-grid": "styles_post-grid__hYkhm",
                "post-grid-fetching": "styles_post-grid-fetching__ogOpp",
                "follow-button": "styles_follow-button__PI_64"
            }
        },
        63411: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__QY8Dp",
                "figma-bubble-wrapper": "styles_figma-bubble-wrapper__iSddp",
                "figma-bubble": "styles_figma-bubble__EK_lQ",
                "figma-bubble-chat": "styles_figma-bubble-chat__tKETN",
                "link-widget--4x2": "styles_link-widget--4x2__8fkR_",
                "link-widget--4x4": "styles_link-widget--4x4__0h3FL",
                "link-widget--1x4": "styles_link-widget--1x4__Yq4lc",
                description: "styles_description__2aGxS",
                "link-meta__container": "styles_link-meta__container__hnLNu",
                handle: "styles_handle__41gm9",
                "link-widget--2x2": "styles_link-widget--2x2__67WUw",
                "link-widget--2x4": "styles_link-widget--2x4__g_UjT",
                cover: "styles_cover__GEqgw",
                title: "styles_title__NPMpm",
                host: "styles_host__oEa6t",
                "title-editor": "styles_title-editor__H4OvT",
                "cover-grid-fetching": "styles_cover-grid-fetching__4qfZU",
                "action-buttons": "styles_action-buttons__F36WH",
                "like-button": "styles_like-button__fULdb",
                "copy-button": "styles_copy-button__S9w2V"
            }
        },
        72614: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__W9Ssk",
                "figma-bubble-wrapper": "styles_figma-bubble-wrapper__NS3lT",
                "figma-bubble": "styles_figma-bubble__ARgjF",
                "figma-bubble-chat": "styles_figma-bubble-chat__R_loE",
                "link-widget--4x2": "styles_link-widget--4x2__E2rRy",
                "link-widget--4x4": "styles_link-widget--4x4__SC7lP",
                "link-widget--1x4": "styles_link-widget--1x4__3nHfI",
                description: "styles_description__RVl7b",
                "link-meta__container": "styles_link-meta__container__ff_Ry",
                handle: "styles_handle__Z__aL",
                "link-widget--2x2": "styles_link-widget--2x2__68q_E",
                "link-widget--2x4": "styles_link-widget--2x4__9_elK",
                title: "styles_title__QyhhK",
                host: "styles_host__fXZzS",
                "title-editor": "styles_title-editor__m8Ged",
                "post-grid": "styles_post-grid__PzIoM",
                "post-grid-fetching": "styles_post-grid-fetching__hnqFX",
                "follow-button": "styles_follow-button__V5j2H"
            }
        },
        79534: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__WOY8_",
                "link-widget--4x2": "styles_link-widget--4x2__kwKhE",
                "link-widget--4x4": "styles_link-widget--4x4__oldmC",
                "link-widget--1x4": "styles_link-widget--1x4__orjBB",
                description: "styles_description__aVbsD",
                "link-meta__container": "styles_link-meta__container__w2b_G",
                title: "styles_title__kGBWE",
                host: "styles_host__zTVRc",
                og: "styles_og__Rq6el",
                "link-widget--2x2": "styles_link-widget--2x2__fvUqB",
                "link-widget--2x4": "styles_link-widget--2x4__ls6Ee",
                "og-empty": "styles_og-empty__90Vy_",
                "title-editor": "styles_title-editor__k_ZSJ"
            }
        },
        42747: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget___XVQG",
                "link-widget--4x2": "styles_link-widget--4x2__4Ke_m",
                "link-widget--4x4": "styles_link-widget--4x4__cdkxs",
                "link-widget--1x4": "styles_link-widget--1x4__EBn1m",
                description: "styles_description__BcDjh",
                "link-meta__container": "styles_link-meta__container__6CCP7",
                "link-widget--2x2": "styles_link-widget--2x2__3b2b_",
                "link-widget--2x4": "styles_link-widget--2x4__U75gw",
                title: "styles_title__MU2Pd",
                host: "styles_host__giOYR",
                "title-editor": "styles_title-editor__yI_Cx",
                graph: "styles_graph__sai4B",
                illustration: "styles_illustration__fo34z",
                "follow-button": "styles_follow-button__rD65O"
            }
        },
        19581: function(e) {
            e.exports = {
                widget: "styles_widget__g5RHH",
                "caption-container": "styles_caption-container__z7r_q",
                "widget--2x4": "styles_widget--2x4__v1ZxE",
                "caption-container--empty": "styles_caption-container--empty__rS4F1",
                "caption-container--mouse": "styles_caption-container--mouse__9pWnS"
            }
        },
        33989: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__xWP2R",
                "link-widget--4x2": "styles_link-widget--4x2__qmkfW",
                "link-widget--4x4": "styles_link-widget--4x4__MIXyu",
                "link-widget--1x4": "styles_link-widget--1x4__SCiKn",
                description: "styles_description__SueNV",
                "link-meta__container": "styles_link-meta__container__Sj4Sr",
                "link-widget--2x2": "styles_link-widget--2x2__cLSha",
                "link-widget--2x4": "styles_link-widget--2x4__BuUO4",
                title: "styles_title__Jtuxw",
                "title-editor": "styles_title-editor__IAEUj",
                "post-grid": "styles_post-grid__TI72u",
                "post-grid--fetching": "styles_post-grid--fetching__yLIpR",
                "follow-button": "styles_follow-button__6z6vM"
            }
        },
        26781: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__uYwDH",
                "link-widget--4x2": "styles_link-widget--4x2__O9CPU",
                "link-widget--4x4": "styles_link-widget--4x4__84G_p",
                "link-widget--1x4": "styles_link-widget--1x4__5ZGtD",
                description: "styles_description__c53Bp",
                "link-widget--2x4": "styles_link-widget--2x4__4yx1P",
                "link-meta__container": "styles_link-meta__container__IPFEU",
                "link-widget--2x2": "styles_link-widget--2x2__3cXDi",
                title: "styles_title__cseoK",
                "title-editor": "styles_title-editor__jbSp2",
                "favicon-wrapper": "styles_favicon-wrapper__reNiI",
                handle: "styles_handle__wuHSX",
                cover: "styles_cover__GELIi"
            }
        },
        70254: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__ZPbvw",
                "link-widget--4x2": "styles_link-widget--4x2__AdOLQ",
                "link-widget--4x4": "styles_link-widget--4x4__OlhXy",
                "link-widget--1x4": "styles_link-widget--1x4__epSSV",
                description: "styles_description__0ps4x",
                "link-meta__container": "styles_link-meta__container__11N0f",
                handle: "styles_handle__Ogcl_",
                "link-widget--2x2": "styles_link-widget--2x2__QIYhF",
                "link-widget--2x4": "styles_link-widget--2x4__3ZtSr",
                title: "styles_title__J1S6U",
                "title-editor": "styles_title-editor__6sRC3",
                "post-grid": "styles_post-grid__GUgsX",
                "post-grid-fetching": "styles_post-grid-fetching__SHhJl",
                "follow-button": "styles_follow-button__ByG7h"
            }
        },
        53406: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget___4Ab4",
                "link-widget--4x2": "styles_link-widget--4x2__sHjvl",
                "link-widget--4x4": "styles_link-widget--4x4___UHle",
                "link-widget--1x4": "styles_link-widget--1x4__E6LRn",
                description: "styles_description__WqTq8",
                "link-widget--2x4": "styles_link-widget--2x4___rt_e",
                "link-meta__container": "styles_link-meta__container__le5hl",
                "link-widget--2x2": "styles_link-widget--2x2__xaXcD",
                title: "styles_title__vA_Db",
                "title-editor": "styles_title-editor__6fHZM",
                handle: "styles_handle__IT1JE",
                cover: "styles_cover__fH6fJ"
            }
        },
        69090: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__JvUyX",
                "link-widget--4x2": "styles_link-widget--4x2__KOnNi",
                "link-widget--4x4": "styles_link-widget--4x4__QVYMw",
                "link-widget--1x4": "styles_link-widget--1x4__jUn6M",
                description: "styles_description__4k93k",
                "link-widget--2x4": "styles_link-widget--2x4__6hXcR",
                "link-meta__container": "styles_link-meta__container___JId8",
                "link-widget--2x2": "styles_link-widget--2x2__o7wJy",
                title: "styles_title__JMAPj",
                "title-editor": "styles_title-editor__j8V4D",
                bio: "styles_bio__5hwZ9",
                handle: "styles_handle__6lmlT",
                cover: "styles_cover__7Mn4e"
            }
        },
        72625: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__P2ncP",
                "link-widget--4x2": "styles_link-widget--4x2__uqQw7",
                "link-widget--4x4": "styles_link-widget--4x4__sKU1c",
                "link-widget--1x4": "styles_link-widget--1x4__Lygwb",
                description: "styles_description__FEuX_",
                "link-widget--2x4": "styles_link-widget--2x4__ijklO",
                "link-meta__container": "styles_link-meta__container__praj3",
                "link-widget--2x2": "styles_link-widget--2x2__JVsYl",
                title: "styles_title__Jgj6F",
                "title-editor": "styles_title-editor__15Ta1",
                "favicon-wrapper": "styles_favicon-wrapper__DFcLQ",
                handle: "styles_handle__xwVHA",
                cover: "styles_cover__H6nKX"
            }
        },
        75179: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__YLC_n",
                "link-widget--4x2": "styles_link-widget--4x2__oKDqq",
                "link-widget--4x4": "styles_link-widget--4x4__g55ST",
                "link-widget--1x4": "styles_link-widget--1x4__KxewL",
                description: "styles_description__JBHvO",
                "link-meta__container": "styles_link-meta__container__Mup54",
                handle: "styles_handle__DqdjI",
                "link-widget--2x2": "styles_link-widget--2x2__TNSMA",
                "link-widget--2x4": "styles_link-widget--2x4__cYc_s",
                title: "styles_title__CRXZV",
                "title-editor": "styles_title-editor__J8akJ",
                "post-grid": "styles_post-grid__kTxAd",
                "post-grid-fetching": "styles_post-grid-fetching__SIG62",
                "follow-button": "styles_follow-button__DisN_"
            }
        },
        34018: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__71Lqs",
                "link-widget--4x2": "styles_link-widget--4x2__esohO",
                "link-widget--4x4": "styles_link-widget--4x4__E7oAM",
                "link-widget--1x4": "styles_link-widget--1x4__f0grT",
                description: "styles_description__Hq1D7",
                "link-widget--2x4": "styles_link-widget--2x4__nG18b",
                "link-meta__container": "styles_link-meta__container__aVYxN",
                "link-widget--2x2": "styles_link-widget--2x2__5N3Xt",
                title: "styles_title__yNrAo",
                "title-editor": "styles_title-editor__uS2jK",
                bio: "styles_bio__XqhDH",
                handle: "styles_handle__AH_Q8",
                cover: "styles_cover__WtIYn"
            }
        },
        94325: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__Bnd7a",
                "link-widget--4x2": "styles_link-widget--4x2__R_BaF",
                "link-widget--4x4": "styles_link-widget--4x4__MErmn",
                "link-widget--1x4": "styles_link-widget--1x4__BxBHl",
                description: "styles_description__iGgyW",
                "link-meta__container": "styles_link-meta__container__B7kgn",
                handle: "styles_handle__MSvSD",
                "link-widget--2x2": "styles_link-widget--2x2__Hzgp3",
                "link-widget--2x4": "styles_link-widget--2x4__Jplqd",
                title: "styles_title__7jJoe",
                "title-editor": "styles_title-editor__pQ3Xp",
                "post-grid": "styles_post-grid__U2qhk",
                "post-grid-fetching": "styles_post-grid-fetching__X6L28",
                "follow-button": "styles_follow-button__i0_33"
            }
        },
        58003: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget___Cd4d",
                "link-widget--4x2": "styles_link-widget--4x2__xAkeL",
                "link-widget--4x4": "styles_link-widget--4x4__YkWAV",
                "link-widget--1x4": "styles_link-widget--1x4__X2VO_",
                description: "styles_description__FRpZD",
                "link-meta__container": "styles_link-meta__container__K1H22",
                "link-widget--2x2": "styles_link-widget--2x2__Lk0SG",
                "link-widget--2x4": "styles_link-widget--2x4__KAleD",
                title: "styles_title___sgwe",
                "title-editor": "styles_title-editor__9ytIN",
                "insta-grid": "styles_insta-grid__XFRRf",
                bio: "styles_bio__EQplv",
                handle: "styles_handle__GaWZ1",
                "follow-button": "styles_follow-button__8DSDT",
                cover: "styles_cover__bCxqs"
            }
        },
        68713: function(e) {
            e.exports = {
                "link-widget": "styles_link-widget__SIb2_",
                "link-widget--4x2": "styles_link-widget--4x2___iqG3",
                "link-widget--4x4": "styles_link-widget--4x4__Ef3WM",
                "link-widget--1x4": "styles_link-widget--1x4__BMrpO",
                description: "styles_description__TkqVF",
                "link-meta__container": "styles_link-meta__container__cH_Y_",
                "link-widget--2x2": "styles_link-widget--2x2__qQsBZ",
                "link-widget--2x4": "styles_link-widget--2x4__erTIj",
                title: "styles_title__uRF8b",
                "title-editor": "styles_title-editor__X6f7y",
                "youtube-grid": "styles_youtube-grid__fIYE8",
                "youtube-grid--loading": "styles_youtube-grid--loading__SoBKf",
                "follow-button": "styles_follow-button__885Ii",
                subs: "styles_subs__lESk_"
            }
        },
        26648: function(e) {
            e.exports = {
                "animation-ctn": "styles_animation-ctn__aIOat",
                inlinesvg: "styles_inlinesvg__R7tgu",
                svg: "styles_svg__igDbe",
                "icon--order-success": "styles_icon--order-success__qDq52",
                checkmark: "styles_checkmark__6SMZz",
                "checkmark-circle": "styles_checkmark-circle__JrrJM",
                colored: "styles_colored__Q6fnb",
                "colored-circle": "styles_colored-circle__R95Eq"
            }
        },
        60741: function(e) {
            e.exports = {
                avatar: "styles_avatar__Qe60n",
                "avatar--circle": "styles_avatar--circle__7p3KY",
                "avatar--portrait": "styles_avatar--portrait__85kOg"
            }
        },
        18543: function(e) {
            e.exports = {
                "progress-svg": "styles_progress-svg__t3oJq",
                "progress-bar": "styles_progress-bar__ZVpTX"
            }
        },
        32108: function(e) {
            e.exports = {
                container: "styles_container__hMD5d",
                vinyl: "styles_vinyl__jOIW6",
                cover: "styles_cover__kbN3D"
            }
        },
        10952: function(e) {
            e.exports = {
                highlight: "styles_highlight__LE2l3"
            }
        },
        85953: function(e) {
            e.exports = {
                container: "styles_container__mN1DY",
                "container--visible": "styles_container--visible__d7lBZ",
                enter: "styles_enter__3YwnN",
                leave: "styles_leave__DIjt0",
                content: "styles_content__2_iS0",
                icon: "styles_icon__vEkgg"
            }
        },
        75126: function(e) {
            e.exports = {
                container: "styles_container__QIm09",
                "input-container": "styles_input-container___DmIW",
                "input-container--error": "styles_input-container--error__F__9w",
                input: "styles_input__CqLya",
                "action-container": "styles_action-container__hsVeH",
                "button--shadow": "styles_button--shadow__WOms6",
                "paste-button-container": "styles_paste-button-container__tuEQu"
            }
        },
        77720: function(e) {
            e.exports = {
                content: "styles_content__Ly3HL",
                "content--animation-default": "styles_content--animation-default__48jfN",
                slideUpAndFade: "styles_slideUpAndFade__HFXr_",
                slideLeftAndFade: "styles_slideLeftAndFade__3vKx6",
                slideDownAndFade: "styles_slideDownAndFade__cDiQ7",
                slideRightAndFade: "styles_slideRightAndFade__wCuvh",
                "content--animation-flipper": "styles_content--animation-flipper__GOzqG",
                flipIn: "styles_flipIn__Ebwjo",
                flipOut: "styles_flipOut__h8E6e",
                flipInR: "styles_flipInR__FPDHN",
                flipOutR: "styles_flipOutR__nzT3R",
                flipInTL: "styles_flipInTL__zbmxU",
                flipOutTL: "styles_flipOutTL__TnqzC",
                "content--default": "styles_content--default__akBdj",
                fadeOut: "styles_fadeOut__ds9eN"
            }
        },
        39690: function(e) {
            e.exports = {
                overlay: "styles_overlay__nV48j",
                overlayShow: "styles_overlayShow__Fb3Su",
                content: "styles_content__kYw2I",
                fadeOut: "styles_fadeOut__z_muc",
                contentShow: "styles_contentShow__Qc7kr"
            }
        },
        17657: function(e) {
            e.exports = {
                container: "styles_container__2GNCj",
                "container--input-active": "styles_container--input-active__1ekrS",
                "container--click-to-activate": "styles_container--click-to-activate__h_Wxw",
                fallback: "styles_fallback__jtZjT",
                "container--floating": "styles_container--floating__mdG_u",
                input: "styles_input__ZzDpL"
            }
        },
        36878: function(e) {
            e.exports = {
                "overlay-top": "styles_overlay-top__QsEw5",
                "overlay-bottom": "styles_overlay-bottom__Icsk5"
            }
        },
        1341: function(e) {
            e.exports = {
                overlay: "styles_overlay__s2ljQ",
                overlayShow: "styles_overlayShow__4VeO5",
                overlayHide: "styles_overlayHide__Um747",
                overlay__bg: "styles_overlay__bg__v8o5Q",
                fadeOut: "styles_fadeOut__0MgEz",
                sheet: "styles_sheet__wdl9_",
                slideOut: "styles_slideOut__cB_b_",
                slideIn: "styles_slideIn__Q3Wwl",
                sheet__content: "styles_sheet__content__qvm_l"
            }
        },
        71692: function(e) {
            e.exports = {
                skeleton: "styles_skeleton__xhCtF",
                "skeleton--animated": "styles_skeleton--animated__tPXbp",
                animation: "styles_animation__HA9NV"
            }
        },
        80162: function(e) {
            e.exports = {
                fade: "styles_fade__oDOwY",
                "fade--active": "styles_fade--active__kxzWH",
                "fade--top": "styles_fade--top__IYU_Y",
                "fade--bottom": "styles_fade--bottom__mvQfe",
                tooltip: "styles_tooltip__on62v"
            }
        },
        8058: function(e) {
            e.exports = {
                "avatar-editor": "styles_avatar-editor__xBM_4",
                preview: "styles_preview__TFfzT",
                "overlay-container": "styles_overlay-container__b2Mpe",
                overlay: "styles_overlay__ndtF4",
                "avatar-editor--has-avatar": "styles_avatar-editor--has-avatar__qznO1",
                "delete-wrapper": "styles_delete-wrapper__8J1Rq",
                "avatar-editor-wrapper": "styles_avatar-editor-wrapper__hgyBW",
                "input-mode--mouse": "styles_input-mode--mouse__RMnJU",
                "input-mode--touch": "styles_input-mode--touch__mE36h",
                "action-button": "styles_action-button__5F5c2",
                "delete-wrapper--dragging": "styles_delete-wrapper--dragging__A8_m5"
            }
        },
        18674: function(e) {
            e.exports = {
                container: "styles_container__LUC3L"
            }
        },
        16233: function(e) {
            e.exports = {
                button: "styles_button__3JDzo",
                "button--selected": "styles_button--selected__JaPY1",
                button__content: "styles_button__content__8pzI8",
                "button__content--shadow-strong": "styles_button__content--shadow-strong__KkUyx",
                border: "styles_border__FeYLK",
                highlight: "styles_highlight__TiiJr",
                "highlight--strong": "styles_highlight--strong__7_nAq",
                gradient: "styles_gradient__5iiUk"
            }
        },
        70873: function(e) {
            e.exports = {
                "drop-indicator": "styles_drop-indicator__QtQvc",
                "drop-indicator--offset": "styles_drop-indicator--offset__poyPc",
                "drop-indicator--dropping": "styles_drop-indicator--dropping__Sztc0",
                menu: "styles_menu__97oGE",
                "menu-button": "styles_menu-button__La8nx",
                "delete-button": "styles_delete-button__6iYKI",
                "bottom-menu": "styles_bottom-menu__xw0Pr",
                "style-menu": "styles_style-menu__FO7Wu",
                "click-button": "styles_click-button__grvG7",
                "style-button": "styles_style-button__5wkxt",
                submenu: "styles_submenu__pm2xQ",
                "submenu-row": "styles_submenu-row___raDd",
                "submenu-colors": "styles_submenu-colors__DomvC"
            }
        },
        14734: function(e) {
            e.exports = {
                "link-bar": "styles_link-bar__7dWte",
                "link-bar--visible": "styles_link-bar--visible__m00Bz",
                highlight: "styles_highlight__rBpnr",
                button: "styles_button__3ExPi",
                "button--paste": "styles_button--paste__9I5l5",
                "button--add": "styles_button--add__PLWft"
            }
        },
        90803: function(e) {
            e.exports = {
                "floating-bar": "styles_floating-bar__UHlNW",
                "enter-transform": "styles_enter-transform__C24Wv",
                divider: "styles_divider__3_u0k",
                "tooltip-container": "styles_tooltip-container__O4IGt",
                highlight: "styles_highlight__oSUNp",
                "enter-opacity": "styles_enter-opacity__b19WP"
            }
        },
        92716: function(e) {
            e.exports = {
                "floating-button": "styles_floating-button__Hh8Bg",
                "flat-button": "styles_flat-button__FUy_M"
            }
        },
        52534: function(e) {
            e.exports = {
                "frame-container": "styles_frame-container__fMW1R",
                "frame-container--animated": "styles_frame-container--animated__aZyL3",
                frame: "styles_frame__IXFMo",
                "frame-container--mobile": "styles_frame-container--mobile__Sn14h"
            }
        },
        94915: function(e) {
            e.exports = {
                container: "styles_container__BF_3_",
                "container--hidden": "styles_container--hidden__76pXI",
                button: "styles_button__Noy8Q"
            }
        },
        9697: function(e) {
            e.exports = {
                "done-button": "styles_done-button__B_Eqo"
            }
        },
        46079: function(e) {
            e.exports = {
                "link-bar": "styles_link-bar__mtqCw",
                "link-bar--visible": "styles_link-bar--visible___SdgL",
                highlight: "styles_highlight__QM9yP",
                button: "styles_button__pZX_5",
                "button--paste": "styles_button--paste__KRojH",
                "button--add": "styles_button--add__K0bS_"
            }
        },
        95157: function(e) {
            e.exports = {
                "floating-bar": "styles_floating-bar__oAf2I",
                "floating-bar--initialized": "styles_floating-bar--initialized__7MTJ5",
                "enter-transform": "styles_enter-transform__izZiF",
                divider: "styles_divider___2Nov",
                "tooltip-container": "styles_tooltip-container__WT8fS",
                highlight: "styles_highlight__7fkdf",
                "force-full-opacity": "styles_force-full-opacity__7iGzR",
                "enter-opacity": "styles_enter-opacity__7B_C7"
            }
        },
        26892: function(e) {
            e.exports = {
                container: "styles_container__TzlGA",
                "container--selected": "styles_container--selected__Y7oXQ",
                button: "styles_button__22GVI",
                hidden: "styles_hidden__EDr2a"
            }
        },
        24441: function(e) {
            e.exports = {
                menu: "styles_menu__p6scU",
                "attached-menu": "styles_attached-menu__53lvP"
            }
        },
        48813: function(e) {
            e.exports = {
                "style-button": "styles_style-button__qclYW"
            }
        },
        40820: function(e) {
            e.exports = {
                og: "styles_og__OUmsA",
                "og--fix-aspect": "styles_og--fix-aspect__cg5Ea",
                "og--empty": "styles_og--empty__GG3X1",
                "upload-button": "styles_upload-button__Fkcgk"
            }
        },
        66996: function(e) {
            e.exports = {
                icon: "styles_icon__GvLPE",
                favicon: "styles_favicon__iBRwF",
                "upload-button": "styles_upload-button__Qn59X"
            }
        },
        70082: function(e) {
            e.exports = {
                "foot-traffic-button": "styles_foot-traffic-button__0scBb",
                "foot-traffic-button--active": "styles_foot-traffic-button--active__JV8UL",
                "fade-in": "styles_fade-in__YsAbr"
            }
        },
        35328: function(e) {
            e.exports = {
                bio: "styles_bio__oMe8p"
            }
        },
        86269: function(e) {
            e.exports = {
                "overlay-left": "styles_overlay-left__zw7ZD",
                "overlay-right": "styles_overlay-right__0Lknb",
                moving: "styles_moving__WgUA_",
                scroll: "styles_scroll__j475f"
            }
        },
        11395: function(e) {
            e.exports = {
                logo: "styles_logo__juHd_",
                "badge-shadow": "styles_badge-shadow__HAlcy",
                glare: "styles_glare__twFkA",
                animation: "styles_animation__Mjuij",
                clip: "styles_clip__wjcb7",
                "url-animation": "styles_url-animation__HvDNJ",
                urlanimation: "styles_urlanimation__HTdvC",
                "badge-animation": "styles_badge-animation__d9pnU",
                badgopacityeanimation: "styles_badgopacityeanimation__s2M2D",
                badgeanimation: "styles_badgeanimation__XwcJr",
                peripheral: "styles_peripheral__3Q73N",
                appear: "styles_appear__y4MNU",
                illustration: "styles_illustration__UFwk_",
                illustrationanimation: "styles_illustrationanimation__jrTBi"
            }
        },
        92478: function(e) {
            e.exports = {
                button: "styles_button__FXBmQ",
                "button--white": "styles_button--white__cgCcR",
                "shiny-button": "styles_shiny-button__STTmi",
                "foot-traffic-divider": "styles_foot-traffic-divider__EKk6W",
                "fade-in": "styles_fade-in__wHsBV"
            }
        },
        73906: function(e) {
            e.exports = {
                "onboarding-popup": "styles_onboarding-popup__2BpYv",
                "onboarding-fade": "styles_onboarding-fade__8GpaN"
            }
        }
    },
    function(e) {
        e.O(0, [812, 736, 25, 759, 784, 879, 767, 891, 739, 223, 774, 888, 179], function() {
            return e(e.s = 53778)
        }), _N_E = e.O()
    }
]);