"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [812], {
        52780: function(e, t, n) {
            n.d(t, {
                EH: function() {
                    return tf
                },
                p: function() {
                    return tc
                },
                tk: function() {
                    return tP
                }
            });
            var o = n(27191),
                i = n(28638),
                s = n(26151);
            let r = "undefined" != typeof navigator ? navigator : null,
                l = "undefined" != typeof document ? document : null,
                d = r && r.userAgent || "",
                a = /Edge\/(\d+)/.exec(d),
                c = /MSIE \d/.exec(d),
                h = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(d),
                u = !!(c || h || a),
                f = c ? document.documentMode : h ? +h[1] : a ? +a[1] : 0,
                p = !u && /gecko\/(\d+)/i.test(d);
            p && (/Firefox\/(\d+)/.exec(d) || [0, 0])[1];
            let m = !u && /Chrome\/(\d+)/.exec(d),
                g = !!m,
                y = m ? +m[1] : 0,
                b = !u && !!r && /Apple Computer/.test(r.vendor),
                v = b && (/Mobile\/\w+/.test(d) || !!r && r.maxTouchPoints > 2),
                w = v || !!r && /Mac/.test(r.platform),
                D = /Android \d/.test(d),
                N = !!l && "webkitFontSmoothing" in l.documentElement.style,
                S = N ? +(/\bAppleWebKit\/(\d+)/.exec(navigator.userAgent) || [0, 0])[1] : 0,
                O = function(e) {
                    for (var t = 0;; t++)
                        if (!(e = e.previousSibling)) return t
                },
                C = function(e) {
                    let t = e.assignedSlot || e.parentNode;
                    return t && 11 == t.nodeType ? t.host : t
                },
                M = null,
                x = function(e, t, n) {
                    let o = M || (M = document.createRange());
                    return o.setEnd(e, null == n ? e.nodeValue.length : n), o.setStart(e, t || 0), o
                },
                k = function(e, t, n, o) {
                    return n && (A(e, t, n, o, -1) || A(e, t, n, o, 1))
                },
                T = /^(img|br|input|textarea|hr)$/i;

            function A(e, t, n, o, i) {
                for (;;) {
                    if (e == n && t == o) return !0;
                    if (t == (i < 0 ? 0 : E(e))) {
                        let n = e.parentNode;
                        if (!n || 1 != n.nodeType || function(e) {
                                let t;
                                for (let n = e; n && !(t = n.pmViewDesc); n = n.parentNode);
                                return t && t.node && t.node.isBlock && (t.dom == e || t.contentDOM == e)
                            }(e) || T.test(e.nodeName) || "false" == e.contentEditable) return !1;
                        t = O(e) + (i < 0 ? 0 : 1), e = n
                    } else {
                        if (1 != e.nodeType || "false" == (e = e.childNodes[t + (i < 0 ? -1 : 0)]).contentEditable) return !1;
                        t = i < 0 ? E(e) : 0
                    }
                }
            }

            function E(e) {
                return 3 == e.nodeType ? e.nodeValue.length : e.childNodes.length
            }
            let P = function(e) {
                let t = e.isCollapsed;
                return t && g && e.rangeCount && !e.getRangeAt(0).collapsed && (t = !1), t
            };

            function V(e, t) {
                let n = document.createEvent("Event");
                return n.initEvent("keydown", !0, !0), n.keyCode = e, n.key = n.code = t, n
            }

            function B(e, t) {
                return "number" == typeof e ? e : e[t]
            }

            function R(e, t, n) {
                let o = e.someProp("scrollThreshold") || 0,
                    i = e.someProp("scrollMargin") || 5,
                    s = e.dom.ownerDocument;
                for (let r = n || e.dom; r; r = C(r)) {
                    if (1 != r.nodeType) continue;
                    let e = r,
                        n = e == s.body,
                        l = n ? {
                            left: 0,
                            right: s.documentElement.clientWidth,
                            top: 0,
                            bottom: s.documentElement.clientHeight
                        } : function(e) {
                            let t = e.getBoundingClientRect(),
                                n = t.width / e.offsetWidth || 1,
                                o = t.height / e.offsetHeight || 1;
                            return {
                                left: t.left,
                                right: t.left + e.clientWidth * n,
                                top: t.top,
                                bottom: t.top + e.clientHeight * o
                            }
                        }(e),
                        d = 0,
                        a = 0;
                    if (t.top < l.top + B(o, "top") ? a = -(l.top - t.top + B(i, "top")) : t.bottom > l.bottom - B(o, "bottom") && (a = t.bottom - l.bottom + B(i, "bottom")), t.left < l.left + B(o, "left") ? d = -(l.left - t.left + B(i, "left")) : t.right > l.right - B(o, "right") && (d = t.right - l.right + B(i, "right")), d || a) {
                        if (n) s.defaultView.scrollBy(d, a);
                        else {
                            let n = e.scrollLeft,
                                o = e.scrollTop;
                            a && (e.scrollTop += a), d && (e.scrollLeft += d);
                            let i = e.scrollLeft - n,
                                s = e.scrollTop - o;
                            t = {
                                left: t.left - i,
                                top: t.top - s,
                                right: t.right - i,
                                bottom: t.bottom - s
                            }
                        }
                    }
                    if (n) break
                }
            }

            function z(e) {
                let t = [],
                    n = e.ownerDocument;
                for (let o = e; o && (t.push({
                        dom: o,
                        top: o.scrollTop,
                        left: o.scrollLeft
                    }), e != n); o = C(o));
                return t
            }

            function I(e, t) {
                for (let n = 0; n < e.length; n++) {
                    let {
                        dom: o,
                        top: i,
                        left: s
                    } = e[n];
                    o.scrollTop != i + t && (o.scrollTop = i + t), o.scrollLeft != s && (o.scrollLeft = s)
                }
            }
            let q = null;

            function L(e, t) {
                return e.left >= t.left - 1 && e.left <= t.right + 1 && e.top >= t.top - 1 && e.top <= t.bottom + 1
            }

            function F(e, t) {
                let n = e.getClientRects();
                return n.length ? n[t < 0 ? 0 : n.length - 1] : e.getBoundingClientRect()
            }
            let K = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/;

            function W(e, t, n) {
                let {
                    node: o,
                    offset: i
                } = e.docView.domFromPos(t, n < 0 ? -1 : 1), s = N || p;
                if (3 == o.nodeType) {
                    if (s && (K.test(o.nodeValue) || (n < 0 ? !i : i == o.nodeValue.length))) {
                        let e = F(x(o, i, i), n);
                        if (p && i && /\s/.test(o.nodeValue[i - 1]) && i < o.nodeValue.length) {
                            let t = F(x(o, i - 1, i - 1), -1);
                            if (t.top == e.top) {
                                let n = F(x(o, i, i + 1), -1);
                                if (n.top != e.top) return $(n, n.left < t.left)
                            }
                        }
                        return e
                    } {
                        let e = i,
                            t = i,
                            s = n < 0 ? 1 : -1;
                        return n < 0 && !i ? (t++, s = -1) : n >= 0 && i == o.nodeValue.length ? (e--, s = 1) : n < 0 ? e-- : t++, $(F(x(o, e, t), s), s < 0)
                    }
                }
                if (!e.state.doc.resolve(t).parent.inlineContent) {
                    if (i && (n < 0 || i == E(o))) {
                        let e = o.childNodes[i - 1];
                        if (1 == e.nodeType) return H(e.getBoundingClientRect(), !1)
                    }
                    if (i < E(o)) {
                        let e = o.childNodes[i];
                        if (1 == e.nodeType) return H(e.getBoundingClientRect(), !0)
                    }
                    return H(o.getBoundingClientRect(), n >= 0)
                }
                if (i && (n < 0 || i == E(o))) {
                    let e = o.childNodes[i - 1],
                        t = 3 == e.nodeType ? x(e, E(e) - (s ? 0 : 1)) : 1 != e.nodeType || "BR" == e.nodeName && e.nextSibling ? null : e;
                    if (t) return $(F(t, 1), !1)
                }
                if (i < E(o)) {
                    let e = o.childNodes[i];
                    for (; e.pmViewDesc && e.pmViewDesc.ignoreForCoords;) e = e.nextSibling;
                    let t = e ? 3 == e.nodeType ? x(e, 0, s ? 0 : 1) : 1 == e.nodeType ? e : null : null;
                    if (t) return $(F(t, -1), !0)
                }
                return $(F(3 == o.nodeType ? x(o) : o, -n), n >= 0)
            }

            function $(e, t) {
                if (0 == e.width) return e;
                let n = t ? e.left : e.right;
                return {
                    top: e.top,
                    bottom: e.bottom,
                    left: n,
                    right: n
                }
            }

            function H(e, t) {
                if (0 == e.height) return e;
                let n = t ? e.top : e.bottom;
                return {
                    top: n,
                    bottom: n,
                    left: e.left,
                    right: e.right
                }
            }

            function _(e, t, n) {
                let o = e.state,
                    i = e.root.activeElement;
                o != t && e.updateState(t), i != e.dom && e.focus();
                try {
                    return n()
                } finally {
                    o != t && e.updateState(o), i != e.dom && i && i.focus()
                }
            }
            let Y = /[\u0590-\u08ac]/,
                U = null,
                G = null,
                j = !1;
            class X {
                constructor(e, t, n, o) {
                    this.parent = e, this.children = t, this.dom = n, this.contentDOM = o, this.dirty = 0, n.pmViewDesc = this
                }
                matchesWidget(e) {
                    return !1
                }
                matchesMark(e) {
                    return !1
                }
                matchesNode(e, t, n) {
                    return !1
                }
                matchesHack(e) {
                    return !1
                }
                parseRule() {
                    return null
                }
                stopEvent(e) {
                    return !1
                }
                get size() {
                    let e = 0;
                    for (let t = 0; t < this.children.length; t++) e += this.children[t].size;
                    return e
                }
                get border() {
                    return 0
                }
                destroy() {
                    this.parent = void 0, this.dom.pmViewDesc == this && (this.dom.pmViewDesc = void 0);
                    for (let e = 0; e < this.children.length; e++) this.children[e].destroy()
                }
                posBeforeChild(e) {
                    for (let t = 0, n = this.posAtStart;; t++) {
                        let o = this.children[t];
                        if (o == e) return n;
                        n += o.size
                    }
                }
                get posBefore() {
                    return this.parent.posBeforeChild(this)
                }
                get posAtStart() {
                    return this.parent ? this.parent.posBeforeChild(this) + this.border : 0
                }
                get posAfter() {
                    return this.posBefore + this.size
                }
                get posAtEnd() {
                    return this.posAtStart + this.size - 2 * this.border
                }
                localPosFromDOM(e, t, n) {
                    let o;
                    if (this.contentDOM && this.contentDOM.contains(1 == e.nodeType ? e : e.parentNode)) {
                        if (n < 0) {
                            let n, o;
                            if (e == this.contentDOM) n = e.childNodes[t - 1];
                            else {
                                for (; e.parentNode != this.contentDOM;) e = e.parentNode;
                                n = e.previousSibling
                            }
                            for (; n && !((o = n.pmViewDesc) && o.parent == this);) n = n.previousSibling;
                            return n ? this.posBeforeChild(o) + o.size : this.posAtStart
                        } {
                            let n, o;
                            if (e == this.contentDOM) n = e.childNodes[t];
                            else {
                                for (; e.parentNode != this.contentDOM;) e = e.parentNode;
                                n = e.nextSibling
                            }
                            for (; n && !((o = n.pmViewDesc) && o.parent == this);) n = n.nextSibling;
                            return n ? this.posBeforeChild(o) : this.posAtEnd
                        }
                    }
                    if (e == this.dom && this.contentDOM) o = t > O(this.contentDOM);
                    else if (this.contentDOM && this.contentDOM != this.dom && this.dom.contains(this.contentDOM)) o = 2 & e.compareDocumentPosition(this.contentDOM);
                    else if (this.dom.firstChild) {
                        if (0 == t)
                            for (let t = e;; t = t.parentNode) {
                                if (t == this.dom) {
                                    o = !1;
                                    break
                                }
                                if (t.previousSibling) break
                            }
                        if (null == o && t == e.childNodes.length)
                            for (let t = e;; t = t.parentNode) {
                                if (t == this.dom) {
                                    o = !0;
                                    break
                                }
                                if (t.nextSibling) break
                            }
                    }
                    return (null == o ? n > 0 : o) ? this.posAtEnd : this.posAtStart
                }
                nearestDesc(e, t = !1) {
                    for (let n = !0, o = e; o; o = o.parentNode) {
                        let i = this.getDesc(o),
                            s;
                        if (i && (!t || i.node)) {
                            if (!n || !(s = i.nodeDOM) || (1 == s.nodeType ? s.contains(1 == e.nodeType ? e : e.parentNode) : s == e)) return i;
                            n = !1
                        }
                    }
                }
                getDesc(e) {
                    let t = e.pmViewDesc;
                    for (let e = t; e; e = e.parent)
                        if (e == this) return t
                }
                posFromDOM(e, t, n) {
                    for (let o = e; o; o = o.parentNode) {
                        let i = this.getDesc(o);
                        if (i) return i.localPosFromDOM(e, t, n)
                    }
                    return -1
                }
                descAt(e) {
                    for (let t = 0, n = 0; t < this.children.length; t++) {
                        let o = this.children[t],
                            i = n + o.size;
                        if (n == e && i != n) {
                            for (; !o.border && o.children.length;) o = o.children[0];
                            return o
                        }
                        if (e < i) return o.descAt(e - n - o.border);
                        n = i
                    }
                }
                domFromPos(e, t) {
                    if (!this.contentDOM) return {
                        node: this.dom,
                        offset: 0
                    };
                    let n = 0,
                        o = 0;
                    for (let t = 0; n < this.children.length; n++) {
                        let i = this.children[n],
                            s = t + i.size;
                        if (s > e || i instanceof eo) {
                            o = e - t;
                            break
                        }
                        t = s
                    }
                    if (o) return this.children[n].domFromPos(o - this.children[n].border, t);
                    for (let e; n && !(e = this.children[n - 1]).size && e instanceof J && e.side >= 0; n--);
                    if (t <= 0) {
                        let e, o = !0;
                        for (;
                            (e = n ? this.children[n - 1] : null) && e.dom.parentNode != this.contentDOM; n--, o = !1);
                        return e && t && o && !e.border && !e.domAtom ? e.domFromPos(e.size, t) : {
                            node: this.contentDOM,
                            offset: e ? O(e.dom) + 1 : 0
                        }
                    } {
                        let e, o = !0;
                        for (;
                            (e = n < this.children.length ? this.children[n] : null) && e.dom.parentNode != this.contentDOM; n++, o = !1);
                        return e && o && !e.border && !e.domAtom ? e.domFromPos(0, t) : {
                            node: this.contentDOM,
                            offset: e ? O(e.dom) : this.contentDOM.childNodes.length
                        }
                    }
                }
                parseRange(e, t, n = 0) {
                    if (0 == this.children.length) return {
                        node: this.contentDOM,
                        from: e,
                        to: t,
                        fromOffset: 0,
                        toOffset: this.contentDOM.childNodes.length
                    };
                    let o = -1,
                        i = -1;
                    for (let s = n, r = 0;; r++) {
                        let n = this.children[r],
                            l = s + n.size;
                        if (-1 == o && e <= l) {
                            let i = s + n.border;
                            if (e >= i && t <= l - n.border && n.node && n.contentDOM && this.contentDOM.contains(n.contentDOM)) return n.parseRange(e, t, i);
                            e = s;
                            for (let t = r; t > 0; t--) {
                                let n = this.children[t - 1];
                                if (n.size && n.dom.parentNode == this.contentDOM && !n.emptyChildAt(1)) {
                                    o = O(n.dom) + 1;
                                    break
                                }
                                e -= n.size
                            } - 1 == o && (o = 0)
                        }
                        if (o > -1 && (l > t || r == this.children.length - 1)) {
                            t = l;
                            for (let e = r + 1; e < this.children.length; e++) {
                                let n = this.children[e];
                                if (n.size && n.dom.parentNode == this.contentDOM && !n.emptyChildAt(-1)) {
                                    i = O(n.dom);
                                    break
                                }
                                t += n.size
                            } - 1 == i && (i = this.contentDOM.childNodes.length);
                            break
                        }
                        s = l
                    }
                    return {
                        node: this.contentDOM,
                        from: e,
                        to: t,
                        fromOffset: o,
                        toOffset: i
                    }
                }
                emptyChildAt(e) {
                    if (this.border || !this.contentDOM || !this.children.length) return !1;
                    let t = this.children[e < 0 ? 0 : this.children.length - 1];
                    return 0 == t.size || t.emptyChildAt(e)
                }
                domAfterPos(e) {
                    let {
                        node: t,
                        offset: n
                    } = this.domFromPos(e, 0);
                    if (1 != t.nodeType || n == t.childNodes.length) throw RangeError("No node after pos " + e);
                    return t.childNodes[n]
                }
                setSelection(e, t, n, o = !1) {
                    let i = Math.min(e, t),
                        s = Math.max(e, t);
                    for (let r = 0, l = 0; r < this.children.length; r++) {
                        let d = this.children[r],
                            a = l + d.size;
                        if (i > l && s < a) return d.setSelection(e - l - d.border, t - l - d.border, n, o);
                        l = a
                    }
                    let r = this.domFromPos(e, e ? -1 : 1),
                        l = t == e ? r : this.domFromPos(t, t ? -1 : 1),
                        d = n.getSelection(),
                        a = !1;
                    if ((p || b) && e == t) {
                        let {
                            node: e,
                            offset: t
                        } = r;
                        if (3 == e.nodeType) {
                            if ((a = !!(t && "\n" == e.nodeValue[t - 1])) && t == e.nodeValue.length)
                                for (let t = e, n; t; t = t.parentNode) {
                                    if (n = t.nextSibling) {
                                        "BR" == n.nodeName && (r = l = {
                                            node: n.parentNode,
                                            offset: O(n) + 1
                                        });
                                        break
                                    }
                                    let e = t.pmViewDesc;
                                    if (e && e.node && e.node.isBlock) break
                                }
                        } else {
                            let n = e.childNodes[t - 1];
                            a = n && ("BR" == n.nodeName || "false" == n.contentEditable)
                        }
                    }
                    if (p && d.focusNode && d.focusNode != l.node && 1 == d.focusNode.nodeType) {
                        let e = d.focusNode.childNodes[d.focusOffset];
                        e && "false" == e.contentEditable && (o = !0)
                    }
                    if (!(o || a && b) && k(r.node, r.offset, d.anchorNode, d.anchorOffset) && k(l.node, l.offset, d.focusNode, d.focusOffset)) return;
                    let c = !1;
                    if ((d.extend || e == t) && !a) {
                        d.collapse(r.node, r.offset);
                        try {
                            e != t && d.extend(l.node, l.offset), c = !0
                        } catch (e) {
                            if (!(e instanceof DOMException)) throw e
                        }
                    }
                    if (!c) {
                        if (e > t) {
                            let e = r;
                            r = l, l = e
                        }
                        let n = document.createRange();
                        n.setEnd(l.node, l.offset), n.setStart(r.node, r.offset), d.removeAllRanges(), d.addRange(n)
                    }
                }
                ignoreMutation(e) {
                    return !this.contentDOM && "selection" != e.type
                }
                get contentLost() {
                    return this.contentDOM && this.contentDOM != this.dom && !this.dom.contains(this.contentDOM)
                }
                markDirty(e, t) {
                    for (let n = 0, o = 0; o < this.children.length; o++) {
                        let i = this.children[o],
                            s = n + i.size;
                        if (n == s ? e <= s && t >= n : e < s && t > n) {
                            let o = n + i.border,
                                r = s - i.border;
                            if (e >= o && t <= r) {
                                this.dirty = e == n || t == s ? 2 : 1, e == o && t == r && (i.contentLost || i.dom.parentNode != this.contentDOM) ? i.dirty = 3 : i.markDirty(e - o, t - o);
                                return
                            }
                            i.dirty = i.dom != i.contentDOM || i.dom.parentNode != this.contentDOM || i.children.length ? 3 : 2
                        }
                        n = s
                    }
                    this.dirty = 2
                }
                markParentsDirty() {
                    let e = 1;
                    for (let t = this.parent; t; t = t.parent, e++) {
                        let n = 1 == e ? 2 : 1;
                        t.dirty < n && (t.dirty = n)
                    }
                }
                get domAtom() {
                    return !1
                }
                get ignoreForCoords() {
                    return !1
                }
            }
            class J extends X {
                constructor(e, t, n, o) {
                    let i, s = t.type.toDOM;
                    if ("function" == typeof s && (s = s(n, () => i ? i.parent ? i.parent.posBeforeChild(i) : void 0 : o)), !t.type.spec.raw) {
                        if (1 != s.nodeType) {
                            let e = document.createElement("span");
                            e.appendChild(s), s = e
                        }
                        s.contentEditable = "false", s.classList.add("ProseMirror-widget")
                    }
                    super(e, [], s, null), this.widget = t, this.widget = t, i = this
                }
                matchesWidget(e) {
                    return 0 == this.dirty && e.type.eq(this.widget.type)
                }
                parseRule() {
                    return {
                        ignore: !0
                    }
                }
                stopEvent(e) {
                    let t = this.widget.spec.stopEvent;
                    return !!t && t(e)
                }
                ignoreMutation(e) {
                    return "selection" != e.type || this.widget.spec.ignoreSelection
                }
                destroy() {
                    this.widget.type.destroy(this.dom), super.destroy()
                }
                get domAtom() {
                    return !0
                }
                get side() {
                    return this.widget.type.side
                }
            }
            class Q extends X {
                constructor(e, t, n, o) {
                    super(e, [], t, null), this.textDOM = n, this.text = o
                }
                get size() {
                    return this.text.length
                }
                localPosFromDOM(e, t) {
                    return e != this.textDOM ? this.posAtStart + (t ? this.size : 0) : this.posAtStart + t
                }
                domFromPos(e) {
                    return {
                        node: this.textDOM,
                        offset: e
                    }
                }
                ignoreMutation(e) {
                    return "characterData" === e.type && e.target.nodeValue == e.oldValue
                }
            }
            class Z extends X {
                constructor(e, t, n, o) {
                    super(e, [], n, o), this.mark = t
                }
                static create(e, t, n, o) {
                    let s = o.nodeViews[t.type.name],
                        r = s && s(t, o, n);
                    return r && r.dom || (r = i.PW.renderSpec(document, t.type.spec.toDOM(t, n))), new Z(e, t, r.dom, r.contentDOM || r.dom)
                }
                parseRule() {
                    return 3 & this.dirty || this.mark.type.spec.reparseInView ? null : {
                        mark: this.mark.type.name,
                        attrs: this.mark.attrs,
                        contentElement: this.contentDOM || void 0
                    }
                }
                matchesMark(e) {
                    return 3 != this.dirty && this.mark.eq(e)
                }
                markDirty(e, t) {
                    if (super.markDirty(e, t), 0 != this.dirty) {
                        let e = this.parent;
                        for (; !e.node;) e = e.parent;
                        e.dirty < this.dirty && (e.dirty = this.dirty), this.dirty = 0
                    }
                }
                slice(e, t, n) {
                    let o = Z.create(this.parent, this.mark, !0, n),
                        i = this.children,
                        s = this.size;
                    t < s && (i = ep(i, t, s, n)), e > 0 && (i = ep(i, 0, e, n));
                    for (let e = 0; e < i.length; e++) i[e].parent = o;
                    return o.children = i, o
                }
            }
            class ee extends X {
                constructor(e, t, n, o, i, s, r, l, d) {
                    super(e, [], i, s), this.node = t, this.outerDeco = n, this.innerDeco = o, this.nodeDOM = r, s && this.updateChildren(l, d)
                }
                static create(e, t, n, o, s, r) {
                    let l = s.nodeViews[t.type.name],
                        d, a = l && l(t, s, () => d ? d.parent ? d.parent.posBeforeChild(d) : void 0 : r, n, o),
                        c = a && a.dom,
                        h = a && a.contentDOM;
                    if (t.isText) {
                        if (c) {
                            if (3 != c.nodeType) throw RangeError("Text must be rendered as a DOM text node")
                        } else c = document.createTextNode(t.text)
                    } else c || ({
                        dom: c,
                        contentDOM: h
                    } = i.PW.renderSpec(document, t.type.spec.toDOM(t)));
                    h || t.isText || "BR" == c.nodeName || (c.hasAttribute("contenteditable") || (c.contentEditable = "false"), t.type.spec.draggable && (c.draggable = !0));
                    let u = c;
                    return (c = ea(c, n, t), a) ? d = new ei(e, t, n, o, c, h || null, u, a, s, r + 1) : t.isText ? new en(e, t, n, o, c, u, s) : new ee(e, t, n, o, c, h || null, u, s, r + 1)
                }
                parseRule() {
                    if (this.node.type.spec.reparseInView) return null;
                    let e = {
                        node: this.node.type.name,
                        attrs: this.node.attrs
                    };
                    if ("pre" == this.node.type.whitespace && (e.preserveWhitespace = "full"), this.contentDOM) {
                        if (this.contentLost) {
                            for (let t = this.children.length - 1; t >= 0; t--) {
                                let n = this.children[t];
                                if (this.dom.contains(n.dom.parentNode)) {
                                    e.contentElement = n.dom.parentNode;
                                    break
                                }
                            }
                            e.contentElement || (e.getContent = () => i.HY.empty)
                        } else e.contentElement = this.contentDOM
                    } else e.getContent = () => this.node.content;
                    return e
                }
                matchesNode(e, t, n) {
                    return 0 == this.dirty && e.eq(this.node) && ec(t, this.outerDeco) && n.eq(this.innerDeco)
                }
                get size() {
                    return this.node.nodeSize
                }
                get border() {
                    return this.node.isLeaf ? 0 : 1
                }
                updateChildren(e, t) {
                    let n = this.node.inlineContent,
                        o = t,
                        s = e.composing ? this.localCompositionInfo(e, t) : null,
                        r = s && s.pos > -1 ? s : null,
                        l = s && s.pos < 0,
                        d = new eu(this, r && r.node);
                    (function(e, t, n, o) {
                        let i = t.locals(e),
                            s = 0;
                        if (0 == i.length) {
                            for (let n = 0; n < e.childCount; n++) {
                                let r = e.child(n);
                                o(r, i, t.forChild(s, r), n), s += r.nodeSize
                            }
                            return
                        }
                        let r = 0,
                            l = [],
                            d = null;
                        for (let a = 0;;) {
                            let c, h;
                            if (r < i.length && i[r].to == s) {
                                let e = i[r++],
                                    t;
                                for (; r < i.length && i[r].to == s;)(t || (t = [e])).push(i[r++]);
                                if (t) {
                                    t.sort(ef);
                                    for (let e = 0; e < t.length; e++) n(t[e], a, !!d)
                                } else n(e, a, !!d)
                            }
                            if (d) h = -1, c = d, d = null;
                            else if (a < e.childCount) h = a, c = e.child(a++);
                            else break;
                            for (let e = 0; e < l.length; e++) l[e].to <= s && l.splice(e--, 1);
                            for (; r < i.length && i[r].from <= s && i[r].to > s;) l.push(i[r++]);
                            let u = s + c.nodeSize;
                            if (c.isText) {
                                let e = u;
                                r < i.length && i[r].from < e && (e = i[r].from);
                                for (let t = 0; t < l.length; t++) l[t].to < e && (e = l[t].to);
                                e < u && (d = c.cut(e - s), c = c.cut(0, e - s), u = e, h = -1)
                            }
                            let f = c.isInline && !c.isLeaf ? l.filter(e => !e.inline) : l.slice();
                            o(c, f, t.forChild(s, c), h), s = u
                        }
                    })(this.node, this.innerDeco, (t, s, r) => {
                        t.spec.marks ? d.syncToMarks(t.spec.marks, n, e) : t.type.side >= 0 && !r && d.syncToMarks(s == this.node.childCount ? i.vc.none : this.node.child(s).marks, n, e), d.placeWidget(t, e, o)
                    }, (t, i, r, a) => {
                        let c;
                        d.syncToMarks(t.marks, n, e), d.findNodeMatch(t, i, r, a) || l && e.state.selection.from > o && e.state.selection.to < o + t.nodeSize && (c = d.findIndexWithChild(s.node)) > -1 && d.updateNodeAt(t, i, r, c, e) || d.updateNextNode(t, i, r, e, a) || d.addNode(t, i, r, e, o), o += t.nodeSize
                    }), d.syncToMarks([], n, e), this.node.isTextblock && d.addTextblockHacks(), d.destroyRest(), (d.changed || 2 == this.dirty) && (r && this.protectLocalComposition(e, r), function e(t, n, o) {
                        let i = t.firstChild,
                            s = !1;
                        for (let r = 0; r < n.length; r++) {
                            let l = n[r],
                                d = l.dom;
                            if (d.parentNode == t) {
                                for (; d != i;) i = eh(i), s = !0;
                                i = i.nextSibling
                            } else s = !0, t.insertBefore(d, i);
                            if (l instanceof Z) {
                                let n = i ? i.previousSibling : t.lastChild;
                                e(l.contentDOM, l.children, o), i = n ? n.nextSibling : t.firstChild
                            }
                        }
                        for (; i;) i = eh(i), s = !0;
                        s && o.trackWrites == t && (o.trackWrites = null)
                    }(this.contentDOM, this.children, e), v && function(e) {
                        if ("UL" == e.nodeName || "OL" == e.nodeName) {
                            let t = e.style.cssText;
                            e.style.cssText = t + "; list-style: square !important", window.getComputedStyle(e).listStyle, e.style.cssText = t
                        }
                    }(this.dom))
                }
                localCompositionInfo(e, t) {
                    let {
                        from: n,
                        to: i
                    } = e.state.selection;
                    if (!(e.state.selection instanceof o.Bs) || n < t || i > t + this.node.content.size) return null;
                    let s = e.domSelection(),
                        r = function(e, t) {
                            for (;;) {
                                if (3 == e.nodeType) return e;
                                if (1 == e.nodeType && t > 0) {
                                    if (e.childNodes.length > t && 3 == e.childNodes[t].nodeType) return e.childNodes[t];
                                    t = E(e = e.childNodes[t - 1])
                                } else {
                                    if (1 != e.nodeType || !(t < e.childNodes.length)) return null;
                                    e = e.childNodes[t], t = 0
                                }
                            }
                        }(s.focusNode, s.focusOffset);
                    if (!r || !this.dom.contains(r.parentNode)) return null;
                    if (!this.node.inlineContent) return {
                        node: r,
                        pos: -1,
                        text: ""
                    }; {
                        let e = r.nodeValue,
                            o = function(e, t, n, o) {
                                for (let i = 0, s = 0; i < e.childCount && s <= o;) {
                                    let r = e.child(i++),
                                        l = s;
                                    if (s += r.nodeSize, !r.isText) continue;
                                    let d = r.text;
                                    for (; i < e.childCount;) {
                                        let t = e.child(i++);
                                        if (s += t.nodeSize, !t.isText) break;
                                        d += t.text
                                    }
                                    if (s >= n) {
                                        let e = l < o ? d.lastIndexOf(t, o - l - 1) : -1;
                                        if (e >= 0 && e + t.length + l >= n) return l + e;
                                        if (n == o && d.length >= o + t.length - l && d.slice(o - l, o - l + t.length) == t) return o
                                    }
                                }
                                return -1
                            }(this.node.content, e, n - t, i - t);
                        return o < 0 ? null : {
                            node: r,
                            pos: o,
                            text: e
                        }
                    }
                }
                protectLocalComposition(e, {
                    node: t,
                    pos: n,
                    text: o
                }) {
                    if (this.getDesc(t)) return;
                    let i = t;
                    for (; i.parentNode != this.contentDOM; i = i.parentNode) {
                        for (; i.previousSibling;) i.parentNode.removeChild(i.previousSibling);
                        for (; i.nextSibling;) i.parentNode.removeChild(i.nextSibling);
                        i.pmViewDesc && (i.pmViewDesc = void 0)
                    }
                    let s = new Q(this, i, t, o);
                    e.input.compositionNodes.push(s), this.children = ep(this.children, n, n + o.length, e, s)
                }
                update(e, t, n, o) {
                    return !!(3 != this.dirty && e.sameMarkup(this.node)) && (this.updateInner(e, t, n, o), !0)
                }
                updateInner(e, t, n, o) {
                    this.updateOuterDeco(t), this.node = e, this.innerDeco = n, this.contentDOM && this.updateChildren(o, this.posAtStart), this.dirty = 0
                }
                updateOuterDeco(e) {
                    if (ec(e, this.outerDeco)) return;
                    let t = 1 != this.nodeDOM.nodeType,
                        n = this.dom;
                    this.dom = ed(this.dom, this.nodeDOM, el(this.outerDeco, this.node, t), el(e, this.node, t)), this.dom != n && (n.pmViewDesc = void 0, this.dom.pmViewDesc = this), this.outerDeco = e
                }
                selectNode() {
                    1 == this.nodeDOM.nodeType && this.nodeDOM.classList.add("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && (this.dom.draggable = !0)
                }
                deselectNode() {
                    1 == this.nodeDOM.nodeType && this.nodeDOM.classList.remove("ProseMirror-selectednode"), (this.contentDOM || !this.node.type.spec.draggable) && this.dom.removeAttribute("draggable")
                }
                get domAtom() {
                    return this.node.isAtom
                }
            }

            function et(e, t, n, o, i) {
                return ea(o, t, e), new ee(void 0, e, t, n, o, o, o, i, 0)
            }
            class en extends ee {
                constructor(e, t, n, o, i, s, r) {
                    super(e, t, n, o, i, null, s, r, 0)
                }
                parseRule() {
                    let e = this.nodeDOM.parentNode;
                    for (; e && e != this.dom && !e.pmIsDeco;) e = e.parentNode;
                    return {
                        skip: e || !0
                    }
                }
                update(e, t, n, o) {
                    return !!(3 != this.dirty && (0 == this.dirty || this.inParent()) && e.sameMarkup(this.node)) && (this.updateOuterDeco(t), (0 != this.dirty || e.text != this.node.text) && e.text != this.nodeDOM.nodeValue && (this.nodeDOM.nodeValue = e.text, o.trackWrites == this.nodeDOM && (o.trackWrites = null)), this.node = e, this.dirty = 0, !0)
                }
                inParent() {
                    let e = this.parent.contentDOM;
                    for (let t = this.nodeDOM; t; t = t.parentNode)
                        if (t == e) return !0;
                    return !1
                }
                domFromPos(e) {
                    return {
                        node: this.nodeDOM,
                        offset: e
                    }
                }
                localPosFromDOM(e, t, n) {
                    return e == this.nodeDOM ? this.posAtStart + Math.min(t, this.node.text.length) : super.localPosFromDOM(e, t, n)
                }
                ignoreMutation(e) {
                    return "characterData" != e.type && "selection" != e.type
                }
                slice(e, t, n) {
                    let o = this.node.cut(e, t),
                        i = document.createTextNode(o.text);
                    return new en(this.parent, o, this.outerDeco, this.innerDeco, i, i, n)
                }
                markDirty(e, t) {
                    super.markDirty(e, t), this.dom != this.nodeDOM && (0 == e || t == this.nodeDOM.nodeValue.length) && (this.dirty = 3)
                }
                get domAtom() {
                    return !1
                }
            }
            class eo extends X {
                parseRule() {
                    return {
                        ignore: !0
                    }
                }
                matchesHack(e) {
                    return 0 == this.dirty && this.dom.nodeName == e
                }
                get domAtom() {
                    return !0
                }
                get ignoreForCoords() {
                    return "IMG" == this.dom.nodeName
                }
            }
            class ei extends ee {
                constructor(e, t, n, o, i, s, r, l, d, a) {
                    super(e, t, n, o, i, s, r, d, a), this.spec = l
                }
                update(e, t, n, o) {
                    if (3 == this.dirty) return !1;
                    if (this.spec.update) {
                        let i = this.spec.update(e, t, n);
                        return i && this.updateInner(e, t, n, o), i
                    }
                    return (!!this.contentDOM || !!e.isLeaf) && super.update(e, t, n, o)
                }
                selectNode() {
                    this.spec.selectNode ? this.spec.selectNode() : super.selectNode()
                }
                deselectNode() {
                    this.spec.deselectNode ? this.spec.deselectNode() : super.deselectNode()
                }
                setSelection(e, t, n, o) {
                    this.spec.setSelection ? this.spec.setSelection(e, t, n) : super.setSelection(e, t, n, o)
                }
                destroy() {
                    this.spec.destroy && this.spec.destroy(), super.destroy()
                }
                stopEvent(e) {
                    return !!this.spec.stopEvent && this.spec.stopEvent(e)
                }
                ignoreMutation(e) {
                    return this.spec.ignoreMutation ? this.spec.ignoreMutation(e) : super.ignoreMutation(e)
                }
            }
            let es = function(e) {
                e && (this.nodeName = e)
            };
            es.prototype = Object.create(null);
            let er = [new es];

            function el(e, t, n) {
                if (0 == e.length) return er;
                let o = n ? er[0] : new es,
                    i = [o];
                for (let s = 0; s < e.length; s++) {
                    let r = e[s].type.attrs;
                    if (r)
                        for (let e in r.nodeName && i.push(o = new es(r.nodeName)), r) {
                            let s = r[e];
                            null != s && (n && 1 == i.length && i.push(o = new es(t.isInline ? "span" : "div")), "class" == e ? o.class = (o.class ? o.class + " " : "") + s : "style" == e ? o.style = (o.style ? o.style + ";" : "") + s : "nodeName" != e && (o[e] = s))
                        }
                }
                return i
            }

            function ed(e, t, n, o) {
                if (n == er && o == er) return t;
                let i = t;
                for (let t = 0; t < o.length; t++) {
                    let s = o[t],
                        r = n[t];
                    if (t) {
                        let t;
                        r && r.nodeName == s.nodeName && i != e && (t = i.parentNode) && t.nodeName.toLowerCase() == s.nodeName || ((t = document.createElement(s.nodeName)).pmIsDeco = !0, t.appendChild(i), r = er[0]), i = t
                    }! function(e, t, n) {
                        for (let o in t) "class" == o || "style" == o || "nodeName" == o || o in n || e.removeAttribute(o);
                        for (let o in n) "class" != o && "style" != o && "nodeName" != o && n[o] != t[o] && e.setAttribute(o, n[o]);
                        if (t.class != n.class) {
                            let o = t.class ? t.class.split(" ").filter(Boolean) : [],
                                i = n.class ? n.class.split(" ").filter(Boolean) : [];
                            for (let t = 0; t < o.length; t++) - 1 == i.indexOf(o[t]) && e.classList.remove(o[t]);
                            for (let t = 0; t < i.length; t++) - 1 == o.indexOf(i[t]) && e.classList.add(i[t]);
                            0 == e.classList.length && e.removeAttribute("class")
                        }
                        if (t.style != n.style) {
                            if (t.style) {
                                let n = /\s*([\w\-\xa1-\uffff]+)\s*:(?:"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\(.*?\)|[^;])*/g,
                                    o;
                                for (; o = n.exec(t.style);) e.style.removeProperty(o[1])
                            }
                            n.style && (e.style.cssText += n.style)
                        }
                    }(i, r || er[0], s)
                }
                return i
            }

            function ea(e, t, n) {
                return ed(e, e, er, el(t, n, 1 != e.nodeType))
            }

            function ec(e, t) {
                if (e.length != t.length) return !1;
                for (let n = 0; n < e.length; n++)
                    if (!e[n].type.eq(t[n].type)) return !1;
                return !0
            }

            function eh(e) {
                let t = e.nextSibling;
                return e.parentNode.removeChild(e), t
            }
            class eu {
                constructor(e, t) {
                    this.lock = t, this.index = 0, this.stack = [], this.changed = !1, this.top = e, this.preMatch = function(e, t) {
                        let n = t,
                            o = n.children.length,
                            i = e.childCount,
                            s = new Map,
                            r = [];
                        e: for (; i > 0;) {
                            let l;
                            for (;;)
                                if (o) {
                                    let e = n.children[o - 1];
                                    if (e instanceof Z) n = e, o = e.children.length;
                                    else {
                                        l = e, o--;
                                        break
                                    }
                                } else if (n == t) break e;
                            else o = n.parent.children.indexOf(n), n = n.parent;
                            let d = l.node;
                            if (d) {
                                if (d != e.child(i - 1)) break;
                                --i, s.set(l, i), r.push(l)
                            }
                        }
                        return {
                            index: i,
                            matched: s,
                            matches: r.reverse()
                        }
                    }(e.node.content, e)
                }
                destroyBetween(e, t) {
                    if (e != t) {
                        for (let n = e; n < t; n++) this.top.children[n].destroy();
                        this.top.children.splice(e, t - e), this.changed = !0
                    }
                }
                destroyRest() {
                    this.destroyBetween(this.index, this.top.children.length)
                }
                syncToMarks(e, t, n) {
                    let o = 0,
                        i = this.stack.length >> 1,
                        s = Math.min(i, e.length);
                    for (; o < s && (o == i - 1 ? this.top : this.stack[o + 1 << 1]).matchesMark(e[o]) && !1 !== e[o].type.spec.spanning;) o++;
                    for (; o < i;) this.destroyRest(), this.top.dirty = 0, this.index = this.stack.pop(), this.top = this.stack.pop(), i--;
                    for (; i < e.length;) {
                        this.stack.push(this.top, this.index + 1);
                        let o = -1;
                        for (let t = this.index; t < Math.min(this.index + 3, this.top.children.length); t++)
                            if (this.top.children[t].matchesMark(e[i])) {
                                o = t;
                                break
                            }
                        if (o > -1) o > this.index && (this.changed = !0, this.destroyBetween(this.index, o)), this.top = this.top.children[this.index];
                        else {
                            let o = Z.create(this.top, e[i], t, n);
                            this.top.children.splice(this.index, 0, o), this.top = o, this.changed = !0
                        }
                        this.index = 0, i++
                    }
                }
                findNodeMatch(e, t, n, o) {
                    let i = -1,
                        s;
                    if (o >= this.preMatch.index && (s = this.preMatch.matches[o - this.preMatch.index]).parent == this.top && s.matchesNode(e, t, n)) i = this.top.children.indexOf(s, this.index);
                    else
                        for (let o = this.index, s = Math.min(this.top.children.length, o + 5); o < s; o++) {
                            let s = this.top.children[o];
                            if (s.matchesNode(e, t, n) && !this.preMatch.matched.has(s)) {
                                i = o;
                                break
                            }
                        }
                    return !(i < 0) && (this.destroyBetween(this.index, i), this.index++, !0)
                }
                updateNodeAt(e, t, n, o, i) {
                    let s = this.top.children[o];
                    return 3 == s.dirty && s.dom == s.contentDOM && (s.dirty = 2), !!s.update(e, t, n, i) && (this.destroyBetween(this.index, o), this.index = o + 1, !0)
                }
                findIndexWithChild(e) {
                    for (;;) {
                        let t = e.parentNode;
                        if (!t) return -1;
                        if (t == this.top.contentDOM) {
                            let t = e.pmViewDesc;
                            if (t) {
                                for (let e = this.index; e < this.top.children.length; e++)
                                    if (this.top.children[e] == t) return e
                            }
                            return -1
                        }
                        e = t
                    }
                }
                updateNextNode(e, t, n, o, i) {
                    for (let s = this.index; s < this.top.children.length; s++) {
                        let r = this.top.children[s];
                        if (r instanceof ee) {
                            let l = this.preMatch.matched.get(r);
                            if (null != l && l != i) return !1;
                            let d = r.dom;
                            if (!(this.lock && (d == this.lock || 1 == d.nodeType && d.contains(this.lock.parentNode)) && !(e.isText && r.node && r.node.isText && r.nodeDOM.nodeValue == e.text && 3 != r.dirty && ec(t, r.outerDeco))) && r.update(e, t, n, o)) return this.destroyBetween(this.index, s), r.dom != d && (this.changed = !0), this.index++, !0;
                            break
                        }
                    }
                    return !1
                }
                addNode(e, t, n, o, i) {
                    this.top.children.splice(this.index++, 0, ee.create(this.top, e, t, n, o, i)), this.changed = !0
                }
                placeWidget(e, t, n) {
                    let o = this.index < this.top.children.length ? this.top.children[this.index] : null;
                    if (o && o.matchesWidget(e) && (e == o.widget || !o.widget.type.toDOM.parentNode)) this.index++;
                    else {
                        let o = new J(this.top, e, t, n);
                        this.top.children.splice(this.index++, 0, o), this.changed = !0
                    }
                }
                addTextblockHacks() {
                    let e = this.top.children[this.index - 1],
                        t = this.top;
                    for (; e instanceof Z;) e = (t = e).children[t.children.length - 1];
                    (!e || !(e instanceof en) || /\n$/.test(e.node.text)) && ((b || g) && e && "false" == e.dom.contentEditable && this.addHackNode("IMG", t), this.addHackNode("BR", this.top))
                }
                addHackNode(e, t) {
                    if (t == this.top && this.index < t.children.length && t.children[this.index].matchesHack(e)) this.index++;
                    else {
                        let n = document.createElement(e);
                        "IMG" == e && (n.className = "ProseMirror-separator", n.alt = ""), "BR" == e && (n.className = "ProseMirror-trailingBreak");
                        let o = new eo(this.top, [], n, null);
                        t != this.top ? t.children.push(o) : t.children.splice(this.index++, 0, o), this.changed = !0
                    }
                }
            }

            function ef(e, t) {
                return e.type.side - t.type.side
            }

            function ep(e, t, n, o, i) {
                let s = [];
                for (let r = 0, l = 0; r < e.length; r++) {
                    let d = e[r],
                        a = l,
                        c = l += d.size;
                    a >= n || c <= t ? s.push(d) : (a < t && s.push(d.slice(0, t - a, o)), i && (s.push(i), i = void 0), c > n && s.push(d.slice(n - a, d.size, o)))
                }
                return s
            }

            function em(e, t = null) {
                let n = e.domSelection(),
                    i = e.state.doc;
                if (!n.focusNode) return null;
                let s = e.docView.nearestDesc(n.focusNode),
                    r = s && 0 == s.size,
                    l = e.docView.posFromDOM(n.focusNode, n.focusOffset, 1);
                if (l < 0) return null;
                let d = i.resolve(l),
                    a, c;
                if (P(n)) {
                    for (a = d; s && !s.node;) s = s.parent;
                    let e = s.node;
                    if (s && e.isAtom && o.qv.isSelectable(e) && s.parent && !(e.isInline && function(e, t, n) {
                            for (let o = 0 == t, i = t == E(e); o || i;) {
                                if (e == n) return !0;
                                let t = O(e);
                                if (!(e = e.parentNode)) return !1;
                                o = o && 0 == t, i = i && t == E(e)
                            }
                        }(n.focusNode, n.focusOffset, s.dom))) {
                        let e = s.posBefore;
                        c = new o.qv(l == e ? d : i.resolve(e))
                    }
                } else {
                    let t = e.docView.posFromDOM(n.anchorNode, n.anchorOffset, 1);
                    if (t < 0) return null;
                    a = i.resolve(t)
                }
                if (!c) {
                    let n = "pointer" == t || e.state.selection.head < d.pos && !r ? 1 : -1;
                    c = eO(e, a, d, n)
                }
                return c
            }

            function eg(e) {
                return e.editable ? e.hasFocus() : eM(e) && document.activeElement && document.activeElement.contains(e.dom)
            }

            function ey(e, t = !1) {
                let n = e.state.selection;
                if (eN(e, n), eg(e)) {
                    var i;
                    if (!t && e.input.mouseDown && e.input.mouseDown.allowDefault && g) {
                        let t = e.domSelection(),
                            n = e.domObserver.currentSelection;
                        if (t.anchorNode && n.anchorNode && k(t.anchorNode, t.anchorOffset, n.anchorNode, n.anchorOffset)) {
                            e.input.mouseDown.delayedSelectionSync = !0, e.domObserver.setCurSelection();
                            return
                        }
                    }
                    if (e.domObserver.disconnectSelection(), e.cursorWrapper) {
                        let t, n, o, i;
                        t = e.domSelection(), n = document.createRange(), (i = "IMG" == (o = e.cursorWrapper.dom).nodeName) ? n.setEnd(o.parentNode, O(o) + 1) : n.setEnd(o, 0), n.collapse(!1), t.removeAllRanges(), t.addRange(n), !i && !e.state.selection.visible && u && f <= 11 && (o.disabled = !0, o.disabled = !1)
                    } else {
                        let s, r, l, d, {
                                anchor: a,
                                head: c
                            } = n,
                            h, u;
                        !eb || n instanceof o.Bs || (n.$from.parent.inlineContent || (h = ev(e, n.from)), n.empty || n.$from.parent.inlineContent || (u = ev(e, n.to))), e.docView.setSelection(a, c, e.root, t), eb && (h && eD(h), u && eD(u)), n.visible ? e.dom.classList.remove("ProseMirror-hideselection") : (e.dom.classList.add("ProseMirror-hideselection"), "onselectionchange" in document && ((s = (i = e).dom.ownerDocument).removeEventListener("selectionchange", i.input.hideSelectionGuard), l = (r = i.domSelection()).anchorNode, d = r.anchorOffset, s.addEventListener("selectionchange", i.input.hideSelectionGuard = () => {
                            (r.anchorNode != l || r.anchorOffset != d) && (s.removeEventListener("selectionchange", i.input.hideSelectionGuard), setTimeout(() => {
                                (!eg(i) || i.state.selection.visible) && i.dom.classList.remove("ProseMirror-hideselection")
                            }, 20))
                        })))
                    }
                    e.domObserver.setCurSelection(), e.domObserver.connectSelection()
                }
            }
            let eb = b || g && y < 63;

            function ev(e, t) {
                let {
                    node: n,
                    offset: o
                } = e.docView.domFromPos(t, 0), i = o < n.childNodes.length ? n.childNodes[o] : null, s = o ? n.childNodes[o - 1] : null;
                if (b && i && "false" == i.contentEditable) return ew(i);
                if ((!i || "false" == i.contentEditable) && (!s || "false" == s.contentEditable)) {
                    if (i) return ew(i);
                    if (s) return ew(s)
                }
            }

            function ew(e) {
                return e.contentEditable = "true", b && e.draggable && (e.draggable = !1, e.wasDraggable = !0), e
            }

            function eD(e) {
                e.contentEditable = "false", e.wasDraggable && (e.draggable = !0, e.wasDraggable = null)
            }

            function eN(e, t) {
                if (t instanceof o.qv) {
                    let n = e.docView.descAt(t.from);
                    n != e.lastSelectedViewDesc && (eS(e), n && n.selectNode(), e.lastSelectedViewDesc = n)
                } else eS(e)
            }

            function eS(e) {
                e.lastSelectedViewDesc && (e.lastSelectedViewDesc.parent && e.lastSelectedViewDesc.deselectNode(), e.lastSelectedViewDesc = void 0)
            }

            function eO(e, t, n, i) {
                return e.someProp("createSelectionBetween", o => o(e, t, n)) || o.Bs.between(t, n, i)
            }

            function eC(e) {
                return (!e.editable || e.root.activeElement == e.dom) && eM(e)
            }

            function eM(e) {
                let t = e.domSelection();
                if (!t.anchorNode) return !1;
                try {
                    return e.dom.contains(3 == t.anchorNode.nodeType ? t.anchorNode.parentNode : t.anchorNode) && (e.editable || e.dom.contains(3 == t.focusNode.nodeType ? t.focusNode.parentNode : t.focusNode))
                } catch (e) {
                    return !1
                }
            }

            function ex(e, t) {
                let {
                    $anchor: n,
                    $head: i
                } = e.selection, s = t > 0 ? n.max(i) : n.min(i), r = s.parent.inlineContent ? s.depth ? e.doc.resolve(t > 0 ? s.after() : s.before()) : null : s;
                return r && o.Y1.findFrom(r, t)
            }

            function ek(e, t) {
                return e.dispatch(e.state.tr.setSelection(t).scrollIntoView()), !0
            }

            function eT(e, t, n) {
                let i = e.state.selection;
                if (i instanceof o.Bs) {
                    if (!i.empty || n.indexOf("s") > -1) return !1;
                    if (e.endOfTextblock(t > 0 ? "right" : "left")) {
                        let n = ex(e.state, t);
                        return !!n && n instanceof o.qv && ek(e, n)
                    }
                    if (!(w && n.indexOf("m") > -1)) {
                        let n = i.$head,
                            s = n.textOffset ? null : t < 0 ? n.nodeBefore : n.nodeAfter,
                            r;
                        if (!s || s.isText) return !1;
                        let l = t < 0 ? n.pos - s.nodeSize : n.pos;
                        return !!(s.isAtom || (r = e.docView.descAt(l)) && !r.contentDOM) && (o.qv.isSelectable(s) ? ek(e, new o.qv(t < 0 ? e.state.doc.resolve(n.pos - s.nodeSize) : n)) : !!N && ek(e, new o.Bs(e.state.doc.resolve(t < 0 ? l : l + s.nodeSize))))
                    }
                } else {
                    if (i instanceof o.qv && i.node.isInline) return ek(e, new o.Bs(t > 0 ? i.$to : i.$from));
                    let n = ex(e.state, t);
                    return !!n && ek(e, n)
                }
            }

            function eA(e) {
                return 3 == e.nodeType ? e.nodeValue.length : e.childNodes.length
            }

            function eE(e) {
                let t = e.pmViewDesc;
                return t && 0 == t.size && (e.nextSibling || "BR" != e.nodeName)
            }

            function eP(e) {
                let t = e.domSelection(),
                    n = t.focusNode,
                    o = t.focusOffset;
                if (!n) return;
                let i, s, r = !1;
                for (p && 1 == n.nodeType && o < eA(n) && eE(n.childNodes[o]) && (r = !0);;)
                    if (o > 0) {
                        if (1 != n.nodeType) break; {
                            let e = n.childNodes[o - 1];
                            if (eE(e)) i = n, s = --o;
                            else if (3 == e.nodeType) o = (n = e).nodeValue.length;
                            else break
                        }
                    } else if (eB(n)) break;
                else {
                    let t = n.previousSibling;
                    for (; t && eE(t);) i = n.parentNode, s = O(t), t = t.previousSibling;
                    if (t) o = eA(n = t);
                    else {
                        if ((n = n.parentNode) == e.dom) break;
                        o = 0
                    }
                }
                r ? eR(e, t, n, o) : i && eR(e, t, i, s)
            }

            function eV(e) {
                let t, n, o = e.domSelection(),
                    i = o.focusNode,
                    s = o.focusOffset;
                if (!i) return;
                let r = eA(i);
                for (;;)
                    if (s < r) {
                        if (1 != i.nodeType) break;
                        if (eE(i.childNodes[s])) t = i, n = ++s;
                        else break
                    } else if (eB(i)) break;
                else {
                    let o = i.nextSibling;
                    for (; o && eE(o);) t = o.parentNode, n = O(o) + 1, o = o.nextSibling;
                    if (o) s = 0, r = eA(i = o);
                    else {
                        if ((i = i.parentNode) == e.dom) break;
                        s = r = 0
                    }
                }
                t && eR(e, o, t, n)
            }

            function eB(e) {
                let t = e.pmViewDesc;
                return t && t.node && t.node.isBlock
            }

            function eR(e, t, n, o) {
                if (P(t)) {
                    let e = document.createRange();
                    e.setEnd(n, o), e.setStart(n, o), t.removeAllRanges(), t.addRange(e)
                } else t.extend && t.extend(n, o);
                e.domObserver.setCurSelection();
                let {
                    state: i
                } = e;
                setTimeout(() => {
                    e.state == i && ey(e)
                }, 50)
            }

            function ez(e, t, n) {
                let i = e.state.selection;
                if (i instanceof o.Bs && !i.empty || n.indexOf("s") > -1 || w && n.indexOf("m") > -1) return !1;
                let {
                    $from: s,
                    $to: r
                } = i;
                if (!s.parent.inlineContent || e.endOfTextblock(t < 0 ? "up" : "down")) {
                    let n = ex(e.state, t);
                    if (n && n instanceof o.qv) return ek(e, n)
                }
                if (!s.parent.inlineContent) {
                    let n = t < 0 ? s : r,
                        l = i instanceof o.C1 ? o.Y1.near(n, t) : o.Y1.findFrom(n, t);
                    return !!l && ek(e, l)
                }
                return !1
            }

            function eI(e, t) {
                if (!(e.state.selection instanceof o.Bs)) return !0;
                let {
                    $head: n,
                    $anchor: i,
                    empty: s
                } = e.state.selection;
                if (!n.sameParent(i)) return !0;
                if (!s) return !1;
                if (e.endOfTextblock(t > 0 ? "forward" : "backward")) return !0;
                let r = !n.textOffset && (t < 0 ? n.nodeBefore : n.nodeAfter);
                if (r && !r.isText) {
                    let o = e.state.tr;
                    return t < 0 ? o.delete(n.pos - r.nodeSize, n.pos) : o.delete(n.pos, n.pos + r.nodeSize), e.dispatch(o), !0
                }
                return !1
            }

            function eq(e, t, n) {
                e.domObserver.stop(), t.contentEditable = n, e.domObserver.start()
            }

            function eL(e, t) {
                let n = [],
                    {
                        content: o,
                        openStart: s,
                        openEnd: r
                    } = t;
                for (; s > 1 && r > 1 && 1 == o.childCount && 1 == o.firstChild.childCount;) {
                    s--, r--;
                    let e = o.firstChild;
                    n.push(e.type.name, e.attrs != e.type.defaultAttrs ? e.attrs : null), o = e.content
                }
                let l = e.someProp("clipboardSerializer") || i.PW.fromSchema(e.state.schema),
                    d = eU(),
                    a = d.createElement("div");
                a.appendChild(l.serializeFragment(o, {
                    document: d
                }));
                let c = a.firstChild,
                    h, u = 0;
                for (; c && 1 == c.nodeType && (h = e_[c.nodeName.toLowerCase()]);) {
                    for (let e = h.length - 1; e >= 0; e--) {
                        let t = d.createElement(h[e]);
                        for (; a.firstChild;) t.appendChild(a.firstChild);
                        a.appendChild(t), u++
                    }
                    c = a.firstChild
                }
                c && 1 == c.nodeType && c.setAttribute("data-pm-slice", `${s} ${r}${u?` -${u}`:""} ${JSON.stringify(n)}`);
                let f = e.someProp("clipboardTextSerializer", e => e(t)) || t.content.textBetween(0, t.content.size, "\n\n");
                return {
                    dom: a,
                    text: f
                }
            }

            function eF(e, t, n, o, s) {
                let r, l, d = s.parent.type.spec.code;
                if (!n && !t) return null;
                let a = t && (o || d || !n);
                if (a) {
                    if (e.someProp("transformPastedText", e => {
                            t = e(t, d || o)
                        }), d) return t ? new i.p2(i.HY.from(e.state.schema.text(t.replace(/\r\n?/g, "\n"))), 0, 0) : i.p2.empty;
                    let n = e.someProp("clipboardTextParser", e => e(t, s, o));
                    if (n) l = n;
                    else {
                        let n = s.marks(),
                            {
                                schema: o
                            } = e.state,
                            l = i.PW.fromSchema(o);
                        r = document.createElement("div"), t.split(/(?:\r\n?|\n)+/).forEach(e => {
                            let t = r.appendChild(document.createElement("p"));
                            e && t.appendChild(l.serializeNode(o.text(e, n)))
                        })
                    }
                } else e.someProp("transformPastedHTML", e => {
                    n = e(n)
                }), r = function(e) {
                    let t = /^(\s*<meta [^>]*>)*/.exec(e);
                    t && (e = e.slice(t[0].length));
                    let n = eU().createElement("div"),
                        o = /<([a-z][^>\s]+)/i.exec(e),
                        i;
                    if ((i = o && e_[o[1].toLowerCase()]) && (e = i.map(e => "<" + e + ">").join("") + e + i.map(e => "</" + e + ">").reverse().join("")), n.innerHTML = e, i)
                        for (let e = 0; e < i.length; e++) n = n.querySelector(i[e]) || n;
                    return n
                }(n), N && function(e) {
                    let t = e.querySelectorAll(g ? "span:not([class]):not([style])" : "span.Apple-converted-space");
                    for (let n = 0; n < t.length; n++) {
                        let o = t[n];
                        1 == o.childNodes.length && "\xa0" == o.textContent && o.parentNode && o.parentNode.replaceChild(e.ownerDocument.createTextNode(" "), o)
                    }
                }(r);
                let c = r && r.querySelector("[data-pm-slice]"),
                    h = c && /^(\d+) (\d+)(?: -(\d+))? (.*)/.exec(c.getAttribute("data-pm-slice") || "");
                if (h && h[3])
                    for (let e = +h[3]; e > 0 && r.firstChild; e--) r = r.firstChild;
                if (l || (l = (e.someProp("clipboardParser") || e.someProp("domParser") || i.aw.fromSchema(e.state.schema)).parseSlice(r, {
                        preserveWhitespace: !!(a || h),
                        context: s,
                        ruleFromNode: e => "BR" != e.nodeName || e.nextSibling || !e.parentNode || eK.test(e.parentNode.nodeName) ? null : {
                            ignore: !0
                        }
                    })), h) l = function(e, t) {
                    if (!e.size) return e;
                    let n = e.content.firstChild.type.schema,
                        o;
                    try {
                        o = JSON.parse(t)
                    } catch (t) {
                        return e
                    }
                    let {
                        content: s,
                        openStart: r,
                        openEnd: l
                    } = e;
                    for (let e = o.length - 2; e >= 0; e -= 2) {
                        let t = n.nodes[o[e]];
                        if (!t || t.hasRequiredAttrs()) break;
                        s = i.HY.from(t.create(o[e + 1], s)), r++, l++
                    }
                    return new i.p2(s, r, l)
                }(eH(l, +h[1], +h[2]), h[4]);
                else if ((l = i.p2.maxOpen(function(e, t) {
                        if (e.childCount < 2) return e;
                        for (let n = t.depth; n >= 0; n--) {
                            let o = t.node(n).contentMatchAt(t.index(n)),
                                s, r = [];
                            if (e.forEach(e => {
                                    if (!r) return;
                                    let t = o.findWrapping(e.type),
                                        n;
                                    if (!t) return r = null;
                                    if (n = r.length && s.length && function e(t, n, o, s, r) {
                                            if (r < t.length && r < n.length && t[r] == n[r]) {
                                                let l = e(t, n, o, s.lastChild, r + 1);
                                                if (l) return s.copy(s.content.replaceChild(s.childCount - 1, l));
                                                if (s.contentMatchAt(s.childCount).matchType(r == t.length - 1 ? o.type : t[r + 1])) return s.copy(s.content.append(i.HY.from(eW(o, t, r + 1))))
                                            }
                                        }(t, s, e, r[r.length - 1], 0)) r[r.length - 1] = n;
                                    else {
                                        r.length && (r[r.length - 1] = function e(t, n) {
                                            if (0 == n) return t;
                                            let o = t.content.replaceChild(t.childCount - 1, e(t.lastChild, n - 1)),
                                                s = t.contentMatchAt(t.childCount).fillBefore(i.HY.empty, !0);
                                            return t.copy(o.append(s))
                                        }(r[r.length - 1], s.length));
                                        let n = eW(e, t);
                                        r.push(n), o = o.matchType(n.type), s = t
                                    }
                                }), r) return i.HY.from(r)
                        }
                        return e
                    }(l.content, s), !0)).openStart || l.openEnd) {
                    let e = 0,
                        t = 0;
                    for (let t = l.content.firstChild; e < l.openStart && !t.type.spec.isolating; e++, t = t.firstChild);
                    for (let e = l.content.lastChild; t < l.openEnd && !e.type.spec.isolating; t++, e = e.lastChild);
                    l = eH(l, e, t)
                }
                return e.someProp("transformPasted", e => {
                    l = e(l)
                }), l
            }
            let eK = /^(a|abbr|acronym|b|cite|code|del|em|i|ins|kbd|label|output|q|ruby|s|samp|span|strong|sub|sup|time|u|tt|var)$/i;

            function eW(e, t, n = 0) {
                for (let o = t.length - 1; o >= n; o--) e = t[o].create(null, i.HY.from(e));
                return e
            }

            function e$(e, t, n, o, s, r) {
                let l = t < 0 ? e.firstChild : e.lastChild,
                    d = l.content;
                return s < o - 1 && (d = e$(d, t, n, o, s + 1, r)), s >= n && (d = t < 0 ? l.contentMatchAt(0).fillBefore(d, e.childCount > 1 || r <= s).append(d) : d.append(l.contentMatchAt(l.childCount).fillBefore(i.HY.empty, !0))), e.replaceChild(t < 0 ? 0 : e.childCount - 1, l.copy(d))
            }

            function eH(e, t, n) {
                return t < e.openStart && (e = new i.p2(e$(e.content, -1, t, e.openStart, 0, e.openEnd), t, e.openEnd)), n < e.openEnd && (e = new i.p2(e$(e.content, 1, n, e.openEnd, 0, 0), e.openStart, n)), e
            }
            let e_ = {
                    thead: ["table"],
                    tbody: ["table"],
                    tfoot: ["table"],
                    caption: ["table"],
                    colgroup: ["table"],
                    col: ["table", "colgroup"],
                    tr: ["table", "tbody"],
                    td: ["table", "tbody", "tr"],
                    th: ["table", "tbody", "tr"]
                },
                eY = null;

            function eU() {
                return eY || (eY = document.implementation.createHTMLDocument("title"))
            }
            let eG = {},
                ej = {};
            class eX {
                constructor() {
                    this.shiftKey = !1, this.mouseDown = null, this.lastKeyCode = null, this.lastKeyCodeTime = 0, this.lastClick = {
                        time: 0,
                        x: 0,
                        y: 0,
                        type: ""
                    }, this.lastSelectionOrigin = null, this.lastSelectionTime = 0, this.lastIOSEnter = 0, this.lastIOSEnterFallbackTimeout = -1, this.lastAndroidDelete = 0, this.composing = !1, this.composingTimeout = -1, this.compositionNodes = [], this.compositionEndedAt = -2e8, this.domChangeCount = 0, this.eventHandlers = Object.create(null), this.hideSelectionGuard = null
                }
            }

            function eJ(e, t) {
                e.input.lastSelectionOrigin = t, e.input.lastSelectionTime = Date.now()
            }

            function eQ(e) {
                e.someProp("handleDOMEvents", t => {
                    for (let n in t) e.input.eventHandlers[n] || e.dom.addEventListener(n, e.input.eventHandlers[n] = t => eZ(e, t))
                })
            }

            function eZ(e, t) {
                return e.someProp("handleDOMEvents", n => {
                    let o = n[t.type];
                    return !!o && (o(e, t) || t.defaultPrevented)
                })
            }

            function e0(e) {
                return {
                    left: e.clientX,
                    top: e.clientY
                }
            }

            function e1(e, t, n, o, i) {
                if (-1 == o) return !1;
                let s = e.state.doc.resolve(o);
                for (let o = s.depth + 1; o > 0; o--)
                    if (e.someProp(t, t => o > s.depth ? t(e, n, s.nodeAfter, s.before(o), i, !0) : t(e, n, s.node(o), s.before(o), i, !1))) return !0;
                return !1
            }

            function e2(e, t, n) {
                e.focused || e.focus();
                let o = e.state.tr.setSelection(t);
                "pointer" == n && o.setMeta("pointer", !0), e.dispatch(o)
            }

            function e3(e, t, n, o) {
                return e1(e, "handleDoubleClickOn", t, n, o) || e.someProp("handleDoubleClick", n => n(e, t, o))
            }

            function e5(e, t, n, i) {
                return e1(e, "handleTripleClickOn", t, n, i) || e.someProp("handleTripleClick", n => n(e, t, i)) || function(e, t, n) {
                    if (0 != n.button) return !1;
                    let i = e.state.doc;
                    if (-1 == t) return !!i.inlineContent && (e2(e, o.Bs.create(i, 0, i.content.size), "pointer"), !0);
                    let s = i.resolve(t);
                    for (let t = s.depth + 1; t > 0; t--) {
                        let n = t > s.depth ? s.nodeAfter : s.node(t),
                            r = s.before(t);
                        if (n.inlineContent) e2(e, o.Bs.create(i, r + 1, r + 1 + n.content.size), "pointer");
                        else {
                            if (!o.qv.isSelectable(n)) continue;
                            e2(e, o.qv.create(i, r), "pointer")
                        }
                        return !0
                    }
                }(e, n, i)
            }
            ej.keydown = (e, t) => {
                if (e.input.shiftKey = 16 == t.keyCode || t.shiftKey, !e7(e, t) && (e.input.lastKeyCode = t.keyCode, e.input.lastKeyCodeTime = Date.now(), !D || !g || 13 != t.keyCode)) {
                    if (229 != t.keyCode && e.domObserver.forceFlush(), !v || 13 != t.keyCode || t.ctrlKey || t.altKey || t.metaKey) e.someProp("handleKeyDown", n => n(e, t)) || function(e, t) {
                        let n;
                        let o = t.keyCode,
                            i = (n = "", t.ctrlKey && (n += "c"), t.metaKey && (n += "m"), t.altKey && (n += "a"), t.shiftKey && (n += "s"), n);
                        if (8 == o || w && 72 == o && "c" == i) return eI(e, -1) || eP(e);
                        if (46 == o || w && 68 == o && "c" == i) return eI(e, 1) || eV(e);
                        if (13 == o || 27 == o) return !0;
                        if (37 == o || w && 66 == o && "c" == i) return eT(e, -1, i) || eP(e);
                        if (39 == o || w && 70 == o && "c" == i) return eT(e, 1, i) || eV(e);
                        if (38 == o || w && 80 == o && "c" == i) return ez(e, -1, i) || eP(e);
                        if (40 == o || w && 78 == o && "c" == i) return function(e) {
                            if (!b || e.state.selection.$head.parentOffset > 0) return !1;
                            let {
                                focusNode: t,
                                focusOffset: n
                            } = e.domSelection();
                            if (t && 1 == t.nodeType && 0 == n && t.firstChild && "false" == t.firstChild.contentEditable) {
                                let n = t.firstChild;
                                eq(e, n, "true"), setTimeout(() => eq(e, n, "false"), 20)
                            }
                            return !1
                        }(e) || ez(e, 1, i) || eV(e);
                        else if (i == (w ? "m" : "c") && (66 == o || 73 == o || 89 == o || 90 == o)) return !0;
                        return !1
                    }(e, t) ? t.preventDefault() : eJ(e, "key");
                    else {
                        let t = Date.now();
                        e.input.lastIOSEnter = t, e.input.lastIOSEnterFallbackTimeout = setTimeout(() => {
                            e.input.lastIOSEnter == t && (e.someProp("handleKeyDown", t => t(e, V(13, "Enter"))), e.input.lastIOSEnter = 0)
                        }, 200)
                    }
                }
            }, ej.keyup = (e, t) => {
                16 == t.keyCode && (e.input.shiftKey = !1)
            }, ej.keypress = (e, t) => {
                if (e7(e, t) || !t.charCode || t.ctrlKey && !t.altKey || w && t.metaKey) return;
                if (e.someProp("handleKeyPress", n => n(e, t))) {
                    t.preventDefault();
                    return
                }
                let n = e.state.selection;
                if (!(n instanceof o.Bs) || !n.$from.sameParent(n.$to)) {
                    let o = String.fromCharCode(t.charCode);
                    e.someProp("handleTextInput", t => t(e, n.$from.pos, n.$to.pos, o)) || e.dispatch(e.state.tr.insertText(o).scrollIntoView()), t.preventDefault()
                }
            };
            let e8 = w ? "metaKey" : "ctrlKey";
            eG.mousedown = (e, t) => {
                var n;
                let o, i;
                e.input.shiftKey = t.shiftKey;
                let s = tt(e),
                    r = Date.now(),
                    l = "singleClick";
                r - e.input.lastClick.time < 500 && (o = (n = e.input.lastClick).x - t.clientX) * o + (i = n.y - t.clientY) * i < 100 && !t[e8] && ("singleClick" == e.input.lastClick.type ? l = "doubleClick" : "doubleClick" == e.input.lastClick.type && (l = "tripleClick")), e.input.lastClick = {
                    time: r,
                    x: t.clientX,
                    y: t.clientY,
                    type: l
                };
                let d = e.posAtCoords(e0(t));
                d && ("singleClick" == l ? (e.input.mouseDown && e.input.mouseDown.done(), e.input.mouseDown = new e6(e, d, t, !!s)) : ("doubleClick" == l ? e3 : e5)(e, d.pos, d.inside, t) ? t.preventDefault() : eJ(e, "pointer"))
            };
            class e6 {
                constructor(e, t, n, i) {
                    let s, r;
                    if (this.view = e, this.pos = t, this.event = n, this.flushed = i, this.delayedSelectionSync = !1, this.mightDrag = null, this.startDoc = e.state.doc, this.selectNode = !!n[e8], this.allowDefault = n.shiftKey, t.inside > -1) s = e.state.doc.nodeAt(t.inside), r = t.inside;
                    else {
                        let n = e.state.doc.resolve(t.pos);
                        s = n.parent, r = n.depth ? n.before() : 0
                    }
                    let l = i ? null : n.target,
                        d = l ? e.docView.nearestDesc(l, !0) : null;
                    this.target = d ? d.dom : null;
                    let {
                        selection: a
                    } = e.state;
                    (0 == n.button && s.type.spec.draggable && !1 !== s.type.spec.selectable || a instanceof o.qv && a.from <= r && a.to > r) && (this.mightDrag = {
                        node: s,
                        pos: r,
                        addAttr: !!(this.target && !this.target.draggable),
                        setUneditable: !!(this.target && p && !this.target.hasAttribute("contentEditable"))
                    }), this.target && this.mightDrag && (this.mightDrag.addAttr || this.mightDrag.setUneditable) && (this.view.domObserver.stop(), this.mightDrag.addAttr && (this.target.draggable = !0), this.mightDrag.setUneditable && setTimeout(() => {
                        this.view.input.mouseDown == this && this.target.setAttribute("contentEditable", "false")
                    }, 20), this.view.domObserver.start()), e.root.addEventListener("mouseup", this.up = this.up.bind(this)), e.root.addEventListener("mousemove", this.move = this.move.bind(this)), eJ(e, "pointer")
                }
                done() {
                    this.view.root.removeEventListener("mouseup", this.up), this.view.root.removeEventListener("mousemove", this.move), this.mightDrag && this.target && (this.view.domObserver.stop(), this.mightDrag.addAttr && this.target.removeAttribute("draggable"), this.mightDrag.setUneditable && this.target.removeAttribute("contentEditable"), this.view.domObserver.start()), this.delayedSelectionSync && setTimeout(() => ey(this.view)), this.view.input.mouseDown = null
                }
                up(e) {
                    if (this.done(), !this.view.dom.contains(e.target)) return;
                    let t = this.pos;
                    if (this.view.state.doc != this.startDoc && (t = this.view.posAtCoords(e0(e))), this.allowDefault || !t) eJ(this.view, "pointer");
                    else {
                        var n, i, s, r;
                        (n = this.view, i = t.pos, s = t.inside, r = this.selectNode, e1(n, "handleClickOn", i, s, e) || n.someProp("handleClick", t => t(n, i, e)) || (r ? function(e, t) {
                            if (-1 == t) return !1;
                            let n = e.state.selection,
                                i, s;
                            n instanceof o.qv && (i = n.node);
                            let r = e.state.doc.resolve(t);
                            for (let e = r.depth + 1; e > 0; e--) {
                                let t = e > r.depth ? r.nodeAfter : r.node(e);
                                if (o.qv.isSelectable(t)) {
                                    s = i && n.$from.depth > 0 && e >= n.$from.depth && r.before(n.$from.depth + 1) == n.$from.pos ? r.before(n.$from.depth) : r.before(e);
                                    break
                                }
                            }
                            return null != s && (e2(e, o.qv.create(e.state.doc, s), "pointer"), !0)
                        }(n, s) : function(e, t) {
                            if (-1 == t) return !1;
                            let n = e.state.doc.resolve(t),
                                i = n.nodeAfter;
                            return !!(i && i.isAtom && o.qv.isSelectable(i)) && (e2(e, new o.qv(n), "pointer"), !0)
                        }(n, s))) ? e.preventDefault(): 0 == e.button && (this.flushed || b && this.mightDrag && !this.mightDrag.node.isAtom || g && !(this.view.state.selection instanceof o.Bs) && 2 >= Math.min(Math.abs(t.pos - this.view.state.selection.from), Math.abs(t.pos - this.view.state.selection.to))) ? (e2(this.view, o.Y1.near(this.view.state.doc.resolve(t.pos)), "pointer"), e.preventDefault()) : eJ(this.view, "pointer")
                    }
                }
                move(e) {
                    !this.allowDefault && (Math.abs(this.event.x - e.clientX) > 4 || Math.abs(this.event.y - e.clientY) > 4) && (this.allowDefault = !0), eJ(this.view, "pointer"), 0 == e.buttons && this.done()
                }
            }

            function e7(e, t) {
                return !!e.composing || !!(b && 500 > Math.abs(t.timeStamp - e.input.compositionEndedAt)) && (e.input.compositionEndedAt = -2e8, !0)
            }
            eG.touchdown = e => {
                tt(e), eJ(e, "pointer")
            }, eG.contextmenu = e => tt(e);
            let e9 = D ? 5e3 : -1;

            function e4(e, t) {
                clearTimeout(e.input.composingTimeout), t > -1 && (e.input.composingTimeout = setTimeout(() => tt(e), t))
            }

            function te(e) {
                let t;
                for (e.composing && (e.input.composing = !1, e.input.compositionEndedAt = ((t = document.createEvent("Event")).initEvent("event", !0, !0), t.timeStamp)); e.input.compositionNodes.length > 0;) e.input.compositionNodes.pop().markParentsDirty()
            }

            function tt(e, t = !1) {
                if (!D || !(e.domObserver.flushingSoon >= 0)) {
                    if (e.domObserver.forceFlush(), te(e), t || e.docView && e.docView.dirty) {
                        let t = em(e);
                        return t && !t.eq(e.state.selection) ? e.dispatch(e.state.tr.setSelection(t)) : e.updateState(e.state), !0
                    }
                    return !1
                }
            }
            ej.compositionstart = ej.compositionupdate = e => {
                if (!e.composing) {
                    e.domObserver.flush();
                    let {
                        state: t
                    } = e, n = t.selection.$from;
                    if (t.selection.empty && (t.storedMarks || !n.textOffset && n.parentOffset && n.nodeBefore.marks.some(e => !1 === e.type.spec.inclusive))) e.markCursor = e.state.storedMarks || n.marks(), tt(e, !0), e.markCursor = null;
                    else if (tt(e), p && t.selection.empty && n.parentOffset && !n.textOffset && n.nodeBefore.marks.length) {
                        let t = e.domSelection();
                        for (let e = t.focusNode, n = t.focusOffset; e && 1 == e.nodeType && 0 != n;) {
                            let o = n < 0 ? e.lastChild : e.childNodes[n - 1];
                            if (!o) break;
                            if (3 == o.nodeType) {
                                t.collapse(o, o.nodeValue.length);
                                break
                            }
                            e = o, n = -1
                        }
                    }
                    e.input.composing = !0
                }
                e4(e, e9)
            }, ej.compositionend = (e, t) => {
                e.composing && (e.input.composing = !1, e.input.compositionEndedAt = t.timeStamp, e4(e, 20))
            };
            let tn = u && f < 15 || v && S < 604;

            function to(e, t, n, o) {
                let s = eF(e, t, n, e.input.shiftKey, e.state.selection.$from);
                if (e.someProp("handlePaste", t => t(e, o, s || i.p2.empty))) return !0;
                if (!s) return !1;
                let r = 0 == s.openStart && 0 == s.openEnd && 1 == s.content.childCount ? s.content.firstChild : null,
                    l = r ? e.state.tr.replaceSelectionWith(r, e.input.shiftKey) : e.state.tr.replaceSelection(s);
                return e.dispatch(l.scrollIntoView().setMeta("paste", !0).setMeta("uiEvent", "paste")), !0
            }
            eG.copy = ej.cut = (e, t) => {
                let n = e.state.selection,
                    o = "cut" == t.type;
                if (n.empty) return;
                let i = tn ? null : t.clipboardData,
                    {
                        dom: s,
                        text: r
                    } = eL(e, n.content());
                i ? (t.preventDefault(), i.clearData(), i.setData("text/html", s.innerHTML), i.setData("text/plain", r)) : function(e, t) {
                    if (!e.dom.parentNode) return;
                    let n = e.dom.parentNode.appendChild(document.createElement("div"));
                    n.appendChild(t), n.style.cssText = "position: fixed; left: -10000px; top: 10px";
                    let o = getSelection(),
                        i = document.createRange();
                    i.selectNodeContents(t), e.dom.blur(), o.removeAllRanges(), o.addRange(i), setTimeout(() => {
                        n.parentNode && n.parentNode.removeChild(n), e.focus()
                    }, 50)
                }(e, s), o && e.dispatch(e.state.tr.deleteSelection().scrollIntoView().setMeta("uiEvent", "cut"))
            }, ej.paste = (e, t) => {
                if (e.composing && !D) return;
                let n = tn ? null : t.clipboardData;
                n && to(e, n.getData("text/plain"), n.getData("text/html"), t) ? t.preventDefault() : function(e, t) {
                    if (!e.dom.parentNode) return;
                    let n = e.input.shiftKey || e.state.selection.$from.parent.type.spec.code,
                        o = e.dom.parentNode.appendChild(document.createElement(n ? "textarea" : "div"));
                    n || (o.contentEditable = "true"), o.style.cssText = "position: fixed; left: -10000px; top: 10px", o.focus(), setTimeout(() => {
                        e.focus(), o.parentNode && o.parentNode.removeChild(o), n ? to(e, o.value, null, t) : to(e, o.textContent, o.innerHTML, t)
                    }, 50)
                }(e, t)
            };
            class ti {
                constructor(e, t) {
                    this.slice = e, this.move = t
                }
            }
            let ts = w ? "altKey" : "ctrlKey";
            for (let e in eG.dragstart = (e, t) => {
                    let n = t,
                        i = e.input.mouseDown;
                    if (i && i.done(), !n.dataTransfer) return;
                    let s = e.state.selection,
                        r = s.empty ? null : e.posAtCoords(e0(n));
                    if (r && r.pos >= s.from && r.pos <= (s instanceof o.qv ? s.to - 1 : s.to));
                    else if (i && i.mightDrag) e.dispatch(e.state.tr.setSelection(o.qv.create(e.state.doc, i.mightDrag.pos)));
                    else if (n.target && 1 == n.target.nodeType) {
                        let t = e.docView.nearestDesc(n.target, !0);
                        t && t.node.type.spec.draggable && t != e.docView && e.dispatch(e.state.tr.setSelection(o.qv.create(e.state.doc, t.posBefore)))
                    }
                    let l = e.state.selection.content(),
                        {
                            dom: d,
                            text: a
                        } = eL(e, l);
                    n.dataTransfer.clearData(), n.dataTransfer.setData(tn ? "Text" : "text/html", d.innerHTML), n.dataTransfer.effectAllowed = "copyMove", tn || n.dataTransfer.setData("text/plain", a), e.dragging = new ti(l, !n[ts])
                }, eG.dragend = e => {
                    let t = e.dragging;
                    window.setTimeout(() => {
                        e.dragging == t && (e.dragging = null)
                    }, 50)
                }, ej.dragover = ej.dragenter = (e, t) => t.preventDefault(), ej.drop = (e, t) => {
                    let n = e.dragging;
                    if (e.dragging = null, !t.dataTransfer) return;
                    let r = e.posAtCoords(e0(t));
                    if (!r) return;
                    let l = e.state.doc.resolve(r.pos);
                    if (!l) return;
                    let d = n && n.slice;
                    d ? e.someProp("transformPasted", e => {
                        d = e(d)
                    }) : d = eF(e, t.dataTransfer.getData(tn ? "Text" : "text/plain"), tn ? null : t.dataTransfer.getData("text/html"), !1, l);
                    let a = !!(n && !t[ts]);
                    if (e.someProp("handleDrop", n => n(e, t, d || i.p2.empty, a))) {
                        t.preventDefault();
                        return
                    }
                    if (!d) return;
                    t.preventDefault();
                    let c = d ? (0, s.nj)(e.state.doc, l.pos, d) : l.pos;
                    null == c && (c = l.pos);
                    let h = e.state.tr;
                    a && h.deleteSelection();
                    let u = h.mapping.map(c),
                        f = 0 == d.openStart && 0 == d.openEnd && 1 == d.content.childCount,
                        p = h.doc;
                    if (f ? h.replaceRangeWith(u, u, d.content.firstChild) : h.replaceRange(u, u, d), h.doc.eq(p)) return;
                    let m = h.doc.resolve(u);
                    if (f && o.qv.isSelectable(d.content.firstChild) && m.nodeAfter && m.nodeAfter.sameMarkup(d.content.firstChild)) h.setSelection(new o.qv(m));
                    else {
                        let t = h.mapping.map(c);
                        h.mapping.maps[h.mapping.maps.length - 1].forEach((e, n, o, i) => t = i), h.setSelection(eO(e, m, h.doc.resolve(t)))
                    }
                    e.focus(), e.dispatch(h.setMeta("uiEvent", "drop"))
                }, eG.focus = e => {
                    e.focused || (e.domObserver.stop(), e.dom.classList.add("ProseMirror-focused"), e.domObserver.start(), e.focused = !0, setTimeout(() => {
                        e.docView && e.hasFocus() && !e.domObserver.currentSelection.eq(e.domSelection()) && ey(e)
                    }, 20))
                }, eG.blur = (e, t) => {
                    e.focused && (e.domObserver.stop(), e.dom.classList.remove("ProseMirror-focused"), e.domObserver.start(), t.relatedTarget && e.dom.contains(t.relatedTarget) && e.domObserver.currentSelection.clear(), e.focused = !1)
                }, eG.beforeinput = (e, t) => {
                    if (g && D && "deleteContentBackward" == t.inputType) {
                        e.domObserver.flushSoon();
                        let {
                            domChangeCount: t
                        } = e.input;
                        setTimeout(() => {
                            if (e.input.domChangeCount != t || (e.dom.blur(), e.focus(), e.someProp("handleKeyDown", t => t(e, V(8, "Backspace"))))) return;
                            let {
                                $cursor: n
                            } = e.state.selection;
                            n && n.pos > 0 && e.dispatch(e.state.tr.delete(n.pos - 1, n.pos).scrollIntoView())
                        }, 50)
                    }
                }, ej) eG[e] = ej[e];

            function tr(e, t) {
                if (e == t) return !0;
                for (let n in e)
                    if (e[n] !== t[n]) return !1;
                for (let n in t)
                    if (!(n in e)) return !1;
                return !0
            }
            class tl {
                constructor(e, t) {
                    this.toDOM = e, this.spec = t || tu, this.side = this.spec.side || 0
                }
                map(e, t, n, o) {
                    let {
                        pos: i,
                        deleted: s
                    } = e.mapResult(t.from + o, this.side < 0 ? -1 : 1);
                    return s ? null : new tc(i - n, i - n, this)
                }
                valid() {
                    return !0
                }
                eq(e) {
                    return this == e || e instanceof tl && (this.spec.key && this.spec.key == e.spec.key || this.toDOM == e.toDOM && tr(this.spec, e.spec))
                }
                destroy(e) {
                    this.spec.destroy && this.spec.destroy(e)
                }
            }
            class td {
                constructor(e, t) {
                    this.attrs = e, this.spec = t || tu
                }
                map(e, t, n, o) {
                    let i = e.map(t.from + o, this.spec.inclusiveStart ? -1 : 1) - n,
                        s = e.map(t.to + o, this.spec.inclusiveEnd ? 1 : -1) - n;
                    return i >= s ? null : new tc(i, s, this)
                }
                valid(e, t) {
                    return t.from < t.to
                }
                eq(e) {
                    return this == e || e instanceof td && tr(this.attrs, e.attrs) && tr(this.spec, e.spec)
                }
                static is(e) {
                    return e.type instanceof td
                }
                destroy() {}
            }
            class ta {
                constructor(e, t) {
                    this.attrs = e, this.spec = t || tu
                }
                map(e, t, n, o) {
                    let i = e.mapResult(t.from + o, 1);
                    if (i.deleted) return null;
                    let s = e.mapResult(t.to + o, -1);
                    return s.deleted || s.pos <= i.pos ? null : new tc(i.pos - n, s.pos - n, this)
                }
                valid(e, t) {
                    let {
                        index: n,
                        offset: o
                    } = e.content.findIndex(t.from), i;
                    return o == t.from && !(i = e.child(n)).isText && o + i.nodeSize == t.to
                }
                eq(e) {
                    return this == e || e instanceof ta && tr(this.attrs, e.attrs) && tr(this.spec, e.spec)
                }
                destroy() {}
            }
            class tc {
                constructor(e, t, n) {
                    this.from = e, this.to = t, this.type = n
                }
                copy(e, t) {
                    return new tc(e, t, this.type)
                }
                eq(e, t = 0) {
                    return this.type.eq(e.type) && this.from + t == e.from && this.to + t == e.to
                }
                map(e, t, n) {
                    return this.type.map(e, this, t, n)
                }
                static widget(e, t, n) {
                    return new tc(e, e, new tl(t, n))
                }
                static inline(e, t, n, o) {
                    return new tc(e, t, new td(n, o))
                }
                static node(e, t, n, o) {
                    return new tc(e, t, new ta(n, o))
                }
                get spec() {
                    return this.type.spec
                }
                get inline() {
                    return this.type instanceof td
                }
            }
            let th = [],
                tu = {};
            class tf {
                constructor(e, t) {
                    this.local = e.length ? e : th, this.children = t.length ? t : th
                }
                static create(e, t) {
                    return t.length ? tv(t, e, 0, tu) : tp
                }
                find(e, t, n) {
                    let o = [];
                    return this.findInner(null == e ? 0 : e, null == t ? 1e9 : t, o, 0, n), o
                }
                findInner(e, t, n, o, i) {
                    for (let s = 0; s < this.local.length; s++) {
                        let r = this.local[s];
                        r.from <= t && r.to >= e && (!i || i(r.spec)) && n.push(r.copy(r.from + o, r.to + o))
                    }
                    for (let s = 0; s < this.children.length; s += 3)
                        if (this.children[s] < t && this.children[s + 1] > e) {
                            let r = this.children[s] + 1;
                            this.children[s + 2].findInner(e - r, t - r, n, o + r, i)
                        }
                }
                map(e, t, n) {
                    return this == tp || 0 == e.maps.length ? this : this.mapInner(e, t, 0, 0, n || tu)
                }
                mapInner(e, t, n, o, i) {
                    let s;
                    for (let r = 0; r < this.local.length; r++) {
                        let l = this.local[r].map(e, n, o);
                        l && l.type.valid(t, l) ? (s || (s = [])).push(l) : i.onRemove && i.onRemove(this.local[r].spec)
                    }
                    return this.children.length ? function(e, t, n, o, i, s, r) {
                        let l = e.slice(),
                            d = (e, t, n, o) => {
                                for (let r = 0; r < l.length; r += 3) {
                                    let d = l[r + 1],
                                        a;
                                    if (d < 0 || e > d + s) continue;
                                    let c = l[r] + s;
                                    t >= c ? l[r + 1] = e <= c ? -2 : -1 : n >= i && (a = o - n - (t - e)) && (l[r] += a, l[r + 1] += a)
                                }
                            };
                        for (let e = 0; e < n.maps.length; e++) n.maps[e].forEach(d);
                        let a = !1;
                        for (let t = 0; t < l.length; t += 3)
                            if (l[t + 1] < 0) {
                                if (-2 == l[t + 1]) {
                                    a = !0, l[t + 1] = -1;
                                    continue
                                }
                                let d = n.map(e[t] + s),
                                    c = d - i;
                                if (c < 0 || c >= o.content.size) {
                                    a = !0;
                                    continue
                                }
                                let h = n.map(e[t + 1] + s, -1) - i,
                                    {
                                        index: u,
                                        offset: f
                                    } = o.content.findIndex(c),
                                    p = o.maybeChild(u);
                                if (p && f == c && f + p.nodeSize == h) {
                                    let o = l[t + 2].mapInner(n, p, d + 1, e[t] + s + 1, r);
                                    o != tp ? (l[t] = c, l[t + 1] = h, l[t + 2] = o) : (l[t + 1] = -2, a = !0)
                                } else a = !0
                            }
                        if (a) {
                            let d = tv(function(e, t, n, o, i, s, r) {
                                for (let l = 0; l < e.length; l += 3) - 1 == e[l + 1] && function e(t, s) {
                                    for (let e = 0; e < t.local.length; e++) {
                                        let l = t.local[e].map(o, i, s);
                                        l ? n.push(l) : r.onRemove && r.onRemove(t.local[e].spec)
                                    }
                                    for (let n = 0; n < t.children.length; n += 3) e(t.children[n + 2], t.children[n] + s + 1)
                                }(e[l + 2], t[l] + s + 1);
                                return n
                            }(l, e, t, n, i, s, r), o, 0, r);
                            t = d.local;
                            for (let e = 0; e < l.length; e += 3) l[e + 1] < 0 && (l.splice(e, 3), e -= 3);
                            for (let e = 0, t = 0; e < d.children.length; e += 3) {
                                let n = d.children[e];
                                for (; t < l.length && l[t] < n;) t += 3;
                                l.splice(t, 0, d.children[e], d.children[e + 1], d.children[e + 2])
                            }
                        }
                        return new tf(t.sort(tw), l)
                    }(this.children, s || [], e, t, n, o, i) : s ? new tf(s.sort(tw), th) : tp
                }
                add(e, t) {
                    return t.length ? this == tp ? tf.create(e, t) : this.addInner(e, t, 0) : this
                }
                addInner(e, t, n) {
                    let o, i = 0;
                    e.forEach((e, s) => {
                        let r = s + n,
                            l;
                        if (l = ty(t, e, r)) {
                            for (o || (o = this.children.slice()); i < o.length && o[i] < s;) i += 3;
                            o[i] == s ? o[i + 2] = o[i + 2].addInner(e, l, r + 1) : o.splice(i, 0, s, s + e.nodeSize, tv(l, e, r + 1, tu)), i += 3
                        }
                    });
                    let s = tg(i ? tb(t) : t, -n);
                    for (let t = 0; t < s.length; t++) s[t].type.valid(e, s[t]) || s.splice(t--, 1);
                    return new tf(s.length ? this.local.concat(s).sort(tw) : this.local, o || this.children)
                }
                remove(e) {
                    return 0 == e.length || this == tp ? this : this.removeInner(e, 0)
                }
                removeInner(e, t) {
                    let n = this.children,
                        o = this.local;
                    for (let o = 0; o < n.length; o += 3) {
                        let i;
                        let s = n[o] + t,
                            r = n[o + 1] + t;
                        for (let t = 0, n; t < e.length; t++)(n = e[t]) && n.from > s && n.to < r && (e[t] = null, (i || (i = [])).push(n));
                        if (!i) continue;
                        n == this.children && (n = this.children.slice());
                        let l = n[o + 2].removeInner(i, s + 1);
                        l != tp ? n[o + 2] = l : (n.splice(o, 3), o -= 3)
                    }
                    if (o.length) {
                        for (let n = 0, i; n < e.length; n++)
                            if (i = e[n])
                                for (let e = 0; e < o.length; e++) o[e].eq(i, t) && (o == this.local && (o = this.local.slice()), o.splice(e--, 1))
                    }
                    return n == this.children && o == this.local ? this : o.length || n.length ? new tf(o, n) : tp
                }
                forChild(e, t) {
                    let n, o;
                    if (this == tp) return this;
                    if (t.isLeaf) return tf.empty;
                    for (let t = 0; t < this.children.length; t += 3)
                        if (this.children[t] >= e) {
                            this.children[t] == e && (n = this.children[t + 2]);
                            break
                        }
                    let i = e + 1,
                        s = i + t.content.size;
                    for (let e = 0; e < this.local.length; e++) {
                        let t = this.local[e];
                        if (t.from < s && t.to > i && t.type instanceof td) {
                            let e = Math.max(i, t.from) - i,
                                n = Math.min(s, t.to) - i;
                            e < n && (o || (o = [])).push(t.copy(e, n))
                        }
                    }
                    if (o) {
                        let e = new tf(o.sort(tw), th);
                        return n ? new tm([e, n]) : e
                    }
                    return n || tp
                }
                eq(e) {
                    if (this == e) return !0;
                    if (!(e instanceof tf) || this.local.length != e.local.length || this.children.length != e.children.length) return !1;
                    for (let t = 0; t < this.local.length; t++)
                        if (!this.local[t].eq(e.local[t])) return !1;
                    for (let t = 0; t < this.children.length; t += 3)
                        if (this.children[t] != e.children[t] || this.children[t + 1] != e.children[t + 1] || !this.children[t + 2].eq(e.children[t + 2])) return !1;
                    return !0
                }
                locals(e) {
                    return tD(this.localsInner(e))
                }
                localsInner(e) {
                    if (this == tp) return th;
                    if (e.inlineContent || !this.local.some(td.is)) return this.local;
                    let t = [];
                    for (let e = 0; e < this.local.length; e++) this.local[e].type instanceof td || t.push(this.local[e]);
                    return t
                }
            }
            tf.empty = new tf([], []), tf.removeOverlap = tD;
            let tp = tf.empty;
            class tm {
                constructor(e) {
                    this.members = e
                }
                map(e, t) {
                    let n = this.members.map(n => n.map(e, t, tu));
                    return tm.from(n)
                }
                forChild(e, t) {
                    if (t.isLeaf) return tf.empty;
                    let n = [];
                    for (let o = 0; o < this.members.length; o++) {
                        let i = this.members[o].forChild(e, t);
                        i != tp && (i instanceof tm ? n = n.concat(i.members) : n.push(i))
                    }
                    return tm.from(n)
                }
                eq(e) {
                    if (!(e instanceof tm) || e.members.length != this.members.length) return !1;
                    for (let t = 0; t < this.members.length; t++)
                        if (!this.members[t].eq(e.members[t])) return !1;
                    return !0
                }
                locals(e) {
                    let t, n = !0;
                    for (let o = 0; o < this.members.length; o++) {
                        let i = this.members[o].localsInner(e);
                        if (i.length) {
                            if (t) {
                                n && (t = t.slice(), n = !1);
                                for (let e = 0; e < i.length; e++) t.push(i[e])
                            } else t = i
                        }
                    }
                    return t ? tD(n ? t : t.sort(tw)) : th
                }
                static from(e) {
                    switch (e.length) {
                        case 0:
                            return tp;
                        case 1:
                            return e[0];
                        default:
                            return new tm(e)
                    }
                }
            }

            function tg(e, t) {
                if (!t || !e.length) return e;
                let n = [];
                for (let o = 0; o < e.length; o++) {
                    let i = e[o];
                    n.push(new tc(i.from + t, i.to + t, i.type))
                }
                return n
            }

            function ty(e, t, n) {
                if (t.isLeaf) return null;
                let o = n + t.nodeSize,
                    i = null;
                for (let t = 0, s; t < e.length; t++)(s = e[t]) && s.from > n && s.to < o && ((i || (i = [])).push(s), e[t] = null);
                return i
            }

            function tb(e) {
                let t = [];
                for (let n = 0; n < e.length; n++) null != e[n] && t.push(e[n]);
                return t
            }

            function tv(e, t, n, o) {
                let i = [],
                    s = !1;
                t.forEach((t, r) => {
                    let l = ty(e, t, r + n);
                    if (l) {
                        s = !0;
                        let e = tv(l, t, n + r + 1, o);
                        e != tp && i.push(r, r + t.nodeSize, e)
                    }
                });
                let r = tg(s ? tb(e) : e, -n).sort(tw);
                for (let e = 0; e < r.length; e++) r[e].type.valid(t, r[e]) || (o.onRemove && o.onRemove(r[e].spec), r.splice(e--, 1));
                return r.length || i.length ? new tf(r, i) : tp
            }

            function tw(e, t) {
                return e.from - t.from || e.to - t.to
            }

            function tD(e) {
                let t = e;
                for (let n = 0; n < t.length - 1; n++) {
                    let o = t[n];
                    if (o.from != o.to)
                        for (let i = n + 1; i < t.length; i++) {
                            let s = t[i];
                            if (s.from == o.from) {
                                s.to != o.to && (t == e && (t = e.slice()), t[i] = s.copy(s.from, o.to), tN(t, i + 1, s.copy(o.to, s.to)));
                                continue
                            }
                            s.from < o.to && (t == e && (t = e.slice()), t[n] = o.copy(o.from, s.from), tN(t, i, o.copy(s.from, o.to)));
                            break
                        }
                }
                return t
            }

            function tN(e, t, n) {
                for (; t < e.length && tw(n, e[t]) > 0;) t++;
                e.splice(t, 0, n)
            }

            function tS(e) {
                let t = [];
                return e.someProp("decorations", n => {
                    let o = n(e.state);
                    o && o != tp && t.push(o)
                }), e.cursorWrapper && t.push(tf.create(e.state.doc, [e.cursorWrapper.deco])), tm.from(t)
            }
            let tO = {
                    childList: !0,
                    characterData: !0,
                    characterDataOldValue: !0,
                    attributes: !0,
                    attributeOldValue: !0,
                    subtree: !0
                },
                tC = u && f <= 11;
            class tM {
                constructor() {
                    this.anchorNode = null, this.anchorOffset = 0, this.focusNode = null, this.focusOffset = 0
                }
                set(e) {
                    this.anchorNode = e.anchorNode, this.anchorOffset = e.anchorOffset, this.focusNode = e.focusNode, this.focusOffset = e.focusOffset
                }
                clear() {
                    this.anchorNode = this.focusNode = null
                }
                eq(e) {
                    return e.anchorNode == this.anchorNode && e.anchorOffset == this.anchorOffset && e.focusNode == this.focusNode && e.focusOffset == this.focusOffset
                }
            }
            class tx {
                constructor(e, t) {
                    this.view = e, this.handleDOMChange = t, this.queue = [], this.flushingSoon = -1, this.observer = null, this.currentSelection = new tM, this.onCharData = null, this.suppressingSelectionUpdates = !1, this.observer = window.MutationObserver && new window.MutationObserver(e => {
                        for (let t = 0; t < e.length; t++) this.queue.push(e[t]);
                        u && f <= 11 && e.some(e => "childList" == e.type && e.removedNodes.length || "characterData" == e.type && e.oldValue.length > e.target.nodeValue.length) ? this.flushSoon() : this.flush()
                    }), tC && (this.onCharData = e => {
                        this.queue.push({
                            target: e.target,
                            type: "characterData",
                            oldValue: e.prevValue
                        }), this.flushSoon()
                    }), this.onSelectionChange = this.onSelectionChange.bind(this)
                }
                flushSoon() {
                    this.flushingSoon < 0 && (this.flushingSoon = window.setTimeout(() => {
                        this.flushingSoon = -1, this.flush()
                    }, 20))
                }
                forceFlush() {
                    this.flushingSoon > -1 && (window.clearTimeout(this.flushingSoon), this.flushingSoon = -1, this.flush())
                }
                start() {
                    this.observer && this.observer.observe(this.view.dom, tO), this.onCharData && this.view.dom.addEventListener("DOMCharacterDataModified", this.onCharData), this.connectSelection()
                }
                stop() {
                    if (this.observer) {
                        let e = this.observer.takeRecords();
                        if (e.length) {
                            for (let t = 0; t < e.length; t++) this.queue.push(e[t]);
                            window.setTimeout(() => this.flush(), 20)
                        }
                        this.observer.disconnect()
                    }
                    this.onCharData && this.view.dom.removeEventListener("DOMCharacterDataModified", this.onCharData), this.disconnectSelection()
                }
                connectSelection() {
                    this.view.dom.ownerDocument.addEventListener("selectionchange", this.onSelectionChange)
                }
                disconnectSelection() {
                    this.view.dom.ownerDocument.removeEventListener("selectionchange", this.onSelectionChange)
                }
                suppressSelectionUpdates() {
                    this.suppressingSelectionUpdates = !0, setTimeout(() => this.suppressingSelectionUpdates = !1, 50)
                }
                onSelectionChange() {
                    if (eC(this.view)) {
                        if (this.suppressingSelectionUpdates) return ey(this.view);
                        if (u && f <= 11 && !this.view.state.selection.empty) {
                            let e = this.view.domSelection();
                            if (e.focusNode && k(e.focusNode, e.focusOffset, e.anchorNode, e.anchorOffset)) return this.flushSoon()
                        }
                        this.flush()
                    }
                }
                setCurSelection() {
                    this.currentSelection.set(this.view.domSelection())
                }
                ignoreSelectionChange(e) {
                    if (0 == e.rangeCount) return !0;
                    let t = e.getRangeAt(0).commonAncestorContainer,
                        n = this.view.docView.nearestDesc(t);
                    if (n && n.ignoreMutation({
                            type: "selection",
                            target: 3 == t.nodeType ? t.parentNode : t
                        })) return this.setCurSelection(), !0
                }
                flush() {
                    var e;
                    if (!this.view.docView || this.flushingSoon > -1) return;
                    let t = this.observer ? this.observer.takeRecords() : [];
                    this.queue.length && (t = this.queue.concat(t), this.queue.length = 0);
                    let n = this.view.domSelection(),
                        o = !this.suppressingSelectionUpdates && !this.currentSelection.eq(n) && eC(this.view) && !this.ignoreSelectionChange(n),
                        i = -1,
                        s = -1,
                        r = !1,
                        l = [];
                    if (this.view.editable)
                        for (let e = 0; e < t.length; e++) {
                            let n = this.registerMutation(t[e], l);
                            n && (i = i < 0 ? n.from : Math.min(n.from, i), s = s < 0 ? n.to : Math.max(n.to, s), n.typeOver && (r = !0))
                        }
                    if (p && l.length > 1) {
                        let e = l.filter(e => "BR" == e.nodeName);
                        if (2 == e.length) {
                            let t = e[0],
                                n = e[1];
                            t.parentNode && t.parentNode.parentNode == n.parentNode ? n.remove() : t.remove()
                        }
                    }(i > -1 || o) && (i > -1 && (this.view.docView.markDirty(i, s), e = this.view, tk || (tk = !0, "normal" == getComputedStyle(e.dom).whiteSpace && console.warn("ProseMirror expects the CSS white-space property to be set, preferably to 'pre-wrap'. It is recommended to load style/prosemirror.css from the prosemirror-view package."))), this.handleDOMChange(i, s, r, l), this.view.docView && this.view.docView.dirty ? this.view.updateState(this.view.state) : this.currentSelection.eq(n) || ey(this.view), this.currentSelection.set(n))
                }
                registerMutation(e, t) {
                    if (t.indexOf(e.target) > -1) return null;
                    let n = this.view.docView.nearestDesc(e.target);
                    if ("attributes" == e.type && (n == this.view.docView || "contenteditable" == e.attributeName || "style" == e.attributeName && !e.oldValue && !e.target.getAttribute("style")) || !n || n.ignoreMutation(e)) return null;
                    if ("childList" == e.type) {
                        for (let n = 0; n < e.addedNodes.length; n++) t.push(e.addedNodes[n]);
                        if (n.contentDOM && n.contentDOM != n.dom && !n.contentDOM.contains(e.target)) return {
                            from: n.posBefore,
                            to: n.posAfter
                        };
                        let o = e.previousSibling,
                            i = e.nextSibling;
                        if (u && f <= 11 && e.addedNodes.length)
                            for (let t = 0; t < e.addedNodes.length; t++) {
                                let {
                                    previousSibling: n,
                                    nextSibling: s
                                } = e.addedNodes[t];
                                (!n || 0 > Array.prototype.indexOf.call(e.addedNodes, n)) && (o = n), (!s || 0 > Array.prototype.indexOf.call(e.addedNodes, s)) && (i = s)
                            }
                        let s = o && o.parentNode == e.target ? O(o) + 1 : 0,
                            r = n.localPosFromDOM(e.target, s, -1),
                            l = i && i.parentNode == e.target ? O(i) : e.target.childNodes.length,
                            d = n.localPosFromDOM(e.target, l, 1);
                        return {
                            from: r,
                            to: d
                        }
                    }
                    return "attributes" == e.type ? {
                        from: n.posAtStart - n.border,
                        to: n.posAtEnd + n.border
                    } : {
                        from: n.posAtStart,
                        to: n.posAtEnd,
                        typeOver: e.target.nodeValue == e.oldValue
                    }
                }
            }
            let tk = !1;

            function tT(e) {
                let t = e.pmViewDesc;
                if (t) return t.parseRule();
                if ("BR" == e.nodeName && e.parentNode) {
                    if (b && /^(ul|ol)$/i.test(e.parentNode.nodeName)) {
                        let e = document.createElement("div");
                        return e.appendChild(document.createElement("li")), {
                            skip: e
                        }
                    }
                    if (e.parentNode.lastChild == e || b && /^(tr|table)$/i.test(e.parentNode.nodeName)) return {
                        ignore: !0
                    }
                } else if ("IMG" == e.nodeName && e.getAttribute("mark-placeholder")) return {
                    ignore: !0
                };
                return null
            }

            function tA(e, t, n) {
                return Math.max(n.anchor, n.head) > t.content.size ? null : eO(e, t.resolve(n.anchor), t.resolve(n.head))
            }

            function tE(e, t, n) {
                let o = e.depth,
                    i = t ? e.end() : e.pos;
                for (; o > 0 && (t || e.indexAfter(o) == e.node(o).childCount);) o--, i++, t = !1;
                if (n) {
                    let t = e.node(o).maybeChild(e.indexAfter(o));
                    for (; t && !t.isLeaf;) t = t.firstChild, i++
                }
                return i
            }
            class tP {
                constructor(e, t) {
                    this._root = null, this.focused = !1, this.trackWrites = null, this.mounted = !1, this.markCursor = null, this.cursorWrapper = null, this.lastSelectedViewDesc = void 0, this.input = new eX, this.prevDirectPlugins = [], this.pluginViews = [], this.dragging = null, this._props = t, this.state = t.state, this.directPlugins = t.plugins || [], this.directPlugins.forEach(tI), this.dispatch = this.dispatch.bind(this), this.dom = e && e.mount || document.createElement("div"), e && (e.appendChild ? e.appendChild(this.dom) : "function" == typeof e ? e(this.dom) : e.mount && (this.mounted = !0)), this.editable = tR(this), tB(this), this.nodeViews = tz(this), this.docView = et(this.state.doc, tV(this), tS(this), this.dom, this), this.domObserver = new tx(this, (e, t, n, s) => (function(e, t, n, s, r) {
                            let l, d, a, c, h, p;
                            if (t < 0) {
                                let t = e.input.lastSelectionTime > Date.now() - 50 ? e.input.lastSelectionOrigin : null,
                                    n = em(e, t);
                                if (n && !e.state.selection.eq(n)) {
                                    let o = e.state.tr.setSelection(n);
                                    "pointer" == t ? o.setMeta("pointer", !0) : "key" == t && o.scrollIntoView(), e.dispatch(o)
                                }
                                return
                            }
                            let m = e.state.doc.resolve(t),
                                y = m.sharedDepth(n);
                            t = m.before(y + 1), n = e.state.doc.resolve(n).after(y + 1);
                            let b = e.state.selection,
                                w = function(e, t, n) {
                                    let o, {
                                            node: s,
                                            fromOffset: r,
                                            toOffset: l,
                                            from: d,
                                            to: a
                                        } = e.docView.parseRange(t, n),
                                        c = e.domSelection(),
                                        h = c.anchorNode;
                                    if (h && e.dom.contains(1 == h.nodeType ? h : h.parentNode) && (o = [{
                                            node: h,
                                            offset: c.anchorOffset
                                        }], P(c) || o.push({
                                            node: c.focusNode,
                                            offset: c.focusOffset
                                        })), g && 8 === e.input.lastKeyCode)
                                        for (let e = l; e > r; e--) {
                                            let t = s.childNodes[e - 1],
                                                n = t.pmViewDesc;
                                            if ("BR" == t.nodeName && !n) {
                                                l = e;
                                                break
                                            }
                                            if (!n || n.size) break
                                        }
                                    let u = e.state.doc,
                                        f = e.someProp("domParser") || i.aw.fromSchema(e.state.schema),
                                        p = u.resolve(d),
                                        m = null,
                                        y = f.parse(s, {
                                            topNode: p.parent,
                                            topMatch: p.parent.contentMatchAt(p.index()),
                                            topOpen: !0,
                                            from: r,
                                            to: l,
                                            preserveWhitespace: "pre" != p.parent.type.whitespace || "full",
                                            findPositions: o,
                                            ruleFromNode: tT,
                                            context: p
                                        });
                                    if (o && null != o[0].pos) {
                                        let e = o[0].pos,
                                            t = o[1] && o[1].pos;
                                        null == t && (t = e), m = {
                                            anchor: e + d,
                                            head: t + d
                                        }
                                    }
                                    return {
                                        doc: y,
                                        sel: m,
                                        from: d,
                                        to: a
                                    }
                                }(e, t, n);
                            if (g && e.cursorWrapper && w.sel && w.sel.anchor == e.cursorWrapper.deco.from) {
                                let t = e.cursorWrapper.deco.type.toDOM.nextSibling,
                                    n = t && t.nodeValue ? t.nodeValue.length : 1;
                                w.sel = {
                                    anchor: w.sel.anchor + n,
                                    head: w.sel.anchor + n
                                }
                            }
                            let N = e.state.doc,
                                S = N.slice(w.from, w.to);
                            8 === e.input.lastKeyCode && Date.now() - 100 < e.input.lastKeyCodeTime ? (l = e.state.selection.to, d = "end") : (l = e.state.selection.from, d = "start"), e.input.lastKeyCode = null;
                            let O = function(e, t, n, o, i) {
                                let s = e.findDiffStart(t, n);
                                if (null == s) return null;
                                let {
                                    a: r,
                                    b: l
                                } = e.findDiffEnd(t, n + e.size, n + t.size);
                                if ("end" == i) {
                                    let e = Math.max(0, s - Math.min(r, l));
                                    o -= r + e - s
                                }
                                if (r < s && e.size < t.size) {
                                    let e = o <= s && o >= r ? s - o : 0;
                                    s -= e, l = s + (l - r), r = s
                                } else if (l < s) {
                                    let e = o <= s && o >= l ? s - o : 0;
                                    s -= e, r = s + (r - l), l = s
                                }
                                return {
                                    start: s,
                                    endA: r,
                                    endB: l
                                }
                            }(S.content, w.doc.content, w.from, l, d);
                            if ((v && e.input.lastIOSEnter > Date.now() - 225 || D) && r.some(e => "DIV" == e.nodeName || "P" == e.nodeName) && (!O || O.endA >= O.endB) && e.someProp("handleKeyDown", t => t(e, V(13, "Enter")))) {
                                e.input.lastIOSEnter = 0;
                                return
                            }
                            if (!O) {
                                if (s && b instanceof o.Bs && !b.empty && b.$head.sameParent(b.$anchor) && !e.composing && !(w.sel && w.sel.anchor != w.sel.head)) O = {
                                    start: b.from,
                                    endA: b.to,
                                    endB: b.to
                                };
                                else {
                                    if (w.sel) {
                                        let t = tA(e, e.state.doc, w.sel);
                                        t && !t.eq(e.state.selection) && e.dispatch(e.state.tr.setSelection(t))
                                    }
                                    return
                                }
                            }
                            e.input.domChangeCount++, e.state.selection.from < e.state.selection.to && O.start == O.endB && e.state.selection instanceof o.Bs && (O.start > e.state.selection.from && O.start <= e.state.selection.from + 2 && e.state.selection.from >= w.from ? O.start = e.state.selection.from : O.endA < e.state.selection.to && O.endA >= e.state.selection.to - 2 && e.state.selection.to <= w.to && (O.endB += e.state.selection.to - O.endA, O.endA = e.state.selection.to)), u && f <= 11 && O.endB == O.start + 1 && O.endA == O.start && O.start > w.from && " \xa0" == w.doc.textBetween(O.start - w.from - 1, O.start - w.from + 1) && (O.start--, O.endA--, O.endB--);
                            let C = w.doc.resolveNoCache(O.start - w.from),
                                M = w.doc.resolveNoCache(O.endB - w.from),
                                x = N.resolve(O.start),
                                k = C.sameParent(M) && C.parent.inlineContent && x.end() >= O.endA;
                            if ((v && e.input.lastIOSEnter > Date.now() - 225 && (!k || r.some(e => "DIV" == e.nodeName || "P" == e.nodeName)) || !k && C.pos < w.doc.content.size && (a = o.Y1.findFrom(w.doc.resolve(C.pos + 1), 1, !0)) && a.head == M.pos) && e.someProp("handleKeyDown", t => t(e, V(13, "Enter")))) {
                                e.input.lastIOSEnter = 0;
                                return
                            }
                            if (e.state.selection.anchor > O.start && function(e, t, n, o, i) {
                                    if (!o.parent.isTextblock || n - t <= i.pos - o.pos || tE(o, !0, !1) < i.pos) return !1;
                                    let s = e.resolve(t);
                                    if (s.parentOffset < s.parent.content.size || !s.parent.isTextblock) return !1;
                                    let r = e.resolve(tE(s, !0, !0));
                                    return !(!r.parent.isTextblock || r.pos > n || tE(r, !0, !1) < n) && o.parent.content.cut(o.parentOffset).eq(r.parent.content)
                                }(N, O.start, O.endA, C, M) && e.someProp("handleKeyDown", t => t(e, V(8, "Backspace")))) {
                                D && g && e.domObserver.suppressSelectionUpdates();
                                return
                            }
                            g && D && O.endB == O.start && (e.input.lastAndroidDelete = Date.now()), D && !k && C.start() != M.start() && 0 == M.parentOffset && C.depth == M.depth && w.sel && w.sel.anchor == w.sel.head && w.sel.head == O.endA && (O.endB -= 2, M = w.doc.resolveNoCache(O.endB - w.from), setTimeout(() => {
                                e.someProp("handleKeyDown", function(t) {
                                    return t(e, V(13, "Enter"))
                                })
                            }, 20));
                            let T = O.start,
                                A = O.endA;
                            if (k) {
                                if (C.pos == M.pos) u && f <= 11 && 0 == C.parentOffset && (e.domObserver.suppressSelectionUpdates(), setTimeout(() => ey(e), 20)), c = e.state.tr.delete(T, A), h = N.resolve(O.start).marksAcross(N.resolve(O.endA));
                                else if (O.endA == O.endB && (p = function(e, t) {
                                        let n = e.firstChild.marks,
                                            o = t.firstChild.marks,
                                            s = n,
                                            r = o,
                                            l, d, a;
                                        for (let e = 0; e < o.length; e++) s = o[e].removeFromSet(s);
                                        for (let e = 0; e < n.length; e++) r = n[e].removeFromSet(r);
                                        if (1 == s.length && 0 == r.length) d = s[0], l = "add", a = e => e.mark(d.addToSet(e.marks));
                                        else {
                                            if (0 != s.length || 1 != r.length) return null;
                                            d = r[0], l = "remove", a = e => e.mark(d.removeFromSet(e.marks))
                                        }
                                        let c = [];
                                        for (let e = 0; e < t.childCount; e++) c.push(a(t.child(e)));
                                        if (i.HY.from(c).eq(e)) return {
                                            mark: d,
                                            type: l
                                        }
                                    }(C.parent.content.cut(C.parentOffset, M.parentOffset), x.parent.content.cut(x.parentOffset, O.endA - x.start())))) c = e.state.tr, "add" == p.type ? c.addMark(T, A, p.mark) : c.removeMark(T, A, p.mark);
                                else if (C.parent.child(C.index()).isText && C.index() == M.index() - (M.textOffset ? 0 : 1)) {
                                    let t = C.parent.textBetween(C.parentOffset, M.parentOffset);
                                    if (e.someProp("handleTextInput", n => n(e, T, A, t))) return;
                                    c = e.state.tr.insertText(t, T, A)
                                }
                            }
                            if (c || (c = e.state.tr.replace(T, A, w.doc.slice(O.start - w.from, O.endB - w.from))), w.sel) {
                                let t = tA(e, c.doc, w.sel);
                                t && !(g && D && e.composing && t.empty && (O.start != O.endB || e.input.lastAndroidDelete < Date.now() - 100) && (t.head == T || t.head == c.mapping.map(A) - 1) || u && t.empty && t.head == T) && c.setSelection(t)
                            }
                            h && c.ensureMarks(h), e.dispatch(c.scrollIntoView())
                        })(this, e, t, n, s)), this.domObserver.start(),
                        function(e) {
                            for (let t in eG) {
                                let n = eG[t];
                                e.dom.addEventListener(t, e.input.eventHandlers[t] = t => {
                                    ! function(e, t) {
                                        if (!t.bubbles) return !0;
                                        if (t.defaultPrevented) return !1;
                                        for (let n = t.target; n != e.dom; n = n.parentNode)
                                            if (!n || 11 == n.nodeType || n.pmViewDesc && n.pmViewDesc.stopEvent(t)) return !1;
                                        return !0
                                    }(e, t) || eZ(e, t) || !e.editable && t.type in ej || n(e, t)
                                })
                            }
                            b && e.dom.addEventListener("input", () => null), eQ(e)
                        }(this), this.updatePluginViews()
                }
                get composing() {
                    return this.input.composing
                }
                get props() {
                    if (this._props.state != this.state) {
                        let e = this._props;
                        for (let t in this._props = {}, e) this._props[t] = e[t];
                        this._props.state = this.state
                    }
                    return this._props
                }
                update(e) {
                    e.handleDOMEvents != this._props.handleDOMEvents && eQ(this), this._props = e, e.plugins && (e.plugins.forEach(tI), this.directPlugins = e.plugins), this.updateStateInner(e.state, !0)
                }
                setProps(e) {
                    let t = {};
                    for (let e in this._props) t[e] = this._props[e];
                    for (let n in t.state = this.state, e) t[n] = e[n];
                    this.update(t)
                }
                updateState(e) {
                    this.updateStateInner(e, this.state.plugins != e.plugins)
                }
                updateStateInner(e, t) {
                    let n = this.state,
                        i = !1,
                        s = !1;
                    if (e.storedMarks && this.composing && (te(this), s = !0), this.state = e, t) {
                        let e = tz(this);
                        (function(e, t) {
                            let n = 0,
                                o = 0;
                            for (let o in e) {
                                if (e[o] != t[o]) return !0;
                                n++
                            }
                            for (let e in t) o++;
                            return n != o
                        })(e, this.nodeViews) && (this.nodeViews = e, i = !0), eQ(this)
                    }
                    this.editable = tR(this), tB(this);
                    let r = tS(this),
                        l = tV(this),
                        d = t ? "reset" : e.scrollToSelection > n.scrollToSelection ? "to selection" : "preserve",
                        a = i || !this.docView.matchesNode(e.doc, l, r);
                    (a || !e.selection.eq(n.selection)) && (s = !0);
                    let c = "preserve" == d && s && null == this.dom.style.overflowAnchor && function(e) {
                        let t, n, o = e.dom.getBoundingClientRect(),
                            i = Math.max(0, o.top);
                        for (let s = (o.left + o.right) / 2, r = i + 1; r < Math.min(innerHeight, o.bottom); r += 5) {
                            let o = e.root.elementFromPoint(s, r);
                            if (!o || o == e.dom || !e.dom.contains(o)) continue;
                            let l = o.getBoundingClientRect();
                            if (l.top >= i - 20) {
                                t = o, n = l.top;
                                break
                            }
                        }
                        return {
                            refDOM: t,
                            refTop: n,
                            stack: z(e.dom)
                        }
                    }(this);
                    if (s) {
                        var h, f;
                        let t, o, s;
                        this.domObserver.stop();
                        let d = a && (u || g) && !this.composing && !n.selection.empty && !e.selection.empty && (h = n.selection, f = e.selection, s = Math.min(h.$anchor.sharedDepth(h.head), f.$anchor.sharedDepth(f.head)), h.$anchor.start(s) != f.$anchor.start(s));
                        if (a) {
                            let t = g ? this.trackWrites = this.domSelection().focusNode : null;
                            (i || !this.docView.update(e.doc, l, r, this)) && (this.docView.updateOuterDeco([]), this.docView.destroy(), this.docView = et(e.doc, l, r, this.dom, this)), t && !this.trackWrites && (d = !0)
                        }
                        d || !(this.input.mouseDown && this.domObserver.currentSelection.eq(this.domSelection()) && (t = this.docView.domFromPos(this.state.selection.anchor, 0), o = this.domSelection(), k(t.node, t.offset, o.anchorNode, o.anchorOffset))) ? ey(this, d) : (eN(this, e.selection), this.domObserver.setCurSelection()), this.domObserver.start()
                    }
                    if (this.updatePluginViews(n), "reset" == d) this.dom.scrollTop = 0;
                    else if ("to selection" == d) {
                        let t = this.domSelection().focusNode;
                        if (this.someProp("handleScrollToSelection", e => e(this)));
                        else if (e.selection instanceof o.qv) {
                            let n = this.docView.domAfterPos(e.selection.from);
                            1 == n.nodeType && R(this, n.getBoundingClientRect(), t)
                        } else R(this, this.coordsAtPos(e.selection.head, 1), t)
                    } else c && function({
                        refDOM: e,
                        refTop: t,
                        stack: n
                    }) {
                        let o = e ? e.getBoundingClientRect().top : 0;
                        I(n, 0 == o ? 0 : o - t)
                    }(c)
                }
                destroyPluginViews() {
                    let e;
                    for (; e = this.pluginViews.pop();) e.destroy && e.destroy()
                }
                updatePluginViews(e) {
                    if (e && e.plugins == this.state.plugins && this.directPlugins == this.prevDirectPlugins)
                        for (let t = 0; t < this.pluginViews.length; t++) {
                            let n = this.pluginViews[t];
                            n.update && n.update(this, e)
                        } else {
                            this.prevDirectPlugins = this.directPlugins, this.destroyPluginViews();
                            for (let e = 0; e < this.directPlugins.length; e++) {
                                let t = this.directPlugins[e];
                                t.spec.view && this.pluginViews.push(t.spec.view(this))
                            }
                            for (let e = 0; e < this.state.plugins.length; e++) {
                                let t = this.state.plugins[e];
                                t.spec.view && this.pluginViews.push(t.spec.view(this))
                            }
                        }
                }
                someProp(e, t) {
                    let n = this._props && this._props[e],
                        o;
                    if (null != n && (o = t ? t(n) : n)) return o;
                    for (let n = 0; n < this.directPlugins.length; n++) {
                        let i = this.directPlugins[n].props[e];
                        if (null != i && (o = t ? t(i) : i)) return o
                    }
                    let i = this.state.plugins;
                    if (i)
                        for (let n = 0; n < i.length; n++) {
                            let s = i[n].props[e];
                            if (null != s && (o = t ? t(s) : s)) return o
                        }
                }
                hasFocus() {
                    return this.root.activeElement == this.dom
                }
                focus() {
                    this.domObserver.stop(), this.editable && function(e) {
                        if (e.setActive) return e.setActive();
                        if (q) return e.focus(q);
                        let t = z(e);
                        e.focus(null == q ? {
                            get preventScroll() {
                                return q = {
                                    preventScroll: !0
                                }, !0
                            }
                        } : void 0), q || (q = !1, I(t, 0))
                    }(this.dom), ey(this), this.domObserver.start()
                }
                get root() {
                    let e = this._root;
                    if (null == e) {
                        for (let e = this.dom.parentNode; e; e = e.parentNode)
                            if (9 == e.nodeType || 11 == e.nodeType && e.host) return e.getSelection || (Object.getPrototypeOf(e).getSelection = () => e.ownerDocument.getSelection()), this._root = e
                    }
                    return e || document
                }
                posAtCoords(e) {
                    return function(e, t) {
                        var n;
                        let o, i, s = e.dom.ownerDocument,
                            r, l = 0;
                        if (s.caretPositionFromPoint) try {
                            let e = s.caretPositionFromPoint(t.left, t.top);
                            e && ({
                                offsetNode: r,
                                offset: l
                            } = e)
                        } catch (e) {}
                        if (!r && s.caretRangeFromPoint) {
                            let e = s.caretRangeFromPoint(t.left, t.top);
                            e && ({
                                startContainer: r,
                                startOffset: l
                            } = e)
                        }
                        let d = (e.root.elementFromPoint ? e.root : s).elementFromPoint(t.left, t.top + 1);
                        if (!d || !e.dom.contains(1 != d.nodeType ? d.parentNode : d)) {
                            let n = e.dom.getBoundingClientRect();
                            if (!L(t, n) || !(d = function e(t, n, o) {
                                    let i = t.childNodes.length;
                                    if (i && o.top < o.bottom)
                                        for (let s = Math.max(0, Math.min(i - 1, Math.floor(i * (n.top - o.top) / (o.bottom - o.top)) - 2)), r = s;;) {
                                            let o = t.childNodes[r];
                                            if (1 == o.nodeType) {
                                                let t = o.getClientRects();
                                                for (let i = 0; i < t.length; i++) {
                                                    let s = t[i];
                                                    if (L(n, s)) return e(o, n, s)
                                                }
                                            }
                                            if ((r = (r + 1) % i) == s) break
                                        }
                                    return t
                                }(e.dom, t, n))) return null
                        }
                        if (b)
                            for (let e = d; r && e; e = C(e)) e.draggable && (r = void 0);
                        if (d = (o = (n = d).parentNode) && /^li$/i.test(o.nodeName) && t.left < n.getBoundingClientRect().left ? o : n, r) {
                            if (p && 1 == r.nodeType && (l = Math.min(l, r.childNodes.length)) < r.childNodes.length) {
                                let e = r.childNodes[l],
                                    n;
                                "IMG" == e.nodeName && (n = e.getBoundingClientRect()).right <= t.left && n.bottom > t.top && l++
                            }
                            r == e.dom && l == r.childNodes.length - 1 && 1 == r.lastChild.nodeType && t.top > r.lastChild.getBoundingClientRect().bottom ? i = e.state.doc.content.size : (0 == l || 1 != r.nodeType || "BR" != r.childNodes[l - 1].nodeName) && (i = function(e, t, n, o) {
                                let i = -1;
                                for (let n = t; n != e.dom;) {
                                    let t = e.docView.nearestDesc(n, !0);
                                    if (!t) return null;
                                    if (t.node.isBlock && t.parent) {
                                        let e = t.dom.getBoundingClientRect();
                                        if (e.left > o.left || e.top > o.top) i = t.posBefore;
                                        else if (e.right < o.left || e.bottom < o.top) i = t.posAfter;
                                        else break
                                    }
                                    n = t.dom.parentNode
                                }
                                return i > -1 ? i : e.docView.posFromDOM(t, n, 1)
                            }(e, r, l, t))
                        }
                        null == i && (i = function(e, t, n) {
                            let {
                                node: o,
                                offset: i
                            } = function e(t, n) {
                                let o, i = 2e8,
                                    s, r = 0,
                                    l = n.top,
                                    d = n.top;
                                for (let e = t.firstChild, a = 0; e; e = e.nextSibling, a++) {
                                    let t;
                                    if (1 == e.nodeType) t = e.getClientRects();
                                    else {
                                        if (3 != e.nodeType) continue;
                                        t = x(e).getClientRects()
                                    }
                                    for (let c = 0; c < t.length; c++) {
                                        let h = t[c];
                                        if (h.top <= l && h.bottom >= d) {
                                            l = Math.max(h.bottom, l), d = Math.min(h.top, d);
                                            let t = h.left > n.left ? h.left - n.left : h.right < n.left ? n.left - h.right : 0;
                                            if (t < i) {
                                                o = e, i = t, s = t && 3 == o.nodeType ? {
                                                    left: h.right < n.left ? h.right : h.left,
                                                    top: n.top
                                                } : n, 1 == e.nodeType && t && (r = a + (n.left >= (h.left + h.right) / 2 ? 1 : 0));
                                                continue
                                            }
                                        }!o && (n.left >= h.right && n.top >= h.top || n.left >= h.left && n.top >= h.bottom) && (r = a + 1)
                                    }
                                }
                                return o && 3 == o.nodeType ? function(e, t) {
                                    let n = e.nodeValue.length,
                                        o = document.createRange();
                                    for (let i = 0; i < n; i++) {
                                        o.setEnd(e, i + 1), o.setStart(e, i);
                                        let n = F(o, 1);
                                        if (n.top != n.bottom && L(t, n)) return {
                                            node: e,
                                            offset: i + (t.left >= (n.left + n.right) / 2 ? 1 : 0)
                                        }
                                    }
                                    return {
                                        node: e,
                                        offset: 0
                                    }
                                }(o, s) : !o || i && 1 == o.nodeType ? {
                                    node: t,
                                    offset: r
                                } : e(o, s)
                            }(t, n), s = -1;
                            if (1 == o.nodeType && !o.firstChild) {
                                let e = o.getBoundingClientRect();
                                s = e.left != e.right && n.left > (e.left + e.right) / 2 ? 1 : -1
                            }
                            return e.docView.posFromDOM(o, i, s)
                        }(e, d, t));
                        let a = e.docView.nearestDesc(d, !0);
                        return {
                            pos: i,
                            inside: a ? a.posAtStart - a.border : -1
                        }
                    }(this, e)
                }
                coordsAtPos(e, t = 1) {
                    return W(this, e, t)
                }
                domAtPos(e, t = 0) {
                    return this.docView.domFromPos(e, t)
                }
                nodeDOM(e) {
                    let t = this.docView.descAt(e);
                    return t ? t.nodeDOM : null
                }
                posAtDOM(e, t, n = -1) {
                    let o = this.docView.posFromDOM(e, t, n);
                    if (null == o) throw RangeError("DOM position not inside the editor");
                    return o
                }
                endOfTextblock(e, t) {
                    var n, o, i;
                    let s, r;
                    return n = this, o = t || this.state, i = e, U == o && G == i ? j : (U = o, G = i, j = "up" == i || "down" == i ? (s = o.selection, r = "up" == i ? s.$from : s.$to, _(n, o, () => {
                        let {
                            node: e
                        } = n.docView.domFromPos(r.pos, "up" == i ? -1 : 1);
                        for (;;) {
                            let t = n.docView.nearestDesc(e, !0);
                            if (!t) break;
                            if (t.node.isBlock) {
                                e = t.dom;
                                break
                            }
                            e = t.dom.parentNode
                        }
                        let t = W(n, r.pos, 1);
                        for (let n = e.firstChild; n; n = n.nextSibling) {
                            let e;
                            if (1 == n.nodeType) e = n.getClientRects();
                            else {
                                if (3 != n.nodeType) continue;
                                e = x(n, 0, n.nodeValue.length).getClientRects()
                            }
                            for (let n = 0; n < e.length; n++) {
                                let o = e[n];
                                if (o.bottom > o.top + 1 && ("up" == i ? t.top - o.top > (o.bottom - t.top) * 2 : o.bottom - t.bottom > (t.bottom - o.top) * 2)) return !1
                            }
                        }
                        return !0
                    })) : function(e, t, n) {
                        let {
                            $head: o
                        } = t.selection;
                        if (!o.parent.isTextblock) return !1;
                        let i = o.parentOffset,
                            s = i == o.parent.content.size,
                            r = e.domSelection();
                        return Y.test(o.parent.textContent) && r.modify ? _(e, t, () => {
                            let t = r.getRangeAt(0),
                                i = r.focusNode,
                                s = r.focusOffset,
                                l = r.caretBidiLevel;
                            r.modify("move", n, "character");
                            let d = !(o.depth ? e.docView.domAfterPos(o.before()) : e.dom).contains(1 == r.focusNode.nodeType ? r.focusNode : r.focusNode.parentNode) || i == r.focusNode && s == r.focusOffset;
                            return r.removeAllRanges(), r.addRange(t), null != l && (r.caretBidiLevel = l), d
                        }) : "left" == n || "backward" == n ? !i : s
                    }(n, o, i))
                }
                destroy() {
                    this.docView && (! function(e) {
                        for (let t in e.domObserver.stop(), e.input.eventHandlers) e.dom.removeEventListener(t, e.input.eventHandlers[t]);
                        clearTimeout(e.input.composingTimeout), clearTimeout(e.input.lastIOSEnterFallbackTimeout)
                    }(this), this.destroyPluginViews(), this.mounted ? (this.docView.update(this.state.doc, [], tS(this), this), this.dom.textContent = "") : this.dom.parentNode && this.dom.parentNode.removeChild(this.dom), this.docView.destroy(), this.docView = null)
                }
                get isDestroyed() {
                    return null == this.docView
                }
                dispatchEvent(e) {
                    eZ(this, e) || !eG[e.type] || !this.editable && e.type in ej || eG[e.type](this, e)
                }
                dispatch(e) {
                    let t = this._props.dispatchTransaction;
                    t ? t.call(this, e) : this.updateState(this.state.apply(e))
                }
                domSelection() {
                    return this.root.getSelection()
                }
            }

            function tV(e) {
                let t = Object.create(null);
                return t.class = "ProseMirror", t.contenteditable = String(e.editable), t.translate = "no", e.someProp("attributes", n => {
                    if ("function" == typeof n && (n = n(e.state)), n)
                        for (let e in n) "class" == e && (t.class += " " + n[e]), "style" == e ? t.style = (t.style ? t.style + ";" : "") + n[e] : t[e] || "contenteditable" == e || "nodeName" == e || (t[e] = String(n[e]))
                }), [tc.node(0, e.state.doc.content.size, t)]
            }

            function tB(e) {
                if (e.markCursor) {
                    let t = document.createElement("img");
                    t.className = "ProseMirror-separator", t.setAttribute("mark-placeholder", "true"), t.setAttribute("alt", ""), e.cursorWrapper = {
                        dom: t,
                        deco: tc.widget(e.state.selection.head, t, {
                            raw: !0,
                            marks: e.markCursor
                        })
                    }
                } else e.cursorWrapper = null
            }

            function tR(e) {
                return !e.someProp("editable", t => !1 === t(e.state))
            }

            function tz(e) {
                let t = Object.create(null);

                function n(e) {
                    for (let n in e) Object.prototype.hasOwnProperty.call(t, n) || (t[n] = e[n])
                }
                return e.someProp("nodeViews", n), e.someProp("markViews", n), t
            }

            function tI(e) {
                if (e.spec.state || e.spec.filterTransaction || e.spec.appendTransaction) throw RangeError("Plugins passed directly to the view must not have a state component")
            }
        }
    }
]);