"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [461], {
        90461: function(t, e, i) {
            i.d(e, {
                g: function() {
                    return nx
                }
            });
            var n, r, o, s, a = i(2784),
                l = i(9340);

            function u(t) {
                return "undefined" != typeof PointerEvent && t instanceof PointerEvent ? !("mouse" !== t.pointerType) : t instanceof MouseEvent
            }

            function h(t) {
                let e = !!t.touches;
                return e
            }
            let d = {
                pageX: 0,
                pageY: 0
            };

            function c(t, e = "page") {
                return {
                    point: h(t) ? function(t, e = "page") {
                        let i = t.touches[0] || t.changedTouches[0],
                            n = i || d;
                        return {
                            x: n[e + "X"],
                            y: n[e + "Y"]
                        }
                    }(t, e) : function(t, e = "page") {
                        return {
                            x: t[e + "X"],
                            y: t[e + "Y"]
                        }
                    }(t, e)
                }
            }
            let p = (t, e = !1) => {
                let i = e => t(e, c(e));
                return e ? t => {
                    let e = t instanceof MouseEvent,
                        n = !e || e && 0 === t.button;
                    n && i(t)
                } : i
            };
            var m = i(58387);
            let f = t => 1e3 * t;

            function v(t, e, i, n = {
                passive: !0
            }) {
                return t.addEventListener(e, i, n), () => t.removeEventListener(e, i)
            }

            function g(t, e, i, n) {
                (0, a.useEffect)(() => {
                    let r = t.current;
                    if (i && r) return v(r, e, i, n)
                }, [t, e, i, n])
            }
            var y = i(33791);
            let x = () => y.j && null === window.onpointerdown,
                V = () => y.j && null === window.ontouchstart,
                P = () => y.j && null === window.onmousedown,
                T = {
                    pointerdown: "mousedown",
                    pointermove: "mousemove",
                    pointerup: "mouseup",
                    pointercancel: "mousecancel",
                    pointerover: "mouseover",
                    pointerout: "mouseout",
                    pointerenter: "mouseenter",
                    pointerleave: "mouseleave"
                },
                b = {
                    pointerdown: "touchstart",
                    pointermove: "touchmove",
                    pointerup: "touchend",
                    pointercancel: "touchcancel"
                };

            function A(t) {
                if (x());
                else if (V()) return b[t];
                else if (P()) return T[t];
                return t
            }

            function E(t, e, i, n) {
                return v(t, A(e), p(i, "pointerdown" === e), n)
            }

            function w(t, e, i, n) {
                return g(t, A(e), i && p(i, "pointerdown" === e), n)
            }
            var S = i(96953);
            let C = (t, e) => Math.abs(t - e);
            var B = i(85403);
            class D {
                constructor(t, e, {
                    transformPagePoint: i
                } = {}) {
                    if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.updatePoint = () => {
                            if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                            let t = k(this.lastMoveEventInfo, this.history),
                                e = null !== this.startEvent,
                                i = function(t, e) {
                                    let i = C(t.x, e.x),
                                        n = C(t.y, e.y);
                                    return Math.sqrt(i ** 2 + n ** 2)
                                }(t.offset, {
                                    x: 0,
                                    y: 0
                                }) >= 3;
                            if (!e && !i) return;
                            let {
                                point: n
                            } = t, {
                                timestamp: r
                            } = B.w;
                            this.history.push({ ...n,
                                timestamp: r
                            });
                            let {
                                onStart: o,
                                onMove: s
                            } = this.handlers;
                            e || (o && o(this.lastMoveEvent, t), this.startEvent = this.lastMoveEvent), s && s(this.lastMoveEvent, t)
                        }, this.handlePointerMove = (t, e) => {
                            if (this.lastMoveEvent = t, this.lastMoveEventInfo = R(e, this.transformPagePoint), u(t) && 0 === t.buttons) {
                                this.handlePointerUp(t, e);
                                return
                            }
                            m.Z_.update(this.updatePoint, !0)
                        }, this.handlePointerUp = (t, e) => {
                            this.end();
                            let {
                                onEnd: i,
                                onSessionEnd: n
                            } = this.handlers, r = k(R(e, this.transformPagePoint), this.history);
                            this.startEvent && i && i(t, r), n && n(t, r)
                        }, h(t) && t.touches.length > 1) return;
                    this.handlers = e, this.transformPagePoint = i;
                    let n = c(t),
                        r = R(n, this.transformPagePoint),
                        {
                            point: o
                        } = r,
                        {
                            timestamp: s
                        } = B.w;
                    this.history = [{ ...o,
                        timestamp: s
                    }];
                    let {
                        onSessionStart: a
                    } = e;
                    a && a(t, k(r, this.history)), this.removeListeners = (0, S.z)(E(window, "pointermove", this.handlePointerMove), E(window, "pointerup", this.handlePointerUp), E(window, "pointercancel", this.handlePointerUp))
                }
                updateHandlers(t) {
                    this.handlers = t
                }
                end() {
                    this.removeListeners && this.removeListeners(), m.qY.update(this.updatePoint)
                }
            }

            function R(t, e) {
                return e ? {
                    point: e(t.point)
                } : t
            }

            function L(t, e) {
                return {
                    x: t.x - e.x,
                    y: t.y - e.y
                }
            }

            function k({
                point: t
            }, e) {
                return {
                    point: t,
                    delta: L(t, M(e)),
                    offset: L(t, e[0]),
                    velocity: function(t, e) {
                        if (t.length < 2) return {
                            x: 0,
                            y: 0
                        };
                        let i = t.length - 1,
                            n = null,
                            r = M(t);
                        for (; i >= 0 && (n = t[i], !(r.timestamp - n.timestamp > f(.1)));) i--;
                        if (!n) return {
                            x: 0,
                            y: 0
                        };
                        let o = (r.timestamp - n.timestamp) / 1e3;
                        if (0 === o) return {
                            x: 0,
                            y: 0
                        };
                        let s = {
                            x: (r.x - n.x) / o,
                            y: (r.y - n.y) / o
                        };
                        return s.x === 1 / 0 && (s.x = 0), s.y === 1 / 0 && (s.y = 0), s
                    }(e, 0)
                }
            }

            function M(t) {
                return t[t.length - 1]
            }

            function j(t) {
                let e = null;
                return () => {
                    let i = () => {
                        e = null
                    };
                    return null === e && (e = t, i)
                }
            }
            let F = j("dragHorizontal"),
                I = j("dragVertical");

            function U(t) {
                let e = !1;
                if ("y" === t) e = I();
                else if ("x" === t) e = F();
                else {
                    let t = F(),
                        i = I();
                    t && i ? e = () => {
                        t(), i()
                    } : (t && t(), i && i())
                }
                return e
            }

            function O() {
                let t = U(!0);
                return !t || (t(), !1)
            }
            var $ = i(8350),
                N = i(17475),
                z = i(65339);

            function Y(t) {
                return t.max - t.min
            }

            function G(t, e = 0, i = .01) {
                return Math.abs(t - e) <= i
            }

            function H(t, e, i, n = .5) {
                t.origin = n, t.originPoint = (0, z.C)(e.min, e.max, t.origin), t.scale = Y(i) / Y(e), (G(t.scale, 1, 1e-4) || isNaN(t.scale)) && (t.scale = 1), t.translate = (0, z.C)(i.min, i.max, t.origin) - t.originPoint, (G(t.translate) || isNaN(t.translate)) && (t.translate = 0)
            }

            function W(t, e, i, n) {
                H(t.x, e.x, i.x, null == n ? void 0 : n.originX), H(t.y, e.y, i.y, null == n ? void 0 : n.originY)
            }

            function _(t, e, i) {
                t.min = i.min + e.min, t.max = t.min + Y(e)
            }

            function Z(t, e, i) {
                t.min = e.min - i.min, t.max = t.min + Y(e)
            }

            function X(t, e, i) {
                Z(t.x, e.x, i.x), Z(t.y, e.y, i.y)
            }
            var q = i(51366);

            function K(t, e, i) {
                return {
                    min: void 0 !== e ? t.min + e : void 0,
                    max: void 0 !== i ? t.max + i - (t.max - t.min) : void 0
                }
            }

            function Q(t, e) {
                let i = e.min - t.min,
                    n = e.max - t.max;
                return e.max - e.min < t.max - t.min && ([i, n] = [n, i]), {
                    min: i,
                    max: n
                }
            }

            function J(t, e, i) {
                return {
                    min: tt(t, e),
                    max: tt(t, i)
                }
            }

            function tt(t, e) {
                return "number" == typeof t ? t : t[e] || 0
            }(n = o || (o = {})).Animate = "animate", n.Hover = "whileHover", n.Tap = "whileTap", n.Drag = "whileDrag", n.Focus = "whileFocus", n.InView = "whileInView", n.Exit = "exit";
            let te = () => ({
                    translate: 0,
                    scale: 1,
                    origin: 0,
                    originPoint: 0
                }),
                ti = () => ({
                    x: te(),
                    y: te()
                }),
                tn = () => ({
                    min: 0,
                    max: 0
                }),
                tr = () => ({
                    x: tn(),
                    y: tn()
                });

            function to(t) {
                return [t("x"), t("y")]
            }

            function ts({
                top: t,
                left: e,
                right: i,
                bottom: n
            }) {
                return {
                    x: {
                        min: e,
                        max: i
                    },
                    y: {
                        min: t,
                        max: n
                    }
                }
            }

            function ta(t) {
                return void 0 === t || 1 === t
            }

            function tl({
                scale: t,
                scaleX: e,
                scaleY: i
            }) {
                return !ta(t) || !ta(e) || !ta(i)
            }

            function tu(t) {
                return tl(t) || th(t) || t.z || t.rotate || t.rotateX || t.rotateY
            }

            function th(t) {
                var e, i;
                return (e = t.x) && "0%" !== e || (i = t.y) && "0%" !== i
            }

            function td(t, e, i, n, r) {
                return void 0 !== r && (t = n + r * (t - n)), n + i * (t - n) + e
            }

            function tc(t, e = 0, i = 1, n, r) {
                t.min = td(t.min, e, i, n, r), t.max = td(t.max, e, i, n, r)
            }

            function tp(t, {
                x: e,
                y: i
            }) {
                tc(t.x, e.translate, e.scale, e.originPoint), tc(t.y, i.translate, i.scale, i.originPoint)
            }

            function tm(t) {
                return Number.isInteger(t) ? t : t > 1.0000000000001 || t < .999999999999 ? t : 1
            }

            function tf(t, e) {
                t.min = t.min + e, t.max = t.max + e
            }

            function tv(t, e, [i, n, r]) {
                let o = void 0 !== e[r] ? e[r] : .5,
                    s = (0, z.C)(t.min, t.max, o);
                tc(t, e[i], e[n], s, e.scale)
            }
            let tg = ["x", "scaleX", "originX"],
                ty = ["y", "scaleY", "originY"];

            function tx(t, e) {
                tv(t.x, e, tg), tv(t.y, e, ty)
            }

            function tV(t, e) {
                return ts(function(t, e) {
                    if (!e) return t;
                    let i = e({
                            x: t.left,
                            y: t.top
                        }),
                        n = e({
                            x: t.right,
                            y: t.bottom
                        });
                    return {
                        top: i.y,
                        left: i.x,
                        bottom: n.y,
                        right: n.x
                    }
                }(t.getBoundingClientRect(), e))
            }
            var tP = i(88772);
            let tT = {
                current: !1
            };
            var tb = i(16036);
            let tA = ([t, e, i, n]) => `cubic-bezier(${t}, ${e}, ${i}, ${n})`,
                tE = {
                    linear: "linear",
                    ease: "ease",
                    easeIn: "ease-in",
                    easeOut: "ease-out",
                    easeInOut: "ease-in-out",
                    circIn: tA([0, .65, .55, 1]),
                    circOut: tA([.55, 0, 1, .45]),
                    backIn: tA([.31, .01, .66, -.59]),
                    backOut: tA([.33, 1.53, .69, .99])
                };

            function tw(t, e) {
                let i = performance.now(),
                    n = ({
                        timestamp: r
                    }) => {
                        let o = r - i;
                        o >= e && (m.qY.read(n), t(o - e))
                    };
                return m.Z_.read(n, !0), () => m.qY.read(n)
            }
            var tS = i(75394);
            let tC = () => ({
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                    restSpeed: 10
                }),
                tB = t => ({
                    type: "spring",
                    stiffness: 550,
                    damping: 0 === t ? 2 * Math.sqrt(550) : 30,
                    restSpeed: 10
                }),
                tD = () => ({
                    type: "keyframes",
                    ease: "linear",
                    duration: .3
                }),
                tR = {
                    type: "keyframes",
                    duration: .8
                },
                tL = {
                    x: tC,
                    y: tC,
                    z: tC,
                    rotate: tC,
                    rotateX: tC,
                    rotateY: tC,
                    rotateZ: tC,
                    scaleX: tB,
                    scaleY: tB,
                    scale: tB,
                    opacity: tD,
                    backgroundColor: tD,
                    color: tD,
                    default: tB
                },
                tk = (t, {
                    keyframes: e
                }) => {
                    if (e.length > 2) return tR; {
                        let i = tL[t] || tL.default;
                        return i(e[1])
                    }
                };
            var tM = i(76865);
            let tj = (t, e) => "zIndex" !== t && !!("number" == typeof e || Array.isArray(e) || "string" == typeof e && tM.P.test(e) && !e.startsWith("url("));
            var tF = i(59747);
            let tI = new Set(["brightness", "contrast", "saturate", "opacity"]);

            function tU(t) {
                let [e, i] = t.slice(0, -1).split("(");
                if ("drop-shadow" === e) return t;
                let [n] = i.match(tF.KP) || [];
                if (!n) return t;
                let r = i.replace(n, ""),
                    o = tI.has(e) ? 1 : 0;
                return n !== i && (o *= 100), e + "(" + o + r + ")"
            }
            let tO = /([a-z-]*)\(.*?\)/g,
                t$ = { ...tM.P,
                    getAnimatableNone: t => {
                        let e = t.match(tO);
                        return e ? e.map(tU).join(" ") : t
                    }
                };
            var tN = i(45982),
                tz = i(28073);
            let tY = { ...tz.j,
                    color: tN.$,
                    backgroundColor: tN.$,
                    outlineColor: tN.$,
                    fill: tN.$,
                    stroke: tN.$,
                    borderColor: tN.$,
                    borderTopColor: tN.$,
                    borderRightColor: tN.$,
                    borderBottomColor: tN.$,
                    borderLeftColor: tN.$,
                    filter: t$,
                    WebkitFilter: t$
                },
                tG = t => tY[t];

            function tH(t, e) {
                var i;
                let n = tG(t);
                return n !== t$ && (n = tM.P), null === (i = n.getAnimatableNone) || void 0 === i ? void 0 : i.call(n, e)
            }

            function tW(t) {
                return 0 === t || "string" == typeof t && 0 === parseFloat(t) && -1 === t.indexOf(" ")
            }

            function t_(t) {
                return "number" == typeof t ? 0 : tH("", t)
            }

            function tZ(t, e) {
                return t[e] || t.default || t
            }
            let tX = {
                    waapi: () => Object.hasOwnProperty.call(Element.prototype, "animate")
                },
                tq = {},
                tK = {};
            for (let t in tX) tK[t] = () => (void 0 === tq[t] && (tq[t] = tX[t]()), tq[t]);
            let tQ = new Set(["opacity"]),
                tJ = (t, e, i, n = {}) => r => {
                    let o = tZ(n, t) || {},
                        s = o.delay || n.delay || 0,
                        {
                            elapsed: a = 0
                        } = n;
                    a -= f(s);
                    let u = function(t, e, i, n) {
                            let r = tj(e, i),
                                o = void 0 !== n.from ? n.from : t.get();
                            return ("none" === o && r && "string" == typeof i ? o = tH(e, i) : tW(o) && "string" == typeof i ? o = t_(i) : !Array.isArray(i) && tW(i) && "string" == typeof o && (i = t_(o)), Array.isArray(i)) ? (null === i[0] && (i[0] = o), i) : [o, i]
                        }(e, t, i, o),
                        h = u[0],
                        d = u[u.length - 1],
                        c = tj(t, h),
                        p = tj(t, d);
                    (0, l.K)(c === p, `You are trying to animate ${t} from "${h}" to "${d}". ${h} is not an animatable value - to enable this animation set ${h} to a value animatable to ${d} via the \`style\` property.`);
                    let v = {
                        keyframes: u,
                        velocity: e.getVelocity(),
                        ...o,
                        elapsed: a,
                        onUpdate: t => {
                            e.set(t), o.onUpdate && o.onUpdate(t)
                        },
                        onComplete: () => {
                            r(), o.onComplete && o.onComplete()
                        }
                    };
                    if (!c || !p || tT.current || !1 === o.type) return function({
                        keyframes: t,
                        elapsed: e,
                        onUpdate: i,
                        onComplete: n
                    }) {
                        let r = () => (i && i(t[t.length - 1]), n && n(), () => {});
                        return e ? tw(r, -e) : r()
                    }(v);
                    if ("inertia" === o.type) {
                        let t = function({
                            keyframes: t,
                            velocity: e = 0,
                            min: i,
                            max: n,
                            power: r = .8,
                            timeConstant: o = 750,
                            bounceStiffness: s = 500,
                            bounceDamping: a = 10,
                            restDelta: l = 1,
                            modifyTarget: u,
                            driver: h,
                            onUpdate: d,
                            onComplete: c,
                            onStop: p
                        }) {
                            let m;
                            let f = t[0];

                            function v(t) {
                                return void 0 !== i && t < i || void 0 !== n && t > n
                            }

                            function g(t) {
                                return void 0 === i ? n : void 0 === n ? i : Math.abs(i - t) < Math.abs(n - t) ? i : n
                            }

                            function y(t) {
                                null == m || m.stop(), m = (0, tb.jt)({
                                    keyframes: [0, 1],
                                    velocity: 0,
                                    ...t,
                                    driver: h,
                                    onUpdate: e => {
                                        var i;
                                        null == d || d(e), null === (i = t.onUpdate) || void 0 === i || i.call(t, e)
                                    },
                                    onComplete: c,
                                    onStop: p
                                })
                            }

                            function x(t) {
                                y({
                                    type: "spring",
                                    stiffness: s,
                                    damping: a,
                                    restDelta: l,
                                    ...t
                                })
                            }
                            if (v(f)) x({
                                velocity: e,
                                keyframes: [f, g(f)]
                            });
                            else {
                                let t, n, s = r * e + f;
                                void 0 !== u && (s = u(s));
                                let a = g(s),
                                    h = a === i ? -1 : 1,
                                    d = i => {
                                        t = n, n = i, e = (0, tS.R)(i - t, B.w.delta), (1 === h && i > a || -1 === h && i < a) && x({
                                            keyframes: [i, a],
                                            velocity: e
                                        })
                                    };
                                y({
                                    type: "decay",
                                    keyframes: [f, 0],
                                    velocity: e,
                                    timeConstant: o,
                                    power: r,
                                    restDelta: l,
                                    modifyTarget: u,
                                    onUpdate: v(s) ? d : void 0
                                })
                            }
                            return {
                                stop: () => null == m ? void 0 : m.stop()
                            }
                        }(v);
                        return () => t.stop()
                    }! function({
                        when: t,
                        delay: e,
                        delayChildren: i,
                        staggerChildren: n,
                        staggerDirection: r,
                        repeat: o,
                        repeatType: s,
                        repeatDelay: a,
                        from: l,
                        ...u
                    }) {
                        return !!Object.keys(u).length
                    }(o) && (v = { ...v,
                        ...tk(t, v)
                    }), v.duration && (v.duration = f(v.duration)), v.repeatDelay && (v.repeatDelay = f(v.repeatDelay));
                    let g = e.owner,
                        y = g && g.current,
                        x = tK.waapi() && tQ.has(t) && !v.repeatDelay && "mirror" !== v.repeatType && 0 !== v.damping && g && y instanceof HTMLElement && !g.getProps().onUpdate;
                    if (x) return function(t, e, {
                        onUpdate: i,
                        onComplete: n,
                        ...r
                    }) {
                        var o;
                        let {
                            keyframes: s,
                            duration: a = .3,
                            elapsed: l = 0,
                            ease: u
                        } = r;
                        if ("spring" === r.type || !(!(o = r.ease) || Array.isArray(o) || "string" == typeof o && tE[o])) {
                            let t = (0, tb.jt)(r),
                                e = {
                                    done: !1,
                                    value: s[0]
                                },
                                i = [],
                                n = 0;
                            for (; !e.done;) i.push((e = t.sample(n)).value), n += 10;
                            s = i, a = n - 10, u = "linear"
                        }
                        let h = function(t, e, i, {
                            delay: n = 0,
                            duration: r,
                            repeat: o = 0,
                            repeatType: s = "loop",
                            ease: a,
                            times: l
                        } = {}) {
                            return t.animate({
                                [e]: i,
                                offset: l
                            }, {
                                delay: n,
                                duration: r,
                                easing: function(t) {
                                    if (t) return Array.isArray(t) ? tA(t) : tE[t]
                                }(a),
                                fill: "both",
                                iterations: o + 1,
                                direction: "reverse" === s ? "alternate" : "normal"
                            })
                        }(t.owner.current, e, s, { ...r,
                            delay: -l,
                            duration: a,
                            ease: u
                        });
                        return h.onfinish = () => {
                            t.set(s[s.length - 1]), n && n()
                        }, () => {
                            let {
                                currentTime: e
                            } = h;
                            if (e) {
                                let i = (0, tb.jt)(r);
                                t.setWithVelocity(i.sample(e - 10).value, i.sample(e).value, 10)
                            }
                            m.Z_.update(() => h.cancel())
                        }
                    }(e, t, v); {
                        let t = (0, tb.jt)(v);
                        return () => t.stop()
                    }
                },
                t0 = new WeakMap;
            class t1 {
                constructor(t) {
                    this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                        x: 0,
                        y: 0
                    }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = tr(), this.visualElement = t
                }
                start(t, {
                    snapToCursor: e = !1
                } = {}) {
                    if (!1 === this.visualElement.isPresent) return;
                    let i = t => {
                            this.stopAnimation(), e && this.snapToCursor(c(t, "page").point)
                        },
                        n = (t, e) => {
                            var i;
                            let {
                                drag: n,
                                dragPropagation: r,
                                onDragStart: s
                            } = this.getProps();
                            (!n || r || (this.openGlobalLock && this.openGlobalLock(), this.openGlobalLock = U(n), this.openGlobalLock)) && (this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), to(t => {
                                var e, i;
                                let n = this.getAxisMotionValue(t).get() || 0;
                                if (tP.aQ.test(n)) {
                                    let r = null === (i = null === (e = this.visualElement.projection) || void 0 === e ? void 0 : e.layout) || void 0 === i ? void 0 : i.layoutBox[t];
                                    if (r) {
                                        let t = Y(r);
                                        n = t * (parseFloat(n) / 100)
                                    }
                                }
                                this.originPoint[t] = n
                            }), null == s || s(t, e), null === (i = this.visualElement.animationState) || void 0 === i || i.setActive(o.Drag, !0))
                        },
                        r = (t, e) => {
                            let {
                                dragPropagation: i,
                                dragDirectionLock: n,
                                onDirectionLock: r,
                                onDrag: o
                            } = this.getProps();
                            if (!i && !this.openGlobalLock) return;
                            let {
                                offset: s
                            } = e;
                            if (n && null === this.currentDirection) {
                                this.currentDirection = function(t, e = 10) {
                                    let i = null;
                                    return Math.abs(t.y) > e ? i = "y" : Math.abs(t.x) > e && (i = "x"), i
                                }(s), null !== this.currentDirection && (null == r || r(this.currentDirection));
                                return
                            }
                            this.updateAxis("x", e.point, s), this.updateAxis("y", e.point, s), this.visualElement.render(), null == o || o(t, e)
                        },
                        s = (t, e) => this.stop(t, e);
                    this.panSession = new D(t, {
                        onSessionStart: i,
                        onStart: n,
                        onMove: r,
                        onSessionEnd: s
                    }, {
                        transformPagePoint: this.visualElement.getTransformPagePoint()
                    })
                }
                stop(t, e) {
                    let i = this.isDragging;
                    if (this.cancel(), !i) return;
                    let {
                        velocity: n
                    } = e;
                    this.startAnimation(n);
                    let {
                        onDragEnd: r
                    } = this.getProps();
                    null == r || r(t, e)
                }
                cancel() {
                    var t, e;
                    this.isDragging = !1, this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !1), null === (t = this.panSession) || void 0 === t || t.end(), this.panSession = void 0;
                    let {
                        dragPropagation: i
                    } = this.getProps();
                    !i && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), null === (e = this.visualElement.animationState) || void 0 === e || e.setActive(o.Drag, !1)
                }
                updateAxis(t, e, i) {
                    let {
                        drag: n
                    } = this.getProps();
                    if (!i || !t5(t, n, this.currentDirection)) return;
                    let r = this.getAxisMotionValue(t),
                        o = this.originPoint[t] + i[t];
                    this.constraints && this.constraints[t] && (o = function(t, {
                        min: e,
                        max: i
                    }, n) {
                        return void 0 !== e && t < e ? t = n ? (0, z.C)(e, t, n.min) : Math.max(t, e) : void 0 !== i && t > i && (t = n ? (0, z.C)(i, t, n.max) : Math.min(t, i)), t
                    }(o, this.constraints[t], this.elastic[t])), r.set(o)
                }
                resolveConstraints() {
                    let {
                        dragConstraints: t,
                        dragElastic: e
                    } = this.getProps(), {
                        layout: i
                    } = this.visualElement.projection || {}, n = this.constraints;
                    t && (0, $.I)(t) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : t && i ? this.constraints = function(t, {
                        top: e,
                        left: i,
                        bottom: n,
                        right: r
                    }) {
                        return {
                            x: K(t.x, i, r),
                            y: K(t.y, e, n)
                        }
                    }(i.layoutBox, t) : this.constraints = !1, this.elastic = function(t = .35) {
                        return !1 === t ? t = 0 : !0 === t && (t = .35), {
                            x: J(t, "left", "right"),
                            y: J(t, "top", "bottom")
                        }
                    }(e), n !== this.constraints && i && this.constraints && !this.hasMutatedConstraints && to(t => {
                        this.getAxisMotionValue(t) && (this.constraints[t] = function(t, e) {
                            let i = {};
                            return void 0 !== e.min && (i.min = e.min - t.min), void 0 !== e.max && (i.max = e.max - t.min), i
                        }(i.layoutBox[t], this.constraints[t]))
                    })
                }
                resolveRefConstraints() {
                    var t;
                    let {
                        dragConstraints: e,
                        onMeasureDragConstraints: i
                    } = this.getProps();
                    if (!e || !(0, $.I)(e)) return !1;
                    let n = e.current;
                    (0, l.k)(null !== n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                    let {
                        projection: r
                    } = this.visualElement;
                    if (!r || !r.layout) return !1;
                    let o = function(t, e, i) {
                            let n = tV(t, i),
                                {
                                    scroll: r
                                } = e;
                            return r && (tf(n.x, r.offset.x), tf(n.y, r.offset.y)), n
                        }(n, r.root, this.visualElement.getTransformPagePoint()),
                        s = {
                            x: Q((t = r.layout.layoutBox).x, o.x),
                            y: Q(t.y, o.y)
                        };
                    if (i) {
                        let t = i(function({
                            x: t,
                            y: e
                        }) {
                            return {
                                top: e.min,
                                right: t.max,
                                bottom: e.max,
                                left: t.min
                            }
                        }(s));
                        this.hasMutatedConstraints = !!t, t && (s = ts(t))
                    }
                    return s
                }
                startAnimation(t) {
                    let {
                        drag: e,
                        dragMomentum: i,
                        dragElastic: n,
                        dragTransition: r,
                        dragSnapToOrigin: o,
                        onDragTransitionEnd: s
                    } = this.getProps(), a = this.constraints || {}, l = to(s => {
                        if (!t5(s, e, this.currentDirection)) return;
                        let l = (null == a ? void 0 : a[s]) || {};
                        o && (l = {
                            min: 0,
                            max: 0
                        });
                        let u = {
                            type: "inertia",
                            velocity: i ? t[s] : 0,
                            bounceStiffness: n ? 200 : 1e6,
                            bounceDamping: n ? 40 : 1e7,
                            timeConstant: 750,
                            restDelta: 1,
                            restSpeed: 10,
                            ...r,
                            ...l
                        };
                        return this.startAxisValueAnimation(s, u)
                    });
                    return Promise.all(l).then(s)
                }
                startAxisValueAnimation(t, e) {
                    let i = this.getAxisMotionValue(t);
                    return i.start(tJ(t, i, 0, e))
                }
                stopAnimation() {
                    to(t => this.getAxisMotionValue(t).stop())
                }
                getAxisMotionValue(t) {
                    var e;
                    let i = "_drag" + t.toUpperCase(),
                        n = this.visualElement.getProps()[i];
                    return n || this.visualElement.getValue(t, (null === (e = this.visualElement.getProps().initial) || void 0 === e ? void 0 : e[t]) || 0)
                }
                snapToCursor(t) {
                    to(e => {
                        let {
                            drag: i
                        } = this.getProps();
                        if (!t5(e, i, this.currentDirection)) return;
                        let {
                            projection: n
                        } = this.visualElement, r = this.getAxisMotionValue(e);
                        if (n && n.layout) {
                            let {
                                min: i,
                                max: o
                            } = n.layout.layoutBox[e];
                            r.set(t[e] - (0, z.C)(i, o, .5))
                        }
                    })
                }
                scalePositionWithinConstraints() {
                    var t;
                    if (!this.visualElement.current) return;
                    let {
                        drag: e,
                        dragConstraints: i
                    } = this.getProps(), {
                        projection: n
                    } = this.visualElement;
                    if (!(0, $.I)(i) || !n || !this.constraints) return;
                    this.stopAnimation();
                    let r = {
                        x: 0,
                        y: 0
                    };
                    to(t => {
                        let e = this.getAxisMotionValue(t);
                        if (e) {
                            let i = e.get();
                            r[t] = function(t, e) {
                                let i = .5,
                                    n = Y(t),
                                    r = Y(e);
                                return r > n ? i = (0, N.Y)(e.min, e.max - n, t.min) : n > r && (i = (0, N.Y)(t.min, t.max - r, e.min)), (0, q.u)(0, 1, i)
                            }({
                                min: i,
                                max: i
                            }, this.constraints[t])
                        }
                    });
                    let {
                        transformTemplate: o
                    } = this.visualElement.getProps();
                    this.visualElement.current.style.transform = o ? o({}, "") : "none", null === (t = n.root) || void 0 === t || t.updateScroll(), n.updateLayout(), this.resolveConstraints(), to(t => {
                        if (!t5(t, e, null)) return;
                        let i = this.getAxisMotionValue(t),
                            {
                                min: n,
                                max: o
                            } = this.constraints[t];
                        i.set((0, z.C)(n, o, r[t]))
                    })
                }
                addListeners() {
                    var t;
                    if (!this.visualElement.current) return;
                    t0.set(this.visualElement, this);
                    let e = this.visualElement.current,
                        i = E(e, "pointerdown", t => {
                            let {
                                drag: e,
                                dragListener: i = !0
                            } = this.getProps();
                            e && i && this.start(t)
                        }),
                        n = () => {
                            let {
                                dragConstraints: t
                            } = this.getProps();
                            (0, $.I)(t) && (this.constraints = this.resolveRefConstraints())
                        },
                        {
                            projection: r
                        } = this.visualElement,
                        o = r.addEventListener("measure", n);
                    r && !r.layout && (null === (t = r.root) || void 0 === t || t.updateScroll(), r.updateLayout()), n();
                    let s = v(window, "resize", () => this.scalePositionWithinConstraints()),
                        a = r.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e
                        }) => {
                            this.isDragging && e && (to(e => {
                                let i = this.getAxisMotionValue(e);
                                i && (this.originPoint[e] += t[e].translate, i.set(i.get() + t[e].translate))
                            }), this.visualElement.render())
                        });
                    return () => {
                        s(), i(), o(), null == a || a()
                    }
                }
                getProps() {
                    let t = this.visualElement.getProps(),
                        {
                            drag: e = !1,
                            dragDirectionLock: i = !1,
                            dragPropagation: n = !1,
                            dragConstraints: r = !1,
                            dragElastic: o = .35,
                            dragMomentum: s = !0
                        } = t;
                    return { ...t,
                        drag: e,
                        dragDirectionLock: i,
                        dragPropagation: n,
                        dragConstraints: r,
                        dragElastic: o,
                        dragMomentum: s
                    }
                }
            }

            function t5(t, e, i) {
                return (!0 === e || e === t) && (null === i || i === t)
            }
            var t3 = i(3105),
                t9 = i(60976),
                t6 = i(96073);
            let t2 = t => e => (t(e), null),
                t4 = {
                    pan: t2(function({
                        onPan: t,
                        onPanStart: e,
                        onPanEnd: i,
                        onPanSessionStart: n,
                        visualElement: r
                    }) {
                        let o = (0, a.useRef)(null),
                            {
                                transformPagePoint: s
                            } = (0, a.useContext)(t9._),
                            l = {
                                onSessionStart: n,
                                onStart: e,
                                onMove: t,
                                onEnd: (t, e) => {
                                    o.current = null, i && i(t, e)
                                }
                            };
                        (0, a.useEffect)(() => {
                            null !== o.current && o.current.updateHandlers(l)
                        }), w(r, "pointerdown", (t || e || i || n) && function(t) {
                            o.current = new D(t, l, {
                                transformPagePoint: s
                            })
                        }), (0, t6.z)(() => o.current && o.current.end())
                    }),
                    drag: t2(function(t) {
                        let {
                            dragControls: e,
                            visualElement: i
                        } = t, n = (0, t3.h)(() => new t1(i));
                        (0, a.useEffect)(() => e && e.subscribe(n), [n, e]), (0, a.useEffect)(() => n.addListeners(), [n])
                    })
                };
            var t7 = i(97967);

            function t8() {
                let t = (0, a.useContext)(t7.O);
                if (null === t) return [!0, null];
                let {
                    isPresent: e,
                    onExitComplete: i,
                    register: n
                } = t, r = (0, a.useId)();
                (0, a.useEffect)(() => n(r), []);
                let o = () => i && i(r);
                return !e && i ? [!1, o] : [!0]
            }
            var et = i(3422),
                ee = i(64460),
                ei = i(63722);

            function en(t, e) {
                return e.max === e.min ? 0 : t / (e.max - e.min) * 100
            }
            let er = {
                correct: (t, e) => {
                    if (!e.target) return t;
                    if ("string" == typeof t) {
                        if (!tP.px.test(t)) return t;
                        t = parseFloat(t)
                    }
                    let i = en(t, e.target.x),
                        n = en(t, e.target.y);
                    return `${i}% ${n}%`
                }
            };

            function eo(t) {
                return "string" == typeof t && t.startsWith("var(--")
            }
            let es = /var\((--[a-zA-Z0-9-_]+),? ?([a-zA-Z0-9 ()%#.,-]+)?\)/;

            function ea(t, e, i = 1) {
                (0, l.k)(i <= 4, `Max CSS variable fallback depth detected in property "${t}". This may indicate a circular fallback dependency.`);
                let [n, r] = function(t) {
                    let e = es.exec(t);
                    if (!e) return [, ];
                    let [, i, n] = e;
                    return [i, n]
                }(t);
                if (!n) return;
                let o = window.getComputedStyle(e).getPropertyValue(n);
                return o ? o.trim() : eo(r) ? ea(r, e, i + 1) : r
            }
            let el = "_$css",
                eu = {
                    correct: (t, {
                        treeScale: e,
                        projectionDelta: i
                    }) => {
                        let n = t,
                            r = t.includes("var("),
                            o = [];
                        r && (t = t.replace(es, t => (o.push(t), el)));
                        let s = tM.P.parse(t);
                        if (s.length > 5) return n;
                        let a = tM.P.createTransformer(t),
                            l = "number" != typeof s[0] ? 1 : 0,
                            u = i.x.scale * e.x,
                            h = i.y.scale * e.y;
                        s[0 + l] /= u, s[1 + l] /= h;
                        let d = (0, z.C)(u, h, .5);
                        "number" == typeof s[2 + l] && (s[2 + l] /= d), "number" == typeof s[3 + l] && (s[3 + l] /= d);
                        let c = a(s);
                        if (r) {
                            let t = 0;
                            c = c.replace(el, () => {
                                let e = o[t];
                                return t++, e
                            })
                        }
                        return c
                    }
                };
            var eh = i(14599);
            class ed extends a.Component {
                componentDidMount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i,
                        layoutId: n
                    } = this.props, {
                        projection: r
                    } = t;
                    (0, eh.B)(ec), r && (e.group && e.group.add(r), i && i.register && n && i.register(r), r.root.didUpdate(), r.addEventListener("animationComplete", () => {
                        this.safeToRemove()
                    }), r.setOptions({ ...r.options,
                        onExitComplete: () => this.safeToRemove()
                    })), ei.V.hasEverUpdated = !0
                }
                getSnapshotBeforeUpdate(t) {
                    let {
                        layoutDependency: e,
                        visualElement: i,
                        drag: n,
                        isPresent: r
                    } = this.props, o = i.projection;
                    return o && (o.isPresent = r, n || t.layoutDependency !== e || void 0 === e ? o.willUpdate() : this.safeToRemove(), t.isPresent === r || (r ? o.promote() : o.relegate() || m.Z_.postRender(() => {
                        var t;
                        (null === (t = o.getStack()) || void 0 === t ? void 0 : t.members.length) || this.safeToRemove()
                    }))), null
                }
                componentDidUpdate() {
                    let {
                        projection: t
                    } = this.props.visualElement;
                    t && (t.root.didUpdate(), !t.currentAnimation && t.isLead() && this.safeToRemove())
                }
                componentWillUnmount() {
                    let {
                        visualElement: t,
                        layoutGroup: e,
                        switchLayoutGroup: i
                    } = this.props, {
                        projection: n
                    } = t;
                    n && (n.scheduleCheckAfterUnmount(), (null == e ? void 0 : e.group) && e.group.remove(n), (null == i ? void 0 : i.deregister) && i.deregister(n))
                }
                safeToRemove() {
                    let {
                        safeToRemove: t
                    } = this.props;
                    null == t || t()
                }
                render() {
                    return null
                }
            }
            let ec = {
                borderRadius: { ...er,
                    applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                },
                borderTopLeftRadius: er,
                borderTopRightRadius: er,
                borderBottomLeftRadius: er,
                borderBottomRightRadius: er,
                boxShadow: eu
            };
            var ep = i(12816),
                em = i(55721);

            function ef(t, e) {
                if (!Array.isArray(e)) return !1;
                let i = e.length;
                if (i !== t.length) return !1;
                for (let n = 0; n < i; n++)
                    if (e[n] !== t[n]) return !1;
                return !0
            }
            let ev = t => /^\-?\d*\.?\d+$/.test(t),
                eg = t => /^0[^.\s]+$/.test(t);
            var ey = i(13809),
                ex = i(40226),
                eV = i(30397);
            let eP = t => e => e.test(t),
                eT = [eV.Rx, tP.px, tP.aQ, tP.RW, tP.vw, tP.vh, {
                    test: t => "auto" === t,
                    parse: t => t
                }],
                eb = t => eT.find(eP(t)),
                eA = [...eT, tN.$, tM.P],
                eE = t => eA.find(eP(t));
            var ew = i(99764);

            function eS(t, e, i) {
                let n = t.getProps();
                return (0, ew.o)(n, e, void 0 !== i ? i : n.custom, function(t) {
                    let e = {};
                    return t.values.forEach((t, i) => e[i] = t.get()), e
                }(t), function(t) {
                    let e = {};
                    return t.values.forEach((t, i) => e[i] = t.getVelocity()), e
                }(t))
            }
            var eC = i(73442),
                eB = i(15815);

            function eD(t) {
                return Boolean((0, eB.i)(t) && t.add)
            }
            let eR = (t, e) => `${t}: ${e}`;
            var eL = i(18754);
            let ek = "data-" + (0, eL.D)("framerAppearId");

            function eM(t, e, i = {}) {
                var n;
                let r = eS(t, e, i.custom),
                    {
                        transition: o = t.getDefaultTransition() || {}
                    } = r || {};
                i.transitionOverride && (o = i.transitionOverride);
                let s = r ? () => ej(t, r, i) : () => Promise.resolve(),
                    a = (null === (n = t.variantChildren) || void 0 === n ? void 0 : n.size) ? (n = 0) => {
                        let {
                            delayChildren: r = 0,
                            staggerChildren: s,
                            staggerDirection: a
                        } = o;
                        return function(t, e, i = 0, n = 0, r = 1, o) {
                            let s = [],
                                a = (t.variantChildren.size - 1) * n,
                                l = 1 === r ? (t = 0) => t * n : (t = 0) => a - t * n;
                            return Array.from(t.variantChildren).sort(eF).forEach((t, n) => {
                                s.push(eM(t, e, { ...o,
                                    delay: i + l(n)
                                }).then(() => t.notify("AnimationComplete", e)))
                            }), Promise.all(s)
                        }(t, e, r + n, s, a, i)
                    } : () => Promise.resolve(),
                    {
                        when: l
                    } = o;
                if (!l) return Promise.all([s(), a(i.delay)]); {
                    let [t, e] = "beforeChildren" === l ? [s, a] : [a, s];
                    return t().then(e)
                }
            }

            function ej(t, e, {
                delay: i = 0,
                transitionOverride: n,
                type: r
            } = {}) {
                var o;
                let {
                    transition: s = t.getDefaultTransition(),
                    transitionEnd: a,
                    ...l
                } = t.makeTargetAnimatable(e), u = t.getValue("willChange");
                n && (s = n);
                let h = [],
                    d = r && (null === (o = t.animationState) || void 0 === o ? void 0 : o.getState()[r]);
                for (let e in l) {
                    let n = t.getValue(e),
                        r = l[e];
                    if (!n || void 0 === r || d && function({
                            protectedKeys: t,
                            needsAnimating: e
                        }, i) {
                            let n = t.hasOwnProperty(i) && !0 !== e[i];
                            return e[i] = !1, n
                        }(d, e)) continue;
                    let o = {
                        delay: i,
                        elapsed: 0,
                        ...s
                    };
                    if (t.shouldReduceMotion && eC.G.has(e) && (o = { ...o,
                            type: !1,
                            delay: 0
                        }), !n.hasAnimated) {
                        let i = t.getProps()[ek];
                        i && (o.elapsed = function(t, e) {
                            let {
                                MotionAppearAnimations: i
                            } = window, n = eR(t, eC.G.has(e) ? "transform" : e), r = i && i.get(n);
                            return r ? (m.Z_.render(() => {
                                try {
                                    r.cancel(), i.delete(n)
                                } catch (t) {}
                            }), r.currentTime || 0) : 0
                        }(i, e))
                    }
                    let a = n.start(tJ(e, n, r, o));
                    eD(u) && (u.add(e), a = a.then(() => u.remove(e))), h.push(a)
                }
                return Promise.all(h).then(() => {
                    a && function(t, e) {
                        let i = eS(t, e),
                            {
                                transitionEnd: n = {},
                                transition: r = {},
                                ...o
                            } = i ? t.makeTargetAnimatable(i, !1) : {};
                        for (let e in o = { ...o,
                                ...n
                            }) {
                            var s;
                            let i = (0, ey.Y)(o[e]);
                            s = e, t.hasValue(s) ? t.getValue(s).set(i) : t.addValue(s, (0, ex.B)(i))
                        }
                    }(t, a)
                })
            }

            function eF(t, e) {
                return t.sortNodePosition(e)
            }
            var eI = i(20330);
            let eU = [o.Animate, o.InView, o.Focus, o.Hover, o.Tap, o.Drag, o.Exit],
                eO = [...eU].reverse(),
                e$ = eU.length;

            function eN(t = !1) {
                return {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }
            let ez = {
                animation: t2(({
                    visualElement: t,
                    animate: e
                }) => {
                    t.animationState || (t.animationState = function(t) {
                        let e = e => Promise.all(e.map(({
                                animation: e,
                                options: i
                            }) => (function(t, e, i = {}) {
                                let n;
                                if (t.notify("AnimationStart", e), Array.isArray(e)) {
                                    let r = e.map(e => eM(t, e, i));
                                    n = Promise.all(r)
                                } else if ("string" == typeof e) n = eM(t, e, i);
                                else {
                                    let r = "function" == typeof e ? eS(t, e, i.custom) : e;
                                    n = ej(t, r, i)
                                }
                                return n.then(() => t.notify("AnimationComplete", e))
                            })(t, e, i))),
                            i = {
                                [o.Animate]: eN(!0),
                                [o.InView]: eN(),
                                [o.Hover]: eN(),
                                [o.Tap]: eN(),
                                [o.Drag]: eN(),
                                [o.Focus]: eN(),
                                [o.Exit]: eN()
                            },
                            n = !0,
                            r = (e, i) => {
                                let n = eS(t, i);
                                if (n) {
                                    let {
                                        transition: t,
                                        transitionEnd: i,
                                        ...r
                                    } = n;
                                    e = { ...e,
                                        ...r,
                                        ...i
                                    }
                                }
                                return e
                            };

                        function s(o, s) {
                            let a = t.getProps(),
                                l = t.getVariantContext(!0) || {},
                                u = [],
                                h = new Set,
                                d = {},
                                c = 1 / 0;
                            for (let e = 0; e < e$; e++) {
                                var p;
                                let m = eO[e],
                                    f = i[m],
                                    v = void 0 !== a[m] ? a[m] : l[m],
                                    g = (0, eI.$)(v),
                                    y = m === s ? f.isActive : null;
                                !1 === y && (c = e);
                                let x = v === l[m] && v !== a[m] && g;
                                if (x && n && t.manuallyAnimateOnMount && (x = !1), f.protectedKeys = { ...d
                                    }, !f.isActive && null === y || !v && !f.prevProp || (0, ep.H)(v) || "boolean" == typeof v) continue;
                                let V = (p = f.prevProp, "string" == typeof v ? v !== p : !!Array.isArray(v) && !ef(v, p)),
                                    P = V || m === s && f.isActive && !x && g || e > c && g,
                                    T = Array.isArray(v) ? v : [v],
                                    b = T.reduce(r, {});
                                !1 === y && (b = {});
                                let {
                                    prevResolvedValues: A = {}
                                } = f, E = { ...A,
                                    ...b
                                }, w = t => {
                                    P = !0, h.delete(t), f.needsAnimating[t] = !0
                                };
                                for (let t in E) {
                                    let e = b[t],
                                        i = A[t];
                                    d.hasOwnProperty(t) || (e !== i ? (0, em.C)(e) && (0, em.C)(i) ? !ef(e, i) || V ? w(t) : f.protectedKeys[t] = !0 : void 0 !== e ? w(t) : h.add(t) : void 0 !== e && h.has(t) ? w(t) : f.protectedKeys[t] = !0)
                                }
                                f.prevProp = v, f.prevResolvedValues = b, f.isActive && (d = { ...d,
                                    ...b
                                }), n && t.blockInitialAnimation && (P = !1), P && !x && u.push(...T.map(t => ({
                                    animation: t,
                                    options: {
                                        type: m,
                                        ...o
                                    }
                                })))
                            }
                            if (h.size) {
                                let e = {};
                                h.forEach(i => {
                                    let n = t.getBaseTarget(i);
                                    void 0 !== n && (e[i] = n)
                                }), u.push({
                                    animation: e
                                })
                            }
                            let m = Boolean(u.length);
                            return n && !1 === a.initial && !t.manuallyAnimateOnMount && (m = !1), n = !1, m ? e(u) : Promise.resolve()
                        }
                        return {
                            animateChanges: s,
                            setActive: function(e, n, r) {
                                var o;
                                if (i[e].isActive === n) return Promise.resolve();
                                null === (o = t.variantChildren) || void 0 === o || o.forEach(t => {
                                    var i;
                                    return null === (i = t.animationState) || void 0 === i ? void 0 : i.setActive(e, n)
                                }), i[e].isActive = n;
                                let a = s(r, e);
                                for (let t in i) i[t].protectedKeys = {};
                                return a
                            },
                            setAnimateFunction: function(i) {
                                e = i(t)
                            },
                            getState: () => i
                        }
                    }(t)), (0, ep.H)(e) && (0, a.useEffect)(() => e.subscribe(t), [e])
                }),
                exit: t2(t => {
                    let {
                        custom: e,
                        visualElement: i
                    } = t, [n, r] = t8(), s = (0, a.useContext)(t7.O);
                    (0, a.useEffect)(() => {
                        i.isPresent = n;
                        let t = i.animationState && i.animationState.setActive(o.Exit, !n, {
                            custom: s && s.custom || e
                        });
                        t && !n && t.then(r)
                    }, [n])
                })
            };

            function eY(t, e, i) {
                return (n, r) => {
                    !(!u(n) || O()) && (t.animationState && t.animationState.setActive(o.Hover, e), i && i(n, r))
                }
            }
            let eG = (t, e) => !!e && (t === e || eG(t, e.parentElement));
            var eH = i(28723),
                eW = i(74963);
            let e_ = new WeakMap,
                eZ = new WeakMap,
                eX = t => {
                    let e = e_.get(t.target);
                    e && e(t)
                },
                eq = t => {
                    t.forEach(eX)
                },
                eK = {
                    some: 0,
                    all: 1
                };

            function eQ(t, e, i, {
                root: n,
                margin: r,
                amount: s = "some",
                once: l
            }) {
                (0, a.useEffect)(() => {
                    if (!t || !i.current) return;
                    let a = {
                            root: null == n ? void 0 : n.current,
                            rootMargin: r,
                            threshold: "number" == typeof s ? s : eK[s]
                        },
                        u = t => {
                            let {
                                isIntersecting: n
                            } = t;
                            if (e.isInView === n || (e.isInView = n, l && !n && e.hasEnteredView)) return;
                            n && (e.hasEnteredView = !0), i.animationState && i.animationState.setActive(o.InView, n);
                            let r = i.getProps(),
                                s = n ? r.onViewportEnter : r.onViewportLeave;
                            s && s(t)
                        };
                    return function(t, e, i) {
                        let n = function({
                            root: t,
                            ...e
                        }) {
                            let i = t || document;
                            eZ.has(i) || eZ.set(i, {});
                            let n = eZ.get(i),
                                r = JSON.stringify(e);
                            return n[r] || (n[r] = new IntersectionObserver(eq, {
                                root: t,
                                ...e
                            })), n[r]
                        }(e);
                        return e_.set(t, i), n.observe(t), () => {
                            e_.delete(t), n.unobserve(t)
                        }
                    }(i.current, a, u)
                }, [t, n, r, s])
            }

            function eJ(t, e, i, {
                fallback: n = !0
            }) {
                (0, a.useEffect)(() => {
                    t && n && ("production" !== eH.O && (0, eW.O)(!1, "IntersectionObserver not available on this device. whileInView animations will trigger on mount."), requestAnimationFrame(() => {
                        e.hasEnteredView = !0;
                        let {
                            onViewportEnter: t
                        } = i.getProps();
                        t && t(null), i.animationState && i.animationState.setActive(o.InView, !0)
                    }))
                }, [t])
            }
            let e0 = {
                inView: t2(function({
                    visualElement: t,
                    whileInView: e,
                    onViewportEnter: i,
                    onViewportLeave: n,
                    viewport: r = {}
                }) {
                    let o = (0, a.useRef)({
                            hasEnteredView: !1,
                            isInView: !1
                        }),
                        s = Boolean(e || i || n);
                    r.once && o.current.hasEnteredView && (s = !1);
                    let l = "undefined" == typeof IntersectionObserver ? eJ : eQ;
                    l(s, o.current, t, r)
                }),
                tap: t2(function({
                    onTap: t,
                    onTapStart: e,
                    onTapCancel: i,
                    whileTap: n,
                    visualElement: r
                }) {
                    let s = (0, a.useRef)(!1),
                        l = (0, a.useRef)(null),
                        u = {
                            passive: !(e || t || i || m)
                        };

                    function h() {
                        l.current && l.current(), l.current = null
                    }

                    function d() {
                        return h(), s.current = !1, r.animationState && r.animationState.setActive(o.Tap, !1), !O()
                    }

                    function c(e, n) {
                        d() && (eG(r.current, e.target) ? t && t(e, n) : i && i(e, n))
                    }

                    function p(t, e) {
                        d() && i && i(t, e)
                    }

                    function m(t, i) {
                        h(), !s.current && (s.current = !0, l.current = (0, S.z)(E(window, "pointerup", c, u), E(window, "pointercancel", p, u)), r.animationState && r.animationState.setActive(o.Tap, !0), e && e(t, i))
                    }
                    w(r, "pointerdown", t || e || i || n ? m : void 0, u), (0, t6.z)(h)
                }),
                focus: t2(function({
                    whileFocus: t,
                    visualElement: e
                }) {
                    let {
                        animationState: i
                    } = e, n = () => {
                        i && i.setActive(o.Focus, !0)
                    }, r = () => {
                        i && i.setActive(o.Focus, !1)
                    };
                    g(e, "focus", t ? n : void 0), g(e, "blur", t ? r : void 0)
                }),
                hover: t2(function({
                    onHoverStart: t,
                    onHoverEnd: e,
                    whileHover: i,
                    visualElement: n
                }) {
                    w(n, "pointerenter", t || i ? eY(n, !0, t) : void 0, {
                        passive: !t
                    }), w(n, "pointerleave", e || i ? eY(n, !1, e) : void 0, {
                        passive: !e
                    })
                })
            };
            var e1 = i(62411),
                e5 = i(91331),
                e3 = i(53921),
                e9 = i(2473);
            let e6 = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y"]),
                e2 = t => e6.has(t),
                e4 = t => Object.keys(t).some(e2),
                e7 = (t, e) => {
                    t.set(e, !1), t.set(e)
                },
                e8 = t => t === eV.Rx || t === tP.px;
            (r = s || (s = {})).width = "width", r.height = "height", r.left = "left", r.right = "right", r.top = "top", r.bottom = "bottom";
            let it = (t, e) => parseFloat(t.split(", ")[e]),
                ie = (t, e) => (i, {
                    transform: n
                }) => {
                    if ("none" === n || !n) return 0;
                    let r = n.match(/^matrix3d\((.+)\)$/);
                    if (r) return it(r[1], e); {
                        let e = n.match(/^matrix\((.+)\)$/);
                        return e ? it(e[1], t) : 0
                    }
                },
                ii = new Set(["x", "y", "z"]),
                ir = eC._.filter(t => !ii.has(t)),
                io = {
                    width: ({
                        x: t
                    }, {
                        paddingLeft: e = "0",
                        paddingRight: i = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                    height: ({
                        y: t
                    }, {
                        paddingTop: e = "0",
                        paddingBottom: i = "0"
                    }) => t.max - t.min - parseFloat(e) - parseFloat(i),
                    top: (t, {
                        top: e
                    }) => parseFloat(e),
                    left: (t, {
                        left: e
                    }) => parseFloat(e),
                    bottom: ({
                        y: t
                    }, {
                        top: e
                    }) => parseFloat(e) + (t.max - t.min),
                    right: ({
                        x: t
                    }, {
                        left: e
                    }) => parseFloat(e) + (t.max - t.min),
                    x: ie(4, 13),
                    y: ie(5, 14)
                },
                is = (t, e, i) => {
                    let n = e.measureViewportBox(),
                        r = e.current,
                        o = getComputedStyle(r),
                        {
                            display: s
                        } = o,
                        a = {};
                    "none" === s && e.setStaticValue("display", t.display || "block"), i.forEach(t => {
                        a[t] = io[t](n, o)
                    }), e.render();
                    let l = e.measureViewportBox();
                    return i.forEach(i => {
                        let n = e.getValue(i);
                        e7(n, a[i]), t[i] = io[i](l, o)
                    }), t
                },
                ia = (t, e, i = {}, n = {}) => {
                    e = { ...e
                    }, n = { ...n
                    };
                    let r = Object.keys(e).filter(e2),
                        o = [],
                        s = !1,
                        a = [];
                    if (r.forEach(r => {
                            let u;
                            let h = t.getValue(r);
                            if (!t.hasValue(r)) return;
                            let d = i[r],
                                c = eb(d),
                                p = e[r];
                            if ((0, em.C)(p)) {
                                let t = p.length,
                                    e = null === p[0] ? 1 : 0;
                                c = eb(d = p[e]);
                                for (let i = e; i < t; i++) u ? (0, l.k)(eb(p[i]) === u, "All keyframes must be of the same type") : (u = eb(p[i]), (0, l.k)(u === c || e8(c) && e8(u), "Keyframes must be of the same dimension as the current value"))
                            } else u = eb(p);
                            if (c !== u) {
                                if (e8(c) && e8(u)) {
                                    let t = h.get();
                                    "string" == typeof t && h.set(parseFloat(t)), "string" == typeof p ? e[r] = parseFloat(p) : Array.isArray(p) && u === tP.px && (e[r] = p.map(parseFloat))
                                } else(null == c ? void 0 : c.transform) && (null == u ? void 0 : u.transform) && (0 === d || 0 === p) ? 0 === d ? h.set(u.transform(d)) : e[r] = c.transform(p) : (s || (o = function(t) {
                                    let e = [];
                                    return ir.forEach(i => {
                                        let n = t.getValue(i);
                                        void 0 !== n && (e.push([i, n.get()]), n.set(i.startsWith("scale") ? 1 : 0))
                                    }), e.length && t.render(), e
                                }(t), s = !0), a.push(r), n[r] = void 0 !== n[r] ? n[r] : e[r], e7(h, p))
                            }
                        }), !a.length) return {
                        target: e,
                        transitionEnd: n
                    }; {
                        let i = a.indexOf("height") >= 0 ? window.pageYOffset : null,
                            r = is(e, t, a);
                        return o.length && o.forEach(([e, i]) => {
                            t.getValue(e).set(i)
                        }), t.render(), y.j && null !== i && window.scrollTo({
                            top: i
                        }), {
                            target: r,
                            transitionEnd: n
                        }
                    }
                },
                il = (t, e, i, n) => {
                    var r, o;
                    let s = function(t, { ...e
                    }, i) {
                        let n = t.current;
                        if (!(n instanceof Element)) return {
                            target: e,
                            transitionEnd: i
                        };
                        for (let r in i && (i = { ...i
                            }), t.values.forEach(t => {
                                let e = t.get();
                                if (!eo(e)) return;
                                let i = ea(e, n);
                                i && t.set(i)
                            }), e) {
                            let t = e[r];
                            if (!eo(t)) continue;
                            let o = ea(t, n);
                            o && (e[r] = o, i && void 0 === i[r] && (i[r] = t))
                        }
                        return {
                            target: e,
                            transitionEnd: i
                        }
                    }(t, e, n);
                    return e = s.target, n = s.transitionEnd, r = e, o = n, e4(r) ? ia(t, r, i, o) : {
                        target: r,
                        transitionEnd: o
                    }
                };
            var iu = i(7397);
            let ih = {
                    current: null
                },
                id = {
                    current: !1
                };
            var ic = i(88069),
                ip = i(23293);
            let im = Object.keys(iu.A),
                iv = im.length,
                ig = ["AnimationStart", "AnimationComplete", "Update", "Unmount", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
            class iy {
                constructor({
                    parent: t,
                    props: e,
                    reducedMotionConfig: i,
                    visualState: n
                }, r = {}) {
                    this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.isPresent = !0, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
                        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
                    }, this.scheduleRender = () => m.Z_.render(this.render, !1, !0);
                    let {
                        latestValues: o,
                        renderState: s
                    } = n;
                    this.latestValues = o, this.baseTarget = { ...o
                    }, this.initialValues = e.initial ? { ...o
                    } : {}, this.renderState = s, this.parent = t, this.props = e, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = i, this.options = r, this.isControllingVariants = (0, ip.G)(e), this.isVariantNode = (0, ip.M)(e), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = Boolean(t && t.current);
                    let {
                        willChange: a,
                        ...l
                    } = this.scrapeMotionValuesFromProps(e);
                    for (let t in l) {
                        let e = l[t];
                        void 0 !== o[t] && (0, eB.i)(e) && (e.set(o[t], !1), eD(a) && a.add(t))
                    }
                }
                scrapeMotionValuesFromProps(t) {
                    return {}
                }
                mount(t) {
                    var e;
                    this.current = t, this.projection && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = null === (e = this.parent) || void 0 === e ? void 0 : e.addVariantChild(this)), this.values.forEach((t, e) => this.bindToMotionValue(e, t)), id.current || function() {
                        if (id.current = !0, y.j) {
                            if (window.matchMedia) {
                                let t = window.matchMedia("(prefers-reduced-motion)"),
                                    e = () => ih.current = t.matches;
                                t.addListener(e), e()
                            } else ih.current = !1
                        }
                    }(), this.shouldReduceMotion = "never" !== this.reducedMotionConfig && ("always" === this.reducedMotionConfig || ih.current), this.parent && this.parent.children.add(this), this.setProps(this.props)
                }
                unmount() {
                    var t, e, i;
                    for (let n in null === (t = this.projection) || void 0 === t || t.unmount(), m.qY.update(this.notifyUpdate), m.qY.render(this.render), this.valueSubscriptions.forEach(t => t()), null === (e = this.removeFromVariantTree) || void 0 === e || e.call(this), null === (i = this.parent) || void 0 === i || i.children.delete(this), this.events) this.events[n].clear();
                    this.current = null
                }
                bindToMotionValue(t, e) {
                    let i = eC.G.has(t),
                        n = e.on("change", e => {
                            this.latestValues[t] = e, this.props.onUpdate && m.Z_.update(this.notifyUpdate, !1, !0), i && this.projection && (this.projection.isTransformDirty = !0)
                        }),
                        r = e.on("renderRequest", this.scheduleRender);
                    this.valueSubscriptions.set(t, () => {
                        n(), r()
                    })
                }
                sortNodePosition(t) {
                    return this.current && this.sortInstanceNodePosition && this.type === t.type ? this.sortInstanceNodePosition(this.current, t.current) : 0
                }
                loadFeatures(t, e, i, n, r, o) {
                    let s = [];
                    "production" !== eH.O && i && e && (0, l.k)(!1, "You have rendered a `motion` component within a `LazyMotion` component. This will break tree shaking. Import and render a `m` component instead.");
                    for (let e = 0; e < iv; e++) {
                        let i = im[e],
                            {
                                isEnabled: n,
                                Component: r
                            } = iu.A[i];
                        n(t) && r && s.push((0, a.createElement)(r, {
                            key: i,
                            ...t,
                            visualElement: this
                        }))
                    }
                    if (!this.projection && r) {
                        this.projection = new r(n, this.latestValues, this.parent && this.parent.projection);
                        let {
                            layoutId: e,
                            layout: i,
                            drag: s,
                            dragConstraints: a,
                            layoutScroll: l
                        } = t;
                        this.projection.setOptions({
                            layoutId: e,
                            layout: i,
                            alwaysMeasureLayout: Boolean(s) || a && (0, $.I)(a),
                            visualElement: this,
                            scheduleRender: () => this.scheduleRender(),
                            animationType: "string" == typeof i ? i : "both",
                            initialPromotionConfig: o,
                            layoutScroll: l
                        })
                    }
                    return s
                }
                triggerBuild() {
                    this.build(this.renderState, this.latestValues, this.options, this.props)
                }
                measureViewportBox() {
                    return this.current ? this.measureInstanceViewportBox(this.current, this.props) : tr()
                }
                getStaticValue(t) {
                    return this.latestValues[t]
                }
                setStaticValue(t, e) {
                    this.latestValues[t] = e
                }
                makeTargetAnimatable(t, e = !0) {
                    return this.makeTargetAnimatableFromInstance(t, this.props, e)
                }
                setProps(t) {
                    (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.props = t;
                    for (let e = 0; e < ig.length; e++) {
                        let i = ig[e];
                        this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
                        let n = t["on" + i];
                        n && (this.propEventSubscriptions[i] = this.on(i, n))
                    }
                    this.prevMotionValues = function(t, e, i) {
                        let {
                            willChange: n
                        } = e;
                        for (let r in e) {
                            let o = e[r],
                                s = i[r];
                            if ((0, eB.i)(o)) t.addValue(r, o), eD(n) && n.add(r);
                            else if ((0, eB.i)(s)) t.addValue(r, (0, ex.B)(o, {
                                owner: t
                            })), eD(n) && n.remove(r);
                            else if (s !== o) {
                                if (t.hasValue(r)) {
                                    let e = t.getValue(r);
                                    e.hasAnimated || e.set(o)
                                } else {
                                    let e = t.getStaticValue(r);
                                    t.addValue(r, (0, ex.B)(void 0 !== e ? e : o))
                                }
                            }
                        }
                        for (let n in i) void 0 === e[n] && t.removeValue(n);
                        return e
                    }(this, this.scrapeMotionValuesFromProps(t), this.prevMotionValues)
                }
                getProps() {
                    return this.props
                }
                getVariant(t) {
                    var e;
                    return null === (e = this.props.variants) || void 0 === e ? void 0 : e[t]
                }
                getDefaultTransition() {
                    return this.props.transition
                }
                getTransformPagePoint() {
                    return this.props.transformPagePoint
                }
                getClosestVariantNode() {
                    var t;
                    return this.isVariantNode ? this : null === (t = this.parent) || void 0 === t ? void 0 : t.getClosestVariantNode()
                }
                getVariantContext(t = !1) {
                    var e, i;
                    if (t) return null === (e = this.parent) || void 0 === e ? void 0 : e.getVariantContext();
                    if (!this.isControllingVariants) {
                        let t = (null === (i = this.parent) || void 0 === i ? void 0 : i.getVariantContext()) || {};
                        return void 0 !== this.props.initial && (t.initial = this.props.initial), t
                    }
                    let n = {};
                    for (let t = 0; t < iV; t++) {
                        let e = ix[t],
                            i = this.props[e];
                        ((0, eI.$)(i) || !1 === i) && (n[e] = i)
                    }
                    return n
                }
                addVariantChild(t) {
                    var e;
                    let i = this.getClosestVariantNode();
                    if (i) return null === (e = i.variantChildren) || void 0 === e || e.add(t), () => i.variantChildren.delete(t)
                }
                addValue(t, e) {
                    this.hasValue(t) && this.removeValue(t), this.values.set(t, e), this.latestValues[t] = e.get(), this.bindToMotionValue(t, e)
                }
                removeValue(t) {
                    var e;
                    this.values.delete(t), null === (e = this.valueSubscriptions.get(t)) || void 0 === e || e(), this.valueSubscriptions.delete(t), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
                }
                hasValue(t) {
                    return this.values.has(t)
                }
                getValue(t, e) {
                    if (this.props.values && this.props.values[t]) return this.props.values[t];
                    let i = this.values.get(t);
                    return void 0 === i && void 0 !== e && (i = (0, ex.B)(e, {
                        owner: this
                    }), this.addValue(t, i)), i
                }
                readValue(t) {
                    return void 0 === this.latestValues[t] && this.current ? this.readValueFromInstance(this.current, t, this.options) : this.latestValues[t]
                }
                setBaseTarget(t, e) {
                    this.baseTarget[t] = e
                }
                getBaseTarget(t) {
                    var e;
                    let {
                        initial: i
                    } = this.props, n = "string" == typeof i || "object" == typeof i ? null === (e = (0, ew.o)(this.props, i)) || void 0 === e ? void 0 : e[t] : void 0;
                    if (i && void 0 !== n) return n;
                    let r = this.getBaseTargetFromProps(this.props, t);
                    return void 0 === r || (0, eB.i)(r) ? void 0 !== this.initialValues[t] && void 0 === n ? void 0 : this.baseTarget[t] : r
                }
                on(t, e) {
                    return this.events[t] || (this.events[t] = new ic.L), this.events[t].add(e)
                }
                notify(t, ...e) {
                    var i;
                    null === (i = this.events[t]) || void 0 === i || i.notify(...e)
                }
            }
            let ix = ["initial", ...eU],
                iV = ix.length;
            class iP extends iy {
                sortInstanceNodePosition(t, e) {
                    return 2 & t.compareDocumentPosition(e) ? 1 : -1
                }
                getBaseTargetFromProps(t, e) {
                    var i;
                    return null === (i = t.style) || void 0 === i ? void 0 : i[e]
                }
                removeValueFromRenderState(t, {
                    vars: e,
                    style: i
                }) {
                    delete e[t], delete i[t]
                }
                makeTargetAnimatableFromInstance({
                    transition: t,
                    transitionEnd: e,
                    ...i
                }, {
                    transformValues: n
                }, r) {
                    let o = function(t, e, i) {
                        var n;
                        let r = {};
                        for (let o in t) {
                            let t = function(t, e) {
                                if (!e) return;
                                let i = e[t] || e.default || e;
                                return i.from
                            }(o, e);
                            r[o] = void 0 !== t ? t : null === (n = i.getValue(o)) || void 0 === n ? void 0 : n.get()
                        }
                        return r
                    }(i, t || {}, this);
                    if (n && (e && (e = n(e)), i && (i = n(i)), o && (o = n(o))), r) {
                        ! function(t, e, i) {
                            var n, r;
                            let o = Object.keys(e).filter(e => !t.hasValue(e)),
                                s = o.length;
                            if (s)
                                for (let a = 0; a < s; a++) {
                                    let s = o[a],
                                        l = e[s],
                                        u = null;
                                    Array.isArray(l) && (u = l[0]), null === u && (u = null !== (r = null !== (n = i[s]) && void 0 !== n ? n : t.readValue(s)) && void 0 !== r ? r : e[s]), null != u && ("string" == typeof u && (ev(u) || eg(u)) ? u = parseFloat(u) : !eE(u) && tM.P.test(l) && (u = tH(s, l)), t.addValue(s, (0, ex.B)(u, {
                                        owner: t
                                    })), void 0 === i[s] && (i[s] = u), null !== u && t.setBaseTarget(s, u))
                                }
                        }(this, i, o);
                        let t = il(this, i, o, e);
                        e = t.transitionEnd, i = t.target
                    }
                    return {
                        transition: t,
                        transitionEnd: e,
                        ...i
                    }
                }
            }
            class iT extends iP {
                readValueFromInstance(t, e) {
                    if (eC.G.has(e)) {
                        let t = tG(e);
                        return t && t.default || 0
                    } {
                        let i = window.getComputedStyle(t),
                            n = ((0, e5.o)(e) ? i.getPropertyValue(e) : i[e]) || 0;
                        return "string" == typeof n ? n.trim() : n
                    }
                }
                measureInstanceViewportBox(t, {
                    transformPagePoint: e
                }) {
                    return tV(t, e)
                }
                build(t, e, i, n) {
                    (0, e1.r)(t, e, i, n.transformTemplate)
                }
                scrapeMotionValuesFromProps(t) {
                    return (0, e3.U)(t)
                }
                renderInstance(t, e, i, n) {
                    (0, e9.N)(t, e, i, n)
                }
            }
            var ib = i(7587),
                iA = i(10658),
                iE = i(55282),
                iw = i(13517),
                iS = i(13336);
            class iC extends iP {
                constructor() {
                    super(...arguments), this.isSVGTag = !1
                }
                getBaseTargetFromProps(t, e) {
                    return t[e]
                }
                readValueFromInstance(t, e) {
                    var i;
                    return eC.G.has(e) ? (null === (i = tG(e)) || void 0 === i ? void 0 : i.default) || 0 : (e = iE.s.has(e) ? e : (0, eL.D)(e), t.getAttribute(e))
                }
                measureInstanceViewportBox() {
                    return tr()
                }
                scrapeMotionValuesFromProps(t) {
                    return (0, ib.U)(t)
                }
                build(t, e, i, n) {
                    (0, iA.i)(t, e, i, this.isSVGTag, n.transformTemplate)
                }
                renderInstance(t, e, i, n) {
                    (0, iw.K)(t, e, i, n)
                }
                mount(t) {
                    this.isSVGTag = (0, iS.a)(t.tagName), super.mount(t)
                }
            }
            var iB = i(75866);
            let iD = (t, e) => (0, iB.q)(t) ? new iC(e, {
                    enableHardwareAcceleration: !1
                }) : new iT(e, {
                    enableHardwareAcceleration: !0
                }),
                iR = {
                    renderer: iD,
                    ...ez,
                    ...e0
                };
            var iL = i(41469),
                ik = i(50065);
            let iM = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
                ij = iM.length,
                iF = t => "string" == typeof t ? parseFloat(t) : t,
                iI = t => "number" == typeof t || tP.px.test(t);

            function iU(t, e) {
                return void 0 !== t[e] ? t[e] : t.borderRadius
            }
            let iO = iN(0, .5, iL.Bn),
                i$ = iN(.5, .95, ik.Z);

            function iN(t, e, i) {
                return n => n < t ? 0 : n > e ? 1 : i((0, N.Y)(t, e, n))
            }

            function iz(t, e) {
                t.min = e.min, t.max = e.max
            }

            function iY(t, e) {
                iz(t.x, e.x), iz(t.y, e.y)
            }

            function iG(t, e, i, n, r) {
                return t -= e, t = n + 1 / i * (t - n), void 0 !== r && (t = n + 1 / r * (t - n)), t
            }

            function iH(t, e, [i, n, r], o, s) {
                ! function(t, e = 0, i = 1, n = .5, r, o = t, s = t) {
                    if (tP.aQ.test(e)) {
                        e = parseFloat(e);
                        let t = (0, z.C)(s.min, s.max, e / 100);
                        e = t - s.min
                    }
                    if ("number" != typeof e) return;
                    let a = (0, z.C)(o.min, o.max, n);
                    t === o && (a -= e), t.min = iG(t.min, e, i, a, r), t.max = iG(t.max, e, i, a, r)
                }(t, e[i], e[n], e[r], e.scale, o, s)
            }
            let iW = ["x", "scaleX", "originX"],
                i_ = ["y", "scaleY", "originY"];

            function iZ(t, e, i, n) {
                iH(t.x, e, iW, null == i ? void 0 : i.x, null == n ? void 0 : n.x), iH(t.y, e, i_, null == i ? void 0 : i.y, null == n ? void 0 : n.y)
            }

            function iX(t) {
                return 0 === t.translate && 1 === t.scale
            }

            function iq(t) {
                return iX(t.x) && iX(t.y)
            }

            function iK(t, e) {
                return t.x.min === e.x.min && t.x.max === e.x.max && t.y.min === e.y.min && t.y.max === e.y.max
            }

            function iQ(t) {
                return Y(t.x) / Y(t.y)
            }
            var iJ = i(44866);
            class i0 {
                constructor() {
                    this.members = []
                }
                add(t) {
                    (0, iJ.y4)(this.members, t), t.scheduleRender()
                }
                remove(t) {
                    if ((0, iJ.cl)(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
                        let t = this.members[this.members.length - 1];
                        t && this.promote(t)
                    }
                }
                relegate(t) {
                    let e;
                    let i = this.members.findIndex(e => t === e);
                    if (0 === i) return !1;
                    for (let t = i; t >= 0; t--) {
                        let i = this.members[t];
                        if (!1 !== i.isPresent) {
                            e = i;
                            break
                        }
                    }
                    return !!e && (this.promote(e), !0)
                }
                promote(t, e) {
                    var i;
                    let n = this.lead;
                    if (t !== n && (this.prevLead = n, this.lead = t, t.show(), n)) {
                        n.instance && n.scheduleRender(), t.scheduleRender(), t.resumeFrom = n, e && (t.resumeFrom.preserveOpacity = !0), n.snapshot && (t.snapshot = n.snapshot, t.snapshot.latestValues = n.animationValues || n.latestValues), (null === (i = t.root) || void 0 === i ? void 0 : i.isUpdating) && (t.isLayoutDirty = !0);
                        let {
                            crossfade: r
                        } = t.options;
                        !1 === r && n.hide()
                    }
                }
                exitAnimationComplete() {
                    this.members.forEach(t => {
                        var e, i, n, r, o;
                        null === (i = (e = t.options).onExitComplete) || void 0 === i || i.call(e), null === (o = null === (n = t.resumingFrom) || void 0 === n ? void 0 : (r = n.options).onExitComplete) || void 0 === o || o.call(r)
                    })
                }
                scheduleRender() {
                    this.members.forEach(t => {
                        t.instance && t.scheduleRender(!1)
                    })
                }
                removeLeadSnapshot() {
                    this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
                }
            }

            function i1(t, e, i) {
                let n = "",
                    r = t.x.translate / e.x,
                    o = t.y.translate / e.y;
                if ((r || o) && (n = `translate3d(${r}px, ${o}px, 0) `), (1 !== e.x || 1 !== e.y) && (n += `scale(${1/e.x}, ${1/e.y}) `), i) {
                    let {
                        rotate: t,
                        rotateX: e,
                        rotateY: r
                    } = i;
                    t && (n += `rotate(${t}deg) `), e && (n += `rotateX(${e}deg) `), r && (n += `rotateY(${r}deg) `)
                }
                let s = t.x.scale * e.x,
                    a = t.y.scale * e.y;
                return (1 !== s || 1 !== a) && (n += `scale(${s}, ${a})`), n || "none"
            }
            let i5 = (t, e) => t.depth - e.depth;
            class i3 {
                constructor() {
                    this.children = [], this.isDirty = !1
                }
                add(t) {
                    (0, iJ.y4)(this.children, t), this.isDirty = !0
                }
                remove(t) {
                    (0, iJ.cl)(this.children, t), this.isDirty = !0
                }
                forEach(t) {
                    this.isDirty && this.children.sort(i5), this.isDirty = !1, this.children.forEach(t)
                }
            }
            var i9 = i(69535);
            let i6 = ["", "X", "Y", "Z"],
                i2 = 0;

            function i4({
                attachResizeListener: t,
                defaultParent: e,
                measureScroll: i,
                checkIsScrollRoot: n,
                resetTransform: r
            }) {
                return class {
                    constructor(t, i = {}, n = null == e ? void 0 : e()) {
                        this.id = i2++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isTransformDirty = !1, this.isProjectionDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.treeScale = {
                            x: 1,
                            y: 1
                        }, this.eventHandlers = new Map, this.potentialNodes = new Map, this.checkUpdateFailed = () => {
                            this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
                        }, this.updateProjection = () => {
                            this.nodes.forEach(nt), this.nodes.forEach(no), this.nodes.forEach(ns)
                        }, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.elementId = t, this.latestValues = i, this.root = n ? n.root || n : this, this.path = n ? [...n.path, n] : [], this.parent = n, this.depth = n ? n.depth + 1 : 0, t && this.root.registerPotentialNode(t, this);
                        for (let t = 0; t < this.path.length; t++) this.path[t].shouldResetTransform = !0;
                        this.root === this && (this.nodes = new i3)
                    }
                    addEventListener(t, e) {
                        return this.eventHandlers.has(t) || this.eventHandlers.set(t, new ic.L), this.eventHandlers.get(t).add(e)
                    }
                    notifyListeners(t, ...e) {
                        let i = this.eventHandlers.get(t);
                        null == i || i.notify(...e)
                    }
                    hasListeners(t) {
                        return this.eventHandlers.has(t)
                    }
                    registerPotentialNode(t, e) {
                        this.potentialNodes.set(t, e)
                    }
                    mount(e, i = !1) {
                        var n;
                        if (this.instance) return;
                        this.isSVG = e instanceof SVGElement && "svg" !== e.tagName, this.instance = e;
                        let {
                            layoutId: r,
                            layout: o,
                            visualElement: s
                        } = this.options;
                        if (s && !s.current && s.mount(e), this.root.nodes.add(this), null === (n = this.parent) || void 0 === n || n.children.add(this), this.elementId && this.root.potentialNodes.delete(this.elementId), i && (o || r) && (this.isLayoutDirty = !0), t) {
                            let i;
                            let n = () => this.root.updateBlockedByResize = !1;
                            t(e, () => {
                                this.root.updateBlockedByResize = !0, i && i(), i = tw(n, 250), ei.V.hasAnimatedSinceResize && (ei.V.hasAnimatedSinceResize = !1, this.nodes.forEach(nr))
                            })
                        }
                        r && this.root.registerSharedNode(r, this), !1 !== this.options.animate && s && (r || o) && this.addEventListener("didUpdate", ({
                            delta: t,
                            hasLayoutChanged: e,
                            hasRelativeTargetChanged: i,
                            layout: n
                        }) => {
                            var r, o, a, l, u;
                            if (this.isTreeAnimationBlocked()) {
                                this.target = void 0, this.relativeTarget = void 0;
                                return
                            }
                            let h = null !== (o = null !== (r = this.options.transition) && void 0 !== r ? r : s.getDefaultTransition()) && void 0 !== o ? o : nc,
                                {
                                    onLayoutAnimationStart: d,
                                    onLayoutAnimationComplete: c
                                } = s.getProps(),
                                p = !this.targetLayout || !iK(this.targetLayout, n) || i,
                                m = !e && i;
                            if ((null === (a = this.resumeFrom) || void 0 === a ? void 0 : a.instance) || m || e && (p || !this.currentAnimation)) {
                                this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(t, m);
                                let e = { ...tZ(h, "layout"),
                                    onPlay: d,
                                    onComplete: c
                                };
                                s.shouldReduceMotion && (e.delay = 0, e.type = !1), this.startAnimation(e)
                            } else e || 0 !== this.animationProgress || nr(this), this.isLead() && (null === (u = (l = this.options).onExitComplete) || void 0 === u || u.call(l));
                            this.targetLayout = n
                        })
                    }
                    unmount() {
                        var t, e;
                        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this), null === (t = this.getStack()) || void 0 === t || t.remove(this), null === (e = this.parent) || void 0 === e || e.children.delete(this), this.instance = void 0, m.qY.preRender(this.updateProjection)
                    }
                    blockUpdate() {
                        this.updateManuallyBlocked = !0
                    }
                    unblockUpdate() {
                        this.updateManuallyBlocked = !1
                    }
                    isUpdateBlocked() {
                        return this.updateManuallyBlocked || this.updateBlockedByResize
                    }
                    isTreeAnimationBlocked() {
                        var t;
                        return this.isAnimationBlocked || (null === (t = this.parent) || void 0 === t ? void 0 : t.isTreeAnimationBlocked()) || !1
                    }
                    startUpdate() {
                        var t;
                        !this.isUpdateBlocked() && (this.isUpdating = !0, null === (t = this.nodes) || void 0 === t || t.forEach(na), this.animationId++)
                    }
                    willUpdate(t = !0) {
                        var e, i, n;
                        if (this.root.isUpdateBlocked()) {
                            null === (i = (e = this.options).onExitComplete) || void 0 === i || i.call(e);
                            return
                        }
                        if (this.root.isUpdating || this.root.startUpdate(), this.isLayoutDirty) return;
                        this.isLayoutDirty = !0;
                        for (let t = 0; t < this.path.length; t++) {
                            let e = this.path[t];
                            e.shouldResetTransform = !0, e.updateScroll("snapshot")
                        }
                        let {
                            layoutId: r,
                            layout: o
                        } = this.options;
                        if (void 0 === r && !o) return;
                        let s = null === (n = this.options.visualElement) || void 0 === n ? void 0 : n.getProps().transformTemplate;
                        this.prevTransformTemplateValue = null == s ? void 0 : s(this.latestValues, ""), this.updateSnapshot(), t && this.notifyListeners("willUpdate")
                    }
                    didUpdate() {
                        let t = this.isUpdateBlocked();
                        if (t) {
                            this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(ni);
                            return
                        }
                        this.isUpdating && (this.isUpdating = !1, this.potentialNodes.size && (this.potentialNodes.forEach(np), this.potentialNodes.clear()), this.nodes.forEach(nn), this.nodes.forEach(i7), this.nodes.forEach(i8), this.clearAllSnapshots(), m.iW.update(), m.iW.preRender(), m.iW.render())
                    }
                    clearAllSnapshots() {
                        this.nodes.forEach(ne), this.sharedNodes.forEach(nl)
                    }
                    scheduleUpdateProjection() {
                        m.Z_.preRender(this.updateProjection, !1, !0)
                    }
                    scheduleCheckAfterUnmount() {
                        m.Z_.postRender(() => {
                            this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
                        })
                    }
                    updateSnapshot() {
                        !this.snapshot && this.instance && (this.snapshot = this.measure())
                    }
                    updateLayout() {
                        var t;
                        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
                        if (this.resumeFrom && !this.resumeFrom.instance)
                            for (let t = 0; t < this.path.length; t++) {
                                let e = this.path[t];
                                e.updateScroll()
                            }
                        let e = this.layout;
                        this.layout = this.measure(!1), this.layoutCorrected = tr(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox), null === (t = this.options.visualElement) || void 0 === t || t.notify("LayoutMeasure", this.layout.layoutBox, null == e ? void 0 : e.layoutBox)
                    }
                    updateScroll(t = "measure") {
                        let e = Boolean(this.options.layoutScroll && this.instance);
                        this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === t && (e = !1), e && (this.scroll = {
                            animationId: this.root.animationId,
                            phase: t,
                            isRoot: n(this.instance),
                            offset: i(this.instance)
                        })
                    }
                    resetTransform() {
                        var t;
                        if (!r) return;
                        let e = this.isLayoutDirty || this.shouldResetTransform,
                            i = this.projectionDelta && !iq(this.projectionDelta),
                            n = null === (t = this.options.visualElement) || void 0 === t ? void 0 : t.getProps().transformTemplate,
                            o = null == n ? void 0 : n(this.latestValues, ""),
                            s = o !== this.prevTransformTemplateValue;
                        e && (i || tu(this.latestValues) || s) && (r(this.instance, o), this.shouldResetTransform = !1, this.scheduleRender())
                    }
                    measure(t = !0) {
                        var e;
                        let i = this.measurePageBox(),
                            n = this.removeElementScroll(i);
                        return t && (n = this.removeTransform(n)), nm((e = n).x), nm(e.y), {
                            animationId: this.root.animationId,
                            measuredBox: i,
                            layoutBox: n,
                            latestValues: {},
                            source: this.id
                        }
                    }
                    measurePageBox() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return tr();
                        let e = t.measureViewportBox(),
                            {
                                scroll: i
                            } = this.root;
                        return i && (tf(e.x, i.offset.x), tf(e.y, i.offset.y)), e
                    }
                    removeElementScroll(t) {
                        let e = tr();
                        iY(e, t);
                        for (let i = 0; i < this.path.length; i++) {
                            let n = this.path[i],
                                {
                                    scroll: r,
                                    options: o
                                } = n;
                            if (n !== this.root && r && o.layoutScroll) {
                                if (r.isRoot) {
                                    iY(e, t);
                                    let {
                                        scroll: i
                                    } = this.root;
                                    i && (tf(e.x, -i.offset.x), tf(e.y, -i.offset.y))
                                }
                                tf(e.x, r.offset.x), tf(e.y, r.offset.y)
                            }
                        }
                        return e
                    }
                    applyTransform(t, e = !1) {
                        let i = tr();
                        iY(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            !e && n.options.layoutScroll && n.scroll && n !== n.root && tx(i, {
                                x: -n.scroll.offset.x,
                                y: -n.scroll.offset.y
                            }), tu(n.latestValues) && tx(i, n.latestValues)
                        }
                        return tu(this.latestValues) && tx(i, this.latestValues), i
                    }
                    removeTransform(t) {
                        var e;
                        let i = tr();
                        iY(i, t);
                        for (let t = 0; t < this.path.length; t++) {
                            let n = this.path[t];
                            if (!n.instance || !tu(n.latestValues)) continue;
                            tl(n.latestValues) && n.updateSnapshot();
                            let r = tr(),
                                o = n.measurePageBox();
                            iY(r, o), iZ(i, n.latestValues, null === (e = n.snapshot) || void 0 === e ? void 0 : e.layoutBox, r)
                        }
                        return tu(this.latestValues) && iZ(i, this.latestValues), i
                    }
                    setTargetDelta(t) {
                        this.targetDelta = t, this.isProjectionDirty = !0, this.root.scheduleUpdateProjection()
                    }
                    setOptions(t) {
                        this.options = { ...this.options,
                            ...t,
                            crossfade: void 0 === t.crossfade || t.crossfade
                        }
                    }
                    clearMeasurements() {
                        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
                    }
                    resolveTargetDelta() {
                        var t, e, i, n;
                        let r = this.getLead();
                        if (this.isProjectionDirty || (this.isProjectionDirty = r.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = r.isTransformDirty), !this.isProjectionDirty && !this.attemptToResolveRelativeTarget) return;
                        let {
                            layout: o,
                            layoutId: s
                        } = this.options;
                        if (this.layout && (o || s)) {
                            if (!this.targetDelta && !this.relativeTarget) {
                                let t = this.getClosestProjectingParent();
                                t && t.layout ? (this.relativeParent = t, this.relativeTarget = tr(), this.relativeTargetOrigin = tr(), X(this.relativeTargetOrigin, this.layout.layoutBox, t.layout.layoutBox), iY(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                            if ((this.relativeTarget || this.targetDelta) && ((this.target || (this.target = tr(), this.targetWithTransforms = tr()), this.relativeTarget && this.relativeTargetOrigin && (null === (t = this.relativeParent) || void 0 === t ? void 0 : t.target)) ? (e = this.target, i = this.relativeTarget, n = this.relativeParent.target, _(e.x, i.x, n.x), _(e.y, i.y, n.y)) : this.targetDelta ? (Boolean(this.resumingFrom) ? this.target = this.applyTransform(this.layout.layoutBox) : iY(this.target, this.layout.layoutBox), tp(this.target, this.targetDelta)) : iY(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget)) {
                                this.attemptToResolveRelativeTarget = !1;
                                let t = this.getClosestProjectingParent();
                                t && Boolean(t.resumingFrom) === Boolean(this.resumingFrom) && !t.options.layoutScroll && t.target ? (this.relativeParent = t, this.relativeTarget = tr(), this.relativeTargetOrigin = tr(), X(this.relativeTargetOrigin, this.target, t.target), iY(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                            }
                        }
                    }
                    getClosestProjectingParent() {
                        if (!(!this.parent || tl(this.parent.latestValues) || th(this.parent.latestValues))) return (this.parent.relativeTarget || this.parent.targetDelta) && this.parent.layout ? this.parent : this.parent.getClosestProjectingParent()
                    }
                    calcProjection() {
                        var t;
                        let {
                            isProjectionDirty: e,
                            isTransformDirty: i
                        } = this;
                        this.isProjectionDirty = this.isTransformDirty = !1;
                        let n = this.getLead(),
                            r = Boolean(this.resumingFrom) || this !== n,
                            o = !0;
                        if (e && (o = !1), r && i && (o = !1), o) return;
                        let {
                            layout: s,
                            layoutId: a
                        } = this.options;
                        if (this.isTreeAnimating = Boolean((null === (t = this.parent) || void 0 === t ? void 0 : t.isTreeAnimating) || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(s || a)) return;
                        iY(this.layoutCorrected, this.layout.layoutBox),
                            function(t, e, i, n = !1) {
                                var r, o;
                                let s, a;
                                let l = i.length;
                                if (l) {
                                    e.x = e.y = 1;
                                    for (let u = 0; u < l; u++) a = (s = i[u]).projectionDelta, (null === (o = null === (r = s.instance) || void 0 === r ? void 0 : r.style) || void 0 === o ? void 0 : o.display) !== "contents" && (n && s.options.layoutScroll && s.scroll && s !== s.root && tx(t, {
                                        x: -s.scroll.offset.x,
                                        y: -s.scroll.offset.y
                                    }), a && (e.x *= a.x.scale, e.y *= a.y.scale, tp(t, a)), n && tu(s.latestValues) && tx(t, s.latestValues));
                                    e.x = tm(e.x), e.y = tm(e.y)
                                }
                            }(this.layoutCorrected, this.treeScale, this.path, r);
                        let {
                            target: l
                        } = n;
                        if (!l) return;
                        this.projectionDelta || (this.projectionDelta = ti(), this.projectionDeltaWithTransform = ti());
                        let u = this.treeScale.x,
                            h = this.treeScale.y,
                            d = this.projectionTransform;
                        W(this.projectionDelta, this.layoutCorrected, l, this.latestValues), this.projectionTransform = i1(this.projectionDelta, this.treeScale), (this.projectionTransform !== d || this.treeScale.x !== u || this.treeScale.y !== h) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", l))
                    }
                    hide() {
                        this.isVisible = !1
                    }
                    show() {
                        this.isVisible = !0
                    }
                    scheduleRender(t = !0) {
                        var e, i, n;
                        null === (i = (e = this.options).scheduleRender) || void 0 === i || i.call(e), t && (null === (n = this.getStack()) || void 0 === n || n.scheduleRender()), this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
                    }
                    setAnimationOrigin(t, e = !1) {
                        var i, n;
                        let r = this.snapshot,
                            o = (null == r ? void 0 : r.latestValues) || {},
                            s = { ...this.latestValues
                            },
                            a = ti();
                        this.relativeTarget = this.relativeTargetOrigin = void 0, this.attemptToResolveRelativeTarget = !e;
                        let l = tr(),
                            u = (null == r ? void 0 : r.source) !== (null === (i = this.layout) || void 0 === i ? void 0 : i.source),
                            h = 1 >= ((null === (n = this.getStack()) || void 0 === n ? void 0 : n.members.length) || 0),
                            d = Boolean(u && !h && !0 === this.options.crossfade && !this.path.some(nd));
                        this.animationProgress = 0, this.mixTargetDelta = e => {
                            var i, n, r;
                            let c = e / 1e3;
                            nu(a.x, t.x, c), nu(a.y, t.y, c), this.setTargetDelta(a), this.relativeTarget && this.relativeTargetOrigin && this.layout && (null === (i = this.relativeParent) || void 0 === i ? void 0 : i.layout) && (X(l, this.layout.layoutBox, this.relativeParent.layout.layoutBox), n = this.relativeTarget, r = this.relativeTargetOrigin, nh(n.x, r.x, l.x, c), nh(n.y, r.y, l.y, c)), u && (this.animationValues = s, function(t, e, i, n, r, o) {
                                r ? (t.opacity = (0, z.C)(0, void 0 !== i.opacity ? i.opacity : 1, iO(n)), t.opacityExit = (0, z.C)(void 0 !== e.opacity ? e.opacity : 1, 0, i$(n))) : o && (t.opacity = (0, z.C)(void 0 !== e.opacity ? e.opacity : 1, void 0 !== i.opacity ? i.opacity : 1, n));
                                for (let r = 0; r < ij; r++) {
                                    let o = `border${iM[r]}Radius`,
                                        s = iU(e, o),
                                        a = iU(i, o);
                                    if (void 0 === s && void 0 === a) continue;
                                    s || (s = 0), a || (a = 0);
                                    let l = 0 === s || 0 === a || iI(s) === iI(a);
                                    l ? (t[o] = Math.max((0, z.C)(iF(s), iF(a), n), 0), (tP.aQ.test(a) || tP.aQ.test(s)) && (t[o] += "%")) : t[o] = a
                                }(e.rotate || i.rotate) && (t.rotate = (0, z.C)(e.rotate || 0, i.rotate || 0, n))
                            }(s, o, this.latestValues, c, d, h)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = c
                        }, this.mixTargetDelta(0)
                    }
                    startAnimation(t) {
                        var e, i;
                        this.notifyListeners("animationStart"), null === (e = this.currentAnimation) || void 0 === e || e.stop(), this.resumingFrom && (null === (i = this.resumingFrom.currentAnimation) || void 0 === i || i.stop()), this.pendingAnimation && (m.qY.update(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = m.Z_.update(() => {
                            ei.V.hasAnimatedSinceResize = !0, this.currentAnimation = function(t, e, i = {}) {
                                let n = (0, eB.i)(t) ? t : (0, ex.B)(t);
                                return n.start(tJ("", n, 1e3, i)), {
                                    stop: () => n.stop(),
                                    isAnimating: () => n.isAnimating()
                                }
                            }(0, 0, { ...t,
                                onUpdate: e => {
                                    var i;
                                    this.mixTargetDelta(e), null === (i = t.onUpdate) || void 0 === i || i.call(t, e)
                                },
                                onComplete: () => {
                                    var e;
                                    null === (e = t.onComplete) || void 0 === e || e.call(t), this.completeAnimation()
                                }
                            }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
                        })
                    }
                    completeAnimation() {
                        var t;
                        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0), null === (t = this.getStack()) || void 0 === t || t.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
                    }
                    finishAnimation() {
                        var t;
                        this.currentAnimation && (null === (t = this.mixTargetDelta) || void 0 === t || t.call(this, 1e3), this.currentAnimation.stop()), this.completeAnimation()
                    }
                    applyTransformsToTarget() {
                        let t = this.getLead(),
                            {
                                targetWithTransforms: e,
                                target: i,
                                layout: n,
                                latestValues: r
                            } = t;
                        if (e && i && n) {
                            if (this !== t && this.layout && n && nf(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
                                i = this.target || tr();
                                let e = Y(this.layout.layoutBox.x);
                                i.x.min = t.target.x.min, i.x.max = i.x.min + e;
                                let n = Y(this.layout.layoutBox.y);
                                i.y.min = t.target.y.min, i.y.max = i.y.min + n
                            }
                            iY(e, i), tx(e, r), W(this.projectionDeltaWithTransform, this.layoutCorrected, e, r)
                        }
                    }
                    registerSharedNode(t, e) {
                        var i, n, r;
                        this.sharedNodes.has(t) || this.sharedNodes.set(t, new i0);
                        let o = this.sharedNodes.get(t);
                        o.add(e), e.promote({
                            transition: null === (i = e.options.initialPromotionConfig) || void 0 === i ? void 0 : i.transition,
                            preserveFollowOpacity: null === (r = null === (n = e.options.initialPromotionConfig) || void 0 === n ? void 0 : n.shouldPreserveFollowOpacity) || void 0 === r ? void 0 : r.call(n, e)
                        })
                    }
                    isLead() {
                        let t = this.getStack();
                        return !t || t.lead === this
                    }
                    getLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e && (null === (t = this.getStack()) || void 0 === t ? void 0 : t.lead) || this
                    }
                    getPrevLead() {
                        var t;
                        let {
                            layoutId: e
                        } = this.options;
                        return e ? null === (t = this.getStack()) || void 0 === t ? void 0 : t.prevLead : void 0
                    }
                    getStack() {
                        let {
                            layoutId: t
                        } = this.options;
                        if (t) return this.root.sharedNodes.get(t)
                    }
                    promote({
                        needsReset: t,
                        transition: e,
                        preserveFollowOpacity: i
                    } = {}) {
                        let n = this.getStack();
                        n && n.promote(this, i), t && (this.projectionDelta = void 0, this.needsReset = !0), e && this.setOptions({
                            transition: e
                        })
                    }
                    relegate() {
                        let t = this.getStack();
                        return !!t && t.relegate(this)
                    }
                    resetRotation() {
                        let {
                            visualElement: t
                        } = this.options;
                        if (!t) return;
                        let e = !1,
                            {
                                latestValues: i
                            } = t;
                        if ((i.rotate || i.rotateX || i.rotateY || i.rotateZ) && (e = !0), !e) return;
                        let n = {};
                        for (let e = 0; e < i6.length; e++) {
                            let r = "rotate" + i6[e];
                            i[r] && (n[r] = i[r], t.setStaticValue(r, 0))
                        }
                        for (let e in null == t || t.render(), n) t.setStaticValue(e, n[e]);
                        t.scheduleRender()
                    }
                    getProjectionStyles(t = {}) {
                        var e, i, n;
                        let r = {};
                        if (!this.instance || this.isSVG) return r;
                        if (!this.isVisible) return {
                            visibility: "hidden"
                        };
                        r.visibility = "";
                        let o = null === (e = this.options.visualElement) || void 0 === e ? void 0 : e.getProps().transformTemplate;
                        if (this.needsReset) return this.needsReset = !1, r.opacity = "", r.pointerEvents = (0, i9.b)(t.pointerEvents) || "", r.transform = o ? o(this.latestValues, "") : "none", r;
                        let s = this.getLead();
                        if (!this.projectionDelta || !this.layout || !s.target) {
                            let e = {};
                            return this.options.layoutId && (e.opacity = void 0 !== this.latestValues.opacity ? this.latestValues.opacity : 1, e.pointerEvents = (0, i9.b)(t.pointerEvents) || ""), this.hasProjected && !tu(this.latestValues) && (e.transform = o ? o({}, "") : "none", this.hasProjected = !1), e
                        }
                        let a = s.animationValues || s.latestValues;
                        this.applyTransformsToTarget(), r.transform = i1(this.projectionDeltaWithTransform, this.treeScale, a), o && (r.transform = o(a, r.transform));
                        let {
                            x: l,
                            y: u
                        } = this.projectionDelta;
                        for (let t in r.transformOrigin = `${100*l.origin}% ${100*u.origin}% 0`, s.animationValues ? r.opacity = s === this ? null !== (n = null !== (i = a.opacity) && void 0 !== i ? i : this.latestValues.opacity) && void 0 !== n ? n : 1 : this.preserveOpacity ? this.latestValues.opacity : a.opacityExit : r.opacity = s === this ? void 0 !== a.opacity ? a.opacity : "" : void 0 !== a.opacityExit ? a.opacityExit : 0, eh.P) {
                            if (void 0 === a[t]) continue;
                            let {
                                correct: e,
                                applyTo: i
                            } = eh.P[t], n = e(a[t], s);
                            if (i) {
                                let t = i.length;
                                for (let e = 0; e < t; e++) r[i[e]] = n
                            } else r[t] = n
                        }
                        return this.options.layoutId && (r.pointerEvents = s === this ? (0, i9.b)(t.pointerEvents) || "" : "none"), r
                    }
                    clearSnapshot() {
                        this.resumeFrom = this.snapshot = void 0
                    }
                    resetTree() {
                        this.root.nodes.forEach(t => {
                            var e;
                            return null === (e = t.currentAnimation) || void 0 === e ? void 0 : e.stop()
                        }), this.root.nodes.forEach(ni), this.root.sharedNodes.clear()
                    }
                }
            }

            function i7(t) {
                t.updateLayout()
            }

            function i8(t) {
                var e, i, n;
                let r = (null === (e = t.resumeFrom) || void 0 === e ? void 0 : e.snapshot) || t.snapshot;
                if (t.isLead() && t.layout && r && t.hasListeners("didUpdate")) {
                    let {
                        layoutBox: e,
                        measuredBox: i
                    } = t.layout, {
                        animationType: n
                    } = t.options, o = r.source !== t.layout.source;
                    "size" === n ? to(t => {
                        let i = o ? r.measuredBox[t] : r.layoutBox[t],
                            n = Y(i);
                        i.min = e[t].min, i.max = i.min + n
                    }) : nf(n, r.layoutBox, e) && to(t => {
                        let i = o ? r.measuredBox[t] : r.layoutBox[t],
                            n = Y(e[t]);
                        i.max = i.min + n
                    });
                    let s = ti();
                    W(s, e, r.layoutBox);
                    let a = ti();
                    o ? W(a, t.applyTransform(i, !0), r.measuredBox) : W(a, e, r.layoutBox);
                    let l = !iq(s),
                        u = !1;
                    if (!t.resumeFrom) {
                        let i = t.getClosestProjectingParent();
                        if (i && !i.resumeFrom) {
                            let {
                                snapshot: t,
                                layout: n
                            } = i;
                            if (t && n) {
                                let i = tr();
                                X(i, r.layoutBox, t.layoutBox);
                                let o = tr();
                                X(o, e, n.layoutBox), iK(i, o) || (u = !0)
                            }
                        }
                    }
                    t.notifyListeners("didUpdate", {
                        layout: e,
                        snapshot: r,
                        delta: a,
                        layoutDelta: s,
                        hasLayoutChanged: l,
                        hasRelativeTargetChanged: u
                    })
                } else t.isLead() && (null === (n = (i = t.options).onExitComplete) || void 0 === n || n.call(i));
                t.options.transition = void 0
            }

            function nt(t) {
                t.isProjectionDirty || (t.isProjectionDirty = Boolean(t.parent && t.parent.isProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = Boolean(t.parent && t.parent.isTransformDirty))
            }

            function ne(t) {
                t.clearSnapshot()
            }

            function ni(t) {
                t.clearMeasurements()
            }

            function nn(t) {
                let {
                    visualElement: e
                } = t.options;
                (null == e ? void 0 : e.getProps().onBeforeLayoutMeasure) && e.notify("BeforeLayoutMeasure"), t.resetTransform()
            }

            function nr(t) {
                t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0
            }

            function no(t) {
                t.resolveTargetDelta()
            }

            function ns(t) {
                t.calcProjection()
            }

            function na(t) {
                t.resetRotation()
            }

            function nl(t) {
                t.removeLeadSnapshot()
            }

            function nu(t, e, i) {
                t.translate = (0, z.C)(e.translate, 0, i), t.scale = (0, z.C)(e.scale, 1, i), t.origin = e.origin, t.originPoint = e.originPoint
            }

            function nh(t, e, i, n) {
                t.min = (0, z.C)(e.min, i.min, n), t.max = (0, z.C)(e.max, i.max, n)
            }

            function nd(t) {
                return t.animationValues && void 0 !== t.animationValues.opacityExit
            }
            let nc = {
                duration: .45,
                ease: [.4, 0, .1, 1]
            };

            function np(t, e) {
                let i = t.root;
                for (let e = t.path.length - 1; e >= 0; e--)
                    if (Boolean(t.path[e].instance)) {
                        i = t.path[e];
                        break
                    }
                let n = i && i !== t.root ? i.instance : document,
                    r = n.querySelector(`[data-projection-id="${e}"]`);
                r && t.mount(r, !0)
            }

            function nm(t) {
                t.min = Math.round(t.min), t.max = Math.round(t.max)
            }

            function nf(t, e, i) {
                return "position" === t || "preserve-aspect" === t && !G(iQ(e), iQ(i), .2)
            }
            let nv = i4({
                    attachResizeListener: (t, e) => v(t, "resize", e),
                    measureScroll: () => ({
                        x: document.documentElement.scrollLeft || document.body.scrollLeft,
                        y: document.documentElement.scrollTop || document.body.scrollTop
                    }),
                    checkIsScrollRoot: () => !0
                }),
                ng = {
                    current: void 0
                },
                ny = i4({
                    measureScroll: t => ({
                        x: t.scrollLeft,
                        y: t.scrollTop
                    }),
                    defaultParent: () => {
                        if (!ng.current) {
                            let t = new nv(0, {});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), ng.current = t
                        }
                        return ng.current
                    },
                    resetTransform: (t, e) => {
                        t.style.transform = void 0 !== e ? e : "none"
                    },
                    checkIsScrollRoot: t => Boolean("fixed" === window.getComputedStyle(t).position)
                }),
                nx = { ...iR,
                    ...t4,
                    measureLayout: function(t) {
                        let [e, i] = t8(), n = (0, a.useContext)(et.p);
                        return a.createElement(ed, { ...t,
                            layoutGroup: n,
                            switchLayoutGroup: (0, a.useContext)(ee.g),
                            isPresent: e,
                            safeToRemove: i
                        })
                    },
                    projectionNodeConstructor: ny
                }
        }
    }
]);